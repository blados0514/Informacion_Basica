--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type TTB_ARCHIVO_TEXTO
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CORRECCION_DATOS"."TTB_ARCHIVO_TEXTO" AS TABLE OF VARCHAR2(4000);

/
--------------------------------------------------------
--  DDL for Trigger PROPIETARIOS_SAP2
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."PROPIETARIOS_SAP2" 
BEFORE INSERT ON PROPIETARIOS_SAP_19112015 

FOR EACH ROW
DECLARE

  v_id_documento NUMBER;

BEGIN

  IF :NEW.DOCUMENTO_SAP = 'CC' THEN
      :NEW.DOCUMENTO_QX  := 1;
  ELSIF :NEW.DOCUMENTO_SAP  = 'NIT' THEN
      :NEW.DOCUMENTO_QX  := 2;  
  ELSIF :NEW.DOCUMENTO_SAP  = 'NUIP' THEN
      :NEW.DOCUMENTO_QX  := 11;  
  ELSIF :NEW.DOCUMENTO_SAP  = 'CE' THEN
      :NEW.DOCUMENTO_QX  := 3;  
  ELSIF :NEW.DOCUMENTO_SAP  = 'TI' THEN
      :NEW.DOCUMENTO_QX  := 4;  
  ELSIF :NEW.DOCUMENTO_SAP  = 'PASAP' THEN
      :NEW.DOCUMENTO_QX  := 6;
      ELSE
      :NEW.DOCUMENTO_QX  := 0;
  END IF;
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."PROPIETARIOS_SAP2" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_CONSOLIDADO_IC_SAP
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_CONSOLIDADO_IC_SAP" 
BEFORE INSERT ON CONSOLIDADO_IC_SAP_14092016 
FOR EACH ROW
DECLARE

V_TIPO_DOC VARCHAR2(4);

BEGIN

BEGIN
 SELECT MIN_DOCUMENTO INTO V_TIPO_DOC FROM QUIPUX.TIPO_DOCUMENTO WHERE ABREV_DOCUMENTO = :NEW.DOCUMENTO;
 
 :NEW.DOCUMENTO2 := V_TIPO_DOC;

EXCEPTION
  WHEN OTHERS THEN
   :NEW.DOCUMENTO2 := :NEW.DOCUMENTO;
  END;
  
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_CONSOLIDADO_IC_SAP" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_DS_TMP_CONTRIBUYENTES2
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_DS_TMP_CONTRIBUYENTES2" 
BEFORE INSERT ON DS_TMP_CONTRIBUYENTES2 

FOR EACH ROW
DECLARE
  v_id_documento NUMBER;  
BEGIN
    BEGIN
          SELECT MIN(ID_DOCUMENTO)
          INTO V_ID_DOCUMENTO
          FROM QUIPUX.TIPO_DOCUMENTO
          WHERE MIN_DOCUMENTO = UPPER(:NEW.ID_DOCUMENTO) AND
                ID_DOCUMENTO >= 0;
        EXCEPTION
        WHEN OTHERS THEN
          V_ID_DOCUMENTO := 0;
        END;
        
        IF V_ID_DOCUMENTO > 0 THEN
          :NEW.ID_DOCUMENTO := TO_CHAR(V_ID_DOCUMENTO);
        END IF;
        
        SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_DOCUMENTO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
          INTO :NEW.ID_DOCUMENTO FROM DUAL;
            
        IF NOT V_ID_DOCUMENTO = 6 THEN    
          SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_USUARIO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
            INTO :NEW.ID_USUARIO FROM DUAL;
        END IF;   
        
        :NEW.ID := :NEW.ID_USUARIO || '-' || :NEW.ID_DOCUMENTO || '-' || :NEW.ID_DIRECCION;
  
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_DS_TMP_CONTRIBUYENTES2" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_EXISTE_PRD
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_EXISTE_PRD" 

BEFORE INSERT ON CORRECCION_DATOS.EXISTE_PRD 

FOR EACH ROW
DECLARE

  v_id_documento NUMBER;

BEGIN

  IF :NEW.VALOR2 = 'CC' THEN
      :NEW.VALOR2 := 1;
  ELSIF :NEW.VALOR2 = 'NIT' THEN
      :NEW.VALOR2 := 2;  
  ELSIF :NEW.VALOR2 = 'NUIP' THEN
      :NEW.VALOR2 := 11;  
  ELSIF :NEW.VALOR2 = 'CE' THEN
      :NEW.VALOR2 := 3;  
  ELSIF :NEW.VALOR2 = 'TI' THEN
      :NEW.VALOR2 := 4;  
  ELSIF :NEW.VALOR2 = 'PASAP' THEN
      :NEW.VALOR2 := 6; 
  END IF;
  
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_EXISTE_PRD" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_FINDSUMA
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_FINDSUMA" 
BEFORE INSERT OR UPDATE ON FINDSUMATABLE 
FOR EACH ROW
DECLARE
BEGIN

IF (:NEW.DATO IS NOT NULL) THEN
:new.RESULT1:=FINDSUMA(:new.dato);

ELSIF (:NEW.DATO2 IS NOT NULL) THEN

:new.RESULT1:=FT_VICTOR(:new.dato2);

END IF;

END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_FINDSUMA" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_INFO_CONTRIBUYENTES
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_INFO_CONTRIBUYENTES" 
BEFORE INSERT ON TMP_INF_CONTRIBUYENTES 

FOR EACH ROW
DECLARE

V_TIPO_DOC VARCHAR2(4);

BEGIN

 SELECT MIN_DOCUMENTO INTO V_TIPO_DOC FROM QUIPUX.TIPO_DOCUMENTO WHERE ABREV_DOCUMENTO = :NEW.TIPO_DOC;
 
 :NEW.TIPO_DOC := V_TIPO_DOC;
  
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_INFO_CONTRIBUYENTES" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_PLANTILLA_PERSONAS_Q
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_PLANTILLA_PERSONAS_Q" 
--BEFORE INSERT OR UPDATE ON CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q 
BEFORE INSERT ON CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q 

FOR EACH ROW
DECLARE

  v_id_documento NUMBER;

BEGIN
/*
  IF :NEW.CLASE_IDENTIFICACION = 1 THEN
      :NEW.CLASE_IDENTIFICACION := 'CC';
  ELSIF :NEW.CLASE_IDENTIFICACION  = 2 THEN
      :NEW.CLASE_IDENTIFICACION  := 'NIT';  
  ELSIF :NEW.CLASE_IDENTIFICACION  = 11 THEN
      :NEW.CLASE_IDENTIFICACION := 'NUIP';  
  ELSIF :NEW.CLASE_IDENTIFICACION  = 3 THEN
      :NEW.CLASE_IDENTIFICACION := 'CE';  
  ELSIF :NEW.CLASE_IDENTIFICACION  = 4 THEN
      :NEW.CLASE_IDENTIFICACION := 'TI';  
  ELSIF :NEW.CLASE_IDENTIFICACION  = 6 THEN
      :NEW.CLASE_IDENTIFICACION  := 'PASAP';
      ELSE
      :NEW.CLASE_IDENTIFICACION  := 0;
  END IF;*/
  null;
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_PLANTILLA_PERSONAS_Q" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_PROPIETARIOS_SAP
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_PROPIETARIOS_SAP" 
BEFORE UPDATE ON CORRECCION_DATOS.PROPIETARIOS_SAP_30072015
--BEFORE INSERT ON CORRECCION_DATOS.PROPIETARIOS_SAP_30072015

FOR EACH ROW
DECLARE

  v_id_documento NUMBER;

BEGIN

  IF :NEW.DOCUMENTO_QX = 'CC' THEN
      :NEW.DOCUMENTO_QX  := 1;
  ELSIF :NEW.DOCUMENTO_QX  = 'NIT' THEN
      :NEW.DOCUMENTO_QX  := 2;  
  ELSIF :NEW.DOCUMENTO_QX  = 'NUIP' THEN
      :NEW.DOCUMENTO_QX  := 11;  
  ELSIF :NEW.DOCUMENTO_QX  = 'CE' THEN
      :NEW.DOCUMENTO_QX  := 3;  
  ELSIF :NEW.DOCUMENTO_QX  = 'TI' THEN
      :NEW.DOCUMENTO_QX  := 4;  
  ELSIF :NEW.DOCUMENTO_QX  = 'PASAP' THEN
      :NEW.DOCUMENTO_QX  := 6;
      ELSE
      :NEW.DOCUMENTO_QX  := 0;
  END IF;
  
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_PROPIETARIOS_SAP" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_TMP_PLANTILLA_IC
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "CORRECCION_DATOS"."TRG_TMP_PLANTILLA_IC" 
BEFORE INSERT ON TMP_PLANTILLA_IC 
FOR EACH ROW
DECLARE

V_TIPO_DOC VARCHAR2(5);

BEGIN
  SELECT ABREV_DOCUMENTO INTO V_TIPO_DOC
  FROM QUIPUX.TIPO_DOCUMENTO WHERE MIN_DOCUMENTO = :NEW.DOCUMENTO;
  
  :NEW.DOCUMENTO_SAP := V_TIPO_DOC;
END;
/
ALTER TRIGGER "CORRECCION_DATOS"."TRG_TMP_PLANTILLA_IC" ENABLE;
--------------------------------------------------------
--  DDL for Procedure EXERCISE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."EXERCISE" AS 

--index1 number := 0;
--index2 number :=0;
EncontrarPotencia number:= 31;
 Suma number :=0;
 bandera number := 0;
 numeros varchar2(4000);

begin

for index1 in 0 .. EncontrarPotencia
loop
numeros := null;
suma :=0;
  for index2 in 0 .. EncontrarPotencia
  loop
     suma := suma + (index1**index2);
     numeros := numeros || ' '|| index1 || '**' ||index2 ;
     
      if suma>EncontrarPotencia then
          exit;
      elsif suma = EncontrarPotencia then
        SYS.DBMS_OUTPUT.put_line(numeros);
        --index1 := 0;
        bandera :=1;
        exit;        
      end if;
      
  end loop;
  --if bandera =1 then  exit; end if;
end loop;

if bandera = 0 then
   SYS.DBMS_OUTPUT.put_line('No se encotro valor.');
end if;

END EXERCISE;

/
--------------------------------------------------------
--  DDL for Procedure IF_ESTAND_DIR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."IF_ESTAND_DIR" AS 


V_ID_REG VARCHAR2(50);
V_NUEVA_DIRECCION VARCHAR2(121);
V_CONTADOR NUMBER := 0;
V_DIR_ESTA VARCHAR2 (121);

CURSOR VAL_DIR_RUNT IS
SELECT ID_REG,NUEVA_DIRECCION
FROM IF_RUNT_UNICO
where DIR_ESTANDAR IS NULL;

BEGIN

FOR X  IN VAL_DIR_RUNT  LOOP

V_CONTADOR := V_CONTADOR + 1;

V_ID_REG := X.ID_REG;
V_NUEVA_DIRECCION := X.NUEVA_DIRECCION;

V_DIR_ESTA := pkg_ds_estandariza_runt.ft_estandarizar_direccion(V_NUEVA_DIRECCION);

UPDATE IF_RUNT_UNICO
SET DIR_ESTANDAR = V_DIR_ESTA
WHERE ID_REG = V_ID_REG;

IF V_CONTADOR = 500 THEN
COMMIT;
V_CONTADOR := 0;
END IF ;

END LOOP;
COMMIT;


END IF_ESTAND_DIR;

/
--------------------------------------------------------
--  DDL for Procedure IF_ESTA_TELEFONO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."IF_ESTA_TELEFONO" AS 

V_ID_REG VARCHAR2(50);
V_TEL VARCHAR2(50);
V_CONTADOR NUMBER := 0;
V_AVANCE NUMBER := 0;

CURSOR VAL_DIR_RUNT IS
SELECT ID_REG, telefono
FROM IF_RUNT_UNICO
where telefono IS NOT NULL;

BEGIN

FOR X  IN VAL_DIR_RUNT  LOOP

V_CONTADOR := V_CONTADOR + 1;
V_AVANCE := V_AVANCE + 1;

V_ID_REG := X.ID_REG;
V_TEL := X.telefono;

V_TEL := pkg_ds_estandariza_runt.ft_estandarizar_telefono(V_TEL);

UPDATE IF_RUNT_UNICO
SET TEL_ESTANDAR = V_TEL
WHERE ID_REG = V_ID_REG;

IF V_CONTADOR = 700 THEN

UPDATE IF_REP_RECAUDO
SET ST = V_AVANCE
WHERE ID_PAGO = '1';
COMMIT;

V_CONTADOR := 0;

END IF ;

END LOOP;
COMMIT;
END IF_ESTA_TELEFONO;

/
--------------------------------------------------------
--  DDL for Procedure IF_VAL_DIR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."IF_VAL_DIR" AS 


V_ID_REG VARCHAR2(50);
V_DIR_ESTANDAR VARCHAR2(121);
V_MENSAJE VARCHAR2(121);
V_CONTADOR NUMBER := 0;
V_ERROR NUMBER;

CURSOR VAL_DIR_RUNT IS
SELECT ID_REG,DIR_ESTANDAR FROM IF_RUNT_UNICO;
--where DIR_ESTANDAR IS NOT NULL AND tipo_error IS NULL;

BEGIN

FOR X IN VAL_DIR_RUNT  LOOP

V_CONTADOR := V_CONTADOR + 1;

V_ID_REG := X.ID_REG;
V_DIR_ESTANDAR := X.DIR_ESTANDAR;

V_ERROR := pkg_generar_plantilla_ic.ft_validar_direccion(V_DIR_ESTANDAR,0);

 CASE V_ERROR
          WHEN 1 THEN
              V_MENSAJE:='DIRECCION < 7 ';
          WHEN 2 THEN
              V_MENSAJE:='DIRECCION SOLO LETRAS ';
          WHEN 3 THEN
              V_MENSAJE:='DIRECCION SOLO NUMEROS ';
          WHEN 4 THEN
              V_MENSAJE:='DIRECCION 3 CONSONANTES ';    
          ELSE
              V_MENSAJE:='NO SE DETECTO ERROR ';
    END CASE;

UPDATE if_runt_unico
SET TIPO_ERROR = V_MENSAJE
WHERE ID_REG = V_ID_REG;
--COMMIT;

IF V_CONTADOR = 500 THEN
COMMIT;
V_CONTADOR := 0;
END IF ;

END LOOP;
COMMIT;


END IF_VAL_DIR;

/
--------------------------------------------------------
--  DDL for Procedure LEER_ARCHIVO1
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."LEER_ARCHIVO1" IS

  V_ARCHIVO UTL_FILE.FILE_TYPE;
  V_LINEA VARCHAR2(1024);
  
BEGIN

  V_ARCHIVO := UTL_FILE.FOPEN ('DIR_PLANOS', 'x.txt', 'R');
  
  LOOP
    UTL_FILE.GET_LINE (V_ARCHIVO, V_LINEA);
    DBMS_OUTPUT.PUT_LINE (V_LINEA);
  END LOOP;
  
EXCEPTION
  WHEN OTHERS THEN
  --DEBEMOS CERRAR EL ARCHIVO AQUI YA QUE EN EL MOMENTO QUE NO ENCUENTRE LINEAS SALTA DIRECTAMENTE A LA LA EXECPCI�N Y NO LO CERRAR�A.
  UTL_FILE.FCLOSE(V_ARCHIVO);
  DBMS_OUTPUT.PUT_LINE ('FIN DEL ARCHIVO');
END;

/
--------------------------------------------------------
--  DDL for Procedure PKG_UPDATE_LINEA1
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PKG_UPDATE_LINEA1" AS 
Lv_Codigo_Tipo Varchar2(10);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
Select Tl.Id_Linea Into Lv_Codigo_Tipo
From Quipux.Lic_Tto Lt
Inner Join Quipux.Qx_Tipo_Linea Qtl On Qtl.Runt_Linea = Lt.Id_Linea_Runt
Inner Join Quipux.Tipo_Linea Tl On Tl.Id_Linea_Qx = Qtl.Id_Linea_Qx
Inner Join sap_lineas SL On Tl.ID_LINEA_QX = SL.ID_LINEA_QX
Where Lt.Nro_Placa = Ln_Index.Nro_Placa AND TL.DESC_LINEA =SL.DESC_LINEA_QX
And Rownum = 1;

Update Quipux.Lic_Tto Lt Set Lt.Id_Linea = Lv_Codigo_Tipo
Where Lt.Nro_Placa = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.Observacion = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PKG_UPDATE_LINEA1;
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

  /* TODO enter package declarations (types, exceptions, methods etc) here */

/
--------------------------------------------------------
--  DDL for Procedure PRUEBA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PRUEBA" AS 


V_ID_REG VARCHAR2(50);
V_NUEVA_DIRECCION VARCHAR2(121);
V_CONTADOR NUMBER := 0;
V_DIR_ESTA VARCHAR2 (121);

CURSOR VAL_DIR_RUNT IS
SELECT ID_REG,NUEVA_DIRECCION
FROM IF_RUNT_UNICO
where DIR_ESTANDAR IS NULL AND NUEVA_DIRECCION IS not null;

BEGIN

FOR X  IN VAL_DIR_RUNT  LOOP

V_CONTADOR := V_CONTADOR + 1;

V_ID_REG := X.ID_REG;
V_NUEVA_DIRECCION := X.NUEVA_DIRECCION;

V_DIR_ESTA := pkg_ds_estandariza_runt.ft_estandarizar_direccion(V_NUEVA_DIRECCION);

UPDATE IF_RUNT_UNICO
SET DIR_ESTANDAR = V_DIR_ESTA
WHERE ID_REG = V_ID_REG;

IF V_CONTADOR = 500 THEN
COMMIT;
V_CONTADOR := 0;
END IF ;

END LOOP;
COMMIT;


END PRUEBA;

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_DIR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PS_ACTUALIZAR_DIR" AS 
Lv_Dir Varchar2(100);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
SELECT CONCAT(CONCAT (CONCAT('NO REPORTA ',ST.NOMBRE_CIUDAD),' - '),VH.ID_SECRETARIA)  INTO Lv_Dir
FROM DS_TMP_CONTRIBUYENTES3 CT
INNER JOIN DS_TMP_PROPIETARIOS3 PR ON  PR.ID_USUARIO = CT.ID_USUARIO
INNER JOIN DS_TMP_VEHICULOS3 VH ON VH.NRO_PLACA = PR.NRO_PLACA
INNER JOIN CIUDADES ST ON ST.CIUDAD_RUNT = VH.ID_SECRETARIA 
WHERE CT.ID_USUARIO = Ln_Index.Nro_Placa
And Rownum = 1;

Update DS_TMP_CONTRIBUTENTES3 CT Set CT.DIRECCION = Lv_Dir
Where CT.ID_USUARIO = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.Observacion = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PS_ACTUALIZAR_DIR;

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_DIRECCION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PS_ACTUALIZAR_DIRECCION" AS 
Lv_Dir Varchar2(100);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
SELECT PR.ID_USUARIO, CONCAT(CONCAT (CONCAT('NO REPORTA ',ST.NOMBRE_CIUDAD),' - '),VH.ID_SECRETARIA) INTO Lv_Dir
FROM DS_TMP_CONTRIBUYENTES3 CT
INNER JOIN DS_TMP_PROPIETARIOS3 PR ON  PR.ID_USUARIO = CT.ID_USUARIO
INNER JOIN DS_TMP_VEHICULOS3 VH ON VH.NRO_PLACA = PR.NRO_PLACA
INNER JOIN CIUDADES ST ON ST.CIUDAD_RUNT = VH.ID_SECRETARIA 
WHERE CT.ID_USUARIO = Ln_Index.Nro_Placa
And Rownum = 1;

Update DS_TMP_CONTRIBUYENTES3 CT Set CT.DIRECCION = Lv_Dir
Where CT.ID_USUARIO = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.Observacion = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PS_ACTUALIZAR_DIRECCION;

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_LINEA_RUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PS_ACTUALIZAR_LINEA_RUNT" AS 

Cursor Actualizar_linea Is select * from Temp_Placas;
lN_EXISTE INTEGER :=0;


Begin

For Ln_Index In Actualizar_linea Loop

    SELECT COUNT (1) INTO lN_EXISTE  FROM RUNT_LINEA
     WHERE CODIGO_LINEA_WS =Ln_Index.ws;

if (lN_EXISTE=0) then
    insert into RUNT_LINEA (CODIGO_LINEA_WS,CODIGO_LINEA, CODIGO_MARCA,DESCRIPCION)
    values (Ln_Index.ws, Ln_Index.marca, Ln_Index.cod_linea, Ln_Index.nombre);

ELSE
    UPDATE TEMP_PLACAS SET ESTADO ='CREADA';

end if;


END LOOP;
end PS_ACTUALIZAR_LINEA_RUNT;

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_LINEA_TIPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."PS_ACTUALIZAR_LINEA_TIPO" AS 
Lv_Codigo_Tipo Varchar2(10);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
Select Tl.Id_Linea Into Lv_Codigo_Tipo
From Quipux.Lic_Tto Lt
Inner Join Quipux.Qx_Tipo_Linea Qtl On Qtl.Runt_Linea = Lt.Id_Linea_Runt
Inner Join Quipux.Tipo_Linea Tl On Tl.Id_Linea_Qx = Qtl.Id_Linea_Qx
Where Lt.Nro_Placa = Ln_Index.Nro_Placa
And Rownum = 1;

Update Quipux.Lic_Tto Lt Set Lt.Id_Linea = Lv_Codigo_Tipo
Where Lt.Nro_Placa = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.ID_SECRETARIA = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PS_ACTUALIZAR_LINEA_TIPO;

/
--------------------------------------------------------
--  DDL for Procedure QAS_CARACTERISTICAS2
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."QAS_CARACTERISTICAS2" AS 
Lv_Placa Varchar2(10);
LV_NOMBRE_MARCA Varchar2(10);
LV_NOMBRE_LINEA Varchar2(10);
LV_MODELO Varchar2(10);
LV_NOMBRE_CLASE Varchar2(10);
LV_NOMBRE_SERVICIO Varchar2(10);
LV_NOMBRE_CARROCERIA Varchar2(10);
LV_NRO_PUERTAS Varchar2(10);
LV_CILINDRAJE Varchar2(10);
LV_CAP_PASAJEROS Varchar2(10);
LV_CAP_TONELADAS Varchar2(10);
LV_ID_RADICADO Varchar2(10);
LV_NOMBRE Varchar2(10);
Ln_Contador Number := 0;

Cursor  consulta_placas Is
Select NRO_PLACA From CORRECCION_DATOS.QAS_CARACTERISTICAS;

Begin

For Ln_Index In consulta_placas Loop

Begin

select St.NRO_PLACA,
St.NOMBRE_MARCA,
St.NOMBRE_LINEA,
St.MODELO,
St.NOMBRE_CLASE,
St.NOMBRE_SERVICIO,
St.NOMBRE_CARROCERIA,
St.NRO_PUERTAS,
St.CILINDRAJE,
St.CAP_PASAJEROS,
St.CAP_TONELADAS,
St.ID_RADICADO,
ot.NOMBRE
INTO
LV_NOMBRE_MARCA,
LV_NOMBRE_LINEA,
LV_MODELO,
LV_NOMBRE_CLASE,
LV_NOMBRE_SERVICIO,
LV_NOMBRE_CARROCERIA,
LV_NRO_PUERTAS,
LV_CILINDRAJE,
LV_CAP_PASAJEROS,
LV_CAP_TONELADAS,
LV_ID_RADICADO,
LV_NOMBRETTO
from BD_TRANSITOS.ST_VEHICULOS St
Inner join BD_TRANSITOS.ST_MAESTRO M on M.Id_Radicado = St.Id_Radicado
Inner join correccion_datos.runt_organismos_tto Ot on ot.divipo = M.Id_Secretaria
where St.NRO_PLACA = Ln_Index.Nro_Placa;


Update CORRECCION_DATOS.QAS_CARACTERISTICAS Lt Set 
LT.NOMBRE_MARCA=LV_NOMBRE_MARCA,
LT.NOMBRE_LINEA=LV_NOMBRE_LINEA,
LT.MODELO=LV_MODELO,
LT.NOMBRE_CLASE=LV_NOMBRE_CLASE,
LT.NOMBRE_SERVICIO=LV_NOMBRE_SERVICIO,
LT.NOMBRE_CARROCERIA=LV_NOMBRE_CARROCERIA,
LT.NRO_PUERTAS=LV_NRO_PUERTAS,
LT.CILINDRAJE=LV_CILINDRAJE,
LT.CAP_PASAJEROS=LV_CAP_PASAJEROS,
LT.CAP_TONELADAS=LV_CAP_TONELADAS,
LT.ID_RADICADO=LV_ID_RADICADO,
LT.NOMBRE=LV_NOMBRETTO
Where Lt.Nro_Placa = Lv_Placa;


Exception
When Others Then

Update CORRECCION_DATOS.QAS_CARACTERISTICAS Lt  Set LT.NOMBRE_MARCA = 'NO ESTA EN BD'
Where LT.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END;

/
--------------------------------------------------------
--  DDL for Procedure SP_ACT_MI_TRASPASO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ACT_MI_TRASPASO" AS 

V_MIN NUMBER:=0;
V_MODELO NUMBER:=0;
V_MI VARCHAR2(10);
V_ERROR VARCHAR2(100);
V_CONTADOR NUMBER :=0;

CURSOR TRAMITE IS
SELECT DISTINCT NRO_PLACA
FROM TEMP_NOVEDADES_TRASPASOS;
--WHERE NRO_PLACA = 'ABO399';

BEGIN

FOR X IN TRAMITE LOOP

V_CONTADOR := V_CONTADOR +1;

  SELECT MIN(CONTADOR)
  INTO V_MIN
  FROM TEMP_NOVEDADES_TRASPASOS
  WHERE NRO_PLACA = X.NRO_PLACA;
  
  BEGIN
    SELECT MODELO, TO_CHAR(TO_DATE(FECHA_MATRICULO),'YYYYMMDD')
    INTO V_MODELO, V_MI
    FROM OC_RUNT_TOTAL
    WHERE NRO_PLACA = X.NRO_PLACA
    AND ROWNUM =1;
  EXCEPTION
  WHEN OTHERS THEN
   V_ERROR:= '+2 MODELOS, ';
   
  END;
  
  UPDATE TEMP_NOVEDADES_TRASPASOS
  SET FECHA_DESDE = V_MI
  WHERE NRO_PLACA = X.NRO_PLACA
    AND CONTADOR = V_MIN
    AND FECHA_DESDE = NVL(V_MODELO||'0101','19000101');


 UPDATE TEMP_NOVEDADES_TRASPASOS
    SET VALIDACION = V_ERROR
    WHERE NRO_PLACA = X.NRO_PLACA
    AND CONTADOR = V_MIN;
    
IF V_CONTADOR = 500 THEN
  COMMIT;
  V_CONTADOR := 0;
END IF;  

END LOOP;
COMMIT;

END SP_ACT_MI_TRASPASO;

/
--------------------------------------------------------
--  DDL for Procedure SP_ACT_TTP_PERMITIDOS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ACT_TTP_PERMITIDOS" AS

BEGIN

 /* *****************************************ACTUALIZAR LOS TELEFONOS FUERAS DEL ESTANDAR A NULL.***************************/
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS --6271
SET TELEFONO = null
--SELECT TELEFONO, REGISTRO_ERROR, CAMPOS_NULL FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS 
WHERE (REPLACE(TRANSLATE (TRANSLATE(TELEFONO,'EXTextPBpb','**********'),'1234567890','@@@@@@@@@@'),' ','')
NOT IN ('@@@@@@@','@@@@@@@@','@@@@@@@@@','@@@@@@@@@@','@@@@@@@***@@@@','@@@@@@@***@@@',
'@@@@@@@***@@','@@@@@@@***@','***@@@@@@@@@@@','***@@@@@@@@@','***@@@@@@@@@@') 
OR INSTR(TELEFONO, '0000000')+INSTR(TELEFONO, '1111111')+INSTR(TELEFONO, '2222222')+INSTR(TELEFONO, '3333333')+INSTR(TELEFONO, '4444444')+INSTR(TELEFONO, '5555555')+INSTR(TELEFONO, '6666666')+INSTR(TELEFONO, '7777777')+INSTR(TELEFONO, '8888888')+INSTR(TELEFONO, '9999999')+INSTR(TELEFONO, '1234567')+INSTR(TELEFONO, '7654321')>0
OR LENGTH (TELEFONO) < 7);


/* *****************************************ACTUALIZAR LOS FAX FUERAS DEL ESTANDAR a NULL. ***************************/
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS --59
SET FAX = null
--SELECT FAX, REGISTRO_ERROR, CAMPOS_NULL FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS 
WHERE (REPLACE(TRANSLATE (TRANSLATE(FAX,'EXTextPBpb','**********'),'1234567890','@@@@@@@@@@'),' ','')
NOT IN ('@@@@@@@','@@@@@@@@','@@@@@@@@@','@@@@@@@@@@','@@@@@@@***@@@@','@@@@@@@***@@@',
'@@@@@@@***@@','@@@@@@@***@','***@@@@@@@@@@@','***@@@@@@@@@','***@@@@@@@@@@') 
OR INSTR(FAX, '0000000')+INSTR(FAX, '1111111')+INSTR(FAX, '2222222')+INSTR(FAX, '3333333')+INSTR(FAX, '4444444')+INSTR(FAX, '5555555')+INSTR(FAX, '6666666')+INSTR(FAX, '7777777')+INSTR(FAX, '8888888')+INSTR(FAX, '9999999')+INSTR(FAX, '1234567')+INSTR(FAX, '7654321')>0
OR LENGTH (FAX) < 7);

/* *****************************************ACTUALIZAR LOS CELULARES FUERAS DEL ESTANDAR A NULL.***************************/       
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS --7010
SET TELEFONO_MOVIL = null
--SELECT TELEFONO,TELEFONO_MOVIL, REGISTRO_ERROR, CAMPOS_NULL FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS 
WHERE (REPLACE(TRANSLATE (TELEFONO_MOVIL,'1234567890','@@@@@@@@@@'),' ','')
NOT IN ('@@@@@@@@@@','@@@@@@@')
OR INSTR(TELEFONO_MOVIL, '0000000')+INSTR(TELEFONO_MOVIL, '1111111')+INSTR(TELEFONO_MOVIL, '2222222')+INSTR(TELEFONO_MOVIL, '3333333')+INSTR(TELEFONO_MOVIL, '4444444')+INSTR(TELEFONO_MOVIL, '5555555')+INSTR(TELEFONO_MOVIL, '6666666')+INSTR(TELEFONO_MOVIL, '7777777')+INSTR(TELEFONO_MOVIL, '8888888')+INSTR(TELEFONO_MOVIL, '9999999')+INSTR(TELEFONO_MOVIL, '1234567')+INSTR(TELEFONO_MOVIL, '7654321')>0) 
;

/* *****************************************ACTUALIZAR LOS MAIL NO VALIDOS A NULL ********************************************/    
				
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS --1363
SET E_MAIL = NULL
--SELECT E_MAIL, REGISTRO_ERROR, CAMPOS_NULL FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS 
WHERE INSTR(LOWER(E_MAIL),'notiene') > 0
OR INSTR(LOWER(E_MAIL),'noregistra') > 0
OR LENGTH(E_MAIL)                   <= 7
OR INSTR(E_MAIL, '@')                =0;

/* *****************************************ACTUALIZAR LAS DIRECCIONES CON CIUDAD_DIR  ***************************/
--DIRECCION_CORRESP
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --854
SET TPP.DIRECCION_CORRESP = (SELECT DISTINCT 'NO REPORTA - ' || SC.DESCRIPCION_CIUDAD_SAP 
                       FROM SAP_CIUDADES SC
                       WHERE SC.ID_CIUDAD_SAP = TPP.POBLACION)
WHERE ((INSTR(UPPER(TPP.DIRECCION_CORRESP),'NO REPORTA') > 0
AND INSTR(REPLACE(TRANSLATE (TPP.DIRECCION_CORRESP,'1234567890','@@@@@@@@@@'),' ',''), '@')=0 )
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_CORRESP, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND  TPP.REGION IS NOT NULL AND 
TPP.POBLACION IS NOT NULL;

--DIRECCION_NOT_VEH
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --854
SET TPP.DIRECCION_NOT_VEH = DIRECCION_CORRESP
WHERE ((INSTR(UPPER(TPP.DIRECCION_NOT_VEH),'NO REPORTA') > 0
AND INSTR(REPLACE(TRANSLATE (TPP.DIRECCION_NOT_VEH,'1234567890','@@@@@@@@@@'),' ',''), '@')=0 )
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_NOT_VEH, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND  TPP.REGION IS NOT NULL AND 
TPP.POBLACION IS NOT NULL;

--DIRECCION_RESIDENCIA
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --854
SET TPP.DIRECCION_RESIDENCIA = DIRECCION_CORRESP
WHERE ((INSTR(UPPER(TPP.DIRECCION_RESIDENCIA),'NO REPORTA') > 0
AND INSTR(REPLACE(TRANSLATE (TPP.DIRECCION_RESIDENCIA,'1234567890','@@@@@@@@@@'),' ',''), '@')=0 )
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_RESIDENCIA, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND  TPP.REGION IS NOT NULL AND 
TPP.POBLACION IS NOT NULL;
 
/* *****************************************ACTUALIZAR LAS DIRECCIONES SIN POBLACI�N  ***************************/
--DIRECCION_CORRESP
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --990
SET TPP.DIRECCION_CORRESP = (SELECT DISTINCT 'NO REPORTA - TTO ' || SC.DESCRIPCION_CIUDAD_SAP 
                       FROM PLANTILLA_OC TPV
                       INNER JOIN SAP_CIUDADES SC
                       ON TPV.UNIDAD_TRANSITO =SC.ID_CIUDAD_SAP
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1)
WHERE (INSTR(UPPER(TPP.DIRECCION_CORRESP),'NO REPORTA') > 0
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_CORRESP, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND TPP.REGION IS NULL AND 
TPP.POBLACION IS NULL;

UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --972
SET TPP.DIRECCION_NOT_VEH = DIRECCION_CORRESP
WHERE (INSTR(UPPER(TPP.DIRECCION_NOT_VEH),'NO REPORTA') > 0
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_NOT_VEH, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND TPP.REGION IS NULL AND 
TPP.POBLACION IS NULL;

--DIRECCION_RESIDENCIA
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --972
SET TPP.DIRECCION_RESIDENCIA = DIRECCION_CORRESP,
                       TPP.POBLACION = (SELECT DISTINCT TPV.UNIDAD_TRANSITO
                       FROM PLANTILLA_OC TPV
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1),
                       TPP.REGION= (SELECT CASE WHEN LENGTH (TPV.UNIDAD_TRANSITO)=5 THEN SUBSTR(TPV.UNIDAD_TRANSITO,0,2) ELSE CASE WHEN LENGTH (TPV.UNIDAD_TRANSITO)=4 THEN 0||SUBSTR(TPV.UNIDAD_TRANSITO,0,1) END END
                       FROM PLANTILLA_OC TPV
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1)
WHERE (INSTR(UPPER(TPP.DIRECCION_RESIDENCIA),'NO REPORTA') > 0
OR NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_RESIDENCIA, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0)--Solo numeros o NULL
AND TPP.REGION IS NULL AND 
TPP.POBLACION IS NULL;

/* *****************************************ACTUALIZAR LAS DIRECCIONES SIN POBLACI�N  ULTIMA OPCION***************************/
--Esto pedazo solo se debe habilitar una vez ya se han buscado todas las direcciones
--DIRECCION_CORRESP
/*UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --990
SET TPP.DIRECCION_CORRESP = (SELECT DISTINCT 'NO REPORTA - TTO ' || SC.DESCRIPCION_CIUDAD_SAP 
                       FROM PLANTILLA_OC TPV
                       INNER JOIN SAP_CIUDADES SC
                       ON TPV.UNIDAD_TRANSITO =SC.ID_CIUDAD_SAP
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1)
WHERE NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_CORRESP, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0--Solo numeros o NULL
OR TPP.REGION IS NULL OR 
TPP.POBLACION IS NULL;

UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --972
SET TPP.DIRECCION_NOT_VEH = DIRECCION_CORRESP
WHERE  NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_NOT_VEH, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0--Solo numeros o NULL
OR TPP.REGION IS NULL OR 
TPP.POBLACION IS NULL;

--DIRECCION_RESIDENCIA
UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TPP --972
SET TPP.DIRECCION_RESIDENCIA = DIRECCION_CORRESP,
                       TPP.POBLACION = (SELECT DISTINCT TPV.UNIDAD_TRANSITO
                       FROM PLANTILLA_OC TPV
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1),
                       TPP.REGION= (SELECT CASE WHEN LENGTH (TPV.UNIDAD_TRANSITO)=5 THEN SUBSTR(TPV.UNIDAD_TRANSITO,0,2) ELSE CASE WHEN LENGTH (TPV.UNIDAD_TRANSITO)=4 THEN 0||SUBSTR(TPV.UNIDAD_TRANSITO,0,1) END END
                       FROM PLANTILLA_OC TPV
                       WHERE TPV.NRO_IDENTIFICACION = TPP.NRO_IDENTIFICACION
                       AND ROWNUM =1)
WHERE NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(DIRECCION_RESIDENCIA, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0)=0--Solo numeros o NULL
OR TPP.REGION IS NULL OR 
TPP.POBLACION IS NULL;
*/


 COMMIT;
        
END SP_ACT_TTP_PERMITIDOS;

/
--------------------------------------------------------
--  DDL for Procedure SP_ACTUALIZAR_LINEA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ACTUALIZAR_LINEA" AS 

  CONTADOR NUMBER:=0;
  V_CIL  NUMBER:=0;
  V_EXISTE NUMBER:=0;
  V_CLASE VARCHAR2(10);
  
CURSOR LINEAS_TTO IS
	SELECT  ltt.nro_placa,
			ltt.id_linea,
			tl.desc_linea,
			ltt.id_linea_runt,
			ltt.nombre_linea_runt,
      pl.CILINDRAJE,
      pl.CLASE,
			INSTR(UPPER(tl.desc_linea),UPPER(PL.DESC_LINEA),1) EXISTE
	FROM QUIPUX.lic_tto ltt
		INNER JOIN CORRECCION_DATOS.placas_LINEAS4 pl
				ON ltt.nro_placa = pl.nro_placa
		LEFT JOIN QUIPUX.tipo_linea tl
			   ON ltt.id_linea = tl.id_linea
	WHERE pl.ESTADO = 'NO ESTA CONTENIDA'
  --AND PL.NRO_PLACA = 'XHY01D'
-- AND PL.ID_LINEA = '19345'
	ORDER BY ltt.nro_placa;

CURSOR LINEA_SAP(vrunt_linea number,vcilindraje number) IS 
  
 	SELECT 	DISTINCT tl.id_linea,
			qtl.runt_linea,
			sl.id_linea_sap,
			sl.desc_linea_sap,
      SL.CILINDRAJE_SAP
	FROM QUIPUX.tipo_linea tl
		LEFT JOIN QUIPUX.qx_tipo_linea qtl
			   ON (tl.id_linea_qx = qtl.id_linea_qx)
		LEFT JOIN QUIPUX.qx_tipo_marca qtm
			   ON (qtm.id_marca_qx = qtl.id_marca_qx)
		LEFT JOIN QUIPUX.marca_vehiculos mv
			   ON (mv.id_marca_qx = qtm.id_marca_qx)
		LEFT JOIN DEPURACION.sap_lineas sl
			   ON (sl.id_linea_qx = TO_CHAR(qtl.id_linea_qx))
	WHERE( mv.id_marca_qx <> 0 ) AND
	      qtl.runt_linea = vrunt_linea AND
        --qtl.runt_linea = '720' AND
      SL.CILINDRAJE_QX = DECODE(SL.CILINDRAJE_QX,0,0
                                                ,vcilindraje,vcilindraje)
      
          -- PENDIENTE PARAMETRIZAR LOS CILINDRAJES SEGUN LA LONGITUD
    ORDER BY tl.id_linea DESC;

BEGIN

BEGIN
  FOR XLIN IN LINEAS_TTO LOOP
  
  V_CIL := XLIN.CILINDRAJE;
  
  IF XLIN.CLASE NOT IN ('10','15','19','14') THEN
    V_CLASE := 1;
  ELSE
    V_CLASE := 2;
  END IF;
  
    IF V_CIL NOT IN (135, 225, 185, 175) THEN
     -- V_CIL  := ROUND(V_CIL , (2-(LENGTH(V_CIL )))); 
     
     BEGIN   
      SELECT CILINDRAJE
      INTO  V_CIL
      FROM SAP_CILINDRAJES SC
      WHERE TIPO_VEHICULO = V_CLASE AND
      XLIN.CILINDRAJE BETWEEN RANGO_DESDE AND RANGO_HASTA;
     EXCEPTION
     WHEN OTHERS THEN
     V_CIL  := ROUND(V_CIL , (2-(LENGTH(V_CIL ))));
     END;
    END IF;
    
    FOR XSAPLIN IN LINEA_SAP(XLIN.ID_LINEA_RUNT,V_CIL) LOOP
    
      IF CONTADOR = 0 THEN  
      
               
            SELECT COUNT(1)
            INTO V_EXISTE
            FROM CORRECCION_DATOS.PLACAS_LINEAS4 PL3
            WHERE INSTR(UPPER(XSAPLIN.desc_linea_sap),UPPER(PL3.DESC_LINEA),1) > 0
            AND PL3.NRO_PLACA = XLIN.NRO_PLACA;   
            
          IF V_EXISTE = 0 THEN
            SELECT COUNT(1)
            INTO V_EXISTE
            from CORRECCION_DATOS.PLACAS_LINEAS4 PL3
            WHERE INSTR(UPPER(PL3.DESC_LINEA),UPPER(XSAPLIN.desc_linea_sap),1)> 0
            AND PL3.NRO_PLACA = XLIN.NRO_PLACA;                 
          END IF;       
          
          IF V_EXISTE = 1 THEN         
          
            BEGIN
            
            UPDATE QUIPUX.LIC_TTO SET ID_LINEA = XSAPLIN.ID_LINEA
            WHERE NRO_PLACA = XLIN.NRO_PLACA; 
            COMMIT;
            
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                DBMS_OUTPUT.PUT_LINE ('ERROR');
                CONTADOR := 0;
            END;
            CONTADOR := 1;   
           END IF; 
         END IF;  
    
    END LOOP; 
    CONTADOR := 0;
  END LOOP;
    
END;

--XLIN.ID_LINEA_RUNT

END SP_ACTUALIZAR_LINEA;

/
--------------------------------------------------------
--  DDL for Procedure SP_ACTUALIZAR_TRASPASO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ACTUALIZAR_TRASPASO" (FECHA_INICIO DATE, FECHA_FIN DATE) AS 
--DESCRIPCION
--Este procedimiento permite actualizar los tramites de traspaso con la 
--informacion de historiales traspaso enviado por los diferentes transitos
V_EXISTE NUMBER;

CURSOR PLACAS IS
SELECT DISTINCT DT1.NRO_PLACA, 
       DT1.ID_USUARIO_ANTERIOR, 
       DT1.ID_USUARIO_NUEVO, 
       DT1.FECHA_TRAMITE
FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DT1
INNER JOIN CORRECCION_DATOS.HISTORIALES_TRASPASO HT
  ON HT.NRO_PLACA = DT1.NRO_PLACA
WHERE DT1.ID_TRAMITE IN ('16','65') AND
      HT.ACTUALIZACION = 'N' AND
      HT.FECHA BETWEEN FECHA_INICIO AND FECHA_FIN;
--AND DT1.NRO_PLACA ='KRN64C';

BEGIN
  
  FOR X IN PLACAS LOOP
  
  V_EXISTE := 0;
  
   BEGIN
   
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM CORRECCION_DATOS.HISTORIALES_TRASPASO HT
    WHERE HT.NRO_PLACA = X.NRO_PLACA AND
          HT.ID_USUARIO = X.ID_USUARIO_ANTERIOR AND
          HT.ID_COMPRADOR = X.ID_USUARIO_NUEVO AND
          ((HT.FECHA = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')) OR (HT.FECHA + 1 = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')))AND
          HT.FECHA BETWEEN FECHA_INICIO AND FECHA_FIN AND
          HT.ACTUALIZACION = 'N';
   
   EXCEPTION
   WHEN OTHERS THEN
    CONTINUE;
   END; 
     
   BEGIN
   
    IF V_EXISTE = 0 THEN
      
      UPDATE CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
         SET PORCENTAJE_PROP = 'BORRAR'
       WHERE DT.NRO_PLACA = X.NRO_PLACA AND
             DT.ID_USUARIO_ANTERIOR = X.ID_USUARIO_ANTERIOR AND
             DT.ID_USUARIO_NUEVO = X.ID_USUARIO_NUEVO AND
             DT.FECHA_TRAMITE = X.FECHA_TRAMITE AND
             DT.FECHA_TRAMITE = X.FECHA_TRAMITE AND
             DT.ID_TRAMITE IN ('16', '65');
     
     ELSIF V_EXISTE = 1 THEN  
     
       UPDATE CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
         SET PORCENTAJE_PROP = (SELECT PORCENTAJE
                                  FROM CORRECCION_DATOS.HISTORIALES_TRASPASO
                                 WHERE NRO_PLACA = X.NRO_PLACA
                                   AND ID_USUARIO = X.ID_USUARIO_ANTERIOR
                                   AND ID_COMPRADOR = X.ID_USUARIO_NUEVO
                                   AND ((FECHA = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')) OR ((FECHA + 1) = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')))
                                   AND FECHA BETWEEN FECHA_INICIO AND FECHA_FIN)
       WHERE DT.NRO_PLACA = X.NRO_PLACA AND
             DT.ID_USUARIO_ANTERIOR = X.ID_USUARIO_ANTERIOR AND
             DT.ID_USUARIO_NUEVO = X.ID_USUARIO_NUEVO AND
             DT.FECHA_TRAMITE = X.FECHA_TRAMITE AND
             DT.ID_TRAMITE IN ('16', '65');
      
     UPDATE CORRECCION_DATOS.HISTORIALES_TRASPASO
        SET ACTUALIZACION = 'S'
     WHERE NRO_PLACA = X.NRO_PLACA
       AND ID_USUARIO = X.ID_USUARIO_ANTERIOR
       AND ID_COMPRADOR = X.ID_USUARIO_NUEVO
       AND ((FECHA = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')) OR ((FECHA + 1) = TO_DATE(X.FECHA_TRAMITE, 'DD/MM/YY')))
       AND FECHA BETWEEN FECHA_INICIO AND FECHA_FIN;       
               
    END IF;
  
    COMMIT;  
  
  EXCEPTION
  WHEN OTHERS THEN
   ROLLBACK; 
   CONTINUE;
  END;
    
  END LOOP;
  
  /*BEGIN
    DELETE FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
    WHERE PORCENTAJE_PROP = 'BORRAR';
    COMMIT;
  EXCEPTION 
  WHEN OTHERS THEN
    ROLLBACK;
  END; */
  
  
END SP_ACTUALIZAR_TRASPASO;

/
--------------------------------------------------------
--  DDL for Procedure SP_CALCULAR_DIGITO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_CALCULAR_DIGITO" AS 

lvUsuarioConDigito varchar2(10);
lnContador number := 0;

Cursor curUsuario is 
Select USUARIO from Tmp_Calcular_Digito;

BEGIN
For lnIndex in curUsuario Loop

if(length(lnIndex.usuario)= 9) then
  lvUsuarioConDigito := lnIndex.USUARIO || Pkg_Ds_Estandariza_Runt.Ft_Calcular_Digito_Verifica(lnIndex.Usuario);
  
  Update Tmp_Calcular_Digito 
     set USUARIO_CON_DIGITO = lvUsuarioConDigito 
   where USUARIO = lnIndex.Usuario;  
end if;

if(lnContador = 200) then
    Commit;
else
  lnContador:= lnContador +1;
End if;  

end Loop;
Commit;
END SP_CALCULAR_DIGITO;

/
--------------------------------------------------------
--  DDL for Procedure SP_CALULAR_DIGITO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_CALULAR_DIGITO" AS 

lvUsuarioConDigito varchar2(10);
lnContador number := 0;

Cursor curUsuario is 
Select USUARIO from Tmp_Calcular_Digito;

BEGIN
For lnIndex in curUsuario Loop

if(length(lnIndex.usuario)= 9) then
  lvUsuarioConDigito := lnIndex.USUARIO || Pkg_Ds_Estandariza_Runt.Ft_Calcular_Digito_Verifica(lnIndex.Usuario);
  
  Update Tmp_Calcular_Digito 
     set USUARIO_CON_DIGITO = lvUsuarioConDigito 
   where USUARIO = lnIndex.Usuario;  
end if;

if(lnContador = 200) then
    Commit;
else
  lnContador:= lnContador +1;
End if;  

end Loop;
Commit;
END SP_CALULAR_DIGITO;

/
--------------------------------------------------------
--  DDL for Procedure SP_CREAR_ESPECIALES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_CREAR_ESPECIALES" AS 

lvGrupo    varchar2(6);
lnAvaluo   number:=0;
lnInicial  number:=0;
lnFinal    number:=0;
lnContador number:=0;
esAnterior boolean:=false;

Cursor curEspeciales is
Select * from dq_especiales
Where modelo in (2016, 1950) and vigencia = 2017  AND LINEA = 'AI002' AND GRUPO = 'K661';

BEGIN

for lnIndex in curEspeciales loop

if(lnIndex.Modelo = 2016) then
  lnInicial := 1993; -- Para especiales modelo superior a 1993
  lnFinal   := 2017;
  esAnterior := false;
else
  lnInicial := 1901; -- Para especiales anteriores a 1993
  lnFinal   := 1992;
  esAnterior := true;
end if;

begin
  Select Grupo_2018 into lvGrupo 
  from Dq_Grupos where GRUPO_2017 = lnIndex.Grupo;
exception 
when others then
CONTINUE;
end;

  for x in lnInicial .. lnFinal loop 
  
  if esAnterior = true and lnInicial = 1901 then
  
  begin  
    Select Avaluo into lnAvaluo 
    from dq_avaluo_vertical
    where GRUPO =lvGrupo and Modelo = 1993;
  exception 
  when others then
   CONTINUE;
  end;  
      
  elsif  esAnterior = false then
  
    Select Avaluo into lnAvaluo 
    from dq_avaluo_vertical
    where GRUPO =lvGrupo and Modelo = x;
    
  end if;
  
    Insert Into Dq_Especiales_2018
               (Vigencia,
                Consecutivo,
                Modelo,
                Uso,
                Marca,
                Linea,
                Clase,
                Carroceria,
                Cilindraje,
                Capacidad,
                Tipo_Carga,
                Caja,
                Puertas,
                Comb_Tracc,
                N_I,
                Grupo,
                Avaluo)
        Values (2018,    
                Seq_Especiales.Nextval,
                X,
                Lnindex.Uso, 
                Lnindex.Marca,
                Lnindex.Linea,
                Lnindex.Clase,
                Lnindex.Carroceria,
                Lnindex.Cilindraje,
                Lnindex.Capacidad,
                Lnindex.Tipo_Carga,
                Lnindex.Caja,
                Lnindex.Puertas,
                Lnindex.Comb_Tracc,
                Lnindex.N_I,
                lvGrupo,
                lnAvaluo);             
  end loop;

if(lnContador = 20) then
    Commit;
else
  lnContador := lnContador +1;
End if;
  
end loop;
Commit;

END SP_CREAR_ESPECIALES;

/
--------------------------------------------------------
--  DDL for Procedure SP_ELIMINAR_CIUDAD
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ELIMINAR_CIUDAD" AS 

V_MIN NUMBER;

CURSOR BORRAR IS
SELECT MIN_CIUDAD_QX
FROM QUIPUX.QX_CIUDAD
--WHERE MIN_CIUDAD_QX = 5101000
GROUP BY MIN_CIUDAD_QX
HAVING COUNT (1) > 1;

BEGIN

FOR X IN BORRAR LOOP

BEGIN

  SELECT MIN (TO_NUMBER(ID_CIUDAD_QX))
  INTO V_MIN
  FROM QUIPUX.QX_CIUDAD
  WHERE MIN_CIUDAD_QX = X.MIN_CIUDAD_QX;
  
  DELETE FROM QUIPUX.QX_CIUDAD
  WHERE MIN_CIUDAD_QX = X.MIN_CIUDAD_QX
  AND ID_CIUDAD_QX != V_MIN;

EXCEPTION 
WHEN OTHERS THEN
CONTINUE;
END;

END LOOP;
END SP_ELIMINAR_CIUDAD;

/
--------------------------------------------------------
--  DDL for Procedure SP_ESTANDARIZAR_NIT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_ESTANDARIZAR_NIT" 
AS
 V_NIT VARCHAR2(15);
 CURSOR NIT
 IS
  SELECT DISTINCT CEDULA
  FROM TEMP_CEDULAS;
BEGIN
 FOR X IN NIT  LOOP
  V_NIT := X.CEDULA;
  V_NIT := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_NIT);
  
  
  UPDATE TEMP_CEDULAS
  SET CEDULA_ESTANDAR=V_NIT
  WHERE CEDULA       =X.CEDULA;
  COMMIT;
  
  
  
 END LOOP;
END SP_ESTANDARIZAR_NIT ;

/
--------------------------------------------------------
--  DDL for Procedure SP_HOMOLGAR_CIUDADES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_HOMOLGAR_CIUDADES" AS 

V_MAX_QXC NUMBER(20);
V_MAX_CIUDADES NUMBER(20);
V_MAX_SAP NUMBER(20);
V_CIUDAD_RUNT NUMBER;
V_DEP_QX NUMBER(20);
V_DEP    NUMBER(20);
V_NOMBRE VARCHAR(100);
V_LONGITUD NUMBER :=0;
V_DIGITO NUMBER :=0;
V_NEW_CITY NUMBER:=0;
V_ID_CIUDAD_QX NUMBER:=0;
V_DESC_CITY_SAP VARCHAR(100);
V_EXISTE NUMBER:=0;

CURSOR CIUDAD IS
SELECT DISTINCT DTC.ID_USUARIO, DTC.ID_CIUDAD_DIR, DTC.NOMBRE_CIUDAD_DIR
FROM CORRECCION_DATOS.CONTRIBUYENTE_RUNT_TOTAL DTC
--INNER JOIN CORRECCION_DATOS.INCONSISTENCIAS INC
--ON  DTC.ID_USUARIO = Inc.Identificador
WHERE DTC.ID_CIUDAD_DIR NOT IN (SELECT QXC.CIUDAD_RUNT
                                         FROM QUIPUX.CIUDADES QXC 
                                         WHERE QXC.CIUDAD_RUNT = DTC.ID_CIUDAD_DIR)
AND  DTC.ID_CIUDAD_DIR IS NOT NULL; 
--AND DTC.ID_CIUDAD_DIR IN( '76130007','5664002');

BEGIN

  -- IDENTIFICO EL ID MAXIMO DE LA TABLA QX_CIUDADES  
  SELECT MAX (TO_NUMBER(QC.ID_CIUDAD_QX))
  INTO V_MAX_QXC
  FROM QUIPUX.QX_CIUDAD QC;
 
  
  -- IDENTIFICO EL ID MAXIMO DE LA TABLA CIUDADES
  SELECT MAX (TO_NUMBER(CIU.ID_CIUDAD))
  INTO V_MAX_CIUDADES
  FROM QUIPUX.CIUDADES CIU;
 

  FOR X IN CIUDAD LOOP
  
   V_CIUDAD_RUNT := X.ID_CIUDAD_DIR;
   V_MAX_QXC := V_MAX_QXC + 1;
   V_MAX_CIUDADES := V_MAX_CIUDADES + 1;
  
  BEGIN
  
    -- CAPTURO EL CODIGO DE DEPARTAMENTO QX
    SELECT QXD.ID_DEPARTAMENTO, DP.ID_DEPARTAMENTO, CRUT.NOMBRE
      INTO V_DEP_QX,  V_DEP, V_NOMBRE
    FROM QUIPUX.QX_DEPARTAMENTO QXD
    INNER JOIN CORRECCION_DATOS.CIUDADES_RUNT CRUT
      ON QXD.MIN_DEPTO_QX = CRUT.COD_DEPARTAMENTO
    INNER JOIN QUIPUX.DEPARTAMENTOS DP
      ON QXD.ID_DEPARTAMENTO = DP.ID_DEPARTAMENTO_QX
    WHERE CRUT.DIVIPO = TO_NUMBER(V_CIUDAD_RUNT);
    
 EXCEPTION
 WHEN OTHERS THEN
 CONTINUE;
 END;
    
    BEGIN
      --INSERT INTO QUIPUX.QX_CIUDADES
      INSERT INTO QUIPUX.QX_CIUDAD
      (ID_CIUDAD_QX,DESC_CIUDAD_QX, MIN_CIUDAD_QX,ID_DEPARTAMENTO_QX) 
      VALUES ( V_MAX_QXC, V_NOMBRE, V_CIUDAD_RUNT, V_DEP_QX);
   
      --INSERT INTO QUIPUX.QX_CIUDADES
      INSERT INTO QUIPUX.CIUDADES
      SELECT V_MAX_CIUDADES, V_NOMBRE, '0', V_MAX_QXC, V_DEP, V_CIUDAD_RUNT  FROM DUAL;
      
      COMMIT;
    EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
    END;
    
    --PROCESO DE INSERCION EN SAP_CIUDADES
    V_LONGITUD := LENGTH (V_CIUDAD_RUNT);
    V_DIGITO := SUBSTR(V_CIUDAD_RUNT,V_LONGITUD,V_LONGITUD);
    
    IF V_DIGITO != 0 THEN
          V_NEW_CITY:= SUBSTR(V_CIUDAD_RUNT,1,V_LONGITUD-1);
          V_NEW_CITY:= V_NEW_CITY || 0;
       
        
       BEGIN 
       
        SELECT ID_CIUDAD_QX
        INTO V_ID_CIUDAD_QX
        FROM QUIPUX.QX_CIUDAD
        WHERE MIN_CIUDAD_QX = V_NEW_CITY;
        
        SELECT DESCRIPCION_CIUDAD_SAP
        INTO V_DESC_CITY_SAP
        FROM DEPURACION.SAP_CIUDADES SC
        WHERE SC.ID_CIUDAD_QX = V_ID_CIUDAD_QX;
        
      EXCEPTION
      WHEN OTHERS THEN
      CONTINUE;
      END;
        
        V_EXISTE := INSTR(V_NOMBRE,V_DESC_CITY_SAP,1,1);
        
        IF (V_EXISTE >0) AND (V_ID_CIUDAD_QX IS NOT NULL) THEN
        
         -- IDENTIFICO EL ID MAXIMO DE LA TABLA SAP_CIUDADES
          SELECT MAX (TO_NUMBER(SAPC.ID))
          INTO V_MAX_SAP
          FROM DEPURACION.SAP_CIUDADES SAPC;
          
          V_MAX_SAP:= V_MAX_SAP + 1;
        
         BEGIN     
          
          INSERT INTO DEPURACION.SAP_CIUDADES
          SELECT  V_MAX_SAP, V_MAX_QXC, V_NOMBRE, DSC.ID_DEPTO_QX, DSC.DESCRIPCION_DEPTO_QX, 
                  DSC.ID_CIUDAD_SAP, DSC.DESCRIPCION_CIUDAD_SAP, DSC.ID_DEPTO_SAP
          FROM DEPURACION.SAP_CIUDADES DSC
          WHERE DSC.ID_CIUDAD_QX = V_ID_CIUDAD_QX
            AND DSC.ID_DEPTO_QX =  V_DEP_QX;
          COMMIT;
        
         EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
         END;
         
        END IF;
    END IF;
    
       
    
      
  END LOOP;
  
END SP_HOMOLGAR_CIUDADES;

/
--------------------------------------------------------
--  DDL for Procedure SP_HOMOLOGAR_LINEAS_QX
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_HOMOLOGAR_LINEAS_QX" AS 
--DESCRIPCION
 /* Este procedimiento permite insertar las lineas creadas en QX herramientas
  las tablas QX_tipo_linea y generar la homologacion con la tablas TIPO_LINEA*/ 
  
V_EXISTE NUMBER := 0;
V_MAX NUMBER := 0;
PARAMETRO NUMBER := 0;  
V_MARCA VARCHAR2 (50);
V_LINEA NUMBER;

CURSOR LINEA IS

--IF PARAMETRO = 1 THEN
  /*
  --CREAR LINEAS QUE ESTAN EN QX_HERRAMIENTAS QUE NO ESTAN EN QX_TPO_LINEA DE DEPURACI�N
    SELECT QXL1.ID_LINEA_QX
    FROM CORRECCION_DATOS.QX_TIPO_LINEA1 QXL1
    WHERE NOT EXISTS (SELECT 1
                      FROM QUIPUX.QX_TIPO_LINEA TL
                      WHERE TL.ID_LINEA_QX = QXL1.ID_LINEA_QX)
    AND (QXL1.LINEA_RNRYS IS NULL AND QXL1.LINEA_RNMA IS NULL); 
    --AND QXL1.ID_LINEA_QX = '36721';
                        
--ELSIF PARAMETRO = 2 THEN
--CREAR LINEAS QUE ESTAN EN QX_TIPO_LINEA QUE no ESTAN EN TIPO_LINEA DE DEPURACI�N
    SELECT QXL1.ID_LINEA_QX
    FROM QUIPUX.QX_TIPO_LINEA QXL1
    WHERE NOT EXISTS (SELECT 1
                      FROM QUIPUX.TIPO_LINEA TL
                      WHERE TL.ID_LINEA_QX = QXL1.ID_LINEA_QX);
    --AND QXL1.ID_LINEA_QX = '40079';*/
    --Crear lineas que vienen de runt que no existen en QX_HERRAMIENTAS ni en QX_TIPO_LINEA de DEPURACION
    SELECT *
    FROM CORRECCION_DATOS.LINEAS_RUNT LR
    WHERE NOT EXISTS (SELECT 1
                      FROM QUIPUX.QX_TIPO_LINEA TL
                      WHERE TL.RUNT_LINEA = LR.ID_LINEA);
                      --AND LR.ID_LINEA = '28824'; 
--END IF;


BEGIN

FOR X IN LINEA LOOP
  
  BEGIN
   
     /* INSERT INTO QUIPUX.QX_TIPO_LINEA 
      SELECT ID_LINEA_QX, ID_MARCA_QX, DESCRIPCION_LINEA_QX, ID_CLASE_QX,
             ID_CARROCERIA_QX, CILINDRAJE_LINEA, POTENCIA_LINEA, PUERTAS_LINEA,
             CAP_TONELADAS_LINEA, CAP_PASAJEROS_LINEA, PESO_BRUTO_LINEA, DIST_EJES_LINEA,
             VOLADIZO_LINEA, NRO_EJES_LINEA, ANCHO_LINEA, ALTO_LINEA, LARGO_LINEA,
             IMPORTADO_NACIONAL_LINEA, ID_COMBUSTIBLE, ID_ADUANA, MIN_LINEA, HDA_LINEA,
             TIPO_CAJA, TRACCION, RUNT_LINEA, ID_LINEA_MAQUINARIA
      FROM CORRECCION_DATOS.QX_TIPO_LINEA1 QXL
      WHERE QXL.ID_LINEA_QX = X.ID_LINEA_QX; */
      
      SELECT TM.ID_MARCA_QX
      INTO V_MARCA
      FROM QUIPUX.QX_TIPO_MARCA TM
      WHERE TM.RUNT_MARCA = X.ID_MARCA AND
      ROWNUM = 1;
      
      IF V_MARCA IS NULL THEN
        
        SELECT MAX(ID_MARCA_QX) + 1 
        INTO V_MARCA
        FROM QUIPUX.QX_TIPO_MARCA;
        
        INSERT INTO QUIPUX.QX_TIPO_MARCA VALUES
                    (V_MARCA, X.DESCRIPCION_MARCA,'0','0',X.ID_MARCA,'');
        
        COMMIT;
        
      END IF;
      
       SELECT MAX(ID_LINEA_QX)+ 1 
        INTO V_LINEA
        FROM QUIPUX.QX_TIPO_LINEA;
      
        INSERT INTO QUIPUX.QX_TIPO_LINEA VALUES
                    ( V_LINEA,V_MARCA, X.DESCRIPCION_LINEA,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,'N',1,0,999,0,'M','0',X.ID_LINEA,0);
 
        COMMIT;
        
      /*SELECT COUNT(1)
      INTO V_EXISTE
      FROM  QUIPUX.TIPO_LINEA TL
      WHERE TL.ID_LINEA_QX = X.ID_LINEA_QX;
      
      IF V_EXISTE < 1 THEN */
        
          SELECT MAX(ID_LINEA)+1
          INTO V_MAX 
          FROM QUIPUX.TIPO_LINEA;
      
         /* INSERT INTO QUIPUX.TIPO_LINEA (ID_LINEA,	DESC_LINEA,	ABREV_LINEA,	MIN_MARCA,	MIN_SECUENCIA_LINEA,	ID_MARCA,	ID_LINEA_QX) 
                  VALUES 
                 (V_MAX, X.DESCRIPCION_LINEA_QX, '0','0','0','0', X.ID_LINEA_QX);*/
                 
                 
            INSERT INTO QUIPUX.TIPO_LINEA (ID_LINEA,	DESC_LINEA,	ABREV_LINEA,	MIN_MARCA,	MIN_SECUENCIA_LINEA,	ID_MARCA,	ID_LINEA_QX) 
                  VALUES 
                 (V_MAX, X.DESCRIPCION_LINEA, '0','0',0,0, V_LINEA);     
          
      --END IF; 
      
  COMMIT;
  
  EXCEPTION
  WHEN OTHERS THEN
    CONTINUE;
  END;  
  
  

END LOOP;


END SP_HOMOLOGAR_LINEAS_QX;

/
--------------------------------------------------------
--  DDL for Procedure SP_INSERTA_DIGITO_VERIFICACION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_INSERTA_DIGITO_VERIFICACION" AS 
/*Autor: Elvis Alexis Betancur 13-07-2015
  Este procedimiento inserta el digito de verificaci�n a los nit de USUARIOS_TTO
  que no lo tienen
*/

V_ID_USUARIO VARCHAR2(10);
V_DIGITO VARCHAR2(1);
V_EXISTE NUMBER;
SQL_ERROR VARCHAR2(200);

CURSOR DIGITO IS
  SELECT ID_USUARIO
  FROM QUIPUX.USUARIOS_TTO 
  WHERE LENGTH (ID_USUARIO) = 9
    AND ID_DOCUMENTO = 2;
    --AND ID_USUARIO = '8600261825';

BEGIN

FOR X IN DIGITO LOOP

SELECT DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_CALCULAR_DIGITO_VERIFICA (X.ID_USUARIO) INTO V_DIGITO FROM DUAL;

V_ID_USUARIO := X.ID_USUARIO || V_DIGITO;

SELECT COUNT(1)
INTO V_EXISTE
FROM QUIPUX.USUARIOS_TTO
WHERE ID_USUARIO = V_ID_USUARIO AND ID_DOCUMENTO = 2;

BEGIN
    IF V_EXISTE = 0 THEN   
        --INSERTO EL REGISTRO CON DIGITO DE VERIFICACI�N--------------------------------------------------------------------------
        INSERT INTO QUIPUX.USUARIOS_TTO 
        SELECT V_ID_USUARIO,ID_DOCUMENTO,ID_CIUDAD,APELLIDOS,NOMBRES,DIRECCION,CIUDAD_DIR,TELEFONO,EMP_O_PART,SEXO,FECHA_NACIMIENTO,
               ID_PAIS,FMODIFICA_USUARIO,FAX,EMAIL,CELULAR,TOKEN_HUELLA,FECHA_VENCIMIENTO,FECHA_REG_INICIAL_PERSONA,ESTADO_PERSONA,
               FECHA_EXP_DOCUMENTO,LUGAR_NACIMIENTO,CODIGO_BIDIMENSIONAL_CC,RUNT_HUELLA_AUTENTICACION
        FROM QUIPUX.USUARIOS_TTO
        WHERE ID_USUARIO = X.ID_USUARIO
          AND ID_DOCUMENTO = 2;
    --ELSE
    --  CONTINUE;
    END IF;
    ---------------------------------------------------------------------------------------------------------------------------
    --ACTUALIZACI�N DE TABLAS QUE TIENEN RELACI�N CON USUARIO_TTO
    UPDATE QUIPUX.HISTORIALES_TRASPASOS SET ID_USUARIO = V_ID_USUARIO WHERE ID_USUARIO =X.ID_USUARIO;
    UPDATE QUIPUX.HISTORIALES_TRASPASOS SET ID_COMPRADOR = V_ID_USUARIO WHERE ID_COMPRADOR =X.ID_USUARIO;
    UPDATE QUIPUX.IU_LIQUIDACION_TEMP SET ID_USUARIO_QX = V_ID_USUARIO WHERE ID_USUARIO_QX =X.ID_USUARIO;
    UPDATE QUIPUX.PROPIETARIOS_VEHICULO SET ID_USUARIO = V_ID_USUARIO WHERE ID_USUARIO =X.ID_USUARIO;  
    
    --INSERTO Y ACTUALIZO EN USUARIOS_TTO DIRECCIONES Y USUARIOS_TTO_DIRECCION_FUENTE-----------------------
    INSERT INTO QUIPUX.USUARIOS_TTO_DIRECCIONES
    SELECT V_ID_USUARIO,CONSECUTIVO_DIRECCION,DIRECCION,ID_MUNICIPIO,ID_TIPO_DIRECCION,PRINCIPAL,
           TELEFONO,FAX,TELEFONO2,ACTIVA,ID_CONFIRMACION_CONTACTO,ID_DEPARTAMENTO
    FROM   QUIPUX.USUARIOS_TTO_DIRECCIONES WHERE ID_USUARIO =X.ID_USUARIO;
    
    UPDATE QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE SET ID_USUARIO = V_ID_USUARIO WHERE ID_USUARIO =X.ID_USUARIO;
    DELETE FROM QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE WHERE ID_USUARIO =X.ID_USUARIO;
      DELETE FROM QUIPUX.USUARIOS_TTO_DIRECCIONES WHERE ID_USUARIO =X.ID_USUARIO;
    ---------------------------------------------------------------------------------------------------------
    
    --INSERTO Y ACTUALIZO USUARIOS_TTO_CELULAR Y USUARIOS_TTO_CELULAR_FUENTE-----------------------------
    INSERT INTO QUIPUX.USUARIOS_TTO_CELULAR
    SELECT V_ID_USUARIO,CONSECUTIVO_CELULAR,CELULAR,ACTIVA,ID_CONFIRMACION_CONTACTO
    FROM   QUIPUX.USUARIOS_TTO_CELULAR WHERE ID_USUARIO =X.ID_USUARIO;
    
    UPDATE QUIPUX.USUARIOS_TTO_CELULAR_FUENTE SET ID_USUARIO = V_ID_USUARIO WHERE ID_USUARIO =X.ID_USUARIO;
    DELETE FROM QUIPUX.USUARIOS_TTO_CELULAR_FUENTE WHERE ID_USUARIO =X.ID_USUARIO;
    DELETE FROM QUIPUX.USUARIOS_TTO_CELULAR WHERE ID_USUARIO =X.ID_USUARIO;
    ------------------------------------------------------------------------------------------------------
    
    --INSERTO Y ACTUALIZO USUARIOS_TTO_EMAIL Y USUARIOS_TTO_EMAIL_FUENTE----------------------------------
    INSERT INTO QUIPUX.USUARIOS_TTO_EMAIL
    SELECT V_ID_USUARIO,CONSECUTIVO_EMAIL,EMAIL,ACTIVA,ID_CONFIRMACION_CONTACTO
    FROM QUIPUX.USUARIOS_TTO_EMAIL WHERE ID_USUARIO =X.ID_USUARIO;
    
    UPDATE QUIPUX.USUARIOS_TTO_EMAIL_FUENTE SET ID_USUARIO = V_ID_USUARIO WHERE ID_USUARIO =X.ID_USUARIO;
    DELETE FROM QUIPUX.USUARIOS_TTO_EMAIL_FUENTE WHERE ID_USUARIO = X.ID_USUARIO;
    DELETE FROM QUIPUX.USUARIOS_TTO_EMAIL WHERE ID_USUARIO = X.ID_USUARIO;
    -------------------------------------------------------------------------------------------------------
    
    DELETE FROM QUIPUX.USUARIOS_TTO 
    WHERE ID_USUARIO = X.ID_USUARIO AND ID_DOCUMENTO = 2;
    COMMIT;
EXCEPTION
WHEN OTHERS THEN
  SQL_ERROR := SQLERRM;
  CONTINUE;
END;  
END LOOP;

END SP_INSERTA_DIGITO_VERIFICACION;

/
--------------------------------------------------------
--  DDL for Procedure SP_INSERTAR_IC_TTP
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_INSERTAR_IC_TTP" 
IS
  V_ID_MAX NUMBER;
  V_CLASE_IDENTIFICACION  VARCHAR2(15);
  V_CONTADOR_COMMIT          NUMBER := 0;
  V_EXISTE                   NUMBER := 0;
  
  
  CURSOR CONTRIBUYENTES IS
  
    SELECT DISTINCT DSC.ID_USUARIO,
      DSC.ID_DOCUMENTO
    FROM CONTRIBUYENTE_RUNT_TOTAL DSC
    WHERE DSC.ID_USUARIO IN (SELECT CEDULA FROM TEMP_CEDULAS)
    --WHERE DSC.ID_USUARIO  IN ('15428687')
    AND DSC.ID_DIRECCION IS NOT NULL
    AND DSC.NRO_IDENTIFICADOR='EST'
    AND DSC.ID_RADICADO=5
    AND DSC.ID_DOCUMENTO IN('U','P','T','E','N','C')
    --AND ROWNUM =210
    ;

BEGIN

  V_CONTADOR_COMMIT := 0;
  
  
  FOR X IN CONTRIBUYENTES  LOOP
    
  
    BEGIN
    
      V_CONTADOR_COMMIT := V_CONTADOR_COMMIT + 1;
      V_CLASE_IDENTIFICACION:=NULL;
      V_ID_MAX:=NULL;
      --SELECCIONO LA MAXIMA DIRECCION
      SELECT MAX (TO_NUMBER(ID_DIRECCION))
      INTO V_ID_MAX
      FROM CONTRIBUYENTE_RUNT_TOTAL
      WHERE ID_USUARIO = X.ID_USUARIO
      AND ID_DOCUMENTO = X.ID_DOCUMENTO;
      
      
      --CONVIERTO EL TIPO DE IDENTIFICACION
      SELECT DISTINCT CASE WHEN CRT.ID_DOCUMENTO ='U' THEN 'RC' ELSE
        CASE WHEN CRT.ID_DOCUMENTO = 'P' THEN 'PASAP' ELSE
        CASE WHEN CRT.ID_DOCUMENTO = 'T' THEN 'TI' ELSE
        CASE WHEN CRT.ID_DOCUMENTO = 'E' THEN 'CE' ELSE
        CASE WHEN CRT.ID_DOCUMENTO = 'N' THEN 'NIT' ELSE
        CASE WHEN CRT.ID_DOCUMENTO = 'C' THEN 'CC'  
        END END END END END END CLASE_IDENTIFICACION
        INTO V_CLASE_IDENTIFICACION
        FROM CONTRIBUYENTE_RUNT_TOTAL CRT 
        WHERE CRT.ID_DOCUMENTO=X.ID_DOCUMENTO;
      
      --VERIFICO SI EL REGISTRO YA EXISTE EN LA TABLA TEMP_PLANTILLA_PERSONAS
     /* V_EXISTE := 0;
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM TEMP_PLANTILLA_PERSONAS TPP               
      WHERE X.ID_USUARIO = TPP.NRO_IDENTIFICACION
      AND V_CLASE_IDENTIFICACION=TPP.CLASE_IDENTIFICACION;
      
      --SI YA EXISTE ACTUALIZO, SINO INSERTO
            IF V_EXISTE > 0 THEN
            
              UPDATE TEMP_PLANTILLA_PERSONAS 
              SET ( 
              DIRECCION_CORRESP,
              DIRECCION_NOT_VEH,
              DIRECCION_RESIDENCIA,
              REGION,
              POBLACION,
              TELEFONO,
              TELEFONO_MOVIL,
              FAX,
              E_MAIL
              )=
              (SELECT DISTINCT TRIM(UPPER(CRT.DIRECCION)) AS DIRECCION_CORRESP,
              TRIM(UPPER(CRT.DIRECCION))       AS DIRECCION_NOT_VEH,
              TRIM(UPPER(CRT.DIRECCION))       AS DIRECCION_RESIDENCIA,
              CASE WHEN LENGTH (SC.ID_CIUDAD_SAP)=5 THEN SUBSTR(SC.ID_CIUDAD_SAP,0,2) ELSE CASE WHEN LENGTH (SC.ID_CIUDAD_SAP)=4 THEN 0 ||SUBSTR(SC.ID_CIUDAD_SAP,0,1) END END AS REGION,
              SC.ID_CIUDAD_SAP AS POBLACION,
              CRT.TELEFONO     AS TELEFONO,
              CRT.TELEFONO     AS TELEFONO_MOVIL,
              CRT.FAX          AS FAX,
              LOWER(CRT.EMAIL) AS E_MAIL
              FROM CORRECCION_DATOS.CONTRIBUYENTE_RUNT_TOTAL CRT
              LEFT JOIN QX_CIUDAD QC
              ON CRT.ID_CIUDAD_DIR=QC.MIN_CIUDAD_QX
              LEFT JOIN SAP_CIUDADES SC
              ON QC.ID_CIUDAD_QX=SC.ID_CIUDAD_QX
              WHERE CRT.ID_USUARIO= X.ID_USUARIO 
              AND CRT.ID_DOCUMENTO= X.ID_DOCUMENTO
              AND CRT.ID_DIRECCION= V_ID_MAX)
              WHERE NRO_IDENTIFICACION= X.ID_USUARIO
              AND CLASE_IDENTIFICACION=V_CLASE_IDENTIFICACION;
              
        ELSE
      */
        INSERT INTO TEMP_PLANTILLA_PERSONAS
        SELECT A.* FROM (
        SELECT DISTINCT IC.ID_INTERLOCUTOR AS INTERLOCUTOR_COMERCIAL,
        CASE WHEN CRT.ID_DOCUMENTO ='N' THEN 2 ELSE 1 END AS TIPO_INTERLOCUTOR,
        CASE WHEN CRT.ID_DOCUMENTO ='N' THEN 'PJPR' ELSE 'PNAT' END AS CLASE_INTERLOCUTOR,
        '0001' AS AGRUPACION_INTERLOCUTOR,
        '' AS NRO_INTERLOCUTOR_SIST_EXTERNO,
        CASE WHEN CRT.ID_DOCUMENTO ='N' THEN TRIM(UPPER(CRT.NOMBRES)) ELSE TRIM(UPPER(CRT.APELLIDOS)) END AS CONCEPTO_BUSQUEDA1,
        '' AS CONCEPTO_BUSQUEDA2,
        '0001' AS LAVE_TRATAMIENTO,
        '' AS PETICION_CENTRAL_ARCHIVO,
        '' AS BLOQUEO_CENTRAL,
        CASE WHEN CRT.ID_DOCUMENTO ='N' THEN TRIM(UPPER(CRT.NOMBRES)) ELSE NULL END AS NOMBRE1_ORGANIZACION,
        '' AS NOMBRE2_ORGANIZACION,
        '' AS FORMA_JURIDICA_ORG,
        '' AS SECTOR_INDUSTRIAL1,
        '' AS RAMO,
        '' AS SECTOR_INDUSTRIAL2,
        '' AS  CALIDAD_DECLARANTE,
        '' AS  F_FUNDACION_ORGANIZACION,
        '' AS  F_LIQUIDACION_ORGANIZACION,
        TRIM(UPPER(CRT.APELLIDOS)) AS APELLIDO_INTERLOCUTOR,
        CASE WHEN CRT.ID_DOCUMENTO ='N' THEN NULL ELSE TRIM(UPPER(CRT.NOMBRES))END  AS NOMBRE_PILA_INTERLOCUTOR,--OJO MODIFICAR
        '' AS  SEGUNDO_APELLIDO,
        '' AS  SEGUNDO_NOMBRE,
        'S' AS IDIOMA_CORRESPONDENCIA,
        '' AS CLAVE_SEXO,
        '' AS LUGAR_NACIMIENTO_INTERLOCUTOR,
        '' AS ESTADO_CIVIL_INTERLOCUTOR,
        'CO' AS NACIONALIDAD_INTERLOCUTOR,
        '' AS PAIS_ORIGEN,
        'S' AS IDIOMA_INTERLOCUTOR,
        '' AS F_NACIMIENTO_INTERLOCUTOR,
        '' AS F_FALLECIMIENTO_INTERLOCUTOR,
        '' AS CLASE_GRUPO,
        CASE WHEN CRT.ID_DOCUMENTO !='N' THEN 'X' ELSE NULL END AS PERSONA_FISICA,
        V_CLASE_IDENTIFICACION AS CLASE_IDENTIFICACION,
        CRT.ID_USUARIO AS NRO_IDENTIFICACION,
        'XXDEFAULT' AS CLASE_DIRECCION_CORRESP,
        TRIM(UPPER(CRT.DIRECCION)) AS DIRECCION_CORRESP,
        '' AS CLASE_DIRECCION_ESTAB,
        '' AS  DIRECCION_ESTABLE,
        '' AS  CLASE_DIRECCION_NOT,
        '' AS  DIRECCION_NOT,
        'ZNOTIFIVEH' AS CLASE_DIRECCION_NOT_VEH,
        TRIM(UPPER(CRT.DIRECCION)) AS DIRECCION_NOT_VEH,
        'ZRESIDVEHI' AS CLASE_DIRECCION_RESIDENCIA,
        TRIM(UPPER(CRT.DIRECCION)) AS  DIRECCION_RESIDENCIA,
        '' AS DISTRITO,
        'CO' AS  PAIS,
        CASE WHEN LENGTH (SC.ID_CIUDAD_SAP)=5 THEN SUBSTR(SC.ID_CIUDAD_SAP,0,2) ELSE CASE WHEN LENGTH (SC.ID_CIUDAD_SAP)=4 THEN 0||SUBSTR(SC.ID_CIUDAD_SAP,0,1) END END AS REGION, 
        SC.ID_CIUDAD_SAP AS POBLACION,
        CRT.TELEFONO AS TELEFONO,
        CRT.TELEFONO AS TELEFONO_MOVIL,
        CRT.FAX AS FAX,
        LOWER(CRT.EMAIL) AS E_MAIL,
        '' AS REGISTRO_ERROR,
        CASE WHEN IC.ID_INTERLOCUTOR IS NULL THEN 'N' ELSE 'M'END  AS TIPO_ARCHIVO,
        '' AS CAMPOS_NULL
        FROM CORRECCION_DATOS.CONTRIBUYENTE_RUNT_TOTAL CRT
        LEFT JOIN CORRECCION_DATOS.IC 
        ON CRT.ID_USUARIO=IC.DCTO_IDENTIFI
        AND V_CLASE_IDENTIFICACION =IC.CLASE_DCTO
        LEFT JOIN QX_CIUDAD QC
        ON CRT.ID_CIUDAD_DIR=QC.MIN_CIUDAD_QX 
        LEFT JOIN SAP_CIUDADES SC
        ON QC.ID_CIUDAD_QX=SC.ID_CIUDAD_QX
        WHERE CRT.ID_USUARIO=X.ID_USUARIO
        AND CRT.ID_DOCUMENTO=X.ID_DOCUMENTO
        AND CRT.ID_DIRECCION=V_ID_MAX
        ORDER BY 46,49,50,51,54 ) A
        WHERE ROWNUM =1;
     
      -- END IF;
      END;
      -- COMMIT;
      IF (V_CONTADOR_COMMIT = 100 ) THEN
                COMMIT;
                V_CONTADOR_COMMIT := 0;
       END IF;
      END LOOP;
 COMMIT;   
END SP_INSERTAR_IC_TTP;

/
--------------------------------------------------------
--  DDL for Procedure SP_INSERTAR_USUARIOS_TTO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_INSERTAR_USUARIOS_TTO" AS 

--CARGAR EN DS_TMP_CONTRIBUYENTES2 LA INFORMACION ORIGINAL ENVIADA POR RUNT

V_ID_DIRECCION NUMBER:=0;
ERROR_MSG VARCHAR(100);

CURSOR USUARIOS IS 
SELECT DISTINCT (Dt.Id_Usuario_Anterior), Dt.Id_DOCUMENTO_Anterior, DT.NRO_PLACA
FROM CORRECCION_DATOS. DS_TMP_TRAMITES1 DT
INNER JOIN CORRECCION_DATOS.INCONSISTENCIAS INC
ON DT.NRO_PLACA = Inc.Identificador
WHERE Dt.Id_Usuario_Anterior NOT IN (SELECT QT.ID_USUARIO
                                         FROM QUIPUX.USUARIOS_TTO QT 
                                         WHERE QT.ID_USUARIO = DT.Id_Usuario_Anterior)
AND INC.NOMBRE_ARCHIVO= 'TRAMITE'
AND INC.CAMPO_FALLO = 'ID_USUARIO_ANTERIOR'
AND Dt.Id_Tramite IN (16,65)
AND DT.ID_DOCUMENTO_ANTERIOR !='S';
--AND DT.NRO_PLACA = 'FLK154'; 

BEGIN
 
 FOR X IN USUARIOS LOOP
    BEGIN 
    
         SELECT MAX(TO_NUMBER(ID_DIRECCION))
         INTO V_ID_DIRECCION
         FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2
         WHERE ID_USUARIO = X.Id_Usuario_Anterior
           AND ID_DOCUMENTO = X.ID_DOCUMENTO_ANTERIOR;
      
        INSERT INTO QUIPUX.USUARIOS_TTO (ID_USUARIO, ID_DOCUMENTO, ID_CIUDAD,CIUDAD_DIR, DIRECCION,	
                                         APELLIDOS,	NOMBRES,	TELEFONO,	EMP_O_PART,	FECHA_NACIMIENTO,	SEXO,	
                                         ID_PAIS,	FAX,	EMAIL,	ESTADO_PERSONA)
        SELECT DTC.ID_USUARIO, 
              (SELECT QXD.ID_DOCUMENTO 
                FROM QUIPUX.TIPO_DOCUMENTO QXD 
                WHERE QXD.MIN_DOCUMENTO =  DTC.ID_DOCUMENTO)  AS ID_DOCUMENTO,
              (SELECT QXC.ID_CIUDAD 
                FROM QUIPUX.CIUDADES QXC 
                WHERE QXC.CIUDAD_RUNT = DTC.ID_CIUDAD) AS ID_CIUDAD,
              (SELECT QXC.ID_CIUDAD 
                FROM QUIPUX.CIUDADES QXC 
                WHERE QXC.CIUDAD_RUNT = DTC.ID_CIUDAD_DIR) AS ID_CIUDAD_DIR,              
                   DTC.DIRECCION,DTC.APELLIDOS,DTC.NOMBRES,DTC.TELEFONO, DTC.EMP_O_PART, 
                   DTC.FECHA_NACIMIENTO,DTC.SEXO, DTC.ID_PAIS, DTC.FAX, DTC.EMAIL, 'ACTIVA' AS ESTADO            
              FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2 DTC
              WHERE DTC.ID_USUARIO = X.Id_Usuario_Anterior
                AND DTC.ID_DOCUMENTO = X.ID_DOCUMENTO_ANTERIOR
                AND DTC.ID_DIRECCION = TO_CHAR(V_ID_DIRECCION);
                  COMMIT;
    
    EXCEPTION 
      WHEN OTHERS THEN
       ERROR_MSG := SQLERRM;
        DBMS_OUTPUT.PUT_LINE(ERROR_MSG); 
      --DBMS_OUPUT.PUT_LINE ();
      continue;
    END;  
    
 END LOOP;
 
 
END SP_INSERTAR_USUARIOS_TTO;

/
--------------------------------------------------------
--  DDL for Procedure SP_LISTAR_AVALUOS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_LISTAR_AVALUOS" AS 

Cursor curAvaluoHorizontal is
Select * from dq_avaluo;

BEGIN

For lnIndex in curAvaluoHorizontal loop

Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1993,Lnindex.A1993 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1994,Lnindex.A1994 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1995,Lnindex.A1995 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1996,Lnindex.A1996 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1997,Lnindex.A1997 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1998,Lnindex.A1998 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,1999,Lnindex.A1999 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2000,Lnindex.A2000 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2001,Lnindex.A2001 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2002,Lnindex.A2002 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2003,Lnindex.A2003 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2004,Lnindex.A2004 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2005,Lnindex.A2005 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2006,Lnindex.A2006 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2007,Lnindex.A2007 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2008,Lnindex.A2008 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2009,Lnindex.A2009 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2010,Lnindex.A2010 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2011,Lnindex.A2011 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2012,Lnindex.A2012 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2013,Lnindex.A2013 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2014,Lnindex.A2014 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2015,Lnindex.A2015 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2016,Lnindex.A2016 * 1000);
Insert Into Dq_Avaluo_Vertical(Grupo,Modelo,Avaluo) Values (Lnindex.Grupo,2017,Lnindex.A2017 * 1000);

Commit;

End loop;

END SP_LISTAR_AVALUOS;

/
--------------------------------------------------------
--  DDL for Procedure SP_NEW_LINEA_SAP
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_NEW_LINEA_SAP" 
(
  V_ID_MARCA IN VARCHAR2 
, V_DESC_LINEA IN VARCHAR2 

) AS 

V_ID_NEW_LINEA VARCHAR2(10);
V_RETURN VARCHAR2(100);
V_CONSECUTIVO NUMBER :=0; --Lleva el consecutivo de la linea SAP.
V_NEW_CONSECUTIVO NUMBER :=0; --Lleva el nuevo consecutivo de la linea SAP.
V_DESC_MARCA VARCHAR2(50);
V_CREAR BOOLEAN := FALSE;--Identifica cuando se cumple la validaci�n para crear.

CURSOR LINEA IS
SELECT * FROM DQ_SAP_LINEAS
WHERE ID_MARCA = V_ID_MARCA
ORDER BY CONSECUTIVO ASC;

BEGIN

FOR X IN LINEA LOOP

V_CONSECUTIVO := X.CONSECUTIVO;
V_DESC_MARCA := X.DESC_MARCA;

  IF V_CONSECUTIVO = V_NEW_CONSECUTIVO THEN
  
      V_NEW_CONSECUTIVO := V_NEW_CONSECUTIVO +1;
      
  ELSE     
  
  V_CREAR := TRUE;
  
  IF V_NEW_CONSECUTIVO < 10 THEN
    V_ID_NEW_LINEA:= V_ID_MARCA || '00' || V_NEW_CONSECUTIVO;
  ELSIF V_NEW_CONSECUTIVO > 9 AND  V_NEW_CONSECUTIVO < 100 THEN
     V_ID_NEW_LINEA:= V_ID_MARCA || '0' || V_NEW_CONSECUTIVO;
  ELSE
     V_ID_NEW_LINEA:= V_ID_MARCA ||V_NEW_CONSECUTIVO;
  END IF;   
    
    V_RETURN := V_ID_NEW_LINEA || ' ' || V_DESC_LINEA;

     INSERT INTO DQ_SAP_LINEAS (ID_MARCA, DESC_MARCA, ID_LINEA, DESC_LINEA, ACCION,CONSECUTIVO)
     VALUES (V_ID_MARCA, V_DESC_MARCA,V_ID_NEW_LINEA,V_DESC_LINEA, 'Crear', V_NEW_CONSECUTIVO);
     COMMIT;    
     EXIT;     
  END IF;
  
END LOOP;

IF V_CREAR = FALSE THEN
    
    -- V_ID_NEW_LINEA:= V_ID_MARCA || V_NEW_CONSECUTIVO;     
      IF V_NEW_CONSECUTIVO < 10 THEN
        V_ID_NEW_LINEA:= V_ID_MARCA || '00' || V_NEW_CONSECUTIVO;
      ELSIF V_NEW_CONSECUTIVO > 9 AND  V_NEW_CONSECUTIVO < 100 THEN
         V_ID_NEW_LINEA:= V_ID_MARCA || '0' || V_NEW_CONSECUTIVO;
      ELSE
         V_ID_NEW_LINEA:= V_ID_MARCA ||V_NEW_CONSECUTIVO;
      END IF; 
     
     INSERT INTO DQ_SAP_LINEAS (ID_MARCA, DESC_MARCA, ID_LINEA, DESC_LINEA, ACCION,CONSECUTIVO)
     VALUES (V_ID_MARCA, V_DESC_MARCA,V_ID_NEW_LINEA,V_DESC_LINEA, 'Crear', V_NEW_CONSECUTIVO);
     COMMIT;   


END IF;

END SP_NEW_LINEA_SAP;

/*Colocar consecutivo*/
/*
DECLARE
V_CONTADOR NUMBER :=0;
V_LARGO_MARCA NUMBER :=0;
V_LARGO_LINEA NUMBER :=0;
V_CONSECUTIVO NUMBER :=0; --Lleva el consecutivo de la linea SAP.

CURSOR LINEA IS
SELECT * FROM DQ_SAP_LINEAS;

BEGIN

FOR X IN LINEA LOOP
V_LARGO_MARCA := LENGTH(X.ID_MARCA);
V_LARGO_LINEA := LENGTH(X.ID_LINEA);
BEGIN
V_CONSECUTIVO := SUBSTR(X.ID_LINEA, V_LARGO_MARCA + 1, V_LARGO_LINEA);

UPDATE DQ_SAP_LINEAS SET CONSECUTIVO = V_CONSECUTIVO
WHERE ID_LINEA = X.ID_LINEA AND ID_MARCA = X.ID_MARCA;

EXCEPTION 
  WHEN OTHERS THEN
    UPDATE DQ_SAP_LINEAS SET ESTADO = 'ERROR'
     WHERE ID_LINEA = X.ID_LINEA AND ID_MARCA = X.ID_MARCA;
  END;  

IF V_CONTADOR = 500 THEN
   V_CONTADOR := 0;
   COMMIT;  
ELSE
   V_CONTADOR := V_CONTADOR + 1;
END IF;

END LOOP;
COMMIT;
END;
/
*/

/
--------------------------------------------------------
--  DDL for Procedure SP_PLACAS_FAL_EN_PROP_VEHI
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_PLACAS_FAL_EN_PROP_VEHI" AS

V_NRO_PLACA VARCHAR2(7);
V_ID_USUARIO VARCHAR2(15);
V_ID_DOCUMENTO NUMBER;
V_PORCENTAJE_PROP NUMBER;
V_CANTIDAD_VEHICULO NUMBER;
V_CANTIDAD_USUARIOS NUMBER;

CURSOR PLACAS_PROP IS
  SELECT DISTINCT(NRO_PLACA), ID_USUARIO, ID_DOCUMENTO, PORCENTAJE_PROP, ESTADO_VALIDACION, ID_RADICADO
  FROM DS_PROPIETARIO
  WHERE (NRO_PLACA, ID_RADICADO) IN (SELECT DV.NRO_PLACA, RADICADO
                                     FROM (SELECT DV.NRO_PLACA, MAX(ID_RADICADO) RADICADO
                                           FROM DEPURACION.DS_VEHICULO DV
                                           WHERE DV.ESTADO_VALIDACION = 'RA'
                                           GROUP BY DV.NRO_PLACA) DV
                                    WHERE NOT EXISTS (SELECT 1 FROM QUIPUX.PROPIETARIOS_VEHICULO PV
                                                      WHERE DV.NRO_PLACA = PV.NRO_PLACA)) AND
      ESTADO_VALIDACION = 'RA' AND
      PORCENTAJE_PROP IS NOT NULL
      ORDER BY 1;	 
BEGIN

  FOR X IN PLACAS_PROP LOOP
    
    V_NRO_PLACA := X.NRO_PLACA;
    V_ID_USUARIO := X.ID_USUARIO;
    V_ID_DOCUMENTO := X.ID_DOCUMENTO;
    V_PORCENTAJE_PROP := X.PORCENTAJE_PROP;
    
    BEGIN
    
      SELECT COUNT(1)
      INTO V_CANTIDAD_VEHICULO
      FROM QUIPUX.LIC_TTO
      WHERE NRO_PLACA = V_NRO_PLACA;
    
    EXCEPTION 
      WHEN OTHERS THEN
        CONTINUE;
    END;
    
    BEGIN
    
      SELECT COUNT(1)
      INTO V_CANTIDAD_USUARIOS
      FROM QUIPUX.USUARIOS_TTO
      WHERE ID_USUARIO = V_ID_USUARIO AND 
            ID_DOCUMENTO = V_ID_DOCUMENTO;
      
    EXCEPTION 
      WHEN OTHERS THEN
        CONTINUE;
    END;
    
    IF V_ID_DOCUMENTO = 10 THEN
      V_CANTIDAD_USUARIOS := 1;
      V_ID_USUARIO := 5134;
    END IF;
    
    IF V_CANTIDAD_VEHICULO = 1 AND V_CANTIDAD_USUARIOS = 1 THEN
      
      BEGIN

        INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) VALUES (V_NRO_PLACA, V_ID_USUARIO, V_PORCENTAJE_PROP);
      
      EXCEPTION 
        WHEN OTHERS THEN
          ROLLBACK;
          CONTINUE;
      END;
      
      COMMIT;
    END IF;
    
  END LOOP;
  
END SP_PLACAS_FAL_EN_PROP_VEHI;

/
--------------------------------------------------------
--  DDL for Procedure SP_PLANTILLA_TRASPASOS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."SP_PLANTILLA_TRASPASOS" AS
  
  V_FECHA_DESDE     VARCHAR2(15);
  V_FECHA_HASTA     VARCHAR2(15);
  V_DOC_ANTERIOR    VARCHAR2(5);
  V_DOC_NUEVO       VARCHAR2(5);
  V_NOMBRE_ANTERIOR VARCHAR2(80);
  V_NOMBRE_NUEVO    VARCHAR2(80);
  V_FECHA_TRAMITE   VARCHAR2(80);
  V_CONTADOR        NUMBER(9);
  V_EXISTE_MI       NUMBER(2);
  
  CURSOR TRASPASOS IS
    SELECT DISTINCT
      Z.NRO_PLACA,
      --TO_DATE(Z.FECHA_TRAMITE) AS FECHA,
      Z.FECHA_TRAMITE,
      Z.ID_TRAMITE,
      --Z.NOMBRE_TRAMITE,
      Z.ID_DOCUMENTO_ANTERIOR,
      Z.ID_USUARIO_ANTERIOR,
      Z.ID_DOCUMENTO_NUEVO,
      Z.ID_USUARIO_NUEVO,
      Z.PORCENTAJE_PROP
    FROM TRAMITES_RUNT_TOTAL Z
    WHERE Z.ID_TRAMITE IN (65, 16)
    --AND Z.NRO_PLACA IN ('MIY232')
    
    --TRABAJAR SOLO CON LOS DE ENERO A MARZO
    AND TO_CHAR(TO_DATE (Z.FECHA_TRAMITE, 'DDMMYYYY'),'YYYY')='2015'
    AND Z.FECHA_ENVIO_INFO NOT IN('2015_06 JUNIO PRIMERA QUINCENA',
    '2015_05 MAYO SEGUNDA QUINCENA',
    '2015_05 MAYO PRIMERA QUINCENA',
    '2015_04 ABRIL SEGUNDA QUINCENA',
    '2015_04 ABRIL PRIMERA QUINCENA')

    ORDER BY Z.NRO_PLACA,TO_DATE(Z.FECHA_TRAMITE);

BEGIN
  V_CONTADOR := 0;
  FOR X IN TRASPASOS LOOP
    
    V_CONTADOR:=V_CONTADOR+1;
    
    --OBTENGO LA FECHA DESDE DE UN TRAMITE DE TRASPASO ANTERIOR DONDE EL COMPRADOR AHORA SEA EL VENDEDOR
    SELECT TO_CHAR(MAX(TO_DATE(TRT.FECHA_TRAMITE)),'YYYYMMDD')
    INTO V_FECHA_DESDE
    FROM TRAMITES_RUNT_TOTAL TRT
    WHERE TRT.NRO_PLACA               =X.NRO_PLACA
    AND TO_DATE(TRT.FECHA_TRAMITE)<=TO_DATE(X.FECHA_TRAMITE)
    AND TRT.ID_USUARIO_NUEVO=X.ID_USUARIO_ANTERIOR
    AND TRT.ID_DOCUMENTO_NUEVO=X.ID_DOCUMENTO_ANTERIOR
    AND TRT.ID_TRAMITE           IN (65, 16);
    
    --SINO OBTENGO FECHA DE UN TRAMITE ANTERIOR BUSCO POR MI O MODELO
    IF V_FECHA_DESDE IS NULL THEN
      
      --VALIDO SI EXISTE UN MATRICULA INICIAL PARA ESE VEHICULO
      SELECT COUNT(1)
      INTO V_EXISTE_MI
      FROM TRAMITES_RUNT_TOTAL TRT
      WHERE TRT.NRO_PLACA   =X.NRO_PLACA
      AND TRT.ID_TRAMITE=9;
      
      --SI EXISTE UNA MI OBTENGO LA DIRECCION DE LA FECHA DE MI
      IF V_EXISTE_MI >0 THEN
        
        BEGIN
        
          SELECT TO_CHAR(TO_DATE(TRT.FECHA_TRAMITE),'YYYYMMDD')
          INTO V_FECHA_DESDE
          FROM TRAMITES_RUNT_TOTAL TRT
          WHERE TRT.NRO_PLACA     =X.NRO_PLACA
          AND TRT.ID_TRAMITE IN (9);
        
        EXCEPTION
        WHEN OTHERS THEN
          V_FECHA_DESDE := NULL;
        END;
        --SI EL VEHICULO NO PRESENTA NI TRASPASOS ANTERIORES NI MI LA FECHA DESDE SE COMPONE CON EL MODELO DEL VEHICULO.
      ELSE
        BEGIN
          SELECT NVL(OC.MODELO||'0101','19000101')
          INTO V_FECHA_DESDE
          FROM PLANTILLA_OC OC
          WHERE OC.NRO_PLACA=X.NRO_PLACA;
          
        EXCEPTION
        WHEN OTHERS THEN
          V_FECHA_DESDE := NULL;
        END;
      END IF;
    END IF;
    
    --CONVIERTO EL TIPO DE IDENTIFICACION DEL VENDEDOR
    IF X.ID_DOCUMENTO_ANTERIOR    = 'C' THEN --CEDULA
      V_DOC_ANTERIOR             := 'CC';
    ELSIF X.ID_DOCUMENTO_ANTERIOR = 'N' THEN --NIT
      V_DOC_ANTERIOR             := 'NIT';
    ELSIF X.ID_DOCUMENTO_ANTERIOR = 'T' THEN --TARJETA IDENTIDA
      V_DOC_ANTERIOR             := 'TI';
    ELSIF X.ID_DOCUMENTO_ANTERIOR = 'P' THEN --PASAPORTES
      V_DOC_ANTERIOR             := 'PASAP';
    ELSIF X.ID_DOCUMENTO_ANTERIOR = 'E' THEN --CEDULA DE EXTRANJERIA
      V_DOC_ANTERIOR             := 'CE';
    ELSIF X.ID_DOCUMENTO_ANTERIOR = 'U' THEN --REGISTRO CIVIL
      V_DOC_ANTERIOR             :='RC';
    END IF;
    
    --CONVIERTO EL TIPO DE IDENTIFICACION DEL COMPRADOR
    IF X.ID_DOCUMENTO_NUEVO    = 'C' THEN --CEDULA
      V_DOC_NUEVO             := 'CC';
    ELSIF X.ID_DOCUMENTO_NUEVO = 'N' THEN --NIT
      V_DOC_NUEVO             := 'NIT';
    ELSIF X.ID_DOCUMENTO_NUEVO = 'T' THEN --TARJETA IDENTIDA
      V_DOC_NUEVO             := 'TI';
    ELSIF X.ID_DOCUMENTO_NUEVO = 'P' THEN --PASAPORTES
      V_DOC_NUEVO             := 'PASAP';
    ELSIF X.ID_DOCUMENTO_NUEVO = 'E' THEN --CEDULA DE EXTRANJERIA
      V_DOC_NUEVO             := 'CE';
    ELSIF X.ID_DOCUMENTO_NUEVO = 'U' THEN --REGISTRO CIVIL
      V_DOC_NUEVO             :='RC';
    END IF;
    
    --OBTENGO EL NOMBRE PARA LOS VENDEDORES
    IF V_DOC_ANTERIOR ='NIT' THEN
      
      BEGIN
        SELECT TPP.NOMBRE1_ORGANIZACION
        INTO V_NOMBRE_ANTERIOR
        FROM TEMP_PLANTILLA_PERSONAS TPP
        WHERE TPP.NRO_IDENTIFICACION    =X.ID_USUARIO_ANTERIOR
        AND TPP.CLASE_IDENTIFICACION=V_DOC_ANTERIOR;
      
      EXCEPTION
      WHEN OTHERS THEN
        V_NOMBRE_ANTERIOR := NULL;
      END;
      
    ELSE
      BEGIN
        SELECT TPP.NOMBRE_PILA_INTERLOCUTOR||' '||TPP.APELLIDO_INTERLOCUTOR
        INTO V_NOMBRE_ANTERIOR
        FROM TEMP_PLANTILLA_PERSONAS TPP
        WHERE TPP.NRO_IDENTIFICACION    =X.ID_USUARIO_ANTERIOR
        AND TPP.CLASE_IDENTIFICACION=V_DOC_ANTERIOR;
      
      EXCEPTION
      WHEN OTHERS THEN
        V_NOMBRE_ANTERIOR := NULL;
      END;
    END IF;
    
    --OBTENGO EL NOMBRE PARA LOS COMPRADORES
    IF V_DOC_NUEVO ='NIT' THEN
      
      BEGIN
        SELECT TPP.NOMBRE1_ORGANIZACION
        INTO V_NOMBRE_NUEVO
        FROM TEMP_PLANTILLA_PERSONAS TPP
        WHERE TPP.NRO_IDENTIFICACION    =X.ID_USUARIO_NUEVO
        AND TPP.CLASE_IDENTIFICACION=V_DOC_NUEVO;
      
      EXCEPTION
      WHEN OTHERS THEN
        V_NOMBRE_NUEVO := NULL;
      END;
      
    ELSE
      BEGIN
      
        SELECT TPP.NOMBRE_PILA_INTERLOCUTOR||' '||TPP.APELLIDO_INTERLOCUTOR
        INTO V_NOMBRE_NUEVO
        FROM TEMP_PLANTILLA_PERSONAS TPP
        WHERE TPP.NRO_IDENTIFICACION    =X.ID_USUARIO_NUEVO
        AND TPP.CLASE_IDENTIFICACION=V_DOC_NUEVO;
      
      EXCEPTION
      WHEN OTHERS THEN
        V_NOMBRE_NUEVO := NULL;
      END;
    END IF;
    
    --OBTENGO LA FECHA HASTA DEL COMPRADOR
    SELECT TO_CHAR(MIN(TO_DATE(TRT.FECHA_TRAMITE)),'YYYYMMDD')
    INTO V_FECHA_HASTA
    FROM TRAMITES_RUNT_TOTAL TRT
    WHERE TRT.NRO_PLACA               =X.NRO_PLACA
    AND TO_DATE(TRT.FECHA_TRAMITE)>=TO_DATE(X.FECHA_TRAMITE)
    AND TRT.ID_TRAMITE           IN (65, 16)
    AND TRT.ID_USUARIO_ANTERIOR= X.ID_USUARIO_NUEVO
    AND TRT.ID_DOCUMENTO_ANTERIOR= X.ID_DOCUMENTO_NUEVO;
    
    --CONVIERTO EL FORMATO DE LA FECHA DE TRAMITE AL REQUERIDO POR LA PLANTILLA YYYYMMDD
    V_FECHA_TRAMITE:= TO_CHAR(TO_DATE(X.FECHA_TRAMITE) ,'YYYYMMDD');
    
    --INSERTO LA INFORMACION DEL VENDEDOR EN LA TABLA TEMP_NOVEDADES_TRASPASOS
    INSERT INTO TEMP_NOVEDADES_TRASPASOS VALUES
      ( X.NRO_PLACA, V_NOMBRE_ANTERIOR,V_DOC_ANTERIOR, X.ID_USUARIO_ANTERIOR, X.PORCENTAJE_PROP, V_FECHA_DESDE, V_FECHA_TRAMITE, V_CONTADOR );
    
    V_CONTADOR := V_CONTADOR+1;
    
    --INSERTO LA INFORMACION DEL COMPRADOR EN LA TABLA TEMP_NOVEDADES_TRASPASOS
    --OBS: Si no se requiere la fecha hasta para el comprador se debe cambiar la variable V_FECHA_HASTA por NULL.
    INSERT INTO TEMP_NOVEDADES_TRASPASOS VALUES
      ( X.NRO_PLACA, V_NOMBRE_NUEVO, V_DOC_NUEVO, X.ID_USUARIO_NUEVO, X.PORCENTAJE_PROP, V_FECHA_TRAMITE, V_FECHA_HASTA, V_CONTADOR );
      
    COMMIT;
    
  END LOOP;
  
END SP_PLANTILLA_TRASPASOS ;

/
--------------------------------------------------------
--  DDL for Procedure VERIFICAR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "CORRECCION_DATOS"."VERIFICAR" AS 
N number:=31;
I number:=0;
formula number:=0;
mostrar varchar2(500):='';
p number:=0;
bandera number:=0;
BEGIN
FOR i1 IN reverse 2..N-2 loop

--formula := formula + (N1**I);
--mostrar := mostrar || (N1||'^'||I||' ');
mostrar :=null;
formula:=0;
for i2 in 0..N loop
      mostrar := mostrar || (i1||'^'||i2||' ');
      formula := formula + (i1**i2);
            if formula = N then
            --p:= N;
             DBMS_OUTPUT.PUT_LINE(mostrar||chr(10));
             bandera:=1;
             exit;
         
            end if ;
          
           -- if formula < N then
           -- I := I+1;
  
           -- end if ;                             
end loop;
end loop;
if bandera=0 then
DBMS_OUTPUT.PUT_LINE('dont');
end if;
END VERIFICAR;

/
--------------------------------------------------------
--  DDL for Package IF_MOVIMIENTO_VH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."IF_MOVIMIENTO_VH" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
 PROCEDURE GENERA_PLANTILLA (V_A�O1 NUMBER, V_MES1 VARCHAR2);   -- GENERA LA PLANTILLA DE MOVIMIENTOS
 PROCEDURE MOVIMIENTO_VH (V_A�O1 NUMBER, V_MES1 VARCHAR2);   -- DETERMINA LOS MOVIMIENTOS REALIZADOS DE ACUERDO AL REPORTE DE NOVEDADES
 PROCEDURE MATR_INICIALES (V_A�O1 NUMBER, V_MES1 VARCHAR2);     -- PERMITE CALCULAR EL NUMERO DE MATRICULAS INICIALES, Y VEHICULOS CREADOS DE ACUERDO AL REPORTE DE OC
 /*PROCEDURE PARUE_AUT (V_A�O1 NUMBER, V_MES1 VARCHAR2);*/   -- PERMITE CALCULAR EL PARQUE AUTOMOTOR ANTES DE UN MES A�O
 FUNCTION FT_CONSULTAR_MES(V_MES1 VARCHAR2) RETURN VARCHAR2;
  

END IF_MOVIMIENTO_VH;

/
--------------------------------------------------------
--  DDL for Package IF_VAL_ARCHIVO_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."IF_VAL_ARCHIVO_RUNT" AS 


PROCEDURE IF_ESTA_DOCUEMNTO;

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

END IF_VAL_ARCHIVO_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_ACTUALIZAR_SECRETARIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_ACTUALIZAR_SECRETARIA" AS 

  PROCEDURE SP_ACTUALIZAR_REGISTROS;

END PKG_ACTUALIZAR_SECRETARIA;

/
--------------------------------------------------------
--  DDL for Package PKG_DEPURAR_INCONSISTENCIAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_DEPURAR_INCONSISTENCIAS" AS 
    
    --Indica el orden de ejcuci�n de los procedimeintos
    PROCEDURE SP_ORDEN_EJECUCION;

    PROCEDURE SP_PORCENTAJE_TRAMITE;
    PROCEDURE SP_PORCENTAJE_PROPIETARIO;
    PROCEDURE SP_DEPURAR_PROPIETARIO;
    PROCEDURE SP_ELIMINAR_PROPIETARIOS_ANT;
    
    --Corrige los errores de Id_Secretaria y Id_Secretaria_Destino
    PROCEDURE SP_ID_SECRETARIA_TRAMITE; 
    PROCEDURE SP_RECORRER (PR_PLACA VARCHAR2);
    PROCEDURE SP_CUATRO_TRAMITES_PROP (PLACA VARCHAR2); 
    
    --Corrige los errores por NOMBRE_LINEA del archivo de Vehiculos.
    PROCEDURE SP_HOMOLOGAR_LINEAS;
    
    PROCEDURE SP_CAPACIDAD_TONELADAS;
    PROCEDURE SP_ESTANDARIZAR_CONTRIBYENTES2;
 

END PKG_DEPURAR_INCONSISTENCIAS;

/
--------------------------------------------------------
--  DDL for Package PKG_DEPURAR_INFO_UNE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_DEPURAR_INFO_UNE" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
PROCEDURE SP_ESTANDARIZAR;
PROCEDURE SP_VALIDACIONES_NEGOCIO;
PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2, PARAMETRO NUMBER);
PROCEDURE SP_ACTUALIZAR_DIRECCION (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2);
PROCEDURE SP_ACTUALIZAR_TELEFONO (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2);
PROCEDURE SP_ACTUALIZAR_EMAIL (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2);
PROCEDURE SP_ACTUALIZAR_CELULAR;
PROCEDURE SP_ACTUALIZAR_PLANTILLA;
END PKG_DEPURAR_INFO_UNE;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_ESTANDARIZA_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_DS_ESTANDARIZA_RUNT" AS 

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_ESTANDARIZA_REGISTROS"
    AUTOR:          FRANCISCO ARBELAEZ
    FECHA CREACION: 22/07/2013
    DESCRIPCION:    PAQUETE PARA CORREGIR INCONSISTENCIAS EN LOS DATOS DE LOS CONTRIBUYENTES

    PARAMETROS:     NINGUNO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_ESTANDARIZAR_RADICADO: PROCEDIMIENTO MAESTRO DE INVOCACION Y ACTUALIZACION DE DATOS
                                              EN LOS CONTRIBUYENTES.
                    FT_ESTANDARIZAR_DIRECCION: ESTANDARIZA LA DIRECCION DE MANERA LEGIBLE EN ABREVIATURAS Y FORMATO ADECUADO.
                    FT_ESTANDARIZAR_NOM_APE: ESTANDARIZA LOS NOMBRES, QUITANDO CUALQUIER CARACTER ESPECIAL.
                    FT_ESTANDARIZAR_TELEFONO: ESTANDARIZA FORMATO, LONGITUDES
                    FT_ESTANDARIZAR_IDENTIFICACION: ESTANDARIZA EL FORMATO DE DOCUMENTO.
                    FT_CALCULAR_DIGITO_VERIFICA: SE CALCULA EL DIGITO DE VERIFICACION PARA LAS EMPRESAS SOLO APLICA AL TIPO NIT
                    FT_SEPARAR_PALABRAS_NUMEROS: SEPARAR NUMEROS DE LETRAS
                    FT_ELIMINAR_CARACTERES_ESPEC: QUITAR CUALQUEIR CARACTER ESPECIAL NO PERMITIDO.
                    FT_ELIMINAR_ESPACIOS: ELIMINAR ESPACIOS INNECESARIOS.
                    FT_ES_NUMERO: VERIFICA QUE LA CADENA EVALUADA SOLO TENGA DATOS NUMERICOS.
                    FT_CONSULTAR_SINONIMO: CONSULTA LA ABREVIATURA PARA LA DIRECCION, DE ACUERDO A LA TABLA DS_SINONIMO_DIRECCION.
                          
    RETORNA:        GUARDADO EN TABLA DS_CONTRIBUYENTE_ESTANDAR : DATOS CORREGIDOS.
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 22/07/2013   ||FRANCISCO ARBELAEZ        ||CREACION DEL PAQUETE.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES DE VALIDACIONES.
 09/04/2014   ||FERNANDO BONILLA          ||MEJORAS A FUNCIONALIDADES Y DOCUMENTACI�N.
*/

  FUNCTION FT_CONSULTAR_SINONIMO(A_PALABRA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ES_NUMERO(A_CARACTER VARCHAR2) RETURN NUMBER;
  FUNCTION FT_ELIMINAR_ESPACIOS(A_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ELIMINAR_CARACTERES_ESPEC(A_CADENA VARCHAR2, A_TIPO_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_SEPARAR_PALABRAS_NUMEROS(A_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_CALCULAR_DIGITO_VERIFICA(A_NIT NUMBER) RETURN NUMBER;
  
  FUNCTION FT_ESTANDARIZAR_IDENTIFICACION(A_IDENTIFICACION VARCHAR2, A_ID_DOCUMENTO VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ESTANDARIZAR_TELEFONO(A_TELEFONO VARCHAR2) RETURN VARCHAR2;--PENDIENTE
  FUNCTION FT_ESTANDARIZAR_NOM_APE(A_NOMBRE_APELLIDO VARCHAR2, A_TIPO VARCHAR) RETURN VARCHAR2;--PENDIENTE
  FUNCTION FT_ESTANDARIZAR_DIRECCION(A_DIRECCION VARCHAR2) RETURN VARCHAR2;--PENDIENTE
  
  PROCEDURE SP_ESTANDARIZAR_RADICADO(A_ID_RADICADO NUMBER);
  
END PKG_DS_ESTANDARIZA_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_GENERAR_PLANTILLA_HT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_HT" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
PROCEDURE SP_GENERAR_PL_TRASPASOS;
PROCEDURE SP_INGRESAR_TRASPASO (V_NRO_PLACA VARCHAR2, V_CANT NUMBER);

PROCEDURE SP_GENERAR_PL_TRASPASOS_DS;
PROCEDURE SP_INGRESAR_TRASPASO_DS (V_NRO_PLACA VARCHAR2, V_CANT NUMBER);
END PKG_GENERAR_PLANTILLA_HT;

/
--------------------------------------------------------
--  DDL for Package PKG_GENERAR_PLANTILLA_IC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_IC" AS 

  /******************************************************************************************************/
  --ARM ROSTER
  PROCEDURE SP_INSERTAR_REGISTRO;--PROCEDIMEINTO QUE DESENCADENA LOS DEMAS
  FUNCTION FT_CONVERT_DOC( V_TIPO_DOC1 VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_HOMOLOGAR_SECRETARIA (PARAMETRO VARCHAR2, CODIGO VARCHAR2) RETURN VARCHAR2;

  --VALIDATION OF BUSINESS
  PROCEDURE SP_VALIDACIONES_NEGOCIO;
  FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER) RETURN NUMBER;
  PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER);
  FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2) RETURN NUMBER;
  FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER) RETURN NUMBER;
  PROCEDURE SP_CAMPOS_NULL;
  PROCEDURE SP_VALIDACIONES_NEGOCIO_SAP;
  /***********************************************************************************************************/
  PROCEDURE VALIDAR_USUARIO;
  FUNCTION FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_ID_DOCUMENTO NUMBER, A_IDENTIFICACION VARCHAR2, OPCION VARCHAR2) RETURN BOOLEAN;
  /***********************************************************************************************************/
  --ARM ROSTER ASOCIAR_IC_A_OC
  PROCEDURE SP_ASOCIAR_IC_A_OC;
  
  /************************************************************************************************************/
 
 
 
END PKG_GENERAR_PLANTILLA_IC;

/
--------------------------------------------------------
--  DDL for Package PKG_GENERAR_PLANTILLA_IC_QUINC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_IC_QUINC" AS 

 
PROCEDURE PS_INSERTAR_REGISTROS;
PROCEDURE SP_VALIDACIONES_NEGOCIO;
PROCEDURE PS_INSERTAR2;
PROCEDURE SP_CAMPOS_NULL;
PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER);
FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2)RETURN VARCHAR2;
FUNCTION FT_INSERTAR2 (USUARIO VARCHAR2, DOCUMENTO VARCHAR2)RETURN VARCHAR2;
 
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

END PKG_GENERAR_PLANTILLA_IC_QUINC;

/
--------------------------------------------------------
--  DDL for Package PKG_GENERAR_PLANTILLA_VH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_VH" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE SP_GENERAR_PLANTILLA (V_A�O NUMBER, V_MES VARCHAR2);
  PROCEDURE SP_TOTALES (V_A�O1 NUMBER, V_MES1 VARCHAR2);
END PKG_GENERAR_PLANTILLA_VH;

/
--------------------------------------------------------
--  DDL for Package PKG_GENERAR_PL_IC2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_GENERAR_PL_IC2" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE SP_INSERTAR_REGISTRO;
  FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2;

END PKG_GENERAR_PL_IC2;

/
--------------------------------------------------------
--  DDL for Package PKG_PLANTILLA_IC_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_PLANTILLA_IC_TTO" AS

  /* TODO enter package declarations (types, exceptions, methods etc) here */ FUNCTION ft_generar_excepcion(parametro NUMBER) RETURN VARCHAR2;
  PROCEDURE sp_insertar_usuarios;
  PROCEDURE sp_no_reporta;
END pkg_plantilla_ic_tto;

/
--------------------------------------------------------
--  DDL for Package PKG_PLANTILLA_OC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_PLANTILLA_OC" AS 


  PROCEDURE SP_GENERAR_PLANTILLA_OC;
  PROCEDURE SP_DENOMINACION_OBJETO (NRO_PLACA VARCHAR2, ID_MARCA VARCHAR2, CILINDRAJE VARCHAR2, LINEA VARCHAR2, CLASE VARCHAR2);
  PROCEDURE SP_LINEA (NRO_PLACA VARCHAR2, ID_MARCA VARCHAR2, CILINDRAJE VARCHAR2, LINEA VARCHAR2, CLASE VARCHAR2);
  PROCEDURE SP_CLASE (NRO_PLACA VARCHAR2, CLASE VARCHAR2);
  PROCEDURE SP_CARROCERIA (NRO_PLACA VARCHAR2, CARROCERIA VARCHAR2);
  PROCEDURE SP_TARIFA (NRO_PLACA VARCHAR2, AVALUO VARCHAR2);
  PROCEDURE SP_AVALUO (NRO_PLACA VARCHAR2, VALOR_FACTURA VARCHAR2, TIPO_ARCHIVO VARCHAR2);
  PROCEDURE SP_UNIDAD_TRANSITO (NRO_PLACA VARCHAR2, SECRETARIA VARCHAR2);
  PROCEDURE SP_VALIDACIONES_PLANTILLA;
  
  FUNCTION  FT_PLACA (NRO_PLACA VARCHAR2) RETURN VARCHAR2;
  FUNCTION  FT_NRO_IDENTIFICACION (NRO_PLACA VARCHAR2) RETURN VARCHAR2;
  FUNCTION  FT_USO (ID_SERVICIO VARCHAR2) RETURN VARCHAR2;
  FUNCTION  FT_TIPO_DE_CARGA (CAP_PASAJEROS VARCHAR2, CAP_TONELADAS VARCHAR2) RETURN VARCHAR2;
  
END PKG_PLANTILLA_OC;

/
--------------------------------------------------------
--  DDL for Package PKG_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_PROPIETARIOS" AS 

  /* Permite actualizar la tabla propietarios vehiculos del esquema quipux
     de los automotores que fallan el insert en esta tabla durante el proceso
     de sostenibilidad*/
     PROCEDURE PS_ACTUALIZAR_DE_TRASPASO;
     PROCEDURE PS_ACTUALIZAR_DE_DSTRAMITE;
     

END PKG_PROPIETARIOS;

/
--------------------------------------------------------
--  DDL for Package PKG_PROPIETARIO_X_VIGENCIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_PROPIETARIO_X_VIGENCIA" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
PROCEDURE DETERMINAR_PROPIETARIO; 
PROCEDURE SP_VENDEDOR_2014(V_NRO_PLACA VARCHAR2, V_FECHA VARCHAR2, V_VIGENCIA NUMBER, PARAMETRO VARCHAR2);
PROCEDURE SP_PROPIETARIO_2014(V_NRO_PLACA VARCHAR2, V_VIGENCIA NUMBER);
PROCEDURE SP_PROPIETARIO_VEHICULO (V_NRO_PLACA VARCHAR2, V_VIGENCIA NUMBER);
PROCEDURE SP_VENDEDOR_HT(V_NRO_PLACA VARCHAR2, V_FECHA VARCHAR2, V_VIGENCIA NUMBER);
END PKG_PROPIETARIO_X_VIGENCIA;

/
--------------------------------------------------------
--  DDL for Package PKG_QAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_QAS" AS 
PROCEDURE QAS_CARACTERISTICAS2;
PROCEDURE QAS_NOVEDADES;
FUNCTION SP_ID_RADICADO_MAX (Placa Varchar) Return Number;

End PKG_QAS;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACIONES_REGISTRO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDACIONES_REGISTRO" AS 

  -- VALIDACIONES DEL CONTRIBUYENTE
  FUNCTION FT_EXISTE_CONTRIBUYENTE(A_ID_USUARIO VARCHAR2, A_NRO_PLACA VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TIPO_DOCUMENTO(A_ID_DOCUMENTO NUMBER,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_EMP_PART(A_EMP_PART VARCHAR2,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_SEXO(A_SEXO VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_FECHA_NACIMIENTO(A_FECHA_NACIMIENTO VARCHAR2,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2,V_ID VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDA_FECHA_ACTUALIZACION(A_ID_USUARIO VARCHAR2, A_FECHA DATE) RETURN BOOLEAN; 
  FUNCTION FT_VALIDAR_APELLIDOS(A_ID_DOCUMENTO NUMBER, A_APELLIDOS VARCHAR2,V_ID VARCHAR2) RETURN BOOLEAN;
  
  
  PROCEDURE SP_GENERAR_EXCEPCION (V_TABLA VARCHAR2, V_INCONSITENCIA NUMBER, V_ID VARCHAR2);
  
  Procedure SP_INCONSISTENCIA2;

END PKG_VALIDACIONES_REGISTRO;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_IDENTIFICACION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDACION_IDENTIFICACION" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE SP_VALIDAR_IDENTIFICACION;
  PROCEDURE SP_VALIDAR_IDENTIFICACION_II;
  PROCEDURE SP_DIVIDIR_NOMBRE_SAP;
  PROCEDURE SP_DIVIDIR_NOMBRE_RUNT;
  PROCEDURE SP_INSERT_ERROR_DIGITO;
  FUNCTION FT_DESGLOSAR_ID(V_ID1 VARCHAR2, V_ID2 VARCHAR2) RETURN NUMBER;
  FUNCTION FT_ORDENAR_ID(V_ID1 VARCHAR2, V_ID2 VARCHAR2) RETURN NUMBER;
END PKG_VALIDACION_IDENTIFICACION;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_NOVEDADES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDACION_NOVEDADES" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  
  PROCEDURE SP_VALIDAR_PAGOS;         
  FUNCTION FT_VALIDO_NOVEDAD (J_PLACA VARCHAR2, J_VIGECIA VARCHAR2)RETURN NUMBER;
  FUNCTION FT_DETERMINA_ESTADO(J_NOVEDAD NUMBER,J_VIGENCIA VARCHAR2,J_FECHA_NOVEDAD DATE,J_VIG_ACTIVA VARCHAR2,J_DESDE DATE,J_HASTA DATE)RETURN NUMBER;
  FUNCTION FT_VALIDA_CONDONACION_PRESCR(J_PLACA VARCHAR2, J_VIGECIA VARCHAR2)RETURN NUMBER;

END PKG_VALIDACION_NOVEDADES;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_PLANTILLAS_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDACION_PLANTILLAS_SAP" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
/*
Estandarizar las direciones 
eliminar espacios
comparar direcciones, telefonos, email, municipio, departamento

*/
PROCEDURE SP_VALIDAR_IC;
PROCEDURE SP_VALIDAR_OC;
PROCEDURE SP_INSERTAR_OC_SAP_ACTUALIZADO;
PROCEDURE SP_INSERTAR_IC_SAP_ACTUALIZADO;
PROCEDURE SP_INSERT_IC_SAP_ACTUALIZA_N;
PROCEDURE SP_INSERTAR_PLANTILLA_OC_RUNT;
PROCEDURE SP_QA_ACTUALIZACION_OC_SAP;
PROCEDURE SP_QA_ACTUALIZACION_IC_SAP;
PROCEDURE SP_QA_ACTUALIZACION_IC_SAP_N;
PROCEDURE SP_QA_ACTUALIZACION_OC_SAP2015;
PROCEDURE SP_INSERTAR_OC_SAP_ACT_2015;
PROCEDURE SP_INSERTAR_PLANT_OC_RUNT_15;
FUNCTION FT_ASIGNAR_# (V_CADENA VARCHAR2)RETURN VARCHAR2; 
END PKG_VALIDACION_PLANTILLAS_SAP;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_PLANT_SAP_2015
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDACION_PLANT_SAP_2015" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
PROCEDURE SP_VALIDAR_PLANTILLA_2015;
PROCEDURE SP_ESTANDARIZAR_REGISTRO;
PROCEDURE SP_VALIDACIONES_NEGOCIO;
PROCEDURE SP_VALIDACIONES_NEGOCIO_II;
PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER);
END PKG_VALIDACION_PLANT_SAP_2015;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_CARGA_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VALIDAR_CARGA_RUNT" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  Function Ft_Validar_Sinonimo(lvDescripcionRunt Varchar2, 
                               lvDescripcionSap Varchar2) Return Boolean;
                               
  Function Ft_Get_TipoCarga(lvIdCarroceria Varchar2, 
                            lvIdClase Varchar2) Return Varchar2;
                            
  Function Ft_Estado_Propietario(lfNroPlaca varchar2, lfidPropietario varchar2,
                               lftipoDocumento varchar2)return Varchar2;
  
  Function Ft_Estado_Propietario_Sap(lfNroPlaca varchar2, lfidPropietario varchar2,
                               lftipoDocumento varchar2)return Varchar2;
  
  Function Ft_Asociacion_Posterior(lfNroPlaca varchar2, lfidPropietario varchar2,                                    
                       lftipoDocumento varchar2,lfFecha date)return boolean; 
  
  Function Ft_Homologar_Tipo_Documento(lfTipoDocumento varchar2, 
                                    lfParametro varchar2)return Varchar2;  
                                    
  Function Ft_Existe_Nov_Sap (lfNroPlaca varchar2, lfTipo varchar2, lfFecha date)return varchar2;                                  
                               
  Procedure sp_validar_vehiculos;
  Procedure Sp_Validar_Propietarios;
  Procedure Sp_Validar_Novedades;
  Procedure Sp_Validar_Traspaso;
END PKG_VALIDAR_CARGA_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_VAL_PLANT_ANT_ACTUALIZAR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_VAL_PLANT_ANT_ACTUALIZAR" AS 

  /*Este paquete permite realizar las validaciones a las plantillas que seran 
    cargadas a Sap con el fin de determinar si la informai�n reportada por RUNT 
    es mejor que la existente en SAP*/ 
  
 PROCEDURE SP_CONTRIBUYNETE_SAP_VS_RUNT(V_RADICADO VARCHAR);
 PROCEDURE SP_CONTRIBUYNETE_SAP_VS_RUNT_2(V_RADICADO VARCHAR);
  FUNCTION FT_ASIGNAR_# (V_CADENA VARCHAR2)RETURN VARCHAR2;
  

END PKG_VAL_PLANT_ANT_ACTUALIZAR;

/
--------------------------------------------------------
--  DDL for Package PKG_WS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."PKG_WS" AS 

PROCEDURE SP_LINEA_RUNT;

END PKG_WS;

/
--------------------------------------------------------
--  DDL for Package TAREA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."TAREA" AS 

GN_EDADMINIMA CONSTANT NUMBER(2):= 18;
GV_SEXOM CONSTANT VARCHAR2(1):='MASCULINO';
GV_SEXOF CONSTANT VARCHAR2(1):='FEMENINO';

PROCEDURE SP_INICIAR;


END TAREA;

/
--------------------------------------------------------
--  DDL for Package VAL_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CORRECCION_DATOS"."VAL_DATOS" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE PS_VALIDAR_REGISTROS;
  PROCEDURE PS_INSERTAR_RESULTADO (ESQUEMA VARCHAR2, TABLA VARCHAR2, PLACA VARCHAR2, CAMPO VARCHAR2, MENSAJE VARCHAR2); 
  


Procedure ESTADO_ENVIO;

Procedure SP_INCONSISTENCIA;

Procedure SP_ACTUALIZAR_LINEA_TIPO;



END VAL_DATOS;

/
--------------------------------------------------------
--  DDL for Package Body IF_MOVIMIENTO_VH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."IF_MOVIMIENTO_VH" AS

PROCEDURE GENERA_PLANTILLA (V_A�O1 NUMBER, V_MES1 VARCHAR2) AS

  BEGIN
  /*
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOCICLETA',10);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOCARRO',15);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'AUTOMOVIL',1);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'CAMPERO',6);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'CUATRIMOTO',16);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'CAMIONETA(C)',5);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MICRO BUS',7);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'CAMION',4);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'BUS',2);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'TRACTO-CAMION',9);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'CAMIONETA(P)',79);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'VOLQUETA',8);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'BUSETA',3);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOTRICICLO',17);
  */
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'SIN CLASE',0);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MAQ. AGRICOLA',11);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MAQ. INDUSTRIAL',12);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTO TRACTOR',13);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'GRUA',14);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOCICLETA ELECTRICA',18);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOCARRO ELECTRICO',19);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'MOTOTRICICLO ELECTRICO',20);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'REMOLQUE',24);
        INSERT INTO IF_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O1,V_MES1,'SEMIREMOLQUE',41);
        

  COMMIT;  
END GENERA_PLANTILLA;


PROCEDURE MOVIMIENTO_VH (V_A�O1 NUMBER, V_MES1 VARCHAR2) AS



          V_REMATRICULA       NUMBER:=0;
          V_CBIO_A_PA         NUMBER:=0;
          V_RADICACION        NUMBER:=0;
          V_CANCELACION       NUMBER:=0;
          V_TRASLADO          NUMBER:=0;
          V_CBIO_DE_PA        NUMBER:=0;
          V_CLASE             VARCHAR2(100);
        
          CURSOR NOVEDADES IS
              SELECT A�O,MES,ID_CLASE
              FROM IF_MOVIMIENTOS_VH
              WHERE A�O = V_A�O1
              AND MES = V_MES1;


BEGIN

    FOR X IN NOVEDADES LOOP
    
      
            V_REMATRICULA:=0;      
            V_CBIO_A_PA:=0;   
            V_RADICACION:=0;        
            V_CANCELACION:=0;       
            V_TRASLADO:=0;         
            V_CBIO_DE_PA:=0;        
                       
            
            
            V_CLASE := REPLACE (X.ID_CLASE,'"');
            
            /*==============================================================================================================================*/
              
              --CONSULTO CANTIDAD DE TRAMITES POR TRASLADO  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_TRASLADO
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '7'
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
                  --CONSULTO CANTIDAD DE TRAMITES POR REMATRICULA  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_REMATRICULA
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '4'
                  --AND RO.CODUSO in (1,3,6)
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
                  --CONSULTO CANTIDAD DE TRAMITES POR RADICACION  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_RADICACION
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '6'
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
                  
                  --CONSULTO CANTIDAD DE TRAMITES POR CAMBIO A PA  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_CBIO_A_PA
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '8'
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
                  
                  --CONSULTO CANTIDAD DE TRAMITES POR CAMBIO A PU  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_CBIO_DE_PA
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '14'
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
                  
                  --CONSULTO CANTIDAD DE TRAMITES POR CANCELACION  POR CLASE DE VEHICULO
                SELECT COUNT (DISTINCT NV.PLACA)
                INTO V_CANCELACION
                FROM IF_NOVEDADES NV
                INNER JOIN IF_REP_OC RO
                ON NV.PLACA = RO.PSOBKEY
                WHERE NV.A�O_ACTO = X.A�O
                  AND NV.MES_ACTO = X.MES
                  AND NV.ID_NOVEDAD = '3'
                  AND RO.CODCLASE IN (V_CLASE)
                  AND RO.MARC_ARCH IS NULL;
                  
            
              --- REALIZO LA ACTUALIZACION DE MOVIMIENTOS EN LA TABLA IF_MOVIMIENTOS_VH 
              
            UPDATE IF_MOVIMIENTOS_VH MV
            SET MV.REMATRICULA = V_REMATRICULA,
                MV.CANCELACION = V_CANCELACION,
                MV.RADICACION = V_RADICACION,
                MV.TRASLADO =  V_TRASLADO,
                MV.CBIO_A_PA = V_CBIO_A_PA,
                MV.CBIO_DE_PA = V_CBIO_DE_PA
            WHERE MV.A�O = X.A�O
            AND MV.MES = X.MES
            AND MV.ID_CLASE = X.ID_CLASE;  
              
            
            COMMIT;
    END LOOP;

END MOVIMIENTO_VH;


PROCEDURE MATR_INICIALES (V_A�O1 NUMBER, V_MES1 VARCHAR2) AS


      V_MI                NUMBER:=0;
      V_MI2               NUMBER:=0;
      V_FMI               NUMBER:=0;
      V_FMI2              NUMBER:=0;
      V_PARQUE            NUMBER:=0;
      V_CREADOS           NUMBER:=0;
      V_CLASE             VARCHAR2(100);
      V_NUM_MES           VARCHAR2(2);
      --V_NOM_MES           VARCHAR2(25);
    
      -- CURSOR PARA CALCULAR MATRICULAS INICIALES Y VEHICULOS CREADOS
        CURSOR MAT_INI IS
            SELECT A�O,MES,ID_CLASE
            FROM   IF_MOVIMIENTOS_VH
            WHERE  A�O = V_A�O1
            AND    MES = V_MES1; 
            
       /*     
            CURSOR PARQUE IS
          SELECT DISTINCT PSOBKEY,CONCAT(to_char(CREADO_EL,'MM'),to_char(CREADO_EL,'YYYY')) AS FECHA,ANO_CREA,MES_CREA,CODCLASE
          FROM IF_REP_OC
          WHERE REGION = '5'
          AND MARC_ARCH IS NULL
          ORDER BY FECHA;
         */ 
            
BEGIN
    
      V_MI :=0;
      V_MI2 :=0;
      V_FMI :=0;
      V_FMI2 :=0;
      V_CREADOS:=0;
      V_PARQUE:=0;
  
    
    -- FOR PARA CALCULAR MATRICULAS INICIALES
      FOR M IN MAT_INI LOOP
      
         V_CLASE := REPLACE (M.ID_CLASE,'"');
         
        --CONSULTO CANTIDAD DE VEHICULOS POR FECHA DE MATRICULA  POR CLASE DE VEHICULO SI NO TIENEN NOVEDADES
        
        
        
        SELECT COUNT (DISTINCT RO.PSOBKEY)
        INTO V_FMI
        FROM IF_REP_OC RO
        WHERE NOT EXISTS (
             SELECT NV.PLACA
             FROM IF_NOVEDADES NV
             WHERE RO.PSOBKEY = NV.PLACA)
        AND TO_CHAR(RO.FECHAMAT,'YYYY') = M.A�O
        AND TRIM(TO_CHAR(RO.FECHAMAT,'MONTH')) = M.MES
        AND RO.MODELO IN (M.A�O,M.A�O + 1,M.A�O -1)
        AND RO.CODCLASE = V_CLASE
        AND RO.MARC_ARCH IS NULL;
         
 
        --SI TIENE NOVEDAD
        
        SELECT COUNT (DISTINCT RO.PSOBKEY)
        INTO V_FMI2
        FROM IF_REP_OC RO
        INNER JOIN IF_NOVEDADES NV
        ON NV.PLACA = RO.PSOBKEY
        WHERE TO_CHAR(RO.FECHAMAT,'YYYY') = M.A�O
        AND TRIM(TO_CHAR(RO.FECHAMAT,'MONTH')) = M.MES
        AND RO.MODELO IN (M.A�O,M.A�O + 1,M.A�O -1)
        AND NV.ID_NOVEDAD NOT IN (6,8,4,14)
        AND RO.CODCLASE = V_CLASE
        AND RO.MARC_ARCH IS NULL;
        
        
        --CONSULTO CANTIDAD DE VEHICULOS POR FECHA DE CREACION POR CLASE DE VEHICULO SI NO TIENEN NOVEDADES
        SELECT COUNT (DISTINCT RO.PSOBKEY)
        INTO V_MI
        FROM IF_REP_OC RO
        WHERE NOT EXISTS (
             SELECT NV.PLACA
             FROM IF_NOVEDADES NV
             WHERE RO.PSOBKEY = NV.PLACA)
        AND RO.ANO_CREA = M.A�O
        AND RO.MES_CREA = M.MES
        AND TO_CHAR(RO.FECHAMAT,'YYYY') = M.A�O
        AND RO.MODELO IN (M.A�O,M.A�O + 1,M.A�O -1)
        AND RO.CODCLASE = V_CLASE
        AND RO.MARC_ARCH IS NULL;
    

           --SI TIENE NOVEDAD
       SELECT COUNT (DISTINCT RO.PSOBKEY)
        INTO V_MI2
        FROM IF_REP_OC RO
        INNER JOIN IF_NOVEDADES NV
        ON NV.PLACA = RO.PSOBKEY
        WHERE RO.ANO_CREA = M.A�O
        AND RO.MES_CREA = M.MES
        AND TO_CHAR(RO.FECHAMAT,'YYYY') = M.A�O
        AND RO.MODELO IN (M.A�O,M.A�O + 1,M.A�O -1)
        AND NV.ID_NOVEDAD NOT IN (6,8,4,14)
        AND RO.CODCLASE = V_CLASE
        AND RO.MARC_ARCH IS NULL;
        
        
        --CALCULO LOS VEHICULOS CREADOS
        SELECT COUNT (DISTINCT RO.PSOBKEY)
        INTO V_CREADOS
        FROM IF_REP_OC RO
        WHERE RO.ANO_CREA = M.A�O
        AND RO.MES_CREA = M.MES
        AND RO.CODCLASE = V_CLASE
     -- AND RO.REGION = '5'
        AND RO.MARC_ARCH IS NULL;
        
        
        --CALCULO LOS VEHICULOS CREADOS HASTA ANTES DEL EL A�O MES CONSULTAD
        

  V_NUM_MES := IF_MOVIMIENTO_VH.FT_CONSULTAR_MES(M.MES);

             SELECT COUNT (DISTINCT RO.PSOBKEY)
             INTO V_PARQUE
             FROM IF_REP_OC RO
             WHERE RO.CODCLASE = V_CLASE
             --AND RO.ANO_CREA = M.A�O
             --AND RO.MES_CREA = M.MES
             --AND REGION = '5'
             AND CONCAT(to_char(RO.CREADO_EL,'YYYY'),to_char(RO.CREADO_EL,'MM')) < CONCAT(M.A�O,V_NUM_MES)
             AND RO.MARC_ARCH IS NULL;


      -- REALIZO LA ACTUALIZACION DE LOS CAMPOS MI_FECHA_MAT Y MI_FECHA_CREADA,VEH_CREADOS,PARQUE_AUTOMOTOR
        UPDATE IF_MOVIMIENTOS_VH MV
        SET MV.MI_FECHA_MAT = V_FMI2 + V_FMI,
            MV.VEH_CREADOS = V_CREADOS,
            MV.PARQUE_AUTOMOTOR = V_PARQUE,
            MV.MI_FECHA_CREADA = V_MI + V_MI2
        WHERE MV.A�O = M.A�O
        AND MV.MES = M.MES
        AND MV.ID_CLASE = V_CLASE;
        
            COMMIT;
      END LOOP;
END MATR_INICIALES;




FUNCTION FT_CONSULTAR_MES(V_MES1 VARCHAR2) RETURN VARCHAR2 AS
    V_NUM_MES VARCHAR2(2);
  BEGIN
    
CASE V_MES1
          WHEN 'ENERO' THEN
             V_NUM_MES :='01';
          WHEN 'FEBRERO' THEN
              V_NUM_MES :='02';
          WHEN 'MARZO' THEN
             V_NUM_MES :='03';
          WHEN 'ABRIL' THEN
             V_NUM_MES :='04';
          WHEN 'MAYO' THEN
             V_NUM_MES :='05';
          WHEN 'JUNIO' THEN
             V_NUM_MES :='06';
          WHEN 'JULIO' THEN
             V_NUM_MES :='07';
          WHEN 'AGOSTO' THEN
             V_NUM_MES :='08';
          WHEN 'SEPTIEMBRE' THEN
            V_NUM_MES :='09';
          WHEN 'OCTUBRE' THEN
              V_NUM_MES :='10';
          WHEN 'NOVIEMBRE' THEN
             V_NUM_MES :='11';
          WHEN 'DICIEMBRE' THEN
             V_NUM_MES :='12';
    END CASE;
    
    RETURN V_NUM_MES;
  END FT_CONSULTAR_MES;

END IF_MOVIMIENTO_VH;

/
--------------------------------------------------------
--  DDL for Package Body IF_VAL_ARCHIVO_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."IF_VAL_ARCHIVO_RUNT" AS


PROCEDURE IF_ESTA_DOCUEMNTO AS 

V_ID_REG VARCHAR2(50);
V_DOC VARCHAR2(50);
V_CONTADOR NUMBER := 0;
V_T_DOC VARCHAR2(2);
V_DOC_NUEVO VARCHAR2(20);
V_EMAIL VARCHAR2(150);
V_EMAIL_NUEVO number;
V_TEL VARCHAR2 (50);
V_MENSAJE varchar(40);


/*CURSOR VAL_DIR_RUNT IS
SELECT ID_REG, id_usuario,id_documento,email
FROM IF_RUNT_UNICO;*/

CURSOR VAL_DIR_RUNT2 IS
SELECT email,ID_REG
FROM IF_RUNT_UNICO
WHERE EMAIL IS NOT NULL;

CURSOR VAL_DIR_RUNT3 IS
SELECT ID_REG, telefono
FROM IF_RUNT_UNICO
WHERE telefono IS NOT NULL;


CURSOR VAL_DIR_RUNT4 IS
SELECT ID_REG,fax
FROM IF_RUNT_UNICO
WHERE fax IS NOT NULL;


BEGIN


--- doc
/*
FOR X  IN VAL_DIR_RUNT  LOOP

V_CONTADOR := V_CONTADOR + 1;


V_ID_REG := X.ID_REG;
V_DOC := X.id_usuario;
V_T_DOC := X.id_documento;

V_DOC_NUEVO := pkg_ds_estandariza_runt.ft_estandarizar_identificacion(V_DOC,V_T_DOC);

UPDATE IF_RUNT_UNICO
SET NUEVO_DOC = V_DOC_NUEVO
WHERE ID_REG = V_ID_REG;


IF V_CONTADOR = 200 THEN
COMMIT;
V_CONTADOR := 0;

END IF ;

END LOOP;
*/

-- email

/*
FOR X  IN VAL_DIR_RUNT2  LOOP

V_CONTADOR := V_CONTADOR + 1;


V_ID_REG := X.ID_REG;
v_email := X.email;


V_EMAIL_NUEVO := pkg_generar_plantilla_ic.ft_validar_email(v_email);

 CASE V_EMAIL_NUEVO
          WHEN 5 THEN
              V_MENSAJE:='email NO TIENE @ ';
          WHEN 6 THEN
              V_MENSAJE:='LONGITUD MENOR DE 7 ';
          WHEN 7 THEN
              V_MENSAJE:='PLABRA NO REGISTRA ';         
          ELSE
              V_MENSAJE:='NO SE DETECTO ERROR ';
    END CASE;

UPDATE IF_RUNT_UNICO
SET val_imei = V_MENSAJE
WHERE ID_REG = V_ID_REG;


IF V_CONTADOR = 500 THEN

COMMIT;
V_CONTADOR := 0;

END IF ;

END LOOP;

UPDATE IF_DIR_WHITE
SET EMAIL = 'TERMINADO'
WHERE ID_REG = '1';

*/
------ telefof



FOR X  IN VAL_DIR_RUNT3  LOOP

V_CONTADOR := V_CONTADOR + 1;


V_ID_REG := X.ID_REG;
V_TEL := X.telefono;

V_TEL := pkg_generar_plantilla_ic.FT_VALIDAR_TELEFONO_FAX(V_TEL,'T',0);


 CASE V_TEL
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              V_MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              V_MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              V_MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              V_MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              V_MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              V_MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              V_MENSAJE:= NULL;          
          ELSE
              V_MENSAJE:='NO SE DETECTO ERROR ';
    END CASE;

UPDATE IF_RUNT_UNICO
SET TEL_ESTANDAR = V_MENSAJE
WHERE ID_REG = V_ID_REG;

IF V_CONTADOR = 300 THEN

COMMIT;
V_CONTADOR := 0;

END IF ;

END LOOP;


UPDATE IF_DIR_WHITE
SET TELEFONO = 'TERMINADO'
WHERE ID_REG = '1';

COMMIT;

---- fax


FOR X  IN VAL_DIR_RUNT4  LOOP

V_CONTADOR := V_CONTADOR + 1;


V_ID_REG := X.ID_REG;
V_TEL := X.fax;

V_TEL := pkg_generar_plantilla_ic.FT_VALIDAR_TELEFONO_FAX(V_TEL,'T',0);



 CASE V_TEL
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              V_MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              V_MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              V_MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              V_MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              V_MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              V_MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              V_MENSAJE:= NULL;          
          ELSE
              V_MENSAJE:='NO SE DETECTO ERROR ';
    END CASE;

UPDATE IF_RUNT_UNICO
SET val_fax = V_MENSAJE
WHERE ID_REG = V_ID_REG;

IF V_CONTADOR = 300 THEN


COMMIT;
V_CONTADOR := 0;

END IF ;

END LOOP;


UPDATE IF_DIR_WHITE
SET FAX = 'TERMINADO'
WHERE ID_REG = '1';


COMMIT;



COMMIT;
END IF_ESTA_DOCUEMNTO;  --- ESTANDRIZA TELEFONO Y FAX

END IF_VAL_ARCHIVO_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_ACTUALIZAR_SECRETARIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_ACTUALIZAR_SECRETARIA" AS

  PROCEDURE SP_ACTUALIZAR_REGISTROS AS
  
    V_NRO_PLACA VARCHAR2(7);
    V_ID_SECRETARIA_ORIGEN NUMBER;
    V_ID_SECRETARIA_LIC_TTO NUMBER;
    V_FECHA_TRAMITE DATE;
    
    CURSOR ACTUALIZAR_SECRETARIA IS
    
      SELECT DISTINCT(DT.NRO_PLACA), DT.ID_SECRETARIA_ORIGEN, DT.FECHA_TRAMITE
      FROM DEPURACION.DS_TRAMITE DT
      INNER JOIN QUIPUX.LIC_TTO LT
        ON DT.NRO_PLACA = LT.NRO_PLACA AND
           DT.ID_TRAMITE = 15 AND
           DT.ESTADO_VALIDACION = 'RA'
      INNER JOIN QUIPUX.TRASLADOS TR
        ON  DT.NRO_PLACA = TR.NRO_PLACA AND
            TO_DATE(DT.FECHA_TRAMITE,'DD/MM/YYYY') = TR.FECHA_TRASLADO
      WHERE DT.ID_SECRETARIA_DESTINO IS NOT NULL AND
            DT.ID_SECRETARIA_ORIGEN IS NOT NULL
      ORDER BY DT.NRO_PLACA, TO_DATE(DT.FECHA_TRAMITE,'DD/MM/YYYY');
         
  BEGIN
    
    FOR XACTUALIZA IN ACTUALIZAR_SECRETARIA LOOP
    
      V_NRO_PLACA := XACTUALIZA.NRO_PLACA;
      V_ID_SECRETARIA_ORIGEN := XACTUALIZA.ID_SECRETARIA_ORIGEN;
      V_FECHA_TRAMITE := XACTUALIZA.FECHA_TRAMITE;
      
      BEGIN
      
        SELECT ID_SECRETARIA
        INTO V_ID_SECRETARIA_LIC_TTO
        FROM QUIPUX.SECRETARIAS_TTO
        WHERE RUNT_SECRETARIA = V_ID_SECRETARIA_ORIGEN AND
              ROWNUM = 1;
        
        EXCEPTION
        WHEN OTHERS THEN
          CONTINUE;
        END;
        
        BEGIN
        
          UPDATE QUIPUX.LIC_TTO
          SET ID_SECRETARIA = V_ID_SECRETARIA_LIC_TTO
          WHERE NRO_PLACA = V_NRO_PLACA;
          
        EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK;
        END;
                             
    END LOOP;
    
  END SP_ACTUALIZAR_REGISTROS;

END PKG_ACTUALIZAR_SECRETARIA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DEPURAR_INCONSISTENCIAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_DEPURAR_INCONSISTENCIAS" AS

/*
*********************************************************************************************************************
    AUTOR: ELVIS ALEXIS BETANCUR LOPEZ
    FECHA CREACI�N: 10/10/2016
    DESCRIPCI�N: PAQUETE QUE REALIZA LAS CORRECCIONES GENERADAS POR EL VALIDADOR, PREVIA IDENTIFICACI�N Y TIPOLOGIA.
    TABLAS: - DS_TMP_CONTRIBUYENTES1 
            - DS_TMP_CONTRIBUYENTES2 (Se carga la informaci�n de contribuyentes original enviada por Runt)
            - DS_TMP_PROPIETARIOS1
            - DS_TMP_TRAMITES1
            - DS_TMP_VEHICULOS1
            - INCONSISTENCIAS
            
    PARAMETROS: NINGUNO.
    OBJETOS: SP_PORCENTAJE_TRAMITE
             SP_PORCENTAJE_PROPIETARIO
             SP_DEPURAR_PROPIETARIO
             SP_ID_SECRETARIA_TRAMITE
             SP_HOMOLOGAR_LINEAS
             SP_CAPACIDAD_TONELADAS
             SP_ESTANDARIZAR_CONTRIBYENTES2
             
    RETORNA: REALIZA LAS CORRECCIONES NECESARIAS EN LAS TABLAS DS_TMP_CONTRIBUYENTES1, DS_TMP_PROPIETARIOS1, 
             DS_TMP_TRAMITES1 Y DS_TMP_VEHICULOS1.  
             
********************************************************************************************************************** 
*/
    
    
PROCEDURE SP_ORDEN_EJECUCION AS

BEGIN

-- 1.Corrige los porcentajes de propiedad de tr�mites cuendo son tr�mites del 100 o 50 %.
   PKG_DEPURAR_INCONSISTENCIAS.SP_PORCENTAJE_TRAMITE; 
-- 2.Coloca el porcentaje de propiedad a los propietarios que reportan tramite de traspaso de 50%    
   PKG_DEPURAR_INCONSISTENCIAS.SP_PORCENTAJE_PROPIETARIO;
-- 3. Elimina quienes no son propietarios   
   PKG_DEPURAR_INCONSISTENCIAS.SP_DEPURAR_PROPIETARIO;
-- 4. Corrige los errores del archivo de tramites Id_Secretaria y Id_Secretaria_Destino   
   PKG_DEPURAR_INCONSISTENCIAS.SP_ID_SECRETARIA_TRAMITE; 
-- 5. Corrige los errores del archivo de vehiculos Nombre_Linea   
   PKG_DEPURAR_INCONSISTENCIAS.SP_HOMOLOGAR_LINEAS;
-- 6.Corrige los errores del archivo de tramites Cap_Toneladas     
   PKG_DEPURAR_INCONSISTENCIAS.SP_CAPACIDAD_TONELADAS; 
-- 7. Corrige los errores de tramites Id_UsuarioAnterior  
   PKG_DEPURAR_INCONSISTENCIAS.SP_ESTANDARIZAR_CONTRIBYENTES2; 
  
   COMMIT;

END SP_ORDEN_EJECUCION;


PROCEDURE SP_PORCENTAJE_TRAMITE AS

V_EXISTE NUMBER:=0;

CURSOR PORCENTAJE IS
SELECT DISTINCT IDENTIFICADOR
FROM CORRECCION_DATOS.INCONSISTENCIAS
WHERE NOMBRE_ARCHIVO='TRAMITE'
AND CAMPO_FALLO ='PORCENTAJE_PROP';
--AND IDENTIFICADOR IN ('DES018');

BEGIN

FOR X IN PORCENTAJE LOOP
SELECT COUNT(1)
into V_EXISTE
FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
WHERE NRO_PLACA = X.IDENTIFICADOR
AND ID_TRAMITE IN (16,65);

IF V_EXISTE = 1 THEN
  UPDATE CORRECCION_DATOS.Ds_Tmp_Tramites1
  SET PORCENTAJE_PROP = 100
  WHERE NRO_PLACA = X.IDENTIFICADOR AND
        ID_TRAMITE IN (16,65);
  COMMIT;      

ELSIF V_EXISTE = 2 THEN
SP_RECORRER(X.IDENTIFICADOR);
--ELSIF V_EXISTE = 4 THEN
--CUATRO_TRAMITES_PROP(X.IDENTIFICADOR);
END IF;
END LOOP;

END SP_PORCENTAJE_TRAMITE;

--:::::::::::::::::::::::::::::::::::::::::::::--
PROCEDURE SP_RECORRER (PR_PLACA VARCHAR2) AS

V_COMP1 VARCHAR2(20);
V_COMP2 VARCHAR2(20);
V_VEND1 VARCHAR2(20);
V_VEND2 VARCHAR2(20);
V_CONTADOR NUMBER:=0;
V_PORCENTAJE NUMBER:=0;
V_PLACA VARCHAR2(10);
V_FECHA1 DATE;
V_FECHA2 DATE;

CURSOR RECORRER IS
SELECT *
FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
WHERE NRO_PLACA = PR_PLACA
AND ID_TRAMITE IN (16,65)
ORDER BY FECHA_TRAMITE ASC;


BEGIN

FOR Z IN RECORRER LOOP
V_CONTADOR:=V_CONTADOR+1;

  IF V_CONTADOR = 1 THEN
    V_COMP1 := Z.ID_USUARIO_NUEVO;
    V_VEND1 := Z.ID_USUARIO_ANTERIOR;  
    V_FECHA1:= Z.FECHA_TRAMITE;
  ELSIF V_CONTADOR =2 THEN
    V_COMP2 := Z.ID_USUARIO_NUEVO;
    V_VEND2 := Z.ID_USUARIO_ANTERIOR;
    V_FECHA2:= Z.FECHA_TRAMITE;
    V_CONTADOR:=0;
  END IF;
END LOOP;

-- Dos vendedores un solo comprador
IF V_VEND1 <> V_VEND2 AND V_COMP1 = V_COMP2 AND V_FECHA1 = V_FECHA2 THEN
 V_PORCENTAJE :=50;
 
-- Un solo vendedor dos compradores 
ELSIF  V_VEND1 = V_VEND2 AND V_COMP1 <> V_COMP2 AND V_FECHA1 = V_FECHA2 THEN
  V_PORCENTAJE :=50;
  
-- Dos tramites de traspso del 100% en la misma quincena   
ELSIF  V_VEND1 <> V_VEND2 AND V_VEND2 = V_COMP1 AND V_COMP1 <> V_COMP2 THEN
  V_PORCENTAJE :=100; 

--Esta validaci�n es para cuando  se carga primero el segundo tramite..
ELSIF   V_VEND1 <> V_VEND2 AND V_VEND1 = V_COMP2 AND V_COMP1 <> V_COMP2 THEN
  V_PORCENTAJE :=100 ;   
ELSE
  V_PORCENTAJE:=NULL;
END IF;

UPDATE CORRECCION_DATOS.DS_TMP_TRAMITES1
   SET PORCENTAJE_PROP= V_PORCENTAJE
 WHERE NRO_PLACA = PR_PLACA
   AND ID_TRAMITE IN (16,65)
   AND PORCENTAJE_PROP IS NULL 
    OR PORCENTAJE_PROP =0;

V_PORCENTAJE:=0;
COMMIT;
END SP_RECORRER;

--:::VALIDAR 4 TRAMITES DE TRASPASO:::--
PROCEDURE SP_CUATRO_TRAMITES_PROP (PLACA VARCHAR2) AS
V_COMP1 VARCHAR2(20);
V_COMP2 VARCHAR2(20);
V_COMP3 VARCHAR2(20);
C_ELIMINAR VARCHAR2(20);
V_VEND1 VARCHAR2(20);
V_VEND2 VARCHAR2(20);
V_VEND3 VARCHAR2(20);
V_ELIMINAR VARCHAR2(20);
V_BANDERA1 NUMBER:=0;
V_BANDERA2 NUMBER:=0;
V_BANDERA3 NUMBER:=0;
V_PORCENTAJE NUMBER:=0;
V_PLACA VARCHAR2(10);
V_FECHA1 DATE;
V_FECHA2 DATE;
V_FECHA3 DATE;
V_FECHA4 DATE;

CURSOR FOUR_PROP IS
select *
FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
WHERE NRO_PLACA = PLACA
AND ID_TRAMITE iN (16,65);

BEGIN

FOR X IN FOUR_PROP LOOP
  --V_CONTADOR:=V_CONTADOR+1;
      
      IF X.ID_USUARIO_ANTERIOR = X.ID_USUARIO_NUEVO THEN
      --ELIMINAR DATO
         delete from CORRECCION_DATOS.DS_TMP_TRAMITES1
        --UPDATE CORRECCION_DATOS.DS_TMP_TRAMITES1
          --SET PORCENTAJE_PROP =123       
          WHERE NRO_PLACA= PLACA
          AND ID_TRAMITE = 16
          AND ID_USUARIO_ANTERIOR = X.ID_USUARIO_ANTERIOR
          AND ID_USUARIO_NUEVO = X.ID_USUARIO_NUEVO;
          --V_CONTADOR:=V_CONTADOR-1;
  
          COMMIT;
   ELSIF  V_BANDERA1=0 THEN
          V_COMP1 := X.ID_USUARIO_NUEVO;
          V_VEND1 := X.ID_USUARIO_ANTERIOR;  
          V_BANDERA1:=1;
      ELSIF  V_BANDERA2=0 THEN
          V_COMP2 := X.ID_USUARIO_NUEVO;
          V_VEND2 := X.ID_USUARIO_ANTERIOR; 
          V_BANDERA2:=1;
      ELSIF V_BANDERA3=0 THEN
          V_COMP3 := X.ID_USUARIO_NUEVO;
          V_VEND3 := X.ID_USUARIO_ANTERIOR;   
          V_BANDERA3:=1;
      END IF;    
END LOOP;

IF V_VEND1 = V_VEND2 AND V_VEND2 <> V_VEND3 THEN
    --ELIMINAR V_VEND1
    V_ELIMINAR:=V_VEND1;
ELSIF V_VEND2 = V_VEND3 AND V_VEND2 <> V_VEND1 THEN
    --ELIMINAR V_VEND2
    V_ELIMINAR:=V_VEND2;
ELSIF V_VEND1 = V_VEND3 AND V_VEND1 <> V_VEND2 THEN
    --ELIMINAR V_VEND1
    V_ELIMINAR:=V_VEND1;
END IF;

IF V_COMP1 = V_COMP2 AND V_COMP2 <> V_COMP3 THEN
    --ELIMINAR V_COMP1
    C_ELIMINAR:=V_COMP1;
ELSIF V_COMP2 = V_COMP3 AND V_COMP2 <> V_COMP1 THEN
    --ELIMINAR V_COMP2
    C_ELIMINAR:=V_COMP2;
ELSIF V_COMP1 = V_COMP3 AND V_COMP1 <> V_COMP2 THEN
    --ELIMINAR V_COMP1
    C_ELIMINAR:=V_COMP1;
END IF;

--UPDATE DS_TMP_TRAMITES1
--SET PORCENTAJE_PROP =333
DELETE FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
WHERE NRO_PLACA = PLACA
AND ID_TRAMITE = 16
AND ID_USUARIO_ANTERIOR = V_ELIMINAR
AND ID_USUARIO_NUEVO = C_ELIMINAR;
COMMIT;

C_ELIMINAR:= NULL;
V_ELIMINAR:= NULL;

SP_RECORRER (PLACA);

END SP_CUATRO_TRAMITES_PROP;

/***********************************************************************************/
/*Este procedimiento coloca el 50% a los propietarios que reportan tramite de traspaso
  del 50%                                                                           */ 
  
PROCEDURE SP_PORCENTAJE_PROPIETARIO IS

CURSOR PLACA IS
SELECT DISTINCT NRO_PLACA
FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 
WHERE PORCENTAJE_PROP = 50
  AND ID_TRAMITE IN (16,65);

BEGIN

FOR X IN PLACA LOOP
  
  BEGIN
    UPDATE CORRECCION_DATOS.DS_TMP_PROPIETARIOS1 DP
    SET DP.PORCENTAJE_PROP = (SELECT DT.PORCENTAJE_PROP
                          FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
                          WHERE DT.NRO_PLACA = DP.NRO_PLACA
                            AND DT.PORCENTAJE_PROP = 50
                            AND DT.ID_USUARIO_NUEVO = DP.ID_USUARIO
                            AND DT.ID_DOCUMENTO_NUEVO = DP.ID_DOCUMENTO
                            AND DT.ID_TRAMITE IN (16,65))
    WHERE DP.PORCENTAJE_PROP IS NULL
      AND NRO_PLACA= X.NRO_PLACA;
    COMMIT;  
   EXCEPTION
   WHEN OTHERS THEN
    CONTINUE;
   END; 

END LOOP;

COMMIT;

END SP_PORCENTAJE_PROPIETARIO;

/*********************************************************************************/
/*Este procedimiento elimina los usuarios que no son propietarios de la tabla DS_TMP_PROPIETARIOS*/

PROCEDURE SP_DEPURAR_PROPIETARIO AS

V_USUARIO_ANTERIOR VARCHAR2(20);
V_DOC_ANT VARCHAR2(20);
V_EXISTE NUMBER:=0;
V_PORCENTAJE NUMBER;

CURSOR PROPIETARIO IS
      SELECT DISTINCT DP.NRO_PLACA 
      FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 DP;
      /*INNER JOIN CORRECCION_DATOS.Ds_Tmp_TRAMITES1 DT
      ON DT.NRO_PLACA = DP.NRO_PLACA*/
      --WHERE NRO_PLACA = 'TMF741';
      /*GROUP BY DP.NRO_PLACA
      HAVING COUNT(DP.NRO_PLACA)=2;*/
      
--Identifica los usuarios que se reportaron como propietarios y son vendedores
--seg�n el tramite.
CURSOR ELIMINAR100 (V_PLACA VARCHAR2) IS
    SELECT DP.ID_USUARIO, DP.ID_DOCUMENTO 
    FROM CORRECCION_DATOS.DS_TMP_PROPIETARIOS1 DP
    WHERE  EXISTS (SELECT DT.ID_USUARIO_ANTERIOR
                          FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
                          WHERE DT.ID_USUARIO_ANTERIOR = DP.ID_USUARIO 
                            AND DT.ID_DOCUMENTO_ANTERIOR = DP.ID_DOCUMENTO
                            AND DT.NRO_PLACA = DP.NRO_PLACA
                            AND DT.ID_TRAMITE IN (16,65)
                            AND DT.PORCENTAJE_PROP = 100)
    AND DP.NRO_PLACA = V_PLACA;  

--Identifica los usuarios que se reportaron como propietarios y venden el 50% 
--y no son reportados como poseedores del 50% restante segun el tr�mite.
CURSOR ELIMINAR50(V_NPLACA VARCHAR2) IS
    SELECT DP.ID_USUARIO, DP.ID_DOCUMENTO  
    FROM CORRECCION_DATOS.DS_TMP_PROPIETARIOS1 DP
    WHERE  EXISTS (SELECT DT.ID_USUARIO_ANTERIOR
                          FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
                          WHERE DT.ID_USUARIO_ANTERIOR = DP.ID_USUARIO
                            AND DT.ID_DOCUMENTO_ANTERIOR = DP.ID_DOCUMENTO
                            AND DT.NRO_PLACA = DP.NRO_PLACA
                            AND DT.ID_TRAMITE IN (16,65)
                            AND DT.PORCENTAJE_PROP != 100)
    AND NOT EXISTS (SELECT DT.ID_USUARIO_NUEVO
                           FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DT
                           WHERE Dt.ID_USUARIO_NUEVO = DP.ID_USUARIO 
                             AND DT.ID_DOCUMENTO_NUEVO = DP.ID_DOCUMENTO
                             AND DT.NRO_PLACA = DP.NRO_PLACA
                             AND DT.ID_TRAMITE IN (16,65)
                             AND DT.PORCENTAJE_PROP != 100)
    AND DP.NRO_PLACA = V_NPLACA;        

BEGIN
    
  FOR X IN PROPIETARIO LOOP   
    
  BEGIN
  
    SELECT COUNT(1) INTO V_EXISTE
    FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 DTT
    WHERE DTT.NRO_PLACA = X.NRO_PLACA
      AND DTT.ID_TRAMITE IN (16,65);
  
   EXCEPTION 
   WHEN OTHERS THEN
     CONTINUE;
   END;   
            
    IF V_EXISTE = 1 THEN
    
    BEGIN 
    
      SELECT ID_USUARIO_ANTERIOR, ID_DOCUMENTO_ANTERIOR
      INTO V_USUARIO_ANTERIOR, V_DOC_ANT
      FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
      WHERE NRO_PLACA = X.NRO_PLACA AND
            --ID_DOCUMENTO_NUEVO = X.ID_DOCUMENTO AND
            ID_TRAMITE IN (16,65);
      
      DELETE FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 TP
      WHERE TP.NRO_PLACA= X.NRO_PLACA AND
            TP.ID_DOCUMENTO = V_DOC_ANT AND
            TP.ID_USUARIO = V_USUARIO_ANTERIOR;
     COMMIT;   
     
    EXCEPTION 
    WHEN OTHERS THEN
      ROLLBACK;
    END; 
        
                      
    ELSIF V_EXISTE = 2 THEN
    
   BEGIN
   
    SELECT PORCENTAJE_PROP
    INTO V_PORCENTAJE
    FROM CORRECCION_DATOS.DS_TMP_TRAMITES1 
    WHERE NRO_PLACA = X.NRO_PLACA
    AND ROWNUM = 1;
    
   EXCEPTION 
   WHEN OTHERS THEN
     CONTINUE;
   END; 
    
      IF V_PORCENTAJE <> 100 THEN
      
        FOR Y IN ELIMINAR50 (X.NRO_PLACA) LOOP
        
        BEGIN
        
          DELETE FROM CORRECCION_DATOS.DS_TMP_PROPIETARIOS1
          WHERE ID_USUARIO = Y.ID_USUARIO
          AND ID_DOCUMENTO = Y.ID_DOCUMENTO;
          COMMIT;
          
        EXCEPTION 
        WHEN OTHERS THEN
          ROLLBACK;
        END; 
        
        
        END LOOP;
                      
      ELSIF V_PORCENTAJE = 100 THEN
          
        FOR Z IN ELIMINAR100 (X.NRO_PLACA) LOOP
        
          BEGIN
          
            DELETE FROM CORRECCION_DATOS.DS_TMP_PROPIETARIOS1
            WHERE ID_USUARIO = Z.ID_USUARIO
            AND ID_DOCUMENTO = Z.ID_DOCUMENTO;              
            COMMIT;
          
          EXCEPTION 
          WHEN OTHERS THEN
            ROLLBACK;
          END; 
        
        END LOOP;
        
      END IF;  
      
    END IF; 
        
  END LOOP;

END SP_DEPURAR_PROPIETARIO;


/* Este procedimiento corrige las inconsistencias del archivo de TRAMITES
   generadas por ID_SECRETARIA y ID_SECRETARIA_DESTINO */
PROCEDURE SP_ID_SECRETARIA_TRAMITE AS

V_SECRE VARCHAR2(20);
V_SECRETARIA_ORIGEN VARCHAR(10);
V_SECRETARIA_DESTINO VARCHAR(10);
V_SECRETARIA_VEHICULO VARCHAR(10);
V_SECRETARIA_LIC_TTO VARCHAR(10);

CURSOR SECRETARIAS IS
    SELECT CV.NRO_PLACA,
           CV.ID_SECRETARIA AS ID_SECRETARIA_VH,
           CT.ID_SECRETARIA_ORIGEN,
           CT.ID_SECRETARIA_DESTINO,
           STTO.RUNT_SECRETARIA AS SECRETARIA_TIPO
    FROM CORRECCION_DATOS.INCONSISTENCIAS CI
          INNER JOIN CORRECCION_DATOS.DS_TMP_VEHICULOS1 CV
           ON CV.NRO_PLACA = CI.IDENTIFICADOR
          INNER JOIN CORRECCION_DATOS.DS_TMP_TRAMITES1 CT
           ON CT.NRO_PLACA = CV.NRO_PLACA
          INNER JOIN QUIPUX.LIC_TTO LT
           ON LT.NRO_PLACA = CV.NRO_PLACA
          INNER JOIN QUIPUX.SECRETARIAS_TTO STTO
           ON STTO.ID_SECRETARIA = LT.ID_SECRETARIA
    WHERE CT.ID_TRAMITE = '15'  AND
          CI.NOMBRE_ARCHIVO = 'TRAMITE' AND
          CI.CAMPO_FALLO IN ('ID_SECRETARIA','ID_SECRETARIA_DESTINO');
          --AND CI.IDENTIFICADOR ='GND205';
          --AND ROWNUM = 1;

BEGIN

  FOR X IN SECRETARIAS LOOP
    
    --CAPTURO LAS SECRETARIAS DEL TRAMITE Y DEL VEHICULO
      V_SECRETARIA_ORIGEN := X.ID_SECRETARIA_ORIGEN;
      V_SECRETARIA_DESTINO := X.ID_SECRETARIA_DESTINO;
      V_SECRETARIA_VEHICULO := X.ID_SECRETARIA_VH;
      V_SECRETARIA_LIC_TTO := X.SECRETARIA_TIPO;      
    ----------------------------------------------------
    
    BEGIN
    
        IF V_SECRETARIA_ORIGEN = V_SECRETARIA_VEHICULO THEN
          
          UPDATE CORRECCION_DATOS.DS_TMP_VEHICULOS1
             SET ID_SECRETARIA = V_SECRETARIA_DESTINO,
                 NOMBRE_SECRETARIA = (SELECT NOMBRE 
                                      FROM CORRECCION_DATOS.RUNT_ORGANISMOS_TTO 
                                      WHERE DIVIPO = V_SECRETARIA_DESTINO)          
           WHERE NRO_PLACA = X.NRO_PLACA;
             
        END IF;
        
        IF V_SECRETARIA_DESTINO = V_SECRETARIA_LIC_TTO THEN
          
          UPDATE QUIPUX.LIC_TTO
             SET ID_SECRETARIA = (SELECT ST.ID_SECRETARIA
                                  FROM QUIPUX.SECRETARIAS_TTO ST
                                  WHERE ST.RUNT_SECRETARIA = X.ID_SECRETARIA_ORIGEN AND ROWNUM = 1)
           WHERE NRO_PLACA = X.NRO_PLACA;
        
        END IF;
      
        COMMIT;
        
    EXCEPTION 
      WHEN OTHERS THEN
        ROLLBACK;
        CONTINUE;
    END;    
          
 END LOOP;

END SP_ID_SECRETARIA_TRAMITE;


/*********************************************************************************/
/*Este procedimeinto corrige las inconsistencias del archivo vehiculos - Nombre_Linea*/
PROCEDURE SP_HOMOLOGAR_LINEAS AS

CONTADOR NUMBER:=0;
V_CIL  NUMBER:=0;
V_EXISTE NUMBER:=0;
V_CLASE VARCHAR2(10);
  
CURSOR LINEAS_TTO IS
    SELECT DV.NRO_PLACA,LTT.ID_LINEA,TL.DESC_LINEA,DV.ID_LINEA AS ID_LINEA_RUNT,
           LTT.NOMBRE_LINEA_RUNT,DV.CILINDRAJE,DV.ID_CLASE,DV.NOMBRE_LINEA,
           INSTR(UPPER(TL.DESC_LINEA),UPPER(DV.NOMBRE_LINEA),1) EXISTE
    FROM CORRECCION_DATOS.INCONSISTENCIAS INC
    INNER JOIN CORRECCION_DATOS. DS_TMP_VEHICULOS1 DV
      ON DV.NRO_PLACA = INC.IDENTIFICADOR 
    INNER JOIN QUIPUX.LIC_TTO LTT 
     ON  LTT.NRO_PLACA = INC.IDENTIFICADOR  
    LEFT JOIN QUIPUX.TIPO_LINEA TL
      ON LTT.ID_LINEA = TL.ID_LINEA
    WHERE INC.NOMBRE_ARCHIVO = 'VEHICULO'
      AND INC.CAMPO_FALLO = 'NOMBRE_LINEA'
      AND INC.TIPO_INCONSISTENCIA ='E'
     -- AND INC.IDENTIFICADOR = 'ZZA66D'
    ORDER BY DV.NRO_PLACA;

CURSOR LINEA_SAP(VRUNT_LINEA NUMBER,VCILINDRAJE NUMBER) IS   
 	SELECT 	DISTINCT TL.ID_LINEA, QTL.RUNT_LINEA,SL.ID_LINEA_SAP,
          SL.DESC_LINEA_SAP,SL.CILINDRAJE_SAP
	FROM QUIPUX.TIPO_LINEA TL
  LEFT JOIN QUIPUX.QX_TIPO_LINEA QTL
    ON (TL.ID_LINEA_QX = QTL.ID_LINEA_QX)
  LEFT JOIN QUIPUX.QX_TIPO_MARCA QTM
    ON (QTM.ID_MARCA_QX = QTL.ID_MARCA_QX)
  LEFT JOIN QUIPUX.MARCA_VEHICULOS MV
    ON (MV.ID_MARCA_QX = QTM.ID_MARCA_QX)
  LEFT JOIN DEPURACION.SAP_LINEAS SL
    ON (SL.ID_LINEA_QX = TO_CHAR(QTL.ID_LINEA_QX))
	WHERE (MV.ID_MARCA_QX <> 0 ) 
    AND QTL.RUNT_LINEA = VRUNT_LINEA 
    AND SL.CILINDRAJE_QX = DECODE(SL.CILINDRAJE_QX,0,0
                                                  ,VCILINDRAJE,VCILINDRAJE)      
          -- PENDIENTE PARAMETRIZAR LOS CILINDRAJES SEGUN LA LONGITUD
  ORDER BY TL.ID_LINEA DESC;

BEGIN

  FOR XLIN IN LINEAS_TTO LOOP
  
    V_CIL := XLIN.CILINDRAJE;
    
    IF XLIN.ID_CLASE NOT IN ('10','15','19','14','17') THEN
      V_CLASE := 1;
    ELSE
      V_CLASE := 2;
    END IF;
  
    IF V_CIL NOT IN (135, 225, 185, 175) THEN
     -- V_CIL  := ROUND(V_CIL , (2-(LENGTH(V_CIL )))); 
     
     BEGIN 
     
      SELECT CILINDRAJE INTO  V_CIL
      FROM SAP_CILINDRAJES SC
      WHERE TIPO_VEHICULO = V_CLASE 
        AND XLIN.CILINDRAJE BETWEEN RANGO_DESDE AND RANGO_HASTA;
        
     EXCEPTION
       WHEN OTHERS THEN
        V_CIL  := ROUND(V_CIL , (2-(LENGTH(V_CIL ))));
       END;
    END IF;
    
    FOR XSAPLIN IN LINEA_SAP(XLIN.ID_LINEA_RUNT,V_CIL) LOOP
    
      IF CONTADOR = 0 THEN       
               
            SELECT COUNT(1) INTO V_EXISTE
            FROM DUAL
            WHERE INSTR(UPPER(XSAPLIN.DESC_LINEA_SAP),UPPER(XLIN.NOMBRE_LINEA),1) > 0;           
            
          IF V_EXISTE = 0 THEN
            SELECT COUNT(1) INTO V_EXISTE
            FROM DUAL
            WHERE INSTR(UPPER(XLIN.NOMBRE_LINEA),UPPER(XSAPLIN.DESC_LINEA_SAP),1)> 0;                     
          END IF;       
          
          IF V_EXISTE = 1 THEN         
          
            BEGIN            
              UPDATE QUIPUX.LIC_TTO 
                 SET ID_LINEA = XSAPLIN.ID_LINEA
              WHERE NRO_PLACA = XLIN.NRO_PLACA; 
              COMMIT;              
            EXCEPTION
              WHEN OTHERS THEN
                ROLLBACK;
                CONTADOR := 0;
              END;
            CONTADOR := 1;   
           END IF; 
         END IF;  
    
    END LOOP; 
    CONTADOR := 0;
  END LOOP;  

END SP_HOMOLOGAR_LINEAS;


/*Este procedimiento permite adiconar la capacidad de toneladas a vehiculos 
  segun la tabla*/  
PROCEDURE SP_CAPACIDAD_TONELADAS AS

BEGIN

/*Ingreso cero a los vehiculos de clase Automovil, Campero, Motocicleta
  Mototriciclo y Cuatrimoto*/
UPDATE DS_TMP_VEHICULOS1 DV
   SET DV.CAP_TONELADAS = 0
WHERE DV.ID_CLASE IN ('1','6','10','17','19')
  AND (DV.CAP_TONELADAS IS NULL OR DV.CAP_TONELADAS = '')
  AND NRO_PLACA IN (SELECT INC.IDENTIFICADOR
                    FROM INCONSISTENCIAS INC
                    WHERE INC.NOMBRE_ARCHIVO = 'VEHICULO'
                      AND INC.CAMPO_FALLO = 'CAP_TONELADAS');                      

/*Ingreso cero a los vehiculos de clase Camioneta y Motocarro que tengan 
  Carroceria CARPADO,AMBULANCIA,STATION WAGON,DOBLE CABINA,DOBLE CABINA ESTACAS,
  WAGON,CABINADO,CARPADO,DOBLE CABINA CERRADA,DOBLE CABINA FURGON,
  DOBLE CABINA CON PLATAFORMA,DOBLE CABINA TRACCION SENCILLA,CABINA EXTENDIDA*/
UPDATE DS_TMP_VEHICULOS1 DV
   SET DV.CAP_TONELADAS = 0
WHERE DV.ID_CLASE IN ('5','14') 
  AND DV.ID_CARROCERIA IN ('22','87','237','241','243','274','389',
                           '390','391','402','472','476','836')
  AND (DV.CAP_TONELADAS IS NULL OR DV.CAP_TONELADAS = '')
  AND NRO_PLACA IN (SELECT INC.IDENTIFICADOR
                    FROM INCONSISTENCIAS INC
                    WHERE INC.NOMBRE_ARCHIVO = 'VEHICULO'
                      AND INC.CAMPO_FALLO = 'CAP_TONELADAS');              

/*Ingreso una tonelada a los vehiculos de clase Motocarro con carrocerias 
  ESTACAS,FURGON,ESTIBAS,REPARTO,PANEL,PICO,PLATON*/
UPDATE DS_TMP_VEHICULOS1 DV
   SET DV.CAP_TONELADAS = 1
WHERE DV.ID_CLASE IN ('14') 
  AND DV.ID_CARROCERIA IN ('276','277','278','386','387','388','404')
  AND (DV.CAP_TONELADAS IS NULL OR DV.CAP_TONELADAS = '')
  AND NRO_PLACA IN (SELECT INC.IDENTIFICADOR
                    FROM INCONSISTENCIAS INC
                    WHERE INC.NOMBRE_ARCHIVO = 'VEHICULO'
                      AND INC.CAMPO_FALLO = 'CAP_TONELADAS');
                      
END SP_CAPACIDAD_TONELADAS;


/*ESTE PROCEDIMIENTO PERMITE ESTANDARIZAR LOS CONTRIBUYENTES2 QUE 
  SERAN INGRESADOS EN USUARIOS_TTO*/
PROCEDURE SP_ESTANDARIZAR_CONTRIBYENTES2 AS

V_ID VARCHAR2(100);
V_IDENTIFICACION NUMBER:=0;
V_DIRECCION VARCHAR2(100);
V_TELEFONO VARCHAR2(100);
V_FAX VARCHAR2(100);
V_EMAIL VARCHAR2(100);
V_NOMBRE VARCHAR2(100);
V_APELLIDO VARCHAR2(100);
V_ID_DOCUMENTO VARCHAR2(2);
V_ERROR BOOLEAN := FALSE;
V_EMP_PART VARCHAR2(100);
V_ID_DIRECCION VARCHAR2(30);
V_TIPO_DOCUMENTO VARCHAR2(2);
V_ID_CIUDAD VARCHAR2(20);
V_ID_CIUDAD_DIR VARCHAR2(20);
V_EXISTE NUMBER := 0;
V_TIPO_INC VARCHAR2(2);
V_PAIS VARCHAR2(2);

  CURSOR ID_USUARIO_ANTERIOR IS 
      SELECT DISTINCT (DT.ID_USUARIO_ANTERIOR),TD.ID_DOCUMENTO AS ID_DOCUMENTO_ANTERIOR
      FROM CORRECCION_DATOS. DS_TMP_TRAMITES1 DT      
      INNER JOIN CORRECCION_DATOS.INCONSISTENCIAS INC
        ON DT.NRO_PLACA = INC.IDENTIFICADOR
      INNER JOIN QUIPUX.TIPO_DOCUMENTO TD
        ON TD.MIN_DOCUMENTO = DT.ID_DOCUMENTO_ANTERIOR
      WHERE DT.ID_USUARIO_ANTERIOR NOT IN (SELECT QT.ID_USUARIO
                                           FROM QUIPUX.USUARIOS_TTO QT 
                                           WHERE QT.ID_USUARIO = DT.ID_USUARIO_ANTERIOR)
      AND INC.NOMBRE_ARCHIVO= 'TRAMITE'
      AND INC.CAMPO_FALLO = 'ID_USUARIO_ANTERIOR'
      AND DT.ID_TRAMITE IN (16,65)
      AND DT.ID_DOCUMENTO_ANTERIOR !='S';
      --AND ID_USUARIO_ANTERIOR = '71832745' ;
      
   
   CURSOR USUARIO (V_ID_USUARIO VARCHAR2, V_TIPO_DOCUMENTO VARCHAR2, V_ID_MAX VARCHAR2)IS
      SELECT *
      FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2
      WHERE ID_USUARIO = V_ID_USUARIO
        AND ID_DOCUMENTO = V_TIPO_DOCUMENTO 
        AND ID_DIRECCION = V_ID_MAX;

BEGIN

FOR X IN ID_USUARIO_ANTERIOR LOOP

  SELECT MAX(TO_NUMBER(ID_DIRECCION))
  INTO V_ID_DIRECCION
  FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2
  WHERE ID_USUARIO = X.ID_USUARIO_ANTERIOR
    AND ID_DOCUMENTO = X.ID_DOCUMENTO_ANTERIOR;

  FOR Y IN USUARIO(X.ID_USUARIO_ANTERIOR,X.ID_DOCUMENTO_ANTERIOR,V_ID_DIRECCION) LOOP
  begin
      V_ID := Y.ID;
      V_IDENTIFICACION := Y.ID_USUARIO;
      V_ID_DOCUMENTO := Y.ID_DOCUMENTO;
      V_EMAIL := Y.EMAIL;
      V_EMP_PART := Y.EMP_O_PART;
      
    /*============================================================================================*/
    /*                        APLICO ESTANDARIZACI�N A LOS REGISTROS                              */
      
      IF (Y.ID_DOCUMENTO = 2 AND LENGTH (Y.ID_DOCUMENTO) < 10) THEN
          V_IDENTIFICACION := V_IDENTIFICACION || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_IDENTIFICACION);
      END IF;
      
      V_NOMBRE := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(Y.NOMBRES,'N');
      V_APELLIDO := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(Y.APELLIDOS,'A');
      V_DIRECCION := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(Y.DIRECCION);
      V_TELEFONO := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO(Y.TELEFONO);
      V_FAX :=  PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO(Y.FAX);
    
    /*============================================================================================*/  
       
       
    /*============================================================================================*/
    /*                           APLICO VALIDACIONES A LOS REGISTROS                              */  
    
      UPDATE CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2
      SET TIPO_INCONSISTENCIA = NULL,
          VALIDACION = NULL
      WHERE ID = V_ID; 
      COMMIT;    
      
      V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_APELLIDOS(V_ID_DOCUMENTO,V_APELLIDO,V_ID);
          
      IF V_ERROR = FALSE THEN
        V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_DIRECCION(V_DIRECCION,0,V_ID);
      END IF;
      
      IF V_ERROR = FALSE THEN
        V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO,'T',0,V_ID);
      END IF;
      
      IF V_ERROR = FALSE THEN
        V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_TIPO_DOCUMENTO(V_ID_DOCUMENTO,V_ID);
      END IF;
      
      IF V_ERROR = FALSE THEN
        V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_EMAIL(V_EMAIL,V_ID);
      END IF;
      
      IF V_ERROR = FALSE THEN
        V_ERROR := PKG_VALIDACIONES_REGISTRO.FT_VALIDAR_EMP_PART(V_EMP_PART,V_ID);
      END IF;
      
    /*============================================================================================*/  
      
      SELECT TIPO_INCONSISTENCIA INTO V_TIPO_INC
      FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES2
      WHERE ID = V_ID;       
      
      --SINO SE REPORTAN ERRORES INSERTO LOS DATOS EN USUARIOS_TTO
      IF V_ERROR = FALSE OR V_TIPO_INC = 'A' THEN
         
         BEGIN   
           
          SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = TO_CHAR(V_IDENTIFICACION);
          
          IF V_ID_DOCUMENTO = 2 AND V_EXISTE = 0 THEN
            SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = TO_CHAR(SUBSTR(V_IDENTIFICACION,1,LENGTH(V_IDENTIFICACION)-1));
          END IF;
          
          IF V_EXISTE = 0 THEN
         
            BEGIN
              SELECT ID_CIUDAD INTO V_ID_CIUDAD FROM QUIPUX.CIUDADES WHERE CIUDAD_RUNT = Y.ID_CIUDAD;
            EXCEPTION 
              WHEN OTHERS THEN 
                CONTINUE; 
            END;
            
            BEGIN
              SELECT ID_CIUDAD INTO V_ID_CIUDAD_DIR FROM QUIPUX.CIUDADES WHERE CIUDAD_RUNT = Y.ID_CIUDAD_DIR;
             EXCEPTION 
              WHEN OTHERS THEN 
                CONTINUE; 
            END;
            
            BEGIN
              SELECT ID_PAIS INTO V_PAIS FROM QUIPUX.PAISES WHERE RUNT_PAIS = Y.ID_PAIS;
             EXCEPTION 
              WHEN OTHERS THEN 
                CONTINUE; 
            END;
            
            INSERT INTO QUIPUX.USUARIOS_TTO (ID_USUARIO, ID_DOCUMENTO, ID_CIUDAD,CIUDAD_DIR, DIRECCION,	
                                           APELLIDOS,	NOMBRES,	TELEFONO,	EMP_O_PART,	FECHA_NACIMIENTO,	SEXO,	
                                           ID_PAIS,	FAX,	EMAIL,	ESTADO_PERSONA)
            VALUES(V_IDENTIFICACION,V_ID_DOCUMENTO, V_ID_CIUDAD,V_ID_CIUDAD_DIR,V_DIRECCION,V_APELLIDO, V_NOMBRE, 
                   V_TELEFONO,V_EMP_PART, Y.FECHA_NACIMIENTO, Y.SEXO, V_PAIS, V_FAX, V_EMAIL, 'ACTIVA');
                   
          END IF;  
          
        EXCEPTION
          WHEN OTHERS THEN
            CONTINUE;
          END;  
                 
      END IF;
      
     EXCEPTION
          WHEN OTHERS THEN
            CONTINUE;
          END;   
  END LOOP;

END LOOP;

END SP_ESTANDARIZAR_CONTRIBYENTES2;

/*ESTE PROCEDIMEINTO ELIMINA LOS USUARIOS QUE FUERON REPORTADOS COMO PROPIETARIOS 
  Y SON VENDEDORES                                                               */

PROCEDURE SP_ELIMINAR_PROPIETARIOS_ANT AS

V_USUARIO_NUEVO VARCHAR2(20);

CURSOR PROPIETARIO IS
      SELECT NRO_PLACA, ID_DOCUMENTO, COUNT(NRO_PLACA)
      FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1
      --WHERE NRO_PLACA = 'AAM81B'
      GROUP BY NRO_PLACA, ID_DOCUMENTO
      HAVING COUNT(NRO_PLACA)>1;

BEGIN
    
    FOR X IN PROPIETARIO LOOP
    
        BEGIN  
        
            SELECT DISTINCT ID_USUARIO_NUEVO
            INTO V_USUARIO_NUEVO
            FROM CORRECCION_DATOS.DS_TMP_TRAMITES1
            WHERE NRO_PLACA = X.NRO_PLACA AND
                  ID_DOCUMENTO_NUEVO = X.ID_DOCUMENTO AND
                  ID_TRAMITE IN (16,65);
            
            DELETE FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1
            WHERE NRO_PLACA= X.NRO_PLACA AND
                  ID_DOCUMENTO = X.ID_DOCUMENTO AND
                  ID_USUARIO <> V_USUARIO_NUEVO;
        
        EXCEPTION 
        WHEN OTHERS THEN
           ROLLBACK;
        END; 
    COMMIT;
    END LOOP;
    
END SP_ELIMINAR_PROPIETARIOS_ANT;

END PKG_DEPURAR_INCONSISTENCIAS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DEPURAR_INFO_UNE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_DEPURAR_INFO_UNE" AS

PROCEDURE SP_ESTANDARIZAR AS

V_NOMBRE VARCHAR2(100);
V_APELLIDO VARCHAR2(100);
V_DIRECCION VARCHAR2(100);
V_TELEFONO VARCHAR2(50);
V_CELULAR VARCHAR2(50);
V_ID_CIUDAD VARCHAR2(20);

CURSOR REGISTRO IS
SELECT CLAVE, NOMBRES, APELLIDOS, DIRECCION, TELEFONO, CELULAR, NOMBRE_CIUDAD
FROM CORRECCION_DATOS.DATOS_UNE;
--WHERE NRO_IDENTIFICACION = '1040512384';

BEGIN

FOR X IN REGISTRO LOOP

V_NOMBRE := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(X.NOMBRES,'N');
V_APELLIDO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(X.APELLIDOS,'A');
V_DIRECCION := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(X.DIRECCION);
V_TELEFONO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
V_CELULAR := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO(X.CELULAR);

/*
SELECT MIN ID_CIUDAD
INTO V_ID_CIUDAD
FROM QUIPUX.CIUDADES
WHERE NOMBRE_CIUDAD LIKE (X.NOMBRE_CIUDAD);*/

UPDATE CORRECCION_DATOS.DATOS_UNE
   SET NOMBRES = V_NOMBRE,
       APELLIDOS = V_APELLIDO,
       DIRECCION = V_DIRECCION,
       TELEFONO = V_TELEFONO,
       CELULAR = V_CELULAR
WHERE CLAVE = X.CLAVE;    

COMMIT;      

END LOOP;

END SP_ESTANDARIZAR;

/*ESTE PROCEDIMIENTO REALIZA LAS VALIDACIONES DE NEGOCIO DE LA PLANTILLA INFO UNE.*/
PROCEDURE SP_VALIDACIONES_NEGOCIO AS

  V_ERROR NUMBER := 0;
   
  CURSOR CONTRIBUYENTES IS
    SELECT *
    FROM CORRECCION_DATOS.DATOS_UNE;

BEGIN

--LIMPIO LOS ERRORES ANTERIORES
  --UPDATE CORRECCION_DATOS.DATOS_UNE SET REGISTRO_ERROR =NULL WHERE REGISTRO_ERROR IS NOT NULL;

  FOR XB IN CONTRIBUYENTES LOOP
    
    --VALIDO LA DIRECCION
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(XB.DIRECCION,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
     SP_GENERAR_EXCEPCION(XB.CLAVE, V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(XB.EMAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.CLAVE, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
     SP_GENERAR_EXCEPCION(XB.CLAVE, V_ERROR);
       V_ERROR := 0;
    END IF;
   /* --VALIDO EL FAX
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.CLAVE, V_ERROR);
       V_ERROR := 0;
    END IF;*/
     --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.CELULAR,'T',0);   
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.CLAVE, V_ERROR);
       V_ERROR := 0;
    END IF;
  
  END LOOP;
  
 --VALIDO CAMPOS NULL EN LA PLANTILLA 
   --SP_CAMPOS_NULL;
 
 --APLICO VALIDACIONES DE NEGOCIO SAP
 --SP_VALIDACIONES_NEGOCIO_SAP;

END SP_VALIDACIONES_NEGOCIO;

PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2, PARAMETRO NUMBER) AS

MENSAJE VARCHAR2(255);

BEGIN
   
   
   CASE PARAMETRO
          WHEN 1 THEN
              MENSAJE:='DIRECCION<7, ';
          WHEN 2 THEN
              MENSAJE:='DIRECCION SOLO LETRAS, ';
          WHEN 3 THEN
              MENSAJE:='DIRECCION SOLO NUMEROS, ';
          WHEN 4 THEN
              MENSAJE:='DIRECCION 3 CONSONANTES, ';
          WHEN 5 THEN
              MENSAJE:='EMAIL @, ';
          WHEN 6 THEN
              MENSAJE:='E-MAIL<7, ';
          WHEN 7 THEN
              MENSAJE:='E-MAIL NOREGISTRA, ';
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              MENSAJE:= NULL;    
          ELSE
              MENSAJE:='ERROR EN USUARIO '||IDENTIFICADOR;
    END CASE;

    --INSERTO DESCRIPCION DEL ERROR EN DATOS_UNE
    UPDATE CORRECCION_DATOS.DATOS_UNE
    SET REGISTRO_ERROR = REGISTRO_ERROR || MENSAJE
    WHERE CLAVE = IDENTIFICADOR ;         
    COMMIT;      
          

END SP_GENERAR_EXCEPCION;

--ACTUALIZAR INFORMACI�N COHERENTE EN TEMP_PLANTILLA_PERSONAS_Q
PROCEDURE SP_ACTUALIZAR_PLANTILLA AS

V_CAMPOS_NULL VARCHAR2(1000);
V_REGISTRO_ERROR VARCHAR2(1000);

CURSOR CONTRIBUYENTES IS
SELECT *
FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
WHERE (CAMPOS_NULL IS NOT NULL OR REGISTRO_ERROR IS NOT NULL);
--AND NRO_IDENTIFICACION IN ('10161684');

BEGIN

FOR X IN CONTRIBUYENTES LOOP

V_CAMPOS_NULL := X.CAMPOS_NULL;
V_REGISTRO_ERROR := X.REGISTRO_ERROR;

IF X.CLASE_IDENTIFICACION = 'CC' THEN

  IF X.REGISTRO_ERROR LIKE 'DIRECCI%' THEN
   SP_ACTUALIZAR_DIRECCION(X.NRO_IDENTIFICACION,X.CLASE_IDENTIFICACION);
  END IF;
  IF  X.REGISTRO_ERROR LIKE '%TELEFO%' OR  V_CAMPOS_NULL LIKE '%TELEFO%' THEN
    SP_ACTUALIZAR_TELEFONO(X.NRO_IDENTIFICACION,X.CLASE_IDENTIFICACION);
  END IF;
  IF  X.REGISTRO_ERROR LIKE '%E_MAIL%' OR V_CAMPOS_NULL LIKE '%E_MAIL%' THEN
    SP_ACTUALIZAR_EMAIL(X.NRO_IDENTIFICACION,X.CLASE_IDENTIFICACION);
  END IF;

END IF;


END LOOP;
--ACTUALIZO EL CELULAR
--SP_ACTUALIZAR_CELULAR;

END SP_ACTUALIZAR_PLANTILLA;

--PERMITE ACTUALIZAR LA DIRECCION EN TMP_PLANTILLA_PERSONAS_Q CON DATOS_UNE
PROCEDURE SP_ACTUALIZAR_DIRECCION (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2) AS

V_MAX VARCHAR2(20);
V_DIRECCION VARCHAR2(100);
V_CANTIDAD NUMBER:=0;
V_NOM_SECRE VARCHAR2(100);
V_DIVIPO VARCHAR2 (100);
V_DEPARTAMENTO VARCHAR2(50);
V_SECRETARIA VARCHAR2(50);
V_ENTIDAD VARCHAR(1000);
V_CIUDAD_DIR VARCHAR2(15);
V_CIUDAD_UNE VARCHAR(100);


BEGIN

--FOR X IN CONT_UNE LOOP
BEGIN

SELECT COUNT(1)
INTO V_CANTIDAD
FROM CORRECCION_DATOS.DATOS_UNE
WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
  AND TIPO_DOCUMENTO = V_TIPO
  AND(REGISTRO_ERROR NOT LIKE '%DIRECCIO%' OR REGISTRO_ERROR IS NULL);

IF V_CANTIDAD > 1 THEN

    SELECT MAX(FECHA)
    INTO V_MAX
    FROM CORRECCION_DATOS.DATOS_UNE
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND TIPO_DOCUMENTO = V_TIPO
      AND(REGISTRO_ERROR NOT LIKE '%DIRECCIO%' OR REGISTRO_ERROR IS NULL);
    
    IF V_MAX IS NOT NULL THEN
      SELECT DIRECCION, NOMBRE_CIUDAD
      INTO V_DIRECCION, V_CIUDAD_UNE
      FROM CORRECCION_DATOS.DATOS_UNE
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND TIPO_DOCUMENTO = V_TIPO
        AND FECHA = V_MAX
        AND(REGISTRO_ERROR NOT LIKE '%DIRECCIO%' OR REGISTRO_ERROR IS NULL);
    END IF; 
    
END IF;

IF V_CANTIDAD = 1 THEN
  SELECT DIRECCION, NOMBRE_CIUDAD
  INTO V_DIRECCION, V_CIUDAD_UNE
  FROM CORRECCION_DATOS.DATOS_UNE
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
    AND TIPO_DOCUMENTO = V_TIPO
   -- AND FECHA = V_MAX
    AND(REGISTRO_ERROR NOT LIKE '%DIRECCIO%' OR REGISTRO_ERROR IS NULL);
END IF;    

--SI NO SE ENCUENTRA UNA DIRECCION VALIDA SE INGRESA NO REPORTA Y EL TTO EN DONDE REGISTRA EL VH
  
IF V_CANTIDAD = 0 THEN

 --VALIDO QUE EL IC TENGA ID POBLACION
 SELECT POBLACION  INTO V_CIUDAD_DIR 
  FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q 
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
  AND CLASE_IDENTIFICACION = V_TIPO
  AND REGION IS NOT NULL ;
    
    IF V_CIUDAD_DIR IS NULL THEN
      SELECT TR.CIUDAD, TR.DIVIPO
      INTO V_NOM_SECRE, V_DIVIPO
      FROM DEPURACION.DS_PROPIETARIO DP
      INNER JOIN DEPURACION.DS_VEHICULO DV
      ON DV.NRO_PLACA = DP.NRO_PLACA
      INNER JOIN CORRECCION_DATOS.ORGANISMOS_TTO_RUNT TR
      ON TR.DIVIPO = DV.ID_SECRETARIA
      WHERE DP.ID_USUARIO = V_IDENTIFICACION
        AND DP.ID_DOCUMENTO = (SELECT ID_DOCUMENTO
                               FROM QUIPUX.TIPO_DOCUMENTO
                               WHERE ABREV_DOCUMENTO = V_TIPO)
       AND ROWNUM = 1;
        
      V_DEPARTAMENTO := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('D', V_DIVIPO);
      V_SECRETARIA := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('S',V_DIVIPO);
      
      V_DIRECCION := 'NO REPORTA ' ||V_NOM_SECRE||' - ' ||V_DIVIPO;
     
       
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
      SET DIRECCION_CORRESP = V_DIRECCION,
          DIRECCION_NOT_VEH = V_DIRECCION,
          DIRECCION_RESIDENCIA = V_DIRECCION,
          REGION = V_DEPARTAMENTO,
          POBLACION = V_SECRETARIA,
          ACTUALIZADO_POR = ACTUALIZADO_POR ||' NO IDENTIFICA DIRECCION, '
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND CLASE_IDENTIFICACION = V_TIPO;
      COMMIT;
  ELSE
  
      V_DIRECCION:='NO REPORTA';
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
      SET DIRECCION_CORRESP = V_DIRECCION,
          DIRECCION_NOT_VEH = V_DIRECCION,
          DIRECCION_RESIDENCIA = V_DIRECCION,
          ACTUALIZADO_POR = ACTUALIZADO_POR ||' NO IDENTIFICA DIRECCION, '
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND CLASE_IDENTIFICACION = V_TIPO;
      COMMIT;
    
      V_CIUDAD_DIR := NULL;

  END IF;
    
END IF;
 
 

IF (V_CANTIDAD > 0 AND V_DIRECCION IS NOT  NULL) THEN

--HOMOLOGO EL DEPARTAMENTO Y LA CIUDAD DE HOMOLOCAGION CIUDADES UNE
SELECT ID_DPTO_SAP,ID_CIUD_SAP
INTO V_DEPARTAMENTO, V_SECRETARIA
FROM CORRECCION_DATOS.HOMOLOGACION_CIUDAD_UNE
WHERE NOMBRE_CIUDAD = V_CIUDAD_UNE;
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--

  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET DIRECCION_CORRESP = V_DIRECCION,
      DIRECCION_NOT_VEH = V_DIRECCION,
      DIRECCION_RESIDENCIA = V_DIRECCION,
      REGION = V_DEPARTAMENTO,
      POBLACION = V_SECRETARIA,
      ACTUALIZADO_POR = ACTUALIZADO_POR ||' UNE DIRECCION, '
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
    AND CLASE_IDENTIFICACION = V_TIPO;
  COMMIT;


END IF; 

EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q SET ACTUALIZADO_POR = 'ERROR DIRECCION,'
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO; 
      COMMIT;
END;
--END LOOP;

END SP_ACTUALIZAR_DIRECCION;

-- ACTUALIZAR TELEFONO Y CELULAR
PROCEDURE SP_ACTUALIZAR_TELEFONO (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2)AS

V_TELEFONO VARCHAR2(20);
V_CANTIDAD NUMBER:=0;
V_MAX VARCHAR2(10);
V_ENTIDAD VARCHAR2(1000);

BEGIN

BEGIN

  SELECT COUNT(1)
  INTO V_CANTIDAD
  FROM CORRECCION_DATOS.DATOS_UNE
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
    AND TIPO_DOCUMENTO = V_TIPO
    AND(REGISTRO_ERROR NOT LIKE '%TELEFONO%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('TELEFON%'));
  
  IF V_CANTIDAD > 1 THEN
  
      SELECT MAX(FECHA)
      INTO V_MAX
      FROM CORRECCION_DATOS.DATOS_UNE
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND TIPO_DOCUMENTO = V_TIPO
        AND(REGISTRO_ERROR NOT LIKE '%TELEFONO%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('TELEFON%'));
      
      IF V_MAX IS NOT NULL THEN
        SELECT TELEFONO
        INTO V_TELEFONO
        FROM CORRECCION_DATOS.DATOS_UNE
        WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
          AND TIPO_DOCUMENTO = V_TIPO
          AND FECHA = V_MAX
          AND(REGISTRO_ERROR NOT LIKE '%TELEFONO%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('TELEFON%'));
      END IF; 
      
  END IF;
  
  IF V_CANTIDAD = 1 THEN
    SELECT TELEFONO
    INTO V_TELEFONO
    FROM CORRECCION_DATOS.DATOS_UNE
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND TIPO_DOCUMENTO = V_TIPO
     -- AND FECHA = V_MAX
      AND(REGISTRO_ERROR NOT LIKE '%TELEFONO%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('TELEFON%'));
  END IF;    
   
  IF V_TELEFONO IS NOT  NULL THEN  
  V_ENTIDAD:='UNE TELEFONO, '; 
  ELSE
  V_ENTIDAD:='NO SE IDENTIFICA TELEFONO, ';
  END IF;
  
   UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    SET TELEFONO = V_TELEFONO,
     ACTUALIZADO_POR = ACTUALIZADO_POR || ' '  || V_ENTIDAD
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO;      
   COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q SET ACTUALIZADO_POR = 'ERROR TELEFONO, '
     WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO; 
      COMMIT;
END;

END SP_ACTUALIZAR_TELEFONO;

--ACTUALIZAR EMAIL
PROCEDURE SP_ACTUALIZAR_EMAIL (V_IDENTIFICACION VARCHAR2,V_TIPO VARCHAR2)AS

V_EMAIL VARCHAR2(200);
V_CANTIDAD NUMBER:=0;
V_MAX VARCHAR2(10);
V_ENTIDAD VARCHAR2(1000);

BEGIN
BEGIN

  SELECT COUNT(1)
  INTO V_CANTIDAD
  FROM CORRECCION_DATOS.DATOS_UNE
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
    AND TIPO_DOCUMENTO = V_TIPO
    AND(REGISTRO_ERROR NOT LIKE '%EMAIL%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('EMAIL%'));
 
IF V_CANTIDAD > 1 THEN
SELECT MAX(FECHA)
      INTO V_MAX
      FROM CORRECCION_DATOS.DATOS_UNE
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND TIPO_DOCUMENTO = V_TIPO
        AND(REGISTRO_ERROR NOT LIKE '%EMAIL%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('EMAIL%'));
      
      IF V_MAX IS NOT NULL THEN
        SELECT EMAIL
        INTO V_EMAIL
        FROM CORRECCION_DATOS.DATOS_UNE
        WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
          AND TIPO_DOCUMENTO = V_TIPO
          AND FECHA = V_MAX
          AND(REGISTRO_ERROR NOT LIKE '%EMAIL%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('EMAIL%'));
      END IF; 
      
  END IF;
  
  IF V_CANTIDAD = 1 THEN
    SELECT EMAIL
    INTO V_EMAIL
    FROM CORRECCION_DATOS.DATOS_UNE
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND TIPO_DOCUMENTO = V_TIPO
     -- AND FECHA = V_MAX
      AND(REGISTRO_ERROR NOT LIKE '%EMAIL%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('EMAIL%'));
  END IF;    

  
  IF V_EMAIL IS NOT  NULL THEN  
  V_ENTIDAD:='UNE EMAIL, '; 
  ELSE
  V_ENTIDAD:='NO SE IDENTIFICA EMAIL, ';
  END IF;

    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    SET E_MAIL = V_EMAIL,
    ACTUALIZADO_POR = ACTUALIZADO_POR || ' '  || V_ENTIDAD
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO;      
    COMMIT;


EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q SET ACTUALIZADO_POR = 'ERROR EMAIL, '
     WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO;    
      COMMIT;
END;

END SP_ACTUALIZAR_EMAIL;


-- ACTUALIZAR CELULAR
PROCEDURE SP_ACTUALIZAR_CELULAR AS

V_MOVIL VARCHAR2(20);
V_CANTIDAD NUMBER:=0;
V_MAX VARCHAR2(10);
V_ENTIDAD VARCHAR2(1000);
V_IDENTIFICACION VARCHAR2(20);
V_TIPO VARCHAR2(5);


CURSOR CONTRIBUYENTES IS
SELECT PQ.*
FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q PQ
--INNER JOIN CORRECCION_DATOS.DATOS_UNE DU
--ON DU.NRO_IDENTIFICACION = PQ.NRO_IDENTIFICACION
WHERE (PQ.TELEFONO_MOVIL IS NULL) OR (PQ.TELEFONO_MOVIL = '0');/*
AND DU.CELULAR IS NOT NULL
AND PQ.CLASE_IDENTIFICACION = 'CC';
--AND NRO_IDENTIFICACION IN ('10121644');*/



BEGIN
begin
FOR X IN CONTRIBUYENTES LOOP

V_TIPO := X.CLASE_IDENTIFICACION;
V_IDENTIFICACION := X.NRO_IDENTIFICACION;

BEGIN

  SELECT COUNT(1)
  INTO V_CANTIDAD
  FROM CORRECCION_DATOS.DATOS_UNE
  WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
    AND TIPO_DOCUMENTO = V_TIPO
    AND(REGISTRO_ERROR NOT LIKE '%CELULAR%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('CELULAR%'));
  
  IF V_CANTIDAD > 1 THEN
  
      SELECT MAX(FECHA)
      INTO V_MAX
      FROM CORRECCION_DATOS.DATOS_UNE
      WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
        AND TIPO_DOCUMENTO = V_TIPO
        AND(REGISTRO_ERROR NOT LIKE '%CELULAR%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('CELULAR%'));
      
      IF V_MAX IS NOT NULL THEN
        SELECT CELULAR
        INTO V_MOVIL
        FROM CORRECCION_DATOS.DATOS_UNE
        WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
          AND TIPO_DOCUMENTO = V_TIPO
          AND FECHA = V_MAX
          AND(REGISTRO_ERROR NOT LIKE '%CELULAR%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('CELULAR%'));
      END IF; 
      
  END IF;
  
  IF V_CANTIDAD = 1 THEN
    SELECT CELULAR
    INTO V_MOVIL
    FROM CORRECCION_DATOS.DATOS_UNE
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND TIPO_DOCUMENTO = V_TIPO
     -- AND FECHA = V_MAX
      AND(REGISTRO_ERROR NOT LIKE '%CELULAR%' OR REGISTRO_ERROR IS NULL)OR(CAMPOS_NULL NOT LIKE('CELULAR%'));
  END IF;    
   
  IF V_MOVIL IS NOT NULL AND V_CANTIDAD >0 THEN  
  V_ENTIDAD:='UNE CELULAR, '; 
  ELSE
  V_ENTIDAD:='NO SE IDENTIFICA CELULAR, ';
  END IF;
  
   UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    SET TELEFONO_MOVIL = V_MOVIL,
     ACTUALIZADO_POR = ACTUALIZADO_POR || ' '  || V_ENTIDAD
    WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO;      
   COMMIT;

EXCEPTION
  WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE(V_IDENTIFICACION || ' PRUEBA');  
    /*ROLLBACK;
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q SET ACTUALIZADO_POR = 'ERROR CELULAR, '
     WHERE NRO_IDENTIFICACION = V_IDENTIFICACION
      AND CLASE_IDENTIFICACION = V_TIPO; 
      COMMIT;*/
      CONTINUE;
END;
END LOOP;
EXCEPTION
  WHEN OTHERS THEN
 DBMS_OUTPUT.PUT_LINE(V_IDENTIFICACION || ' PRUEBA');
 end;
END SP_ACTUALIZAR_CELULAR;

END PKG_DEPURAR_INFO_UNE;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_ESTANDARIZA_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_DS_ESTANDARIZA_RUNT" AS

  /****************************************************************************/
  /*ESTA FUNCION CONSULTA EL SINONIMO ESTANDARIZADO DE UNA PALABRA Y SI LO
    RETORNA EN CASO DE QUE LO ENCUENTRE EN LA TABLA, SINO RETORNA CADENA VACIA.*/
  FUNCTION FT_CONSULTAR_SINONIMO(A_PALABRA VARCHAR2) RETURN VARCHAR2 AS
    V_SINONIMO VARCHAR2(30);
    V_PALABRA VARCHAR2(121); --30
  BEGIN
    
    V_PALABRA := A_PALABRA;
    --LE QUITO ESPACIOS AL INICIO Y AL FINAL A LA PALABRA QUE ESTAN CONSULTANDO
    V_PALABRA := TRIM(V_PALABRA);
    --PONGO LA PALABRA EN MAYUSCULAS PARA CONSULTARLA
    V_PALABRA := UPPER(V_PALABRA);
    
    BEGIN
      SELECT DSS.SINONIMO
      INTO V_SINONIMO
      FROM DS_SINONIMO_DIRECCION DSS
      WHERE DSS.PALABRA = V_PALABRA;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_SINONIMO := '';
    END;
    
    RETURN V_SINONIMO;
  END FT_CONSULTAR_SINONIMO;
  
  /****************************************************************************/
  /*ESTA FUNCION RETORNA UN 1 SI EL CARACTER ES UN NUMERO Y UN 0 SI NO ES*/
  FUNCTION FT_ES_NUMERO(A_CARACTER VARCHAR2) RETURN NUMBER AS
    V_POSICION NUMBER;
  BEGIN
    
    V_POSICION := 0;
    
    SELECT INSTR('0123456789',A_CARACTER)
    INTO V_POSICION
    FROM DUAL;
    
    IF V_POSICION > 0 THEN
       RETURN 1;
    ELSE
       RETURN 0;
    END IF;
    
  END FT_ES_NUMERO;
  
  /****************************************************************************/
  /*ESTA FUNCION ELIMINA LOS ESPACIOS EN BLANCO DE UNA CADENA DE CARACTERES*/
  FUNCTION FT_ELIMINAR_ESPACIOS(A_CADENA VARCHAR2) RETURN VARCHAR2 AS
    V_CADENA_RETORNO VARCHAR2(200);
    V_POSICION NUMBER;
  BEGIN
    V_CADENA_RETORNO := A_CADENA;
    --CAMBIO TABULACIONES POR ESPACIOS EN BLANCO
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    --ELIMINO ESPACIOS AL INICIO Y AL FINAL
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    
    --BUSCO SI LA CADENA TIENE ESPACIOS EN BLANCO Y LOS VOY ELIMINANDO
    V_POSICION := 0;
    V_POSICION := INSTR(V_CADENA_RETORNO, ' ');
    WHILE V_POSICION <> 0 
    LOOP
      V_CADENA_RETORNO := SUBSTR(V_CADENA_RETORNO, 1 , V_POSICION - 1) || SUBSTR(V_CADENA_RETORNO, V_POSICION + 1 , LENGTH(V_CADENA_RETORNO));
      V_POSICION := 0;
      V_POSICION := INSTR(V_CADENA_RETORNO, ' ');
    END LOOP;
    
    RETURN V_CADENA_RETORNO;
  END FT_ELIMINAR_ESPACIOS;
  
  /****************************************************************************/
  /*ESTA FUNCION ELIMINA LOS CARACTERES ESPECIALES Y LOS REEMPLAZA POR ESPACIO*/
  FUNCTION FT_ELIMINAR_CARACTERES_ESPEC(A_CADENA VARCHAR2, A_TIPO_CADENA VARCHAR2) RETURN VARCHAR2 AS
    /*EL TIPO ME INDICA SI ES CEDULA, TELEFONO, DIRECCION, NOMBRE, APELLIDO PARA
      SABER QUE CARACTERES ESPECIALES SE ADMITEN
      C - CEDULA
      T - TELEFONO
      D - DIRECCION
      N - NOMBRE
      A - APELLIDO*/
    V_CADENA_RETORNO VARCHAR2(1000);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_POSICION NUMBER;
  BEGIN
       
    IF A_CADENA = '' OR A_CADENA IS NULL THEN
      V_CADENA_RETORNO := '';
    END IF;
    
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(A_CADENA);
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := SUBSTR(A_CADENA, V_CONTADOR, 1);
      V_POSICION := 0;
      V_POSICION := INSTR('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ',UPPER(V_CARACTER),1,1);
      IF V_POSICION > 0 THEN
        V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
      ELSE
        CASE A_TIPO_CADENA
          /*WHEN 'C' THEN
            IF V_CARACTER = '-' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            END IF;*/
          WHEN 'T' THEN
            IF V_CARACTER = '(' OR V_CARACTER = ')' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'D' THEN
            IF V_CARACTER = '#' OR V_CARACTER = '�' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'N' THEN
            IF V_CARACTER = '�' OR V_CARACTER = '.' OR V_CARACTER = '&' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'A' THEN
            IF V_CARACTER = '�' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          ELSE
            V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
        END CASE;
        
      END IF;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    RETURN V_CADENA_RETORNO;
  END FT_ELIMINAR_CARACTERES_ESPEC;
  
  /****************************************************************************/
  /*ESTA FUNCION TOMA UNA CADENA Y SEPARA LA PARTE NUMERICA DEL TEXTO Y VICEBERSA
    SI LA CADENA TIENE CARACTERES ESPECIALES ESTOS SE TOMAN COMO TEXTO*/
  FUNCTION FT_SEPARAR_PALABRAS_NUMEROS(A_CADENA VARCHAR2) RETURN VARCHAR2 AS
    V_CADENA_RETORNO VARCHAR2(500);
    V_CADENA_RETORNO2 VARCHAR2(500);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_ANTERIOR NUMBER;
    V_POSICION NUMBER;
  BEGIN
    V_CADENA_RETORNO := A_CADENA;
    
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    /*RECCORRO LA CADENA CARACTER POR CARACTER Y SI CUANDO ENCUENTRE UN CARACTER
      Y UN NUMERO SEGUIDOS LOS SEPARO*/
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(V_CADENA_RETORNO);
    V_ANTERIOR := 0;
    V_CADENA_RETORNO2 := '';
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := SUBSTR(V_CADENA_RETORNO, V_CONTADOR, 1);
      IF FT_ES_NUMERO(V_CARACTER) <> V_ANTERIOR THEN
        V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || ' ' || V_CARACTER;
        V_ANTERIOR := FT_ES_NUMERO(V_CARACTER);
      ELSE
        V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || V_CARACTER;
      END IF;
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    --ELIMINO POSIBLES ESPACIOS AL INICIO Y DOBLES ESPACION
    V_CADENA_RETORNO2 := TRIM(V_CADENA_RETORNO2);
    V_POSICION := 0;
    V_POSICION := INSTR(V_CADENA_RETORNO2, '  ', 1, 1);
    WHILE V_POSICION > 0
    LOOP
      V_CADENA_RETORNO2 := REPLACE(V_CADENA_RETORNO2, '  ', ' ');
      V_POSICION := INSTR(V_CADENA_RETORNO2, '  ', 1, 1);
    END LOOP;
    
    RETURN V_CADENA_RETORNO2;
  END FT_SEPARAR_PALABRAS_NUMEROS;
  
  /****************************************************************************/
  /*ESTA FUNCION CALCULA EL DIGITO DE VERIFICACION DE UN NIT*/
  FUNCTION FT_CALCULAR_DIGITO_VERIFICA(A_NIT NUMBER) RETURN NUMBER AS
    V_DIGITO_VERICACION NUMBER;
    V_DIGITO NUMBER;
    V_NIT NUMBER;
    V_NIT_15 VARCHAR2(15);
    V_CONTADOR NUMBER;
  BEGIN
    V_NIT := A_NIT;
    --TOMO COMO LONGITUD DE CADENA 15 SI NO LOS TIENE COMPLETO CON CEROS A LA IZQUIERDA
    V_NIT_15 := LPAD(TO_CHAR(V_NIT),15,'0');
    V_CONTADOR := 1;
    V_DIGITO_VERICACION := 0;
    --REALIZO EL CALCULO DEL DIGITO DE VERIFICACION
    WHILE V_CONTADOR <= 15
    LOOP
      V_DIGITO := TO_NUMBER(SUBSTR(V_NIT_15,V_CONTADOR,1));
      CASE V_CONTADOR
        WHEN 1 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 71);
        WHEN 2 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 67);
        WHEN 3 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 59);
        WHEN 4 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 53);
        WHEN 5 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 47);
        WHEN 6 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 43);
        WHEN 7 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 41);
        WHEN 8 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 37);
        WHEN 9 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 29);
        WHEN 10 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 23);
        WHEN 11 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 19);
        WHEN 12 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 17);
        WHEN 13 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 13);
        WHEN 14 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 7);
        WHEN 15 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 3);
        ELSE
          NULL;
      END CASE;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    V_DIGITO_VERICACION := MOD(V_DIGITO_VERICACION, 11);
    IF V_DIGITO_VERICACION > 1 THEN
      V_DIGITO_VERICACION := 11 - V_DIGITO_VERICACION;
    END IF;
    
    RETURN V_DIGITO_VERICACION;
  END FT_CALCULAR_DIGITO_VERIFICA;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA EL NUMERO DE IDENTIFICACION*/
  FUNCTION FT_ESTANDARIZAR_IDENTIFICACION(A_IDENTIFICACION VARCHAR2, A_ID_DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS
    V_IDENTIFICACION_RETORNO VARCHAR2(15);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_DIGITO_VERIFICACION NUMBER;
    V_EXCEPCION BOOLEAN;
  BEGIN 
    V_IDENTIFICACION_RETORNO := A_IDENTIFICACION;
    --ELIMINO LOS CARACTERES ESPECIALES
    V_IDENTIFICACION_RETORNO := FT_ELIMINAR_CARACTERES_ESPEC(V_IDENTIFICACION_RETORNO, 'C');
    --ELIMINO ESPACIOS EN BLANCO
    V_IDENTIFICACION_RETORNO := FT_ELIMINAR_ESPACIOS(V_IDENTIFICACION_RETORNO);
    
    V_EXCEPCION := FALSE;
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(V_IDENTIFICACION_RETORNO);
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      --VERIFICO QUE NO CONTENGA LETRAS
      V_CARACTER := SUBSTR(V_IDENTIFICACION_RETORNO, V_CONTADOR, 1);
      IF FT_ES_NUMERO(V_CARACTER) = 0 THEN
        V_EXCEPCION := TRUE;
      END IF;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    --REALIZO VALIDACIONES DE NIT, SI NO TIENE DIGITO DE VERIFICACION LO CALCULO
    IF A_ID_DOCUMENTO = 'N' AND NOT V_EXCEPCION THEN
      --SI SOLO TIENE 9 DIGITOS CALCULO EL DIGITO DE VERIFICACION
      IF LENGTH(V_IDENTIFICACION_RETORNO) = 9 THEN
        V_DIGITO_VERIFICACION := FT_CALCULAR_DIGITO_VERIFICA(TO_NUMBER(V_IDENTIFICACION_RETORNO));
        V_IDENTIFICACION_RETORNO := V_IDENTIFICACION_RETORNO || TO_CHAR(V_DIGITO_VERIFICACION);
      END IF;
    END IF;
    
    RETURN V_IDENTIFICACION_RETORNO;
  END FT_ESTANDARIZAR_IDENTIFICACION;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA EL NUMERO DE TELEFONO */
  FUNCTION FT_ESTANDARIZAR_TELEFONO(A_TELEFONO VARCHAR2) RETURN VARCHAR2 AS
    V_TELEFONO_RETORNO VARCHAR2(30);
    V_TELEFONO_TEMP VARCHAR2(30);
    V_POSICION NUMBER;
    V_SINONIMO VARCHAR2(30);
    V_PALABRA VARCHAR2(30);
  BEGIN
    V_TELEFONO_TEMP := A_TELEFONO;
    
    --ELIMINO CARACTERES ESPECIALES
    V_TELEFONO_TEMP := FT_ELIMINAR_CARACTERES_ESPEC(V_TELEFONO_TEMP, 'T');
    --ELIMINO LOS ESPACIOS EN BLANCO
    V_TELEFONO_TEMP := FT_ELIMINAR_ESPACIOS(V_TELEFONO_TEMP);
    --SEPARO LETRAS DE NUMEROS
    V_TELEFONO_TEMP := FT_SEPARAR_PALABRAS_NUMEROS(V_TELEFONO_TEMP);
       
    --QUITO ESPACIOS AL INICIO Y AL FINAL.
    V_TELEFONO_TEMP := TRIM(V_TELEFONO_TEMP);
    V_TELEFONO_RETORNO := '';
    V_POSICION := 0;
    WHILE LENGTH(V_TELEFONO_TEMP) > 0
    LOOP
      V_SINONIMO := '';
      V_PALABRA := '';
      V_POSICION := INSTR(V_TELEFONO_TEMP,' ', 1, 1);
      IF V_POSICION > 0 THEN
        V_PALABRA := SUBSTR(V_TELEFONO_TEMP, 1, V_POSICION - 1);
        V_TELEFONO_TEMP := SUBSTR(V_TELEFONO_TEMP, V_POSICION + 1, LENGTH(V_TELEFONO_TEMP));
      ELSE
        V_PALABRA := V_TELEFONO_TEMP;
        V_TELEFONO_TEMP := '';
      END IF;
      
      V_PALABRA := UPPER(V_PALABRA);
      IF V_PALABRA IN ('E','EX','EXT') THEN
        IF V_TELEFONO_TEMP IS NOT NULL THEN
          V_TELEFONO_RETORNO := V_TELEFONO_RETORNO || ' ' || 'EXT';
        END IF;
      ELSE
        V_TELEFONO_RETORNO := V_TELEFONO_RETORNO || ' ' || V_PALABRA;
      END IF;
    END LOOP;
    --ELIMINO POSIBLES ESPACIOS EN BLANCO AL INICIO Y AL FINAL
    V_TELEFONO_RETORNO := FT_ELIMINAR_ESPACIOS(V_TELEFONO_RETORNO);
    
    --SI TIENE PARENTESIS ESTOS NO DEBEN QUEDAR SEPARADOS DE LOS NUMERO
    V_TELEFONO_RETORNO := REPLACE(V_TELEFONO_RETORNO,'( ', '(');
    V_TELEFONO_RETORNO := REPLACE(V_TELEFONO_RETORNO,' )', ')');
    
    IF LENGTH(V_TELEFONO_RETORNO) > 14 THEN
      V_POSICION := INSTR(V_TELEFONO_RETORNO, 'EXT');
      V_TELEFONO_RETORNO := SUBSTR(V_TELEFONO_RETORNO, 1, V_POSICION - 1);
    END IF;
    
    RETURN V_TELEFONO_RETORNO;
  END FT_ESTANDARIZAR_TELEFONO;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA LOS NOMBRES Y APELLIDOS EL PARAMETRO A_TIPO INDICA
    SI ES NOMBRE O APELLIDO N - NOMBRE, A - APELLIDO*/
  
  FUNCTION FT_ESTANDARIZAR_NOM_APE(A_NOMBRE_APELLIDO VARCHAR2, A_TIPO VARCHAR) RETURN VARCHAR2 AS
    V_NOM_APE_RETORNO VARCHAR2(80);
    V_POSICION NUMBER;
  BEGIN
    V_NOM_APE_RETORNO := UPPER(A_NOMBRE_APELLIDO);
    
    --ELIMINO TILDES Y �'S
    V_NOM_APE_RETORNO := TRANSLATE(V_NOM_APE_RETORNO, '����������������������', 'AEIOUAEIOUAEIOUAEIOUNN');
    --PERMITO LOS CARACTERES ' PERO COMO �
    V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, '''', '�');
    --ELIMINO LOS CARACTERES ESPECIALES
    V_NOM_APE_RETORNO := FT_ELIMINAR_CARACTERES_ESPEC(V_NOM_APE_RETORNO, A_TIPO);
    --ELIMINO CUANDO HALLAN 2 ESPACIOS SEGUIDOS
    V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, CHR(9), ' ');
    V_POSICION := 0;
    V_POSICION := INSTR(V_NOM_APE_RETORNO, '  ', 1, 1);
    WHILE V_POSICION > 0
    LOOP
      V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, '  ', ' ');
      V_POSICION := INSTR(V_NOM_APE_RETORNO, '  ', 1, 1);
    END LOOP;
    
    --ELIMINO ESPCIOS EN BLANCO AL INICIO Y L FINAL.
    V_NOM_APE_RETORNO := TRIM(V_NOM_APE_RETORNO);
    --LO PONGO EN MAYUSCULAS
    V_NOM_APE_RETORNO := UPPER(V_NOM_APE_RETORNO);
    RETURN V_NOM_APE_RETORNO;
  END FT_ESTANDARIZAR_NOM_APE;
  
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA LA DIRECCION*/
  FUNCTION FT_ESTANDARIZAR_DIRECCION(A_DIRECCION VARCHAR2) RETURN VARCHAR2 AS
    V_DIRECCION_RETORNO VARCHAR2(121);    --100
    V_DIRECCION_RETORNO_TEMP VARCHAR2(121); --100
    V_PALABRA VARCHAR2(121); --30
    V_SINONIMO VARCHAR2(30);
    V_POSICION NUMBER;
  BEGIN
    V_DIRECCION_RETORNO_TEMP := A_DIRECCION;
    
    --ELIMINO TILDES Y �'S
    V_DIRECCION_RETORNO_TEMP := TRANSLATE(V_DIRECCION_RETORNO_TEMP, '����������������������', 'AEIOUAEIOUAEIOUAEIOUNN');
    --ELIMINO CARACTERES ESPECIALES
    V_DIRECCION_RETORNO_TEMP := FT_ELIMINAR_CARACTERES_ESPEC(V_DIRECCION_RETORNO_TEMP,'D');
    --SEPARO LOS NUMEROS DEL TEXTO
    V_DIRECCION_RETORNO_TEMP := FT_SEPARAR_PALABRAS_NUMEROS(V_DIRECCION_RETORNO_TEMP);
    
    --QUITO ESPACIOS AL INICIO Y AL FINAL.
    V_DIRECCION_RETORNO_TEMP := TRIM(V_DIRECCION_RETORNO_TEMP);
    V_DIRECCION_RETORNO := '';
    V_POSICION := 0;
    WHILE LENGTH(V_DIRECCION_RETORNO_TEMP) > 0
    LOOP
      V_SINONIMO := '';
      V_PALABRA := '';
      V_POSICION := INSTR(V_DIRECCION_RETORNO_TEMP,' ', 1, 1);
      IF V_POSICION > 0 THEN
        V_PALABRA := SUBSTR(V_DIRECCION_RETORNO_TEMP, 1, V_POSICION - 1);
        V_DIRECCION_RETORNO_TEMP := SUBSTR(V_DIRECCION_RETORNO_TEMP, V_POSICION + 1, LENGTH(V_DIRECCION_RETORNO_TEMP));
      ELSE
        V_PALABRA := V_DIRECCION_RETORNO_TEMP;
        V_DIRECCION_RETORNO_TEMP := '';
      END IF;
      
      V_SINONIMO := FT_CONSULTAR_SINONIMO(V_PALABRA);
      IF V_SINONIMO = '' OR V_SINONIMO IS NULL THEN
        V_DIRECCION_RETORNO := V_DIRECCION_RETORNO || ' ' || V_PALABRA;
      ELSE
        V_DIRECCION_RETORNO := V_DIRECCION_RETORNO || ' ' || V_SINONIMO;
      END IF;
    END LOOP;
    --ELIMINO POSIBLES ESPACIOS EN BLANCO AL INICIO Y AL FINAL
    V_DIRECCION_RETORNO := TRIM(V_DIRECCION_RETORNO);
    --LA PONGO EN MAYUSCULAS
    V_DIRECCION_RETORNO := UPPER(V_DIRECCION_RETORNO);
    RETURN V_DIRECCION_RETORNO;
  END FT_ESTANDARIZAR_DIRECCION;
  
  /****************************************************************************/
  /*ESTE PROCESDIMIENTO RECUPERA LA LISTA DE CONTRIBUYENTES DE UN RADICADO 
    PASADO COMO PARAMETRO Y LE REALIZA LA ESTANDARIZACION DE LOS DATOS*/
--PROCEDURE SP_ESTANDARIZAR_RADICADO AS 
PROCEDURE SP_ESTANDARIZAR_RADICADO(A_ID_RADICADO NUMBER) IS

    V_ID_USUARIO_ESTANDARIZADO VARCHAR2(15);
    V_TELEFONO_ESTANDARIZADO   VARCHAR2(14);
    V_FAX_ESTANDARIZADO        VARCHAR2(14);
    V_NOMBRES_ESTANDARIZADO    VARCHAR2(80);
    V_APELLIDOS_ESTANDARIZADO  VARCHAR2(80);
    V_DIRECCION_ESTANDARIZADO  VARCHAR2(100);
    V_ERROR                    VARCHAR2(200);

    V_EXISTE                   NUMBER := 0;
    V_CONTADOR_COMMIT          NUMBER := 0;
    V_ID_REGISTRO              NUMBER := 0;    
    --CONTROL_REGISTRO UTL_FILE.FILE_TYPE;

    
    --CURSOR CONTRIBUYENTES(V_RAD NUMBER) IS
    --V_RAD
    CURSOR CONTRIBUYENTES  IS
    SELECT  DISTINCT DSC.ID_USUARIO,
            DSC.ID_DOCUMENTO,
            DSC.TELEFONO,
            DSC.NOMBRES,
            DSC.APELLIDOS,
            DSC.DIRECCION,
            DSC.ID_DIRECCION
    FROM CONTRIBUYENTE_RUNT_TOTAL DSC
    WHERE DSC.ID_RADICADO = A_ID_RADICADO
    AND DSC.NRO_IDENTIFICADOR IS NULL
    AND DSC.DIRECCION IS NOT NULL
   --AND DSC.ESTADO_VALIDACION = 'VP'
    --AND DSC.ID_USUARIO='800140616'
   --AND DSC.ID_USUARIO IN(SELECT CEDULA FROM TEMP_CEDULAS)
   --AND DSC.ID_USUARIO IN(SELECT NRO_IDENTIFICACION FROM TEMP_PLANTILLA_PERSONAS)
      ;
      
      
    /*CURSOR DIRECCIONES   IS
          SELECT ID_DIRECCION, ID_RADICADO, DIRECCION,ID_CIUDAD, TELEFONO, FAX, NOMBRE_CIUDAD_DIR FROM CONTRIBUYENTE_RUNT_TOTAL
           WHERE ID_RADICADO = A_ID_RADICADO --ID_RADICADO = IDRADICADO
                 --AND ESTADO_VALIDACION = 'VP'
                 ;*/
    
 
    
  BEGIN
    V_CONTADOR_COMMIT := 0;
    
    --POR CADA CONTRIBUYENTE DE ESTE RADICADO REALIZO LA ESTANDARIZACION DE LOS DATOS
    FOR X IN CONTRIBUYENTES LOOP
         BEGIN
         
            V_CONTADOR_COMMIT := V_CONTADOR_COMMIT + 1;
            
            --ESTANDARIZO IDENTIFICACION, TELEFONO, NOMBRES, APELLIDOS, DIRECCION.
           -- V_ID_USUARIO_ESTANDARIZADO := FT_ESTANDARIZAR_IDENTIFICACION(X.ID_USUARIO, X.ID_DOCUMENTO);
            V_TELEFONO_ESTANDARIZADO := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_NOMBRES_ESTANDARIZADO := FT_ESTANDARIZAR_NOM_APE(X.NOMBRES, 'N');
            V_APELLIDOS_ESTANDARIZADO := FT_ESTANDARIZAR_NOM_APE(X.APELLIDOS, 'A');
            V_DIRECCION_ESTANDARIZADO := FT_ESTANDARIZAR_DIRECCION(X.DIRECCION);
            
            V_EXISTE := 0;
            --V_ID_REGISTRO := X.NRO_IDENTIFICADOR;
            
            --VERIFICO SI EL REGISTRO YA EXISTE EN LA TABLA DE CONTRIBUYENTES ESTANDARIZADOS
            /*SELECT COUNT(1)
            INTO V_EXISTE
            FROM CONTRIBUYENTE_RUNT_TOTAL DSCE               
            WHERE DSCE.ID_RADICADO = A_ID_RADICADO
            AND X.ID_USUARIO = DSCE.ID_USUARIO
            AND X.ID_DOCUMENTO=DSCE.ID_DOCUMENTO;*/
            
            --DELETE FROM DEPURACION.DS_CONTRIBUYENTE_ESTANDAR WHERE ID_USUARIO = X.ID_USUARIO AND ID_DOCUMENTO = X.ID_DOCUMENTO AND NRO_IDENTIFICADOR <> X.NRO_IDENTIFICADOR;
            --SI YA EXISTE ACTUALIZO, SINO INSERTO
           --IF V_EXISTE > 0 then
              
              UPDATE CORRECCION_DATOS.CONTRIBUYENTE_RUNT_TOTAL
              SET --ID_USUARIO = V_ID_USUARIO_ESTANDARIZADO,
                  TELEFONO = V_TELEFONO_ESTANDARIZADO,
                  NOMBRES = V_NOMBRES_ESTANDARIZADO,
                  APELLIDOS = V_APELLIDOS_ESTANDARIZADO,
                  DIRECCION = V_DIRECCION_ESTANDARIZADO,
                  NRO_IDENTIFICADOR='EST'
              WHERE ID_USUARIO = X.ID_USUARIO
              AND ID_DOCUMENTO= X.ID_DOCUMENTO
              AND ID_DIRECCION=X.ID_DIRECCION;
            /*ELSE    

              INSERT INTO DEPURACION.DS_CONTRIBUYENTE_ESTANDAR
                      (NRO_IDENTIFICADOR,
											ID_DOCUMENTO,
                      ID_USUARIO,
                      TELEFONO,
                      NOMBRES,
                      APELLIDOS,
                      DIRECCION)
              VALUES  (X.NRO_IDENTIFICADOR,
											X.ID_DOCUMENTO,
                      V_ID_USUARIO_ESTANDARIZADO,
                      V_TELEFONO_ESTANDARIZADO,
                      V_NOMBRES_ESTANDARIZADO,
                      V_APELLIDOS_ESTANDARIZADO,
                      V_DIRECCION_ESTANDARIZADO);*/
            --END IF;            
            COMMIT;            
         EXCEPTION
            WHEN OTHERS THEN
            V_ERROR := SQLERRM;
            /*INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,
                                                                        2,
                                                                        A_ID_RADICADO,
                                                                        V_ID_REGISTRO,
                                                                        V_ERROR, 4
                                                                       );
            UPDATE DEPURACION.DS_CONTRIBUYENTE SET ESTADO_VALIDACION = 'RE'
                   WHERE NRO_IDENTIFICADOR = V_ID_REGISTRO
                     AND ID_RADICADO = A_ID_RADICADO;
              
            COMMIT;*/
             IF (V_CONTADOR_COMMIT = 500 ) THEN
                COMMIT;
                V_CONTADOR_COMMIT := 0;
            END IF;
            
         END;
    END LOOP;

   /* V_CONTADOR_COMMIT := 0;
    FOR X IN DIRECCIONES  LOOP
        
            V_CONTADOR_COMMIT := V_CONTADOR_COMMIT + 1;
            
            --ESTANDARIZO IDENTIFICACION, TELEFONO, NOMBRES, APELLIDOS, DIRECCION.
            --V_ID_USUARIO_ESTANDARIZADO := FT_ESTANDARIZAR_IDENTIFICACION(X.ID_USUARIO, X.ID_DOCUMENTO);
            V_TELEFONO_ESTANDARIZADO  := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_FAX_ESTANDARIZADO       := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_DIRECCION_ESTANDARIZADO := FT_ESTANDARIZAR_DIRECCION(X.DIRECCION);
            
            V_EXISTE := 0;
            V_ID_REGISTRO := X.ID_DIRECCION;           

              UPDATE CORRECCION_DATOS.CONTRIBUYENTE_RUNT_TOTAL
              SET TELEFONO = V_TELEFONO_ESTANDARIZADO,
                  DIRECCION = V_DIRECCION_ESTANDARIZADO,
                  FAX = V_FAX_ESTANDARIZADO
              WHERE ID_DIRECCION = X.ID_DIRECCION;

            IF (V_CONTADOR_COMMIT = 500 ) THEN
                COMMIT;
                V_CONTADOR_COMMIT := 0;
            END IF;
    END LOOP;*/
    COMMIT;
    
  END SP_ESTANDARIZAR_RADICADO;

END PKG_DS_ESTANDARIZA_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_GENERAR_PLANTILLA_HT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_HT" AS

PROCEDURE SP_GENERAR_PL_TRASPASOS AS
V_PLACA VARCHAR2(10);
V_EXISTE NUMBER:=0;

CURSOR PLACAS IS
SELECT DISTINCT NRO_PLACA FROM TEMP_PLACAS;

BEGIN

  FOR X IN PLACAS LOOP
    
    V_PLACA := X.NRO_PLACA;    
    --Valido si existe en historiales traspaso.
    SELECT COUNT(1) INTO V_EXISTE 
    FROM QUIPUX.HISTORIALES_TRASPASOS WHERE NRO_PLACA = V_PLACA;
    
    IF V_EXISTE > 0 THEN    
      SP_INGRESAR_TRASPASO(V_PLACA, V_EXISTE);    
    END IF;  
  
  END LOOP;

END SP_GENERAR_PL_TRASPASOS;

PROCEDURE SP_INGRESAR_TRASPASO (V_NRO_PLACA VARCHAR2, V_CANT NUMBER) AS

V_FECHA_MATRICULA DATE;
V_PROPIETARIO VARCHAR2(15);
V_PROPIETARIO_NUEVO VARCHAR2(15);
V_FECHA_INICIO VARCHAR2(10);
V_FECHA_FIN VARCHAR2(10);
V_FECHA DATE;
V_PLACA VARCHAR2(6);
V_EXISTE NUMBER:=0;
V_NOMBRE VARCHAR2(100);
V_TIPO_DOC VARCHAR2(4);
V_CONTADOR NUMBER:=1;

CURSOR HISTORIAL IS
SELECT * 
FROM QUIPUX.HISTORIALES_TRASPASOS HT
WHERE HT.NRO_PLACA = V_NRO_PLACA ORDER BY FECHA asc;

BEGIN

 FOR X IN HISTORIAL LOOP
    
    V_PLACA := X.NRO_PLACA;    
    V_FECHA_FIN := TO_CHAR(X.FECHA, 'YYYYMMDD');
    V_PROPIETARIO := X.ID_USUARIO;
    
   --Valido Cuantos tramites tiene de la misma fecha
   /*
   SELECT COUNT(1) INTO V_EXISTE 
   FROM QUIPUX.HISTORIALES_TRASPASOS 
   WHERE NRO_PLACA = V_PLACA AND FECHA = V_FECHA;*/
   
    --Consulto la feha matricula inicial
    SELECT FECHA_MI INTO V_FECHA_MATRICULA 
    FROM CORRECCION_DATOS.TEMP_PLACAS WHERE NRO_PLACA = V_NRO_PLACA;
    
    --Si la fecha MI esta vacia, llevo la fecha ingreso tto
    IF V_FECHA_MATRICULA IS NULL OR V_FECHA_MATRICULA = '' THEN
      SELECT FECHA_INGRESO_TTO INTO V_FECHA_MATRICULA 
      FROM QUIPUX.LIC_TTO WHERE NRO_PLACA = V_PLACA;    
    END IF;
    
    IF V_CONTADOR = 1 THEN 
      V_FECHA_INICIO := TO_CHAR(V_FECHA_MATRICULA, 'YYYYMMDD'); 
    END IF;    
    
        --Consulto el propietario
       SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = V_PROPIETARIO AND ID_DOCUMENTO = 2;
     
          IF V_EXISTE > 0 THEN        
            SELECT NOMBRES, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
            FROM QUIPUX.USUARIOS_TTO UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
            WHERE ID_USUARIO = V_PROPIETARIO;
          --Estandarizo el nit de ser necesario  
          IF LENGTH(V_PROPIETARIO)= 9 THEN
              V_PROPIETARIO := V_PROPIETARIO || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_PROPIETARIO);
          END IF;  
          
        ELSE
        
          SELECT NOMBRES || ' ' || APELLIDOS, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
          FROM QUIPUX.USUARIOS_TTO UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
          WHERE ID_USUARIO = V_PROPIETARIO;
        
        END IF;      
    
    INSERT INTO TMP_PLANTILLA_TRASPASOS (NRO_PLACA, PROPIETARIO, ID_DOCUMENTO, ID_USUARIO, PORCENTAJE, DESDE, HASTA)
    VALUES (V_PLACA, V_NOMBRE, V_TIPO_DOC, V_PROPIETARIO, X.PORCENTAJE, V_FECHA_INICIO, V_FECHA_FIN );
   
   V_FECHA_INICIO := V_FECHA_FIN;
 
   --Si es el ultimo tramite ingreso el comprador
   IF V_CANT = V_CONTADOR THEN
      V_NOMBRE := NULL;
      V_TIPO_DOC := NULL;
      V_PROPIETARIO := X.ID_COMPRADOR;
      
      SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = V_PROPIETARIO AND ID_DOCUMENTO = 2;
     
      IF V_EXISTE > 0 THEN        
      
        SELECT NOMBRES, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
        FROM QUIPUX.USUARIOS_TTO UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
        WHERE ID_USUARIO = X.ID_COMPRADOR;
        --Estandarizo el nit de ser necesario  
        IF LENGTH(V_PROPIETARIO)= 9 THEN
          V_PROPIETARIO := V_PROPIETARIO || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_PROPIETARIO);
        END IF;
          
      ELSE
      
        SELECT NOMBRES || ' ' || APELLIDOS, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
        FROM QUIPUX.USUARIOS_TTO UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
        WHERE ID_USUARIO = X.ID_COMPRADOR;
      
      END IF; 
     
    INSERT INTO TMP_PLANTILLA_TRASPASOS (NRO_PLACA, PROPIETARIO, ID_DOCUMENTO, ID_USUARIO, PORCENTAJE, DESDE, HASTA)
    VALUES (V_PLACA, V_NOMBRE, V_TIPO_DOC, V_PROPIETARIO, X.PORCENTAJE, V_FECHA_INICIO, '');
      
   END IF;
   
     V_CONTADOR := V_CONTADOR +1;   
  
  END LOOP;
  commit;

END SP_INGRESAR_TRASPASO;

/*ARMAR PLANTILLA DE TABLAS DS*/
PROCEDURE SP_GENERAR_PL_TRASPASOS_DS AS
V_PLACA VARCHAR2(10);
V_EXISTE NUMBER:=0;

CURSOR PLACAS IS
SELECT DISTINCT NRO_PLACA FROM TEMP_PLACAS;

BEGIN

  FOR X IN PLACAS LOOP
    
    V_PLACA := X.NRO_PLACA;    
    --Valido si existe en historiales traspaso.
    SELECT COUNT(1) INTO V_EXISTE 
    FROM DEPURACION.DS_TRAMITE 
    WHERE NRO_PLACA = V_PLACA AND ID_TRAMITE IN (16,65);
    
    IF V_EXISTE > 0 THEN    
      SP_INGRESAR_TRASPASO(V_PLACA, V_EXISTE);    
    END IF;  
  
  END LOOP;

END SP_GENERAR_PL_TRASPASOS_DS;

PROCEDURE SP_INGRESAR_TRASPASO_DS (V_NRO_PLACA VARCHAR2, V_CANT NUMBER) AS

V_FECHA_MATRICULA DATE;
V_PROPIETARIO VARCHAR2(15);
V_PROPIETARIO_NUEVO VARCHAR2(15);
V_FECHA_INICIO VARCHAR2(10);
V_FECHA_FIN VARCHAR2(10);
V_FECHA DATE;
V_PLACA VARCHAR2(6);
V_EXISTE NUMBER:=0;
V_CANT1 NUMBER:=0;
V_NOMBRE VARCHAR2(100);
V_TIPO_DOC VARCHAR2(4);
V_CONTADOR NUMBER:=1;

CURSOR HISTORIAL IS
SELECT * 
FROM DEPURACION.DS_TRAMITE DT
WHERE DT.NRO_PLACA = V_NRO_PLACA 
  AND ID_RADICADO = (SELECT MAX(TO_NUMBER(ID_RADICADO)) FROM DEPURACION.DS_TRAMITE DT1
                              WHERE DT1.NRO_PLACA = V_NRO_PLACA) 
ORDER BY FECHA_TRAMITE ASC;

BEGIN

 FOR X IN HISTORIAL LOOP
    
    V_PLACA := X.NRO_PLACA;    
    V_FECHA_FIN := TO_CHAR(X.FECHA_TRAMITE, 'YYYYMMDD');
    V_PROPIETARIO := X.ID_USUARIO_ANTERIOR;
    V_TIPO_DOC := X.ID_DOCUMENTO_ANTERIOR;
    
    SELECT COUNT(1) INTO V_CANT1 FROM DEPURACION.DS_TRAMITE DT
    WHERE DT.NRO_PLACA = V_PLACA 
      AND ID_RADICADO = X.ID_RADICADO;
    
   --Valido Cuantos tramites tiene de la misma fecha
   /*
   SELECT COUNT(1) INTO V_EXISTE 
   FROM QUIPUX.HISTORIALES_TRASPASOS 
   WHERE NRO_PLACA = V_PLACA AND FECHA = V_FECHA;*/
   
    --Consulto la feha matricula inicial
    SELECT FECHA_MI INTO V_FECHA_MATRICULA 
    FROM CORRECCION_DATOS.TEMP_PLACAS WHERE NRO_PLACA = V_NRO_PLACA;
    
    --Si la fecha MI esta vacia, llevo la fecha ingreso tto
    IF V_FECHA_MATRICULA IS NULL OR V_FECHA_MATRICULA = '' THEN
      SELECT FECHA_INGRESO_TTO INTO V_FECHA_MATRICULA 
      FROM QUIPUX.LIC_TTO WHERE NRO_PLACA = V_PLACA;    
    END IF;
    
    IF V_CONTADOR = 1 THEN 
      V_FECHA_INICIO := TO_CHAR(V_FECHA_MATRICULA, 'YYYYMMDD'); 
    END IF;    
    
        --Consulto el propietario
      -- SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = V_PROPIETARIO AND ID_DOCUMENTO = 2;
     
          IF V_TIPO_DOC > 2 THEN        
            SELECT NOMBRES, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
            FROM DEPURACION.DS_CONTRIBUYENTE UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
            WHERE UT.ID_USUARIO = V_PROPIETARIO AND UT.ID_DOCUMENTO = V_TIPO_DOC;
          --Estandarizo el nit de ser necesario  
          IF LENGTH(V_PROPIETARIO)= 9 THEN
              V_PROPIETARIO := V_PROPIETARIO || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_PROPIETARIO);
          END IF;  
          
        ELSE
        
          SELECT NOMBRES || ' ' || APELLIDOS, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
          FROM DEPURACION.DS_CONTRIBUYENTE UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
          WHERE UT.ID_USUARIO = V_PROPIETARIO AND UT.ID_DOCUMENTO = V_TIPO_DOC;
        
        END IF;      
    
    INSERT INTO TMP_PLANTILLA_TRASPASOS (NRO_PLACA, PROPIETARIO, ID_DOCUMENTO, ID_USUARIO, PORCENTAJE, DESDE, HASTA)
    VALUES (V_PLACA, V_NOMBRE, V_TIPO_DOC, V_PROPIETARIO, X.PORCENTAJE_PROP, V_FECHA_INICIO, V_FECHA_FIN );
   
   V_FECHA_INICIO := V_FECHA_FIN;
 
   --Si es el ultimo tramite ingreso el comprador
   IF V_CANT1 = V_CONTADOR THEN
      V_NOMBRE := NULL;
      V_TIPO_DOC := X.ID_DOCUMENTO_NUEVO;
      V_PROPIETARIO := X.ID_USUARIO_NUEVO;
      
      --SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO WHERE ID_USUARIO = V_PROPIETARIO AND ID_DOCUMENTO = 2;
     
      IF V_TIPO_DOC = 2 THEN        
      
        SELECT NOMBRES, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
        FROM DEPURACION.DS_CONTRIBUYENTE UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
        WHERE UT.ID_USUARIO = V_PROPIETARIO AND UT.ID_DOCUMENTO = V_TIPO_DOC;
        --Estandarizo el nit de ser necesario  
        IF LENGTH(V_PROPIETARIO)= 9 THEN
          V_PROPIETARIO := V_PROPIETARIO || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_PROPIETARIO);
        END IF;
          
      ELSE
      
        SELECT NOMBRES || ' ' || APELLIDOS, TD.ABREV_DOCUMENTO INTO V_NOMBRE, V_TIPO_DOC 
        FROM DEPURACION.DS_CONTRIBUYENTE UT INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
        WHERE UT.ID_USUARIO = V_PROPIETARIO AND UT.ID_DOCUMENTO = V_TIPO_DOC;
      
      END IF; 
     
    INSERT INTO TMP_PLANTILLA_TRASPASOS (NRO_PLACA, PROPIETARIO, ID_DOCUMENTO, ID_USUARIO, PORCENTAJE, DESDE, HASTA)
    VALUES (V_PLACA, V_NOMBRE, V_TIPO_DOC, V_PROPIETARIO, X.PORCENTAJE_PROP, V_FECHA_INICIO, '');
      
   END IF;
   
     V_CONTADOR := V_CONTADOR +1;   
  
  END LOOP;
  commit;

END SP_INGRESAR_TRASPASO_DS;


END PKG_GENERAR_PLANTILLA_HT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_GENERAR_PLANTILLA_IC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_IC" AS  

PROCEDURE SP_INSERTAR_REGISTRO AS
   
	V_EXISTE VARCHAR2(20);
	V_TELEFONO VARCHAR2(20);
	V_NOMBRE VARCHAR2 (150);
	V_APELLIDO VARCHAR2 (150);
	V_DIRECCION VARCHAR2 (150);
	V_TIPO_DOC1 VARCHAR2(20);
	V_TIPO_DOC2 VARCHAR2(20);
	V_CLASE_INT VARCHAR2(10);
	V_DEPARTAMENTO VARCHAR2(50);
	V_SECRETARIA VARCHAR2 (100);
	V_BUSCAR VARCHAR2 (20);
	V_INT VARCHAR2 (20);
	V_TIPO_V VARCHAR2(2);
	V_TIPO_INT VARCHAR2 (2);
	ERROR_MSG VARCHAR2 (255);
	V_IDENTIFICADOR VARCHAR2(20);
   
   CURSOR INTERLOCUTOR IS
		SELECT DISTINCT NRO_IDENTIFICADOR,
					  ID_USUARIO,
					  ID_DOCUMENTO,
					  ID_CIUDAD_DIR
		FROM CONTRIBUYENTE_RUNT_TOTAL
    WHERE ID_USUARIO ='811043951'; 
		--WHERE ROWNUM <= 1;
    --WHERE ID_USUARIO IN (SELECT CEDULA FROM TEMP_CEDULAS);--10941, 10910, 2165, 625
BEGIN

	FOR X IN INTERLOCUTOR LOOP
		--INSERTO EL REGISTRO EN LA TEMP_PLANTILLA_PERSONAS Y CAPTURO EL IDENTIFICADOR
		V_IDENTIFICADOR:=FT_INSERTAR (X.ID_USUARIO, X.ID_DOCUMENTO);  
  
		IF V_IDENTIFICADOR IS NOT NULL THEN
			BEGIN
				--CAPTURO INFORMACION ESTANDARIZADA DE ESTANDAR_DIRECCIONES
				SELECT ID_DOCUMENTO,
						NOMBRES,
						APELLIDOS,
						DIRECCION,
						TELEFONO
				INTO V_TIPO_DOC1,
					 V_NOMBRE,
					 V_APELLIDO,
					 V_DIRECCION,
					 V_TELEFONO
				FROM CORRECCION_DATOS.ESTANDAR_DIRECCIONES ED
				WHERE Ed.Nro_Identificador = V_IDENTIFICADOR; /* AND
					Ed.Id_Usuario = X.ID_USUARIO AND
					Ed.Id_Documento = X.ID_DOCUMENTO AND
					ED.NRO_IDENTIFICADOR = V_IDENTIF;*/
					
			EXCEPTION
			WHEN OTHERS THEN
				V_TIPO_DOC1:= NULL;
				V_NOMBRE:= NULL; 
				V_APELLIDO:= NULL;
				V_DIRECCION:= NULL;
				V_TELEFONO:= NULL;
				--ERROR_MSG := SQLERRM;
				--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
			END;       
			-- CONVIERTO CODIGO TIPO DOCUMENTO QX A CODIGO SAP 
			V_TIPO_DOC2:=FT_CONVERT_DOC( V_TIPO_DOC1);      
			/* 	IF V_Tipo_Doc1 = 1 OR V_Tipo_Doc1 =10 THEN    -- CEDULA O IDETERMINADO
					V_TIPO_DOC2:='CC';
					--V_CLASE_INT:='PNAT';
					V_TIPO_INT:='1';
				ELSIF V_Tipo_Doc1 = 2 THEN --NIT
					V_TIPO_DOC2:= 'NIT';
					--V_CLASE_INT:='PJPR';
					V_TIPO_INT:='2';
				ELSIF V_Tipo_Doc1 = 3 THEN --EXTRANJERIA
					V_TIPO_DOC2:= 'CE';
				ELSIF V_Tipo_Doc1 = 4 THEN --TARJETA IDENTIDAD
					V_TIPO_DOC2:= 'TI';
				ELSIF V_Tipo_Doc1 = 6 THEN --PASAPORTE
					V_TIPO_DOC2:= 'PASAP';       
				END IF;*/     
		   
			V_DEPARTAMENTO := FT_HOMOLOGAR_SECRETARIA ('D',X.ID_CIUDAD_DIR);
			V_SECRETARIA := FT_HOMOLOGAR_SECRETARIA ('S',X.ID_CIUDAD_DIR);
		 
		  --VALIDO SI EXISTE EL USUARIO EN SAP
			SELECT COUNT(1)
			 INTO V_EXISTE
			FROM CORRECCION_DATOS.IC
			WHERE DCTO_IDENTIFI=X.ID_USUARIO AND
				  CLASE_DCTO = V_TIPO_DOC2;
			   
			IF V_EXISTE > 0 THEN
			   V_TIPO_V:='M';
			   
				BEGIN     
					--CAPTURO EL INTERLOCUTOR COMERCIAL SAP DE TABLA IC
					SELECT ID_INTERLOCUTOR
					INTO V_INT
					FROM CORRECCION_DATOS.IC
					WHERE DCTO_IDENTIFI=X.ID_USUARIO AND
						  CLASE_DCTO = V_TIPO_DOC2 AND
						  ROWNUM = 1;
						
				EXCEPTION
					WHEN OTHERS THEN
					   V_INT:= NULL;
					 --ERROR_MSG := SQLERRM;
					 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
				END;          
						
			ELSE            
			  V_TIPO_V:='N';  
			  V_INT :=NULL;
			END IF;     
		 
			BEGIN   
				--ACTUALIZA DATOS EN TEMP PLANTILLA PERSONAS--
				UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS TP
				SET CONCEPTO_BUSQUEDA1 =       DECODE(V_APELLIDO,NULL,V_NOMBRE
                                                              ,V_APELLIDO),
				   APELLIDO_INTERLOCUTOR =    V_APELLIDO,
				   NOMBRE_PILA_INTERLOCUTOR = V_NOMBRE,
				   DIRECCION_CORRESP =        V_DIRECCION,
				   DIRECCION_NOT_VEH =        V_DIRECCION,
				   DIRECCION_RESIDENCIA =     V_DIRECCION,
				   TELEFONO =                 V_TELEFONO,
				   TELEFONO_MOVIL=            V_TELEFONO,
				   CLASE_IDENTIFICACION =     V_TIPO_DOC2,
				   CLASE_INTERLOCUTOR =       DECODE(V_Tipo_Doc1,'2','PJPR'
																	,'PNAT'),
				   REGION =                   V_DEPARTAMENTO,
				   POBLACION =                V_SECRETARIA,
				   INTERLOCUTOR_COMERCIAL=    V_INT,
				   NOMBRE1_ORGANIZACION =     DECODE(V_Tipo_Doc1,'2', V_NOMBRE),
				   PERSONA_FISICA =           DECODE(V_TIPO_INT,'2', NULL
																   , 'X' ),  
				   TIPO_ARCHIVO=              V_TIPO_V,
				   TIPO_INTERLOCUTOR=         DECODE(V_Tipo_Doc1,'2','2'
																	,'1')
				WHERE TP.NRO_IDENTIFICACION = X.ID_USUARIO AND
					  Tp.Clase_Identificacion = V_TIPO_DOC1;
				   
				COMMIT;
		
			EXCEPTION
				WHEN OTHERS THEN
				ROLLBACK;
				 --ERROR_MSG := SQLERRM;
				 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG); 
			END; 
			
		END IF;  
            
	END LOOP;   
  --EJECUTO LAS VALIDACIONES DE NEGOCIO
  SP_VALIDACIONES_NEGOCIO;
    
END SP_INSERTAR_REGISTRO;
  
  --*************************************************************************************--
  -- ESTA FUNCION RETORNA EL VALOR DE UN CODIGO HOMOLOGADO SEGUN EL PARAMETRO ENVIADO --
FUNCTION FT_HOMOLOGAR_SECRETARIA (PARAMETRO VARCHAR2, CODIGO VARCHAR2) RETURN VARCHAR2 AS

	V_CODIGO VARCHAR2(20);
	ERROR_MSG VARCHAR2(255);
BEGIN

	IF PARAMETRO = 'S' THEN -- CAPTURO EL CODIGO DE LA SECRETARIA

		BEGIN
			
			SELECT Sapc.Id_Ciudad_Sap
			INTO V_CODIGO
			FROM QUIPUX.CIUDADES QXC
			INNER JOIN DEPURACION.Sap_Ciudades SAPC
			ON Sapc.Id_Ciudad_Qx = TO_CHAR(Qxc.Id_Ciudad_Qx)
			WHERE Qxc.Ciudad_Runt = CODIGO;

		EXCEPTION
			WHEN OTHERS THEN
				--ERROR_MSG := SQLERRM;
				V_CODIGO :=NULL;
				--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
		END;


	ELSIF PARAMETRO = 'D' THEN -- CAPTURO EL CODIGO DEL DEPARTAMENTO

		BEGIN 

			SELECT DISTINCT Sapc.Id_Depto_Sap
			INTO V_CODIGO
			FROM QUIPUX.CIUDADES QXC
			INNER JOIN DEPURACION.Sap_Ciudades SAPC
				ON Sapc.Id_Depto_Sap = Qxc.Id_Departamento
			WHERE Qxc.Ciudad_Runt = CODIGO AND
				  ROWNUM =1;     

		EXCEPTION
			WHEN OTHERS THEN
				--ERROR_MSG := SQLERRM;
				--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);  
        V_CODIGO := null;
		END;

	END IF;

RETURN V_CODIGO;

END FT_HOMOLOGAR_SECRETARIA;
  
--**************************************************************************--
--INSERTO INTERLOCUTOR CON DATOS ESTANDAR PARA TODOS  
FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS  
   
	ERROR_MSG VARCHAR2(255); 
	V_IDENTIF VARCHAR2(20); 
	V_ID_MAX VARCHAR2 (20);
	V_DOC VARCHAR2 (20);
	V_EXISTE NUMBER:=0;
   
BEGIN

	BEGIN

		SELECT MAX (TO_NUMBER(ID_DIRECCION))
		INTO V_ID_MAX
		FROM CONTRIBUYENTE_RUNT
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;
		--GROUP BY   ID_DIRECCION;  

		V_DOC:= FT_CONVERT_DOC(DOCUMENTO);
		/*  IF DOCUMENTO = 1 OR DOCUMENTO =10 THEN    -- CEDULA O IDETERMINADO
			V_DOC:='CC';
		ELSIF DOCUMENTO = 2 THEN --NIT
			V_DOC:= 'NIT';
		ELSIF DOCUMENTO = 3 THEN --EXTRANJERIA
			V_DOC:= 'CE';
		ELSIF DOCUMENTO = 4 THEN --TARJETA IDENTIDAD
			V_DOC:= 'TI';
		ELSIF DOCUMENTO = 6 THEN --PASAPORTE
			V_DOC:= 'PASAP';       
		END IF;*/

	-- VALIDO SI EL REGISTRO YA EXISTE EN LA PLANTILLA        
		SELECT COUNT(1)
		INTO V_EXISTE
		FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
		WHERE NRO_IDENTIFICACION = USUARIO AND
			  CLASE_IDENTIFICACION = V_DOC;

		IF V_EXISTE = 0 THEN
			INSERT INTO TEMP_PLANTILLA_PERSONAS (
					  NRO_IDENTIFICACION,         --36                         
					  AGRUPACION_INTERLOCUTOR,    -- 4
					  CLASE_IDENTIFICACION,       --35                      
					  LAVE_TRATAMIENTO,           -- 8
					  NACIONALIDAD_INTERLOCUTOR,  --28
					  IDIOMA_INTERLOCUTOR,        --30
					  IDIOMA_CORRESPONDENCIA,     --24
					  CLASE_DIRECCION_CORRESP,    --37
					  CLASE_DIRECCION_NOT_VEH,    --43
					  CLASE_DIRECCION_RESIDENCIA, --45 
					  PAIS,                       --48
					  FAX,                        --53
					  E_MAIL)                     --54                       
			SELECT  DISTINCT ID_USUARIO,      --36                             
						  '0001',             -- 4
						  ID_DOCUMENTO,       --35
						  '0001',             -- 8
						  'CO',               --28
						  'S',                --30    
						  'S',                --24
						  'XXDEFAULT',        --37
						  'ZNOTIFIVEH',       --43  
						  'ZRESIDVEHI',       --45
						  'CO',               --48 
						  FAX,                --53
						  EMAIL               --54
			FROM CONTRIBUYENTE_RUNT
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO;
      
			--NRO_IDENTIFICADOR =V_IDENTIF; 
			--GROUP BY ID_USUARIO, ID_DIRECCION; 
			--ROWNUM < 11;
			--WHERE  NRO_IDENTIFICADOR ='398685';
			COMMIT;

			--RETORNO EL IDENTIFICADOR DEL ID MAXIMO PARA CONSULTAR OS DATOS ESTANDARIZADOS
			SELECT NRO_IDENTIFICADOR
			INTO V_IDENTIF
			FROM CONTRIBUYENTE_RUNT
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO;
       

		ELSE
		V_IDENTIF := NULL;
		END IF;

	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			V_IDENTIF := NULL;
			ERROR_MSG := SQLERRM;
			--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
END;

RETURN V_IDENTIF;

END FT_INSERTAR;     
  
 -- ESTA FUNCION HOMOLOGA LOS TIPO DOCUMENTO QX A CODIFOS SAP
FUNCTION FT_CONVERT_DOC( V_TIPO_DOC1 VARCHAR2) RETURN VARCHAR2 AS      

	V_CONV VARCHAR2(15);

BEGIN

	IF V_Tipo_Doc1 = 1 OR V_Tipo_Doc1 =10 THEN    -- CEDULA O IDETERMINADO
		V_CONV:='CC';
	ELSIF V_Tipo_Doc1 = 2 THEN --NIT
		V_CONV:= 'NIT';            
	ELSIF V_Tipo_Doc1 = 3 THEN --EXTRANJERIA
		V_CONV:= 'CE';
	ELSIF V_Tipo_Doc1 = 4 THEN --TARJETA IDENTIDAD
		V_CONV:= 'TI';
	ELSIF V_Tipo_Doc1 = 6 THEN --PASAPORTE
		V_CONV:= 'PASAP';       
	END IF;

RETURN V_CONV;

END FT_CONVERT_DOC;  

/*******************************************************************************************/
  /*ESTE PROCEDIMIENTO REALIZA LAS VALIDACIONES DE NEGOCIO DE LA PLANTILLA CONTRIBUYENTE.*/
PROCEDURE SP_VALIDACIONES_NEGOCIO AS

  V_ERROR NUMBER := 0;
   
  CURSOR CONTRIBUYENTES IS
    SELECT *
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS;

BEGIN

--LIMPIO LOS ERRORES ANTERIORES
  --UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS SET REGISTRO_ERROR =NULL WHERE REGISTRO_ERROR IS NOT NULL;

  FOR XB IN CONTRIBUYENTES LOOP
    
    --VALIDO LA DIRECCION
    V_ERROR := FT_VALIDAR_DIRECCION(XB.DIRECCION_CORRESP,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := FT_VALIDAR_EMAIL(XB.E_MAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL FAX
    V_ERROR := FT_VALIDAR_TELEFONO_FAX(XB.FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
     --VALIDO EL TELEFON
    V_ERROR := FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO_MOVIL,'T',0);   
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
  
  END LOOP;
  
 --VALIDO CAMPOS NULL EN LA PLANTILLA 
 SP_CAMPOS_NULL;
 
 --APLICO VALIDACIONES DE NEGOCIO SAP
 SP_VALIDACIONES_NEGOCIO_SAP;

END SP_VALIDACIONES_NEGOCIO;


/****************************************************************************/
  /*ESTA FUNCION REALIZA LAS VALIDACIONES DE LA DIRECCION.*/
  FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER) RETURN NUMBER AS
    V_DIRECCION_TEMPORAL VARCHAR2(121);--100
    V_DIRECCION VARCHAR2(121); ---100
    V_CONSONANTES VARCHAR2(121);--100
    V_LONGITUD NUMBER;
    V_TIENE_NUMEROS NUMBER := 0;
    V_TIENE_CARACTERES NUMBER := 0;
    V_POSICION NUMBER;
    V_EXISTE NUMBER := 0;
    V_EXCEPCION NUMBER := 0;
  BEGIN
     
       
     --LA DIRECCION NO PUEDE TENER UNA LONGITUD MENOR A 7 CARACTERES
    IF LENGTH(V_DIRECCION_TEMPORAL) <= 7 THEN
      --SP_EXCEPCION('LA DIRECCION DEBE TENER MAS DE 7 CARACTERES.');
      IF OPCIONDIR = 0 THEN
          --SP_GENERAR_EXCEPCION(NIDENTIFICADOR,TIPO, 1);
          V_EXCEPCION := 1;
      END IF;
      V_EXISTE := 1;
    END IF;
    
    --VALIDO QUE NO TENGA SOLO NUMEROS Y QUE NO TENGA SOLO LETRAS A NO SER QUE SEA VEREDA  
    V_DIRECCION_TEMPORAL := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ELIMINAR_ESPACIOS(A_DIRECCION);      
    
    V_LONGITUD := LENGTH(V_DIRECCION_TEMPORAL);
    V_TIENE_CARACTERES := NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^0-9]','')),0);
    V_TIENE_NUMEROS    := NVL(LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]','')),0);

    --SOLO NUMEROS
    IF V_TIENE_CARACTERES = 0 THEN
      --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO NUMEROS.');
      V_POSICION := 0;
      V_POSICION := INSTR(V_DIRECCION_TEMPORAL,'VRD');
      IF V_POSICION = 0 THEN
         --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO LETRAS A NO SER QUE SEA VEREDA.');
         IF OPCIONDIR = 0 THEN
              --SP_GENERAR_EXCEPCION(NIDENTIFICADOR,TIPO, 2);
              V_EXCEPCION := 2;
         END IF;
         V_EXISTE := 1;
      END IF;      
    END IF;
    --SOLO LETRAS
    IF V_TIENE_NUMEROS = 0 THEN
        IF OPCIONDIR = 0 THEN
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR,TIPO, 3); 
            V_EXCEPCION := 3;
        END IF;
        V_EXISTE := 1;
    END IF;
    
    --VALIDO QUE NO TENGA TRES CONSONANTES SEGUIDAS, VALIDAS(VRD, BRR, CRV, CRT, BLV, APTDO, CRG, DPTO, CTRAL)
    V_CONSONANTES := A_DIRECCION;
    V_CONSONANTES := UPPER(V_CONSONANTES);
    V_CONSONANTES := REPLACE(V_CONSONANTES,'VRD','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'BRR','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRV','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRT','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'BLV','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'APTDO','*****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRG','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'DPTO','****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CTRAL','*****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'NTR','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'STR','***');
    V_CONSONANTES := TRANSLATE(V_CONSONANTES,'BCDFGHJKLMNPQRSTVWXYZ','~~~~~~~~~~~~~~~~~~~~~');
    
    IF INSTR(V_CONSONANTES,'~~~') > 0 THEN
      --SP_EXCEPCION('LA DIRECCI�N NO PUEDE CONTENER TRES CONSONANTES SEGUIDAS.');
      IF OPCIONDIR = 0 THEN
          --SP_GENERAR_EXCEPCION(NIDENTIFICADOR,TIPO, 4); 
          V_EXCEPCION := 4;
      END IF;
      V_EXISTE := 1;
    END IF;
    
    /*--VALIDO SI HUBIERON EXEPCIONES.
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;*/
    
    RETURN V_EXCEPCION;
    
  END FT_VALIDAR_DIRECCION;
  
PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER) AS

MENSAJE VARCHAR2(255);

BEGIN
   
   /* --CAPTURO EL MENSAJE ERROR DE TEMP_PLANTILLA_PERSONAS PARA CONCATENARLO
    SELECT REGISTRO_ERROR
    INTO MENSAJE
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE NRO_IDENTIFICACION = IDENTIFICADOR AND
          CLASE_IDENTIFICACION = TIPO_IDENTIFICACION;*/

   CASE PARAMETRO
          WHEN 1 THEN
              MENSAJE:='DIRECCION<7, ';
          WHEN 2 THEN
              MENSAJE:='DIRECCION SOLO LETRAS, ';
          WHEN 3 THEN
              MENSAJE:='DIRECCION SOLO NUMEROS, ';
          WHEN 4 THEN
              MENSAJE:='DIRECCION 3 CONSONANTES, ';
          WHEN 5 THEN
              MENSAJE:='EMAIL @, ';
          WHEN 6 THEN
              MENSAJE:='E-MAIL<7, ';
          WHEN 7 THEN
              MENSAJE:='E-MAIL NOREGISTRA, ';
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              MENSAJE:= NULL;    
          ELSE
              MENSAJE:='ERROR EN USUARIO '||IDENTIFICADOR;
    END CASE;

    --INSERTO DESCRIPCION DEL ERROR EN TEMP_PLANTILLA_PERSONAS
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    SET REGISTRO_ERROR = REGISTRO_ERROR || MENSAJE
    WHERE NRO_IDENTIFICACION = IDENTIFICADOR AND
          CLASE_IDENTIFICACION = TIPO_IDENTIFICACION;
    COMMIT;      
          

END SP_GENERAR_EXCEPCION;

/****************************************************************************/
/*ESTA FUNCION VALIDA LOS DATOS DEL CAMPO EMAIL.*/
FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2) RETURN NUMBER AS
    V_POSICION NUMBER;
    V_EMAIL_RETORNA VARCHAR2(50);
    V_EXISTE NUMBER := 0;
    V_EXCEPCION NUMBER := 0;
  BEGIN

    
    V_EMAIL_RETORNA := REPLACE(A_EMAIL,' ','');
    
    --VALIDO QUE TENGA @
    V_POSICION := INSTR(V_EMAIL_RETORNA, '@');
    IF V_EMAIL_RETORNA IS NOT NULL AND V_POSICION = 0 THEN
      --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 61); 
      --V_EXISTE := 1;  
      V_EXCEPCION := 5;
    END IF;
    
    --VALIDO QUE LA LONGITUD SEA MAYOR A 7
    IF V_EMAIL_RETORNA IS NOT NULL AND LENGTH(V_EMAIL_RETORNA) <= 7 THEN
      --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 62); 
      --V_EXISTE := 1; 
      V_EXCEPCION := 6;
    END IF;
    
    --VALIDO QUE EL EMAIL NO TENGA LAS PALABRAS NOTIENE NOREGISTRA
    IF INSTR(UPPER(V_EMAIL_RETORNA),'NOTIENE') > 0 OR INSTR(UPPER(V_EMAIL_RETORNA),'NOREGISTRA') > 0 THEN
      --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 63); 
      --V_EXISTE := 1; 
      V_EXCEPCION := 7;
    END IF;
    
    /*--VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;*/
  RETURN V_EXCEPCION;
  
  END FT_VALIDAR_EMAIL;
  
/**********************************************************************************************************/
/*ESTA FUNCION REALIZA VALIDACIONES EN EL TELEFONO*/
FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER) RETURN NUMBER AS
    V_TELEFONO_TEMP VARCHAR2(20);
    V_POSICION NUMBER;
    V_CONTADOR NUMBER;
    V_LONGITUD NUMBER;
    V_CARACTER VARCHAR2(1);
    V_EXCEPCION BOOLEAN;
    V_EXISTE NUMBER := 0;
    V_EXCEPCION1 NUMBER := 0;
       
  BEGIN
  
  IF A_TELEFONO IS NOT NULL  THEN
    
   --VALIDO QUE TENGA UN NUMERO DE TELEFONO VALIDO POR LO MENOS 7 DIGITOS SEGUIDOS Y LOS UNICOS CARACTERES PERMITIDOS SON "EXT"
    V_TELEFONO_TEMP := NVL(A_TELEFONO,' ');
    V_TELEFONO_TEMP := TRANSLATE(V_TELEFONO_TEMP,'0123456789()','**********~~');
    V_TELEFONO_TEMP := REPLACE(V_TELEFONO_TEMP,'EXT','~~~');
    V_POSICION := INSTR(V_TELEFONO_TEMP, '*******');
    IF V_POSICION = 0 THEN
      IF A_TIPO = 'T' THEN
--        SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 25); 
            V_EXCEPCION1 := 8;
        END IF;
        V_EXISTE := 1;                  
      ELSE
--        SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 33); 
            V_EXCEPCION1 := 9;
        END IF;
        V_EXISTE := 1;                  
      END IF;
    END IF;
    
    V_LONGITUD := LENGTH(V_TELEFONO_TEMP);
    V_CONTADOR := 1;
    V_EXCEPCION := FALSE;
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := '';
      V_CARACTER := SUBSTR(V_TELEFONO_TEMP, V_CONTADOR, 1);
      IF V_CARACTER <> '*' AND V_CARACTER <> '~' THEN
        V_EXCEPCION := TRUE;
      END IF;
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    IF V_EXCEPCION THEN
      IF A_TIPO = 'T' THEN
        --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
        IF OPCIONDIR = 0 THEN        
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 26); 
            V_EXCEPCION1 := 10;
        END IF;
        V_EXISTE := 1;         
      ELSE
        --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
        IF OPCIONDIR = 0 THEN        
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 34);
            V_EXCEPCION1 := 11;
        END IF;
        V_EXISTE := 1; 
      END IF;
    END IF;
    
    V_POSICION := 0;
    V_POSICION := INSTR(A_TELEFONO, '0000000')+INSTR(A_TELEFONO, '1111111')+INSTR(A_TELEFONO, '2222222')+INSTR(A_TELEFONO, '3333333')+INSTR(A_TELEFONO, '4444444')+INSTR(A_TELEFONO, '5555555')+INSTR(A_TELEFONO, '6666666')+INSTR(A_TELEFONO, '7777777')+INSTR(A_TELEFONO, '8888888')+INSTR(A_TELEFONO, '9999999')+INSTR(A_TELEFONO, '1234567')+INSTR(A_TELEFONO, '7654321');
    IF V_POSICION > 0 THEN
      IF A_TIPO = 'T' THEN
        --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 27); 
            V_EXCEPCION1 := 12;
        END IF;
        V_EXISTE := 1;         
      ELSE
        --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            --SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 35); 
            V_EXCEPCION1 := 13;
        END IF;
        V_EXISTE := 1; 
      END IF;
    END IF;
    
   /* --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;*/
    RETURN V_EXCEPCION1;
 
 ELSE
 V_EXCEPCION1:= '14';
  RETURN V_EXCEPCION1;
 
 END IF;  
    
  END FT_VALIDAR_TELEFONO_FAX;
  
/**********************************************************************************************************/
/*ESTA FUNCION VALIDAD CAMPOS NULL*/
PROCEDURE SP_CAMPOS_NULL AS

BEGIN

  --SE LIMIA DE LOS ERRORES ANTERIORES
  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL=NULL WHERE CAMPOS_NULL IS NOT NULL;

  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'INTERLOCUTOR_COMERCIAL, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE INTERLOCUTOR_COMERCIAL IS NULL AND
          TIPO_ARCHIVO= 'M'
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);

  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'TIPO_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE TIPO_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CLASE_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
      
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'AGRUPACION_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE AGRUPACION_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);   
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CONCEPTO_BUSQUEDA1, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CONCEPTO_BUSQUEDA1 IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);   
    
        UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLAVE_TRATAMIENTO, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE LAVE_TRATAMIENTO IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'APELLIDO_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE APELLIDO_INTERLOCUTOR IS NULL AND
          CLASE_IDENTIFICACION <> 'NIT'          
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'NOMBRE1_ORGANIZACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE NOMBRE1_ORGANIZACION IS NULL AND
          CLASE_IDENTIFICACION = 'NIT'          
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    
        UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'NOMBRE_PILA_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE NOMBRE_PILA_INTERLOCUTOR IS NULL AND
          CLASE_IDENTIFICACION <> 'NIT'  
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'IDIOMA_CORRESPONDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE IDIOMA_CORRESPONDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'NACIONALIDAD_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE NACIONALIDAD_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'IDIOMA_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE IDIOMA_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'PERSONA_FISICA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE PERSONA_FISICA IS NULL AND
           CLASE_IDENTIFICACION <> 'NIT'
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_IDENTIFICACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CLASE_IDENTIFICACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'Nro_Identificacion || CLASE_IDENTIFICACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE Nro_Identificacion || CLASE_IDENTIFICACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_CORRESP, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CLASE_DIRECCION_CORRESP IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_NOT_VEH, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE DIRECCION_NOT_VEH IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_RESIDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CLASE_DIRECCION_RESIDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_RESIDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE DIRECCION_RESIDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_NOT_VEH, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE CLASE_DIRECCION_NOT_VEH IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_CORRESP, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE DIRECCION_CORRESP IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'PAIS, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE PAIS IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'REGION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE REGION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'POBLACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE POBLACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'TELEFONO, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE TELEFONO IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'FAX, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE FAX IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'CELULAR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE TELEFONO_MOVIL IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
  SET CAMPOS_NULL = CAMPOS_NULL || 'E_MAIL, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
    WHERE E_MAIL IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
 
 
 COMMIT;
        
END SP_CAMPOS_NULL;

/*****************************************************************************/
/*VALIDACIONES DE NEGOCIO SAP*/
PROCEDURE SP_VALIDACIONES_NEGOCIO_SAP AS

V_EXISTE VARCHAR2(2);

BEGIN

  BEGIN
      --TIPO DE INTERLOCUTOR DIFERENTE 1 O 2
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'TIPO DE INTERLOCUTOR DIFERENTE 1 O 2'
      WHERE TIPO_INTERLOCUTOR NOT IN ('1','2');
      
      --CLASE INTERLOCUTOR DIFERENTE DE PNAT O PJPR
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'CLASE INTERLOCUTOR DIFERENTE DE PNAT O PJPR'
      WHERE CLASE_INTERLOCUTOR NOT IN ('PNAT','PJPR');
      
      --AGRUPACION INTERLOCUTOR = 0001
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'AGRUPACION INTERLOCUTOR <> 0001'
      WHERE AGRUPACION_INTERLOCUTOR <> '0001';
      
      --CONCEPTO DE BUSQUEDA NULOS
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'CONCEPTO DE BUSQUEDA NULOS'
      WHERE CONCEPTO_BUSQUEDA1 IS NULL;
      
      --CONCEPTO DE BUSQUEDA CON NUMEROS
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'CONCEPTO DE BUSQUEDA CON NUMEROS'
      WHERE INSTR (TRANSLATE (CONCEPTO_BUSQUEDA1,'1234567890','**********'),'*',1,1)>0;
      
      --CONCEPTO DE BUSQUEDA DESCONOCIDO
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'CONCEPTO DE BUSQUEDA CONTIENE DESCONOCIDO'
      WHERE INSTR (CONCEPTO_BUSQUEDA1,'DESC',1,1)>0;
      
      --TELEFONO FUERA DEL ESTANDAR
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'TELEFONO FUERA DEL ESTANDAR'
      WHERE REPLACE(TRANSLATE (TRANSLATE(TELEFONO,'EXTextPBpb','**********'),'1234567890','@@@@@@@@@@'),' ','')
          NOT IN ('@@@@@@@','@@@@@@@@','@@@@@@@@@','@@@@@@@@@@','@@@@@@@***@@@@','@@@@@@@***@@@',
              '@@@@@@@***@@','@@@@@@@***@','***@@@@@@@@@@@','***@@@@@@@@@','***@@@@@@@@@@') OR
          LENGTH (TELEFONO) < 7;
      
      --REGION CON REALACION A POBLACION
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'LA POBLACION NO PERTENECE A REGION'
      WHERE REGION <> DECODE(LENGTH(POBLACION),4,('0'|| SUBSTR (POBLACION,1,1)),                       
                            SUBSTR (POBLACION,1,2));	
      
      --LONGITUD NRO IDENTIFICACION
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS
      SET CAMPOS_NULL = 'ERROR LONGITUD NRO IDENTIFICACION O CARACTER NO NUMERICO'
      WHERE LENGTH(NRO_IDENTIFICACION) < 4 OR
          LENGTH(NRO_IDENTIFICACION) > 11 OR
           INSTR (TRANSLATE(NRO_IDENTIFICACION,'0123456789','**********'),'*') = 0 OR
           INSTR (TRANSLATE (UPPER(NRO_IDENTIFICACION),'ABCDEFGHIJKLMN�OPQRSTUVWXYZ','***************************'),'*') = 1 OR
           INSTR (TRANSLATE (UPPER(NRO_IDENTIFICACION),'�!"#$%&/()=?�|��+{}[],.;:_*-','****************************'), '*') = 1;				
           
      COMMIT;
      
  EXCEPTION
    WHEN OTHERS THEN
    V_EXISTE := NULL;
    
  END;  



END SP_VALIDACIONES_NEGOCIO_SAP;


/*****************************************************************************/
/* ESTE PROCEDIMIENTO CREA LA PLANTILA ASOCIAR IC A OC */
PROCEDURE SP_ASOCIAR_IC_A_OC AS

V_MAX VARCHAR2(15);
V_CANTIDAD NUMBER := 0;
V_PORCENTAJE NUMBER := 0;
V_EXISTE NUMBER := 0;
V_PLACA  VARCHAR2(15);
V_INDETIFICACION VARCHAR2(20);
V_TIPO VARCHAR2 (5);
ERROR_MSG VARCHAR (255);
V_CONTADOR NUMBER := 0;

  CURSOR PLACAS IS 
  SELECT DISTINCT NRO_PLACA
  FROM CORRECCION_DATOS.PROPIETARIOS_RUNT
  WHERE FECHA_ARCHIVO IN ('2015041',	'2015042',	'2015051',	'2015052',	'2015061',	'2015062',	
                          '2015071',	'2015072',	'2015081',	'2015082',	'2015091',	'2015092');
  --WHERE NRO_PLACA IN ( 'BXD463');

BEGIN

  FOR X IN PLACAS LOOP
    
    BEGIN
    V_CONTADOR := V_CONTADOR + 1;
        --UBICO EL TRAMITE MAS ACTUAL POR FECHA ARCHIVO
        SELECT MAX(FECHA_ARCHIVO)
        INTO V_MAX
        FROM PROPIETARIOS_RUNT
        WHERE NRO_PLACA =X.NRO_PLACA;
        
        --IDENTIFICO EL USUARIO CON MAS PORCENTAJE DE PROPIEDAD
        SELECT MAX(PORCENTAJE_PROP)
        INTO V_PORCENTAJE
        FROM PROPIETARIOS_RUNT
        WHERE NRO_PLACA =X.NRO_PLACA AND
              FECHA_ARCHIVO = V_MAX;
        
        --CAPTURO LOS DATOS A INSERTAR EN LA PLANTILLA
        SELECT PR.NRO_PLACA, PR.ID_USUARIO, PR.ID_DOCUMENTO
        INTO V_PLACA,
             V_INDETIFICACION,
             V_TIPO
        FROM CORRECCION_DATOS.PROPIETARIOS_RUNT PR
        WHERE PR.NRO_PLACA =X.NRO_PLACA AND
               PR.FECHA_ARCHIVO = V_MAX AND
               PR.PORCENTAJE_PROP = V_PORCENTAJE AND
               ROWNUM = 1; -- RETORNO UNA FILA SI EXISTEN VARIOS PROPIETARIOS
                           -- CON LEL MISMO PORCENTAJE DE PROPIEDAD
         
        --VALIDO SI YA EXISTE LA PLACA EN LA PLANTILLA
        SELECT COUNT(1)
        INTO V_EXISTE
        FROM CORRECCION_DATOS.PLANTILLA_IC_A_OC
        WHERE NRO_PLACA = X.NRO_PLACA;   
           
         
        IF V_EXISTE = 0 THEN     
          --INSERTO DATOS EN PLANTILLA_IC_A_OC
          INSERT INTO CORRECCION_DATOS.PLANTILLA_IC_A_OC(
                NRO_PLACA,
                IDENTIFICACION,
                TIPO_IDENTIFICACION) 
          VALUES (V_PLACA,
               V_INDETIFICACION,
               V_TIPO);
          
                  
        ELSE
        
          UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
          SET IDENTIFICACION = V_INDETIFICACION,
          TIPO_IDENTIFICACION = V_TIPO
          WHERE NRO_PLACA = X.NRO_PLACA;    
          
                 
        END IF;
    
    IF V_CONTADOR = 500 THEN
      COMMIT;
      V_CONTADOR := 0;
    END IF;    
    
    EXCEPTION
      WHEN OTHERS THEN
        --V_INDETIFICACION := NULL; 
        ERROR_MSG := SQLERRM;
			  DBMS_OUTPUT.PUT_LINE(ERROR_MSG || X.NRO_PLACA);   
    END;  
    
    
   /* BEGIN
    --INSERTO <
    /*
      UPDATE CORRECCION_DATOS.PLANTILLA_OC
      SET NRO_IDENTIFICACION = V_INDETIFICACION
      WHERE OBJETO_CONTRATO =X.NRO_PLACA;
    
      
   
   EXCEPTION
    WHEN OTHERS THEN
      V_INDETIFICACION := NULL; 
   END; */
         
    END LOOP;

  --CONVIERTO LOS ID DOCUMENTO A CODIGOS SAP
  UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
  SET TIPO_IDENTIFICACION = 'CC'
  WHERE TIPO_IDENTIFICACION = 'C'; --C�dula Ciudadania

  
  UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
  SET TIPO_IDENTIFICACION = 'NIT'
  WHERE TIPO_IDENTIFICACION = 'N'; --NIT
    
  UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
  SET TIPO_IDENTIFICACION = 'PASAP'
  WHERE TIPO_IDENTIFICACION = 'P'; --Pasaporte 
  
  UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
  SET TIPO_IDENTIFICACION = 'CE'
  WHERE TIPO_IDENTIFICACION = 'E'; --C�dula de Extranjer�a          
  
  UPDATE CORRECCION_DATOS.PLANTILLA_IC_A_OC
  SET TIPO_IDENTIFICACION = 'TI'
  WHERE TIPO_IDENTIFICACION = 'T'; --Tarjeta de Identidad 
  COMMIT;
END SP_ASOCIAR_IC_A_OC;

  /*ESTE FUNCION VALIDA SI EL PROPIETARIO YA EXISTE EN LA BD DE IMPUESTOS.*/
  FUNCTION FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_ID_DOCUMENTO NUMBER, A_IDENTIFICACION VARCHAR2, OPCION VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    V_IDENTIFICACION VARCHAR(15);
  BEGIN
    
    -- PARA NITS SE LES QUITA EL DIGITO DE VERIFICACION EN LA BUSQUEDA
    IF ( A_ID_DOCUMENTO = 2 ) THEN
          V_IDENTIFICACION := SUBSTR(A_IDENTIFICACION,1,9);
    END IF;
    --VERIFICO SI ESTE USUARIO ESTA REGISTRADO COMO PROPIETARIO DEL VEHICULO
    IF ( OPCION = 'P' ) THEN
        SELECT COUNT(1)
        INTO V_EXISTE
        FROM QUIPUX.PROPIETARIOS_VEHICULO PV
        WHERE PV.NRO_PLACA = A_NRO_PLACA AND
                     (PV.ID_USUARIO = A_IDENTIFICACION OR PV.ID_USUARIO = V_IDENTIFICACION);
              
        --SI EXITE RETORNO TRUE SI NO RETORNO FALSE
        IF V_EXISTE > 0 THEN
          RETURN TRUE;
        ELSE
          RETURN FALSE;
        END IF;
    ELSE
        SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO
              WHERE ID_DOCUMENTO = A_ID_DOCUMENTO AND
                           (ID_USUARIO = A_IDENTIFICACION OR ID_USUARIO = V_IDENTIFICACION);
        
        --SI EXITE RETORNO TRUE SI NO RETORNO FALSE
        IF V_EXISTE > 0 THEN
          RETURN TRUE;
        ELSE
          RETURN FALSE;
        END IF;
        
    END IF;
  END FT_EXISTE_USUARIO_PROPIETARIO;
  
-- VALIDAR USUARIO  
PROCEDURE VALIDAR_USUARIO AS
    
  
  DOC NUMBER:=0;
  CURSOR USUARIO IS
  SELECT NRO_PLACA, ID_DOCUMENTO_ANTERIOR, ID_USUARIO_ANTERIOR
  FROM CORRECCION_DATOS.DS_TMP_tramites1 DV
  WHERE DV.NRO_PLACA IN (SELECT identificador
                          FROM CORRECCION_DATOS.Inconsistencias
                          WHERE DV.NRO_PLACA = IDENTIFICADOR AND 
                          Campo_Fallo = 'ID_USUARIO_ANTERIOR' AND
                                Nombre_Archivo = 'TRAMITE')and
        dv.id_tramite = 16;
        --AND NRO_PLACA ='YCL55';
  
  BEGIN
  
  FOR X IN USUARIO LOOP
  SELECT ID_DOCUMENTO
  INTO DOC
  FROM QUIPUX.Tipo_Documento
  WHERE Min_Documento = X.ID_DOCUMENTO_ANTERIOR;
  
    IF PKG_GENERAR_PLANTILLA_IC.FT_EXISTE_USUARIO_PROPIETARIO(X.NRO_PLACA, DOC, X.ID_USUARIO_ANTERIOR, '')= TRUE THEN
      NULL;
        --INSERT INTO CORRECCION_DATOS.PLACAS_LINEAS (NRO_PLACA,CILINDRAJE) VALUES (X.NRO_PLACA,'1');
    ELSE
        NULL;
         --INSERT INTO CORRECCION_DATOS.PLACAS_LINEAS (NRO_PLACA,CILINDRAJE) VALUES (X.NRO_PLACA,'0');  
    END IF;
  
  END LOOP;

  END VALIDAR_USUARIO;
   
  
END PKG_GENERAR_PLANTILLA_IC;

/
--------------------------------------------------------
--  DDL for Package Body PKG_GENERAR_PLANTILLA_IC_QUINC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_IC_QUINC" AS

  PROCEDURE PS_INSERTAR_REGISTROS AS
  
  V_IDENTIFICADOR NUMBER;
  V_USUARIO VARCHAR2(20);
  V_DOCUMENTO NUMBER;
  V_NOMBRE VARCHAR2(100);
  V_APELLIDO VARCHAR2(100);
  V_DIRECCION VARCHAR2(100);
  V_TELEFONO VARCHAR2(100);
  V_RADICADO NUMBER;
  V_DEPARTAMENTO VARCHAR2(20);
  V_SECRETARIA VARCHAR2 (20);
  V_CIUDAD_DIR VARCHAR2 (10);
  ERROR_MSG VARCHAR2 (100);
   
  
  CURSOR REGISTROS IS
  SELECT DISTINCT Dp.Id_Documento, Dp.Id_Usuario
  FROM DEPURACION.DS_PROPIETARIO DP
  WHERE  NOT EXISTS (SELECT 1
                        FROM CORRECCION_DATOS.Propietarios_Sap_30072015 PS
                        WHERE to_number(PS.DOCUMENTO_QX) = Dp.Id_Documento
                          AND PS.USUARIO = Dp.Id_Usuario)
  AND DP.ID_RADICADO IN (22,38,62,77,86) 
  AND Dp.Id_Usuario = '3266729'
  AND Dp.Id_Documento = 1;
  
  BEGIN
   
   FOR X IN REGISTROS LOOP
   V_USUARIO := X.Id_Usuario;
   V_DOCUMENTO :=  X.Id_Documento;
   V_IDENTIFICADOR := FT_INSERTAR (V_USUARIO, V_DOCUMENTO);
   
   
   		IF V_IDENTIFICADOR IS NOT NULL THEN
			BEGIN
				--CAPTURO INFORMACION ESTANDARIZADA DE ESTANDAR_DIRECCIONES
				SELECT --ID_DOCUMENTO,
						NOMBRES,
						APELLIDOS,
						DIRECCION,
						TELEFONO
				INTO --V_TIPO_DOC1,
					 V_NOMBRE,
					 V_APELLIDO,
					 V_DIRECCION,
					 V_TELEFONO
				FROM DEPURACION.DS_CONTRIBUYENTE_ESTANDAR ED
				WHERE Ed.NRO_IDENTIFICADOR = V_IDENTIFICADOR; /* AND
					Ed.Id_Usuario = X.ID_USUARIO AND
					Ed.Id_Documento = X.ID_DOCUMENTO AND
					ED.NRO_IDENTIFICADOR = V_IDENTIF;*/
					
			EXCEPTION
			WHEN OTHERS THEN
				--V_TIPO_DOC1:= NULL;
				V_NOMBRE:= NULL; 
				V_APELLIDO:= NULL;
				V_DIRECCION:= NULL;
				V_TELEFONO:= NULL;
				ERROR_MSG := SQLERRM;
				--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
			END;       

			--V_TIPO_DOC2:=FT_CONVERT_DOC( V_TIPO_DOC1);      
      
      SELECT ID_CIUDAD_DIR
      INTO V_CIUDAD_DIR
      FROM DEPURACION.DS_CONTRIBUYENTE
      WHERE NRO_IDENTIFICADOR = V_IDENTIFICADOR;
		
			V_DEPARTAMENTO := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('D',V_CIUDAD_DIR);
			V_SECRETARIA := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('S',V_CIUDAD_DIR);
		 
		/*  --VALIDO SI EXISTE EL USUARIO EN SAP
			SELECT COUNT(1)
			 INTO V_EXISTE
			FROM CORRECCION_DATOS.IC
			WHERE DCTO_IDENTIFI=X.ID_USUARIO AND
				  CLASE_DCTO = V_TIPO_DOC2;*/
			   
			/*IF V_EXISTE > 0 THEN
			   V_TIPO_V:='M';
			   
				BEGIN     
					--CAPTURO EL INTERLOCUTOR COMERCIAL SAP DE TABLA IC
				/*	SELECT ID_INTERLOCUTOR
					INTO V_INT
					FROM CORRECCION_DATOS.IC
					WHERE DCTO_IDENTIFI=X.ID_USUARIO AND
						  CLASE_DCTO = V_TIPO_DOC2 AND
						  ROWNUM = 1;
						
				EXCEPTION
					WHEN OTHERS THEN
					   V_INT:= NULL;
					 --ERROR_MSG := SQLERRM;
					 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
				END;          
						
			ELSE            
			  V_TIPO_V:='N';  
			  V_INT :=NULL;
			END IF;  */   
		 
			BEGIN   
				--ACTUALIZA DATOS EN TEMP PLANTILLA PERSONAS--
				UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q TP
				SET CONCEPTO_BUSQUEDA1 =       DECODE(V_APELLIDO,NULL,V_NOMBRE
                                                              ,V_APELLIDO),
				   APELLIDO_INTERLOCUTOR =    V_APELLIDO,
				   NOMBRE_PILA_INTERLOCUTOR = V_NOMBRE,
				   DIRECCION_CORRESP =        V_DIRECCION,
				   DIRECCION_NOT_VEH =        V_DIRECCION,
				   DIRECCION_RESIDENCIA =     V_DIRECCION,
				   TELEFONO =                 V_TELEFONO,
				   TELEFONO_MOVIL=            V_TELEFONO,
				  -- CLASE_IDENTIFICACION =     V_DOCUMENTO,
				   CLASE_INTERLOCUTOR =       DECODE(V_DOCUMENTO,'2','PJPR'
																	,'PNAT'),
				   REGION =                   V_DEPARTAMENTO,
				   POBLACION =                V_SECRETARIA,
				   --INTERLOCUTOR_COMERCIAL=    V_INT,
				   NOMBRE1_ORGANIZACION =     DECODE(V_DOCUMENTO,'2', V_NOMBRE),
				   PERSONA_FISICA =           DECODE(V_DOCUMENTO,'2', NULL
																   , 'X' ),  
				   --TIPO_ARCHIVO=              V_TIPO_V,
				   TIPO_INTERLOCUTOR=         DECODE(V_DOCUMENTO,'2','2'
																	,'1')
				WHERE TP.NRO_IDENTIFICACION = V_USUARIO AND
					  TP.CLASE_IDENTIFICACION = V_DOCUMENTO;
				   
				COMMIT;
		
			EXCEPTION
				WHEN OTHERS THEN
				ROLLBACK;
        CONTINUE;
				 --ERROR_MSG := SQLERRM;
				 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG); 
			END; 
			
		END IF;  
            
	END LOOP;  
   
    
   
  END PS_INSERTAR_REGISTROS;

FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS  
   
	ERROR_MSG VARCHAR2(255); 
	V_IDENTIF VARCHAR2(20); 
	V_ID_MAX VARCHAR2 (20);
	V_DOC VARCHAR2 (20);
	V_EXISTE NUMBER:=0;
  V_RADICADO NUMBER;
   
BEGIN

	BEGIN

		SELECT MAX (TO_NUMBER(ID_DIRECCION))
		INTO V_ID_MAX
		FROM DEPURACION.DS_CONTRIBUYENTE
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;
        
    SELECT MAX (TO_NUMBER(ID_RADICADO))
		INTO V_RADICADO
		FROM DEPURACION.DS_CONTRIBUYENTE
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;    
		--GROUP BY   ID_DIRECCION;  

		
	-- VALIDO SI EL REGISTRO YA EXISTE EN LA PLANTILLA        
		SELECT COUNT(1)
		INTO V_EXISTE
		FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
		WHERE NRO_IDENTIFICACION = USUARIO AND
			  CLASE_IDENTIFICACION = DOCUMENTO;

		IF V_EXISTE = 0 THEN
			INSERT INTO CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q (
					  NRO_IDENTIFICACION,         --36                         
					  AGRUPACION_INTERLOCUTOR,    -- 4
					  CLASE_IDENTIFICACION,       --35                      
					  LAVE_TRATAMIENTO,           -- 8
					  NACIONALIDAD_INTERLOCUTOR,  --28
					  IDIOMA_INTERLOCUTOR,        --30
					  IDIOMA_CORRESPONDENCIA,     --24
					  CLASE_DIRECCION_CORRESP,    --37
					  CLASE_DIRECCION_NOT_VEH,    --43
					  CLASE_DIRECCION_RESIDENCIA, --45 
					  PAIS,                       --48
					  FAX,                        --53
					  E_MAIL)                     --54                       
			SELECT  DISTINCT ID_USUARIO,      --36                             
						  '0001',             -- 4
						  ID_DOCUMENTO,       --35
						  '0001',             -- 8
						  'CO',               --28
						  'S',                --30    
						  'S',                --24
						  'XXDEFAULT',        --37
						  'ZNOTIFIVEH',       --43  
						  'ZRESIDVEHI',       --45
						  'CO',               --48 
						  FAX,                --53
						  EMAIL               --54
			FROM DEPURACION.DS_CONTRIBUYENTE
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO AND
            ID_RADICADO = V_RADICADO;
      
			--NRO_IDENTIFICADOR =V_IDENTIF; 
			--GROUP BY ID_USUARIO, ID_DIRECCION; 
			--ROWNUM < 11;
			--WHERE  NRO_IDENTIFICADOR ='398685';
			COMMIT;

			--RETORNO EL IDENTIFICADOR DEL ID MAXIMO PARA CONSULTAR OS DATOS ESTANDARIZADOS
			SELECT NRO_IDENTIFICADOR
			INTO V_IDENTIF
			FROM DEPURACION.DS_CONTRIBUYENTE
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO AND
            ID_RADICADO = V_RADICADO;
       

		ELSE
		V_IDENTIF := NULL;
		END IF;

	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			V_IDENTIF := NULL;
			ERROR_MSG := SQLERRM;
			--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
END;

RETURN V_IDENTIF;

END FT_INSERTAR;     

-- ESTE PROCEDIMIENTO GENERA LA PLANTILLA DE LA SEGUNDA QUINCENA DE JUNIO
PROCEDURE PS_INSERTAR2 AS

V_IDENTIFICADOR NUMBER;
V_DIRECCION VARCHAR2(100);
V_DOCUMENTO NUMBER;
V_NOMBRE VARCHAR2 (100);
V_APELLIDO VARCHAR2 (100);
V_TELEFONO VARCHAR2 (50);
V_USUARIO VARCHAR2 (25);
V_SECRETARIA VARCHAR2 (25);
V_DEPARTAMENTO VARCHAR2 (25);
V_CIUDAD_DIR VARCHAR2(20);


CURSOR USUARIOS1 IS
SELECT DISTINCT DT.ID_USUARIO,DT.ID_DOCUMENTO
FROM CORRECCION_DATOS.DS_TMP_PROPIETARIOS2 DT
WHERE NOT EXISTS (SELECT 1
                     FROM CORRECCION_DATOS.PROPIETARIOS_SAP_30072015 PS
                     WHERE PS.USUARIO = DT.ID_USUARIO)
  AND NOT EXISTS (SELECT 1
                  FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q TQ
                  WHERE TQ.NRO_IDENTIFICACION = DT.ID_USUARIO)
  AND DT.ID_DOCUMENTO != 10;
 /* AND DT.ID_USUARIO = '1036618104'
  AND DT.ID_DOCUMENTO = 1;*/
 
BEGIN 
  
FOR X IN USUARIOS1 LOOP

V_DOCUMENTO:= X.ID_DOCUMENTO;
V_USUARIO := X.ID_USUARIO;

V_IDENTIFICADOR := FT_INSERTAR2 (V_USUARIO,V_DOCUMENTO); 

SELECT NOMBRES, APELLIDOS, DIRECCION, TELEFONO, ID_CIUDAD_DIR
INTO V_NOMBRE, V_APELLIDO,V_DIRECCION, V_TELEFONO, V_CIUDAD_DIR 
FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES3
WHERE ID_USUARIO = V_USUARIO
  AND ID_DOCUMENTO = V_DOCUMENTO
  AND ID_DIRECCION = V_IDENTIFICADOR;

 V_NOMBRE := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE (V_NOMBRE,V_DOCUMENTO);
 V_APELLIDO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE (V_APELLIDO,V_DOCUMENTO);
V_DIRECCION := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION (V_DIRECCION);
 V_TELEFONO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO (V_TELEFONO);
 
 	
			V_DEPARTAMENTO := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('D',V_CIUDAD_DIR);
			V_SECRETARIA := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('S',V_CIUDAD_DIR);
 
 BEGIN
 
 UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q TP
				SET CONCEPTO_BUSQUEDA1 =       DECODE(V_APELLIDO,NULL,V_NOMBRE
                                                              ,V_APELLIDO),
				   APELLIDO_INTERLOCUTOR =    V_APELLIDO,
				   NOMBRE_PILA_INTERLOCUTOR = V_NOMBRE,
				   DIRECCION_CORRESP =        V_DIRECCION,
				   DIRECCION_NOT_VEH =        V_DIRECCION,
				   DIRECCION_RESIDENCIA =     V_DIRECCION,
				   TELEFONO =                 V_TELEFONO,
				   TELEFONO_MOVIL=            V_TELEFONO,
				  -- CLASE_IDENTIFICACION =     V_DOCUMENTO,
				   CLASE_INTERLOCUTOR =       DECODE(V_DOCUMENTO,'2','PJPR'
																	,'PNAT'),
				   REGION =                   V_DEPARTAMENTO,
				   POBLACION =                V_SECRETARIA,
				   --INTERLOCUTOR_COMERCIAL=    V_INT,
				   NOMBRE1_ORGANIZACION =     DECODE(V_DOCUMENTO,'2', V_NOMBRE),
				   PERSONA_FISICA =           DECODE(V_DOCUMENTO,'2', NULL
																   , 'X' ),  
				   --TIPO_ARCHIVO=              V_TIPO_V,
				   TIPO_INTERLOCUTOR=         DECODE(V_DOCUMENTO,'2','2'
																	,'1')
				WHERE TP.NRO_IDENTIFICACION = V_USUARIO AND
					  TP.CLASE_IDENTIFICACION = V_DOCUMENTO AND
            TP.TIPO_ARCHIVO = '2';
				   
				COMMIT;
		
			EXCEPTION
				WHEN OTHERS THEN
				ROLLBACK;
        CONTINUE;
				 --ERROR_MSG := SQLERRM;
				 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG); 
			END; 
 
 

END LOOP;

END PS_INSERTAR2;

FUNCTION FT_INSERTAR2 (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS  
   
	ERROR_MSG VARCHAR2(255); 
	V_IDENTIF VARCHAR2(20); 
	V_ID_MAX VARCHAR2 (20);
	V_DOC VARCHAR2 (20);
	V_EXISTE NUMBER:=0;
  V_RADICADO NUMBER;
   
BEGIN

	BEGIN

		SELECT MAX (TO_NUMBER(ID_DIRECCION))
		INTO V_ID_MAX
		FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES3
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;
        
    /*SELECT MAX (TO_NUMBER(ID_RADICADO))
		INTO V_RADICADO
		FROM DEPURACION.DS_TMP_CONTRIBUYENTES3
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;    
		--GROUP BY   ID_DIRECCION; */ 
		
	-- VALIDO SI EL REGISTRO YA EXISTE EN LA PLANTILLA        
		SELECT COUNT(1)
		INTO V_EXISTE
		FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
		WHERE NRO_IDENTIFICACION = USUARIO AND
			  CLASE_IDENTIFICACION = DOCUMENTO;

		IF V_EXISTE = 0 THEN
			INSERT INTO CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q (
              NRO_IDENTIFICACION,         --36                         
              AGRUPACION_INTERLOCUTOR,    -- 4
              CLASE_IDENTIFICACION,       --35                      
              LAVE_TRATAMIENTO,           -- 8
              NACIONALIDAD_INTERLOCUTOR,  --28
              IDIOMA_INTERLOCUTOR,        --30
              IDIOMA_CORRESPONDENCIA,     --24
              CLASE_DIRECCION_CORRESP,    --37
              CLASE_DIRECCION_NOT_VEH,    --43
              CLASE_DIRECCION_RESIDENCIA, --45 
              PAIS,                       --48
              FAX,                        --53
              E_MAIL,                     --54 
              TIPO_ARCHIVO)                                          
			SELECT  DISTINCT ID_USUARIO,--36                             
						  '0001',             -- 4
						  ID_DOCUMENTO,       --35
						  '0001',             -- 8
						  'CO',               --28
						  'S',                --30    
						  'S',                --24
						  'XXDEFAULT',        --37
						  'ZNOTIFIVEH',       --43  
						  'ZRESIDVEHI',       --45
						  'CO',               --48 
						  FAX,                --53
						  EMAIL,              --54
              '2'
			FROM CORRECCION_DATOS.DS_TMP_CONTRIBUYENTES3
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO;
      
		  COMMIT;
	      
		ELSE
	V_ID_MAX := NULL;
		END IF;

	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			V_ID_MAX := NULL;
			ERROR_MSG := SQLERRM;
			--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
END;

RETURN V_ID_MAX;

END FT_INSERTAR2; 

/*ESTE PROCEDIMIENTO REALIZA LAS VALIDACIONES DE NEGOCIO DE LA PLANTILLA CONTRIBUYENTE.*/
PROCEDURE SP_VALIDACIONES_NEGOCIO AS

  V_ERROR NUMBER := 0;
   
  CURSOR CONTRIBUYENTES IS
    SELECT *
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q;

BEGIN

--LIMPIO LOS ERRORES ANTERIORES
  --UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q SET REGISTRO_ERROR =NULL WHERE REGISTRO_ERROR IS NOT NULL;

  FOR XB IN CONTRIBUYENTES LOOP
    
    --VALIDO LA DIRECCION
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(XB.DIRECCION_CORRESP,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
     SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(XB.E_MAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
    SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL FAX
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
     --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO_MOVIL,'T',0);   
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
  
  END LOOP;
  
 --VALIDO CAMPOS NULL EN LA PLANTILLA 
   --SP_CAMPOS_NULL;
 
 --APLICO VALIDACIONES DE NEGOCIO SAP
 --SP_VALIDACIONES_NEGOCIO_SAP;

END SP_VALIDACIONES_NEGOCIO;


/*ESTA FUNCION VALIDAD CAMPOS NULL*/
PROCEDURE SP_CAMPOS_NULL AS

BEGIN

  --SE LIMIA DE LOS ERRORES ANTERIORES
  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL=NULL WHERE CAMPOS_NULL IS NOT NULL;

  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'INTERLOCUTOR_COMERCIAL, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE INTERLOCUTOR_COMERCIAL IS NULL AND
          TIPO_ARCHIVO= 'M'
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);

  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'TIPO_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE TIPO_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
  UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CLASE_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
      
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'AGRUPACION_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE AGRUPACION_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);   
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CONCEPTO_BUSQUEDA1, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CONCEPTO_BUSQUEDA1 IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);   
    
        UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLAVE_TRATAMIENTO, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE LAVE_TRATAMIENTO IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'APELLIDO_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE APELLIDO_INTERLOCUTOR IS NULL AND
          CLASE_IDENTIFICACION <> 'NIT'          
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'NOMBRE1_ORGANIZACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE NOMBRE1_ORGANIZACION IS NULL AND
          CLASE_IDENTIFICACION = 'NIT'          
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    
        UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'NOMBRE_PILA_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE NOMBRE_PILA_INTERLOCUTOR IS NULL AND
          CLASE_IDENTIFICACION <> 'NIT'  
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'IDIOMA_CORRESPONDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE IDIOMA_CORRESPONDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'NACIONALIDAD_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE NACIONALIDAD_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'IDIOMA_INTERLOCUTOR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE IDIOMA_INTERLOCUTOR IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'PERSONA_FISICA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE PERSONA_FISICA IS NULL AND
           CLASE_IDENTIFICACION <> 'NIT'
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION); 
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_IDENTIFICACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CLASE_IDENTIFICACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'Nro_Identificacion || CLASE_IDENTIFICACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE Nro_Identificacion || CLASE_IDENTIFICACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_CORRESP, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CLASE_DIRECCION_CORRESP IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_NOT_VEH, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE DIRECCION_NOT_VEH IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_RESIDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CLASE_DIRECCION_RESIDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_RESIDENCIA, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE DIRECCION_RESIDENCIA IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CLASE_DIRECCION_NOT_VEH, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE CLASE_DIRECCION_NOT_VEH IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'DIRECCION_CORRESP, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE DIRECCION_CORRESP IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
     UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'PAIS, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE PAIS IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'REGION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE REGION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'POBLACION, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE POBLACION IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'TELEFONO, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE TELEFONO IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
       UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'FAX, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE FAX IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
      UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'CELULAR, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE TELEFONO_MOVIL IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
    
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
  SET CAMPOS_NULL = CAMPOS_NULL || 'E_MAIL, '
  WHERE Nro_Identificacion || CLASE_IDENTIFICACION IN
    (SELECT Nro_Identificacion || CLASE_IDENTIFICACION
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE E_MAIL IS NULL
    GROUP BY Nro_Identificacion || CLASE_IDENTIFICACION);
 
 
 COMMIT;
        
END SP_CAMPOS_NULL;

PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER) AS

MENSAJE VARCHAR2(255);

BEGIN
   
   /* --CAPTURO EL MENSAJE ERROR DE TEMP_PLANTILLA_PERSONAS_Q PARA CONCATENARLO
    SELECT REGISTRO_ERROR
    INTO MENSAJE
    FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    WHERE NRO_IDENTIFICACION = IDENTIFICADOR AND
          CLASE_IDENTIFICACION = TIPO_IDENTIFICACION;*/

   CASE PARAMETRO
          WHEN 1 THEN
              MENSAJE:='DIRECCION<7, ';
          WHEN 2 THEN
              MENSAJE:='DIRECCION SOLO LETRAS, ';
          WHEN 3 THEN
              MENSAJE:='DIRECCION SOLO NUMEROS, ';
          WHEN 4 THEN
              MENSAJE:='DIRECCION 3 CONSONANTES, ';
          WHEN 5 THEN
              MENSAJE:='EMAIL @, ';
          WHEN 6 THEN
              MENSAJE:='E-MAIL<7, ';
          WHEN 7 THEN
              MENSAJE:='E-MAIL NOREGISTRA, ';
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              MENSAJE:= NULL;    
          ELSE
              MENSAJE:='ERROR EN USUARIO '||IDENTIFICADOR;
    END CASE;

    --INSERTO DESCRIPCION DEL ERROR EN TEMP_PLANTILLA_PERSONAS_Q
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_Q
    SET REGISTRO_ERROR = REGISTRO_ERROR || MENSAJE
    WHERE NRO_IDENTIFICACION = IDENTIFICADOR AND
          CLASE_IDENTIFICACION = TIPO_IDENTIFICACION;
    COMMIT;      
          

END SP_GENERAR_EXCEPCION;

END PKG_GENERAR_PLANTILLA_IC_QUINC;

/
--------------------------------------------------------
--  DDL for Package Body PKG_GENERAR_PLANTILLA_VH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_GENERAR_PLANTILLA_VH" AS

PROCEDURE SP_GENERAR_PLANTILLA (V_A�O NUMBER, V_MES VARCHAR2) AS


BEGIN

/*=========================================================================================================================

INSERTO LA INFORMACION ESTANDAR POR MES Y A�O */

INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'AUTOMOVIL',1);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'BUS',2);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'BUSETA',3);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'CAMION',4);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'CAMIONETA',5);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'CAMPERO',6);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'MICROBUS',7);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'MOTOCICLETA',10);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'MOTOCARROS',14);
INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'OTROS',99);
--INSERT INTO CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH (A�O,MES,CLASE,ID_CLASE) VALUES (V_A�O,V_MES,'OTROS',4||''','''||8||''','''||19||''','''||24||''','''||41||''','''||42||''','''||43||''','''||160);


COMMIT;
/*==========================================================================================================================*/
--CALULO LOS TOTALES POR NOVEDAD
SP_TOTALES (V_A�O,V_MES);


END SP_GENERAR_PLANTILLA;

PROCEDURE SP_TOTALES (V_A�O1 NUMBER, V_MES1 VARCHAR2) AS


V_MI                NUMBER:=0;
V_REMATRICULA       NUMBER:=0;
V_CBIO_A_PA         NUMBER:=0;
V_RADICACION        NUMBER:=0;
V_CANCELACION       NUMBER:=0;
V_TRASLADO          NUMBER:=0;
V_CBIO_DE_PA        NUMBER:=0;
V_EXISTE            NUMBER:=0;
V_ERROR             VARCHAR2(100);
V_CLASE             VARCHAR2(100);

CURSOR TRAMITES IS
SELECT A�O,MES,ID_CLASE
FROM CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH
WHERE A�O = V_A�O1
  AND MES = V_MES1;


BEGIN

FOR X IN TRAMITES LOOP

V_ERROR:= NULL;
V_MI:=0;             
V_REMATRICULA:=0;      
V_CBIO_A_PA:=0;   
V_RADICACION:=0;        
V_CANCELACION:=0;       
V_TRASLADO:=0;         
V_CBIO_DE_PA:=0;        
V_EXISTE:=0;             


V_CLASE := REPLACE (X.ID_CLASE,'"');

/*==============================================================================================================================*/
--REALIZO LA CONSULTA POR SERVICIO PARTICULAR, PUBLICO Y OFICIAL SOLO PARA LA CLASE MOTOCICLETA

IF V_CLASE = 10 THEN -- MOTOCICLETA

  --CONSULTO CANTIDAD DE TRAMITES POR MATRICULA INICIAL POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_MI
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 9
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE);
      
  
  --CONSULTO CANTIDAD DE TRAMITES POR REMATRICULA POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_REMATRICULA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 13
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE);
      
  --CONSULTO CANTIDAD DE TRAMITES POR CANCELACION POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CANCELACION
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 20
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE); 
      
  --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO A PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_A_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SERVICIO_NUEVO = 1;  
      
  --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO DE PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_DE_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SERVICIO_NUEVO != 1;             
  
  --CONSULTO CANTIDAD DE TRAMITES POR RADICACION POR CLASE DE VEHICULO  
    SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 10
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_DESTINO IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_DESTINO
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 10
        AND VRT.ID_SERVICIO in (1,4)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
        
      IF V_EXISTE = 0 THEN
        
        SELECT COUNT (DISTINCT TRT.NRO_PLACA)
        INTO V_RADICACION
        FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
        INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
        ON TRT.NRO_PLACA = VRT.NRO_PLACA
        WHERE TRT.A�O = X.A�O
          AND TRT.MES = X.MES
          AND TRT.ID_TRAMITE = 10
          AND VRT.ID_SERVICIO in (1,4)
          AND VRT.ID_CLASE IN (V_CLASE);     
    
      ELSE
        V_ERROR := 'Radicaci�n fuera de antioquia';      
      END IF;  
      
  ELSE 
     V_ERROR := 'Id Secretara destino Null';
    
  END IF;
      
      
  --CONSULTO CANTIDAD DE TRAMITES POR TRASLADO POR CLASE DE VEHICULO
    
    SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a origen no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 15
      AND VRT.ID_SERVICIO in (1,4)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_ORIGEN IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a origen sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_ORIGEN
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 15
        AND VRT.ID_SERVICIO in (1,4)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
  
        IF V_EXISTE = 0 THEN
        
            SELECT COUNT (DISTINCT TRT.NRO_PLACA)
            INTO V_TRASLADO
            FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
            INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
            ON TRT.NRO_PLACA = VRT.NRO_PLACA
            WHERE TRT.A�O = X.A�O
              AND TRT.MES = X.MES
              AND TRT.ID_TRAMITE = 15
              AND VRT.ID_SERVICIO in (1,4)
              AND VRT.ID_CLASE IN (V_CLASE);
        ELSE
             V_ERROR :=  V_ERROR ||'Traslado originado fuera de antioquia';      
        END IF;  
        
    ELSE 
       V_ERROR := V_ERROR || 'Id Secretara origen Null';
      
    END IF;
/*==============================================================================================================================*/


/*==============================================================================================================================*/
/*REALIZO CONSULTA PARA SERVICIOS PARTICULAR Y OFICIAL AGRUPANDO LAS CLASES CAMION, TRACTOCAMION, MOTOTRICICLO, CUATRIMOTO
  REMOLQUE, SEMIREMOLQUE, VOLQUETA, SIN CLASE Y MAQ. CONSTRUCCION O MINERA*/

ELSIF V_CLASE = 99 THEN --OTROS: Veh�culos que no presentan demaciados tramites

  --CONSULTO CANTIDAD DE TRAMITES POR MATRICULA INICIAL POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_MI
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 9
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (8,17,19,24,41,42,43);
      
  
  --CONSULTO CANTIDAD DE TRAMITES POR REMATRICULA POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_REMATRICULA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 13
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (8,17,19,24,41,42,43);
      
  --CONSULTO CANTIDAD DE TRAMITES POR CANCELACION POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CANCELACION
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 20
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (8,17,19,24,41,42,43);
      
   --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO A PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_A_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (8,17,19,24,41,42,43)
      AND TRT.ID_SERVICIO_NUEVO = 1;  
      
  --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO DE PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_DE_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (8,17,19,24,41,42,43)
      AND TRT.ID_SERVICIO_NUEVO != 1;     
    
--CONSULTO CANTIDAD DE TRAMITES POR RADICACION PARA LA CLASE DE VEHICULO
  SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 10
      AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_DESTINO IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_DESTINO
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 10
        AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
        
      IF V_EXISTE = 0 THEN
        
        SELECT COUNT (DISTINCT TRT.NRO_PLACA)
        INTO V_RADICACION
        FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
        INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
        ON TRT.NRO_PLACA = VRT.NRO_PLACA
        WHERE TRT.A�O = X.A�O
          AND TRT.MES = X.MES
          AND TRT.ID_TRAMITE = 10
          AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
          AND VRT.ID_CLASE IN (V_CLASE);     
    
      ELSE
        V_ERROR := 'Radicaci�n fuera de antioquia';      
      END IF;  
      
  ELSE 
     V_ERROR := 'Id Secretara destino Null';
    
  END IF;
      
      
  --CONSULTO CANTIDAD DE TRAMITES POR TRASLADO POR CLASE DE VEHICULO
    
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)--Valido que la secretar�a origen no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 15
      AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_ORIGEN IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a origen sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_ORIGEN
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 15
        AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
  
        IF V_EXISTE = 0 THEN
        
            SELECT COUNT (DISTINCT TRT.NRO_PLACA)
            INTO V_TRASLADO
            FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
            INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
            ON TRT.NRO_PLACA = VRT.NRO_PLACA
            WHERE TRT.A�O = X.A�O
              AND TRT.MES = X.MES
              AND TRT.ID_TRAMITE = 15
              AND VRT.ID_SERVICIO IN (8,17,19,24,41,42,43)
              AND VRT.ID_CLASE IN (V_CLASE);
        ELSE
             V_ERROR :=  V_ERROR ||'Traslado originado fuera de antioquia';      
        END IF;  
        
    ELSE 
       V_ERROR := V_ERROR || 'Id Secretara origen Null';
      
    END IF;
/*==============================================================================================================================*/


/*==============================================================================================================================
REALIZO CONSULTA PARA SERVICOS PARTICULAR Y PUBLICO DE LAS CLASES AUTOMOVIL, BUS, BUSETA, MICROBUS, CAMPERO
  CAMIONETA, MOTOCICLETA, MOTOCARROS*/
  
ELSE  
  --CONSULTO CANTIDAD DE TRAMITES POR MATRICULA INICIAL POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_MI
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 9
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE);
      
  
  --CONSULTO CANTIDAD DE TRAMITES POR REMATRICULA POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_REMATRICULA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 13
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE);
      
  --CONSULTO CANTIDAD DE TRAMITES POR CANCELACION POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CANCELACION
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 20
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE);
      
 --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO A PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_A_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SERVICIO_NUEVO = 1;  
      
  --CONSULTO CANTIDAD DE TRAMITES POR CBIO DE SERVICIO DE PARTICULAR POR CLASE DE VEHICULO
    SELECT COUNT (DISTINCT TRT.NRO_PLACA)
    INTO V_CBIO_DE_PA
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 6
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SERVICIO_NUEVO != 1;     
    
  --CONSULTO CANTIDAD DE TRAMITES POR RADICACION POR CLASE DE VEHICULO
   SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 10
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_DESTINO IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a destino sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_DESTINO
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 10
        AND VRT.ID_SERVICIO in (1)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
        
      IF V_EXISTE = 0 THEN
        
        SELECT COUNT (DISTINCT TRT.NRO_PLACA)
        INTO V_RADICACION
        FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
        INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
        ON TRT.NRO_PLACA = VRT.NRO_PLACA
        WHERE TRT.A�O = X.A�O
          AND TRT.MES = X.MES
          AND TRT.ID_TRAMITE = 10
          AND VRT.ID_SERVICIO in (1)
          AND VRT.ID_CLASE IN (V_CLASE);     
    
      ELSE
        V_ERROR := 'Radicaci�n fuera de antioquia';      
      END IF;  
      
  ELSE 
     V_ERROR := 'Id Secretara destino Null';
    
  END IF;
      
      
  --CONSULTO CANTIDAD DE TRAMITES POR TRASLADO POR CLASE DE VEHICULO
    
    SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a origen no sea null
    INTO V_EXISTE
    FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
    INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
    ON TRT.NRO_PLACA = VRT.NRO_PLACA
    WHERE TRT.A�O = X.A�O
      AND TRT.MES = X.MES
      AND TRT.ID_TRAMITE = 15
      AND VRT.ID_SERVICIO in (1)
      AND VRT.ID_CLASE IN (V_CLASE)
      AND TRT.ID_SECRETARIA_ORIGEN IS NULL;   
    
    IF V_EXISTE = 0 THEN
      
      SELECT COUNT (DISTINCT TRT.NRO_PLACA) --Valido que la secretar�a origen sea de Antioquia
      INTO V_EXISTE
      FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
      INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
      ON TRT.NRO_PLACA = VRT.NRO_PLACA
      INNER JOIN QUIPUX.SECRETARIAS_TTO ST
      ON ST.RUNT_SECRETARIA = TRT.ID_SECRETARIA_ORIGEN
      WHERE TRT.A�O = X.A�O
        AND TRT.MES = X.MES
        AND TRT.ID_TRAMITE = 15
        AND VRT.ID_SERVICIO in (1)
        AND VRT.ID_CLASE IN (V_CLASE)
        AND ST.ID_DEPARTAMENTO != 5;
  
        IF V_EXISTE = 0 THEN
        
            SELECT COUNT (DISTINCT TRT.NRO_PLACA)
            INTO V_TRASLADO
            FROM CORRECCION_DATOS.TRAMITES_RUNT_TOTAL TRT
            INNER JOIN CORRECCION_DATOS.OC_RUNT_TOTAL VRT
            ON TRT.NRO_PLACA = VRT.NRO_PLACA
            WHERE TRT.A�O = X.A�O
              AND TRT.MES = X.MES
              AND TRT.ID_TRAMITE = 15
              AND VRT.ID_SERVICIO in (1)
              AND VRT.ID_CLASE IN (V_CLASE);
        ELSE
             V_ERROR :=  V_ERROR ||'Traslado originado fuera de antioquia';      
        END IF;  
        
    ELSE 
       V_ERROR := V_ERROR || 'Id Secretara origen Null';      
    END IF;
     
END IF;

    
UPDATE CORRECCION_DATOS.PLANTILLA_MOVIMIENTOS_VH MV
SET MV.MATRICULA_INICIAL = V_MI,
    MV.REMATRICULA = V_REMATRICULA,
    MV.CANCELACION = V_CANCELACION,
    MV.RADICACION = V_RADICACION,
    MV.TRASLADO =  V_TRASLADO,
    MV.CBIO_A_PA = V_CBIO_A_PA,
    MV.CBIO_DE_PA = V_CBIO_DE_PA,
    MV.ALERTAS = V_ERROR
WHERE MV.A�O = X.A�O
  AND MV.MES = X.MES
  AND MV.ID_CLASE = X.ID_CLASE;  

COMMIT;
END LOOP;


END SP_TOTALES;

END PKG_GENERAR_PLANTILLA_VH;

/
--------------------------------------------------------
--  DDL for Package Body PKG_GENERAR_PL_IC2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_GENERAR_PL_IC2" AS

PROCEDURE SP_INSERTAR_REGISTRO AS
   
	V_EXISTE VARCHAR2(20);
	V_TELEFONO VARCHAR2(20);
	V_NOMBRE VARCHAR2 (150);
	V_APELLIDO VARCHAR2 (150);
	V_DIRECCION VARCHAR2 (150);
	V_TIPO_DOC1 VARCHAR2(20);
	V_TIPO_DOC2 VARCHAR2(20);
	V_CLASE_INT VARCHAR2(10);
	V_DEPARTAMENTO VARCHAR2(50);
	V_SECRETARIA VARCHAR2 (100);
	V_BUSCAR VARCHAR2 (20);
	V_INT VARCHAR2 (20);
	V_TIPO_V VARCHAR2(2);
	V_TIPO_INT VARCHAR2 (2);
	ERROR_MSG VARCHAR2 (255);
	V_IDENTIFICADOR VARCHAR2(20);
  V_CIUDAD VARCHAR2(20);
  V_TIP_ID VARCHAR2(5);
   
CURSOR INTERLOCUTOR IS
SELECT IDENTIFICACION, TIPO_IDENTIFICACION   
FROM CORRECCION_DATOS.PLANTILLA_IC_A_OC IC
INNER JOIN CORRECCION_DATOS.CONTRIBUYENTE_RUNT PR
ON PR.ID_USUARIO = IC.IDENTIFICACION

--Consulto solo las personas 
INNER JOIN CORRECCION_DATOS.OC_SAP_ACTUALIZADO OS
ON OS.NRO_PLACA = IC.NRO_PLACA
WHERE OS.INCONSISTENCIA = 'RUNT = SAP'
AND NOT EXISTS (SELECT 1
                  FROM CORRECCION_DATOS.PROPIETARIOS_SAP_19112015 PS
                  WHERE PS.IDENTIFICACION = IC.IDENTIFICACION)
AND IC.TIPO_IDENTIFICACION != 'S'
AND NOT EXISTS (SELECT 1
                FROM CORRECCION_DATOS.TEMP_NOVEDADES_TRASPASOS NT
                WHERE NT.NRO_IDENTIFICACION = IC.IDENTIFICACION)
  --AND IDENTIFICACION ='1140857147'; 
  AND IC.NOMBRE = 'Verdadero';
 -- AND ROWNUM < 501;
   
BEGIN

	FOR X IN INTERLOCUTOR LOOP
  
  V_TIP_ID:= X.TIPO_IDENTIFICACION;
  
  IF V_TIP_ID = 'CC' THEN -- CEDULA O IDETERMINADO
    IF X.IDENTIFICACION = '5134' THEN
      V_TIP_ID:='10'; -- IDETERMINADO
    ELSE
      V_TIP_ID:='1'; -- CEDULA
     END IF; 
	ELSIF V_TIP_ID = 'NIT' THEN --NIT
		V_TIP_ID:= '2';            
	ELSIF V_TIP_ID = 'CE' THEN --EXTRANJERIA
		V_TIP_ID:= '3';
	ELSIF V_TIP_ID = 'TI' THEN --TARJETA IDENTIDAD
		V_TIP_ID:= '4';
	ELSIF V_TIP_ID = 'PASAP' THEN --PASAPORTE
		V_TIP_ID:= '6';       
	END IF; 
  
		--INSERTO EL REGISTRO EN LA TEMP_PLANTILLA_PERSONASII Y CAPTURO EL IDENTIFICADOR
		V_IDENTIFICADOR:= FT_INSERTAR (X.IDENTIFICACION, V_TIP_ID);  
  
		IF V_IDENTIFICADOR IS NOT NULL THEN
			BEGIN
				--CAPTURO INFORMACION ESTANDARIZADA DE ESTANDAR_DIRECCIONES
				SELECT ID_DOCUMENTO,
						NOMBRES,
						APELLIDOS,
						DIRECCION,
						TELEFONO
				INTO V_TIPO_DOC1,
					 V_NOMBRE,
					 V_APELLIDO,
					 V_DIRECCION,
					 V_TELEFONO
				FROM CORRECCION_DATOS.ESTANDAR_DIRECCIONES ED
				WHERE Ed.Nro_Identificador = V_IDENTIFICADOR; /* AND
					Ed.Id_Usuario = X.ID_USUARIO AND
					Ed.Id_Documento = X.ID_DOCUMENTO AND
					ED.NRO_IDENTIFICADOR = V_IDENTIF;*/
          
          --CAPTURO LA DIRECCION
          SELECT ID_CIUDAD_DIR
          INTO V_CIUDAD
          FROM CORRECCION_DATOS.CONTRIBUYENTE_RUNT
          WHERE NRO_IDENTIFICADOR = V_IDENTIFICADOR;
					
			EXCEPTION
			WHEN OTHERS THEN
        CONTINUE;
				--V_TIPO_DOC1:= NULL;
				--V_NOMBRE:= NULL; 
				--V_APELLIDO:= NULL;
				--V_DIRECCION:= NULL;
				--V_TELEFONO:= NULL;
				--ERROR_MSG := SQLERRM;
				--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
			END;       
			-- CONVIERTO CODIGO TIPO DOCUMENTO QX A CODIGO SAP 
			V_TIPO_DOC2:=PKG_GENERAR_PLANTILLA_IC.FT_CONVERT_DOC( V_TIPO_DOC1);      
					   
			V_DEPARTAMENTO := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('D',V_CIUDAD);
			V_SECRETARIA := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('S',V_CIUDAD);
		 
		  --VALIDO SI EXISTE EL USUARIO EN SAP
			SELECT COUNT(1)
			 INTO V_EXISTE
			FROM CORRECCION_DATOS.IC
			WHERE DCTO_IDENTIFI=X.IDENTIFICACION AND
				  CLASE_DCTO = V_TIPO_DOC2;
			   
			IF V_EXISTE > 0 THEN
			   V_TIPO_V:='M';
			   
				BEGIN     
					--CAPTURO EL INTERLOCUTOR COMERCIAL SAP DE TABLA IC
					SELECT ID_INTERLOCUTOR
					INTO V_INT
					FROM CORRECCION_DATOS.IC
					WHERE DCTO_IDENTIFI=X.IDENTIFICACION AND
						  CLASE_DCTO = V_TIPO_DOC2 AND
						  ROWNUM = 1;
						
				EXCEPTION
					WHEN OTHERS THEN
					   V_INT:= NULL;
					 --ERROR_MSG := SQLERRM;
					 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
				END;          
						
			ELSE            
			  V_TIPO_V:='N';  
			  V_INT :=NULL;
			END IF;     
		 
			BEGIN   
				--ACTUALIZA DATOS EN TEMP PLANTILLA PERSONAS--
				UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONASII TP
				SET CONCEPTO_BUSQUEDA1 =      DECODE(V_APELLIDO,NULL,V_NOMBRE,V_APELLIDO),
				   APELLIDO_INTERLOCUTOR =    V_APELLIDO,
				   NOMBRE_PILA_INTERLOCUTOR = V_NOMBRE,
				   DIRECCION_CORRESP =        V_DIRECCION,
				   DIRECCION_NOT_VEH =        V_DIRECCION,
				   DIRECCION_RESIDENCIA =     V_DIRECCION,
				   TELEFONO =                 V_TELEFONO,
				   TELEFONO_MOVIL=            V_TELEFONO,
				   CLASE_IDENTIFICACION =     V_TIPO_DOC2,
				   CLASE_INTERLOCUTOR =       DECODE(V_Tipo_Doc1,'2','PJPR','PNAT'),
				   REGION =                   V_DEPARTAMENTO,
				   POBLACION =                V_SECRETARIA,
				   INTERLOCUTOR_COMERCIAL=    V_INT,
				   NOMBRE1_ORGANIZACION =     DECODE(V_Tipo_Doc1,'2', V_NOMBRE),
				   PERSONA_FISICA =           DECODE(V_TIPO_INT,'2', NULL, 'X' ),  
				   TIPO_ARCHIVO=              V_TIPO_V,
				   TIPO_INTERLOCUTOR=         DECODE(V_Tipo_Doc1,'2','2','1')
				WHERE TP.NRO_IDENTIFICACION = X.IDENTIFICACION AND
					  Tp.Clase_Identificacion = V_TIPO_DOC1;
				   
				COMMIT;
		
			EXCEPTION
				WHEN OTHERS THEN
				ROLLBACK;
				 --ERROR_MSG := SQLERRM;
				 --DBMS_OUTPUT.PUT_LINE(ERROR_MSG); 
			END; 
			
		END IF;  
            
	END LOOP;   
  --EJECUTO LAS VALIDACIONES DE NEGOCIO
 -- PKG_GENERAR_PLANTILLA_IC.SP_VALIDACIONES_NEGOCIO;
    
END SP_INSERTAR_REGISTRO;

--**************************************************************************--
--INSERTO INTERLOCUTOR CON DATOS ESTANDAR PARA TODOS  
FUNCTION FT_INSERTAR (USUARIO VARCHAR2, DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS  
   
	ERROR_MSG VARCHAR2(255); 
	V_IDENTIF VARCHAR2(20); 
	V_ID_MAX VARCHAR2 (20);
	V_DOC VARCHAR2 (20);
	V_EXISTE NUMBER:=0;
   
BEGIN

	BEGIN

		SELECT MAX (TO_NUMBER(ID_DIRECCION))
		INTO V_ID_MAX
		FROM CONTRIBUYENTE_RUNT
		WHERE ID_USUARIO = USUARIO AND
			  ID_DOCUMENTO = DOCUMENTO;
		--GROUP BY   ID_DIRECCION;  

		V_DOC:= PKG_GENERAR_PLANTILLA_IC.FT_CONVERT_DOC((DOCUMENTO)); 
     
	-- VALIDO SI EL REGISTRO YA EXISTE EN LA PLANTILLA        
		SELECT COUNT(1)
		INTO V_EXISTE
		FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONASII
		WHERE NRO_IDENTIFICACION = USUARIO AND
			  CLASE_IDENTIFICACION = V_DOC;

		IF V_EXISTE = 0 THEN
			INSERT INTO TEMP_PLANTILLA_PERSONASII (
					  NRO_IDENTIFICACION,         --36                         
					  AGRUPACION_INTERLOCUTOR,    -- 4
					  CLASE_IDENTIFICACION,       --35                      
					  LAVE_TRATAMIENTO,           -- 8
					  NACIONALIDAD_INTERLOCUTOR,  --28
					  IDIOMA_INTERLOCUTOR,        --30
					  IDIOMA_CORRESPONDENCIA,     --24
					  CLASE_DIRECCION_CORRESP,    --37
					  CLASE_DIRECCION_NOT_VEH,    --43
					  CLASE_DIRECCION_RESIDENCIA, --45 
					  PAIS,                       --48
					  FAX,                        --53
					  E_MAIL)                     --54                       
			SELECT  DISTINCT ID_USUARIO,      --36                             
						  '0001',             -- 4
						  ID_DOCUMENTO,       --35
						  '0001',             -- 8
						  'CO',               --28
						  'S',                --30    
						  'S',                --24
						  'XXDEFAULT',        --37
						  'ZNOTIFIVEH',       --43  
						  'ZRESIDVEHI',       --45
						  'CO',               --48 
						  FAX,                --53
						  EMAIL               --54
			FROM CONTRIBUYENTE_RUNT
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO;
      
			--NRO_IDENTIFICADOR =V_IDENTIF; 
			--GROUP BY ID_USUARIO, ID_DIRECCION; 
			--ROWNUM < 11;
			--WHERE  NRO_IDENTIFICADOR ='398685';
			COMMIT;

			--RETORNO EL IDENTIFICADOR DEL ID MAXIMO PARA CONSULTAR OS DATOS ESTANDARIZADOS
			SELECT NRO_IDENTIFICADOR
			INTO V_IDENTIF
			FROM CONTRIBUYENTE_RUNT
			WHERE ID_DIRECCION = V_ID_MAX AND
            ID_USUARIO = USUARIO AND
            ID_DOCUMENTO = DOCUMENTO;
       

		ELSE
		V_IDENTIF := NULL;
		END IF;

	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			V_IDENTIF := NULL;
			ERROR_MSG := SQLERRM;
			--DBMS_OUTPUT.PUT_LINE(ERROR_MSG);   
END;

RETURN V_IDENTIF;

END FT_INSERTAR;     








END PKG_GENERAR_PL_IC2;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PLANTILLA_IC_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_PLANTILLA_IC_TTO" AS

/*Este pakete genera la plantilla de actualizacion de los contribuyentes 
  reportados po transito*/
  
PROCEDURE SP_INSERTAR_USUARIOS AS

V_ID_USUARIO VARCHAR2(20);
V_DOCUMENTO VARCHAR2(20);
V_NOMBRES VARCHAR2(100);
V_APELLIDOS VARCHAR2(100);
V_DIRECION VARCHAR2(100);
V_ID_CIUDAD VARCHAR2(20);
V_DESC_CIUDAD VARCHAR2(100);
V_ID_DPTO VARCHAR2(20);
V_DESC_DPTO VARCHAR2(100);
V_TELEFONO VARCHAR2(20);
V_FAX VARCHAR2(20);
V_CELULAR VARCHAR2(30);
V_EMAIL VARCHAR2(100);
V_ERROR VARCHAR2(5);
V_ID_CIUDAD_SAP VARCHAR2(20);
V_INCONSISTENCIA VARCHAR2(1000);
V_CONTADOR NUMBER :=0;
V_SECRETARIA VARCHAR2(100);
V_ID_SECRETARIA VARCHAR2(100);
V_DIGITO VARCHAR2(1);
V_EXISTE NUMBER :=0;

CURSOR USUARIOS IS

/* SELECT DC.* 
  FROM Ds_Tmp_Contribuyentes1 DC
  INNER JOIN Ds_Tmp_Propietarios1 DP
  on DC.Id_Usuario = Dp.Id_Usuario and DC.id_Documento = Dp.Id_Documento
  where DC.Id_Usuario in('42767579');*/
  
 SELECT DC.* 
  FROM Ds_Tmp_Contribuyentes1 DC
  INNER JOIN Ds_Tmp_Propietarios1 DP
  on DC.Id_Usuario = Dp.Id_Usuario and DC.id_Documento = Dp.Id_Documento
  where DC.Id_Usuario not in( select ID_USUARIO
                                from Tmp_Plantilla_Ic);
  
 

   
BEGIN
  
FOR X IN USUARIOS LOOP

  BEGIN  
  
    V_INCONSISTENCIA :=NULL;
    V_DIGITO := NULL;
    V_SECRETARIA := NULL;
    V_ID_SECRETARIA := NULL;
    V_ID_CIUDAD_SAP := NULL; 
    V_DESC_CIUDAD := NULL;
    V_ID_DPTO := NULL;
    V_DESC_DPTO := NULL;
    V_ERROR := 0;
  
    V_ID_USUARIO := X.ID_USUARIO;
    V_DOCUMENTO := X.ID_DOCUMENTO;
    V_NOMBRES := X.NOMBRES;
    V_APELLIDOS := X.APELLIDOS;
    V_DIRECION := X.DIRECCION;
    V_ID_CIUDAD := X.ID_CIUDAD_DIR;
    V_TELEFONO := X.TELEFONO;
    V_FAX := X.FAX;
    V_EMAIL := X.EMAIL;
    V_CELULAR := X.CELULAR;
   
/*Estandarizo la direcci�n*/
V_DIRECION := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(V_DIRECION);

/*Estandarizo el nombre*/
V_NOMBRES := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(V_NOMBRES,'N');

/*Estandarizo el apellido*/
V_APELLIDOS := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(V_APELLIDOS,'A');
   
/*Estandarizo el telefono*/
V_TELEFONO := PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE(V_TELEFONO, 'T');     
  
 /*Valido que la direccion no sea vacia*/
   IF V_DIRECION IS NULL or  V_DIRECION = '' THEN
   
    SELECT DV.ID_SECRETARIA, DV.NOMBRE_SECRETARIA INTO V_ID_SECRETARIA, V_SECRETARIA
    FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 DP
    INNER JOIN CORRECCION_DATOS.DS_TMP_VEHICULOS1 DV
       ON DV.NRO_PLACA = DP.NRO_PLACA
    WHERE DP.ID_USUARIO = v_ID_USUARIO AND Dp.Id_Documento = V_DOCUMENTO
    AND ROWNUM = 1; 
    
    --Como no tiene direcci�n se envia No reporta y el id del transito.  
    V_DIRECION := 'NO REPORTA - ' || V_SECRETARIA || ' ' || V_ID_SECRETARIA;
      
   END IF;
   
   /*Valido que el id direccion no sea null*/
   /*IF V_ID_CIUDAD IS NULL or  V_ID_CIUDAD = '' or  V_ID_CIUDAD = '0' THEN
   
    SELECT DV.ID_SECRETARIA, DV.NOMBRE_SECRETARIA INTO V_ID_SECRETARIA, V_SECRETARIA
    FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 DP
    INNER JOIN CORRECCION_DATOS.DS_TMP_VEHICULOS1 DV
       ON DV.NRO_PLACA = DP.NRO_PLACA
    WHERE DP.ID_USUARIO = V_ID_USUARIO AND Dp.Id_Documento = V_DOCUMENTO
    AND ROWNUM = 1; 
    
    --Como no tiene id ciudad se envia No reporta y el id del transito.  
    V_DIRECION := 'NO REPORTA - ' || V_SECRETARIA || ' ' || V_ID_SECRETARIA;
    
    --Como no tiene id ciudad se le envia la secretaria de transito 
    V_ID_CIUDAD :=  V_ID_SECRETARIA;    
      
   END IF;*/
   
   /*Valido que el id direccion sea valido y que tenga trazabilidad*/
   SELECT COUNT(1) INTO V_EXISTE  
   FROM QUIPUX.CIUDADES CI
   INNER JOIN DEPURACION.SAP_CIUDADES SC 
      ON SC.ID_CIUDAD_QX = CI.ID_CIUDAD_QX 
   WHERE CI.CIUDAD_RUNT = V_ID_CIUDAD; 
   
   IF V_EXISTE = 0 THEN
   
    SELECT DV.ID_SECRETARIA, DV.NOMBRE_SECRETARIA INTO V_ID_SECRETARIA, V_SECRETARIA
    FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 DP
    INNER JOIN CORRECCION_DATOS.DS_TMP_VEHICULOS1 DV
       ON DV.NRO_PLACA = DP.NRO_PLACA
    WHERE DP.ID_USUARIO = V_ID_USUARIO AND Dp.Id_Documento = V_DOCUMENTO
    AND ROWNUM = 1; 
    
    --Como no tiene id ciudad se envia No reporta y el id del transito.  
    V_DIRECION := 'NO REPORTA - ' || V_SECRETARIA || ' ' || V_ID_SECRETARIA;
    
    --Como no tiene id ciudad se le envia la secretaria de transito 
    V_ID_CIUDAD :=  V_ID_SECRETARIA;    
      
  END IF;
   
     /**************************************************************************************/
     SELECT SC.ID_CIUDAD_SAP, UPPER(SC.DESCRIPCION_CIUDAD_SAP), SC.ID_DEPTO_SAP, UPPER(SC.DESCRIPCION_DEPTO_QX)
        INTO V_ID_CIUDAD_SAP, V_DESC_CIUDAD, V_ID_DPTO, V_DESC_DPTO
     FROM QUIPUX.CIUDADES CI
     INNER JOIN DEPURACION.SAP_CIUDADES SC ON SC.ID_CIUDAD_QX = CI.ID_CIUDAD_QX 
     WHERE CI.CIUDAD_RUNT = V_ID_CIUDAD; 
     /**************************************************************************************/
 

 
 /* Adiciono el digito de verificacion si el nit es de 9 digitos */
   IF (LENGTH(V_ID_USUARIO)  =  9 AND  V_DOCUMENTO = 'N') THEN
      V_DIGITO := PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_ID_USUARIO);
   END IF;
 
 /*==============================================================*/
 
 /*INICIO VALIDACION DE DATOS*/
 --VALIDO LA DIRECCION
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECION,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      V_INCONSISTENCIA := V_INCONSISTENCIA || FT_GENERAR_EXCEPCION(V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      V_INCONSISTENCIA := V_INCONSISTENCIA || FT_GENERAR_EXCEPCION(V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
         V_INCONSISTENCIA := V_INCONSISTENCIA || FT_GENERAR_EXCEPCION(V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL FAX
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
        V_INCONSISTENCIA := V_INCONSISTENCIA || FT_GENERAR_EXCEPCION(V_ERROR);
       V_ERROR := 0;
    END IF;
     --VALIDO EL CELULAR
    IF V_CELULAR IS NOT NULL THEN
      V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_CELULAR,'T',0);  
    END IF;
    IF V_ERROR > 0 THEN
    
      IF V_ERROR = 12 THEN 
          V_ERROR := 15;
      ELSIF V_ERROR = 10 THEN 
          V_ERROR := 16;
      ELSIF V_ERROR = 8 THEN 
          V_ERROR := 17;
      END IF;
      
      --INSERTO LA EXCEPCION EN EL CAMPO
        V_INCONSISTENCIA := V_INCONSISTENCIA || FT_GENERAR_EXCEPCION(V_ERROR);
        V_ERROR := 0;
       
    END IF;
  
 /*GUARDO EL REGISTRO*/ 
 INSERT INTO TMP_PLANTILLA_IC (ID_USUARIO, DOCUMENTO, NOMBRES, APELLIDOS, DIRECCION, ID_CIUDAD, DESC_CIUDAD, ID_DPTO,
                               DESC_DPTO, TELEFONO, FAX, CELULAR, EMAIL, INCONSISTENCIA, DIGITO_VERIFICA) VALUES
             (V_ID_USUARIO, V_DOCUMENTO, V_NOMBRES, V_APELLIDOS, V_DIRECION, V_ID_CIUDAD_SAP, 
               V_DESC_CIUDAD, V_ID_DPTO, V_DESC_DPTO, V_TELEFONO,V_FAX,V_CELULAR,V_EMAIL,V_INCONSISTENCIA, V_DIGITO);   
    
EXCEPTION 
WHEN OTHERS THEN
    CONTINUE;
END;    
               
  IF V_CONTADOR = 500 THEN
     V_CONTADOR := 0;
     COMMIT;
  ELSE
     V_CONTADOR := V_CONTADOR + 1;
  END IF;   
   
END LOOP;   
COMMIT;  
--ADICIONO LOS NO REPORTA
SP_NO_REPORTA;
   
END SP_INSERTAR_USUARIOS;


PROCEDURE SP_NO_REPORTA AS

V_SECRETARIA VARCHAR2(100);
V_ID_SECRETARIA VARCHAR2(100);
V_DIRECCION VARCHAR2(100);

CURSOR DIRECCION IS 
SELECT * FROM CORRECCION_DATOS.Tmp_Plantilla_Ic TP
WHERE INCONSISTENCIA LIKE '%DIRECCION%' AND DIRECCION2 IS NULL;

BEGIN

FOR X IN DIRECCION LOOP  

BEGIN

  SELECT DV.ID_SECRETARIA, DV.NOMBRE_SECRETARIA INTO V_ID_SECRETARIA, V_SECRETARIA
  FROM CORRECCION_DATOS.Ds_Tmp_Propietarios1 DP
  INNER JOIN CORRECCION_DATOS.DS_TMP_VEHICULOS1 DV
     ON DV.NRO_PLACA = DP.NRO_PLACA
  WHERE DP.ID_USUARIO = X.ID_USUARIO AND Dp.Id_Documento = X.DOCUMENTO;
  
  UPDATE CORRECCION_DATOS.Tmp_Plantilla_Ic 
     SET DIRECCION2 = 'NO REPORTA - ' || V_SECRETARIA || ' ' || V_ID_SECRETARIA
  WHERE ID_USUARIO = X.ID_USUARIO AND Documento = X.DOCUMENTO;

EXCEPTION
  WHEN OTHERS THEN
    CONTINUE;
  END;  

END LOOP;
COMMIT;

END SP_NO_REPORTA;


FUNCTION FT_GENERAR_EXCEPCION (PARAMETRO NUMBER) RETURN VARCHAR2 AS

MENSAJE VARCHAR2(255);

BEGIN


   CASE PARAMETRO
          WHEN 1 THEN
              MENSAJE:='DIRECCION<7, ';
          WHEN 2 THEN
              MENSAJE:='DIRECCION SOLO LETRAS, ';
          WHEN 3 THEN
              MENSAJE:='DIRECCION SOLO NUMEROS, ';
          WHEN 4 THEN
              MENSAJE:='DIRECCION 3 CONSONANTES, ';
          WHEN 5 THEN
              MENSAJE:='EMAIL @, ';
          WHEN 6 THEN
              MENSAJE:='E-MAIL<7, ';
          WHEN 7 THEN
              MENSAJE:='E-MAIL NOREGISTRA, ';
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              MENSAJE:= NULL; 
          WHEN 15 THEN
              MENSAJE:='CELULAR 0000000, '; 
          WHEN 16 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='CELULAR CARACTERES, ';
          WHEN 17 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='CELULAR NO VALIDO, ';    
          ELSE
              MENSAJE:='NO SE PUEDE DETERMINAR EL ERROR';
    END CASE;

   RETURN MENSAJE;
   
END FT_GENERAR_EXCEPCION;


END PKG_PLANTILLA_IC_TTO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PLANTILLA_OC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_PLANTILLA_OC" AS

	  --::::::::::::::::::::::::::::::::::::::--
	  
	PROCEDURE SP_GENERAR_PLANTILLA_OC AS

		V_PLACA                        VARCHAR2(8);
		V_CLASE_OBJETO                 VARCHAR2(5);
		V_GRUPO_AUTORIZACIONES         VARCHAR2(5);
		V_MARCA                        VARCHAR2(80);
		V_DENOMINACION_OBJETO          VARCHAR2(80);
		V_TIPO_CUENTA_CONTRATO         VARCHAR2(2);
		V_FACTURA_SEPARADA             VARCHAR2(1);
		V_TIPO_FACTURA                 VARCHAR2(2);
		V_PERIODICIDAD_CORRESPONDENCIA VARCHAR2(20);
		V_CILINDRAJE                   VARCHAR2(10);
		V_LINEA                        VARCHAR2(10);
		V_CLASE                        VARCHAR2(10);
		V_MODELO                       VARCHAR2(4);
		V_CARROCERIA                   VARCHAR2(10);
		V_ID_SERVICIO                  VARCHAR2(5);
		V_USO                          VARCHAR2(5);
		V_FECHA_FACTURA                VARCHAR2(15);
		V_IMPORTADO_NACIONAL           VARCHAR2(1);
		V_NUMERO_MANIFIESTO            VARCHAR2(2);
		V_TIPO_DE_CARGA                VARCHAR2(1);
		V_CAP_PASAJEROS                VARCHAR2(10);
		V_CAP_TONELADAS                VARCHAR2(10);
		V_SECRETARIA                   VARCHAR2(10);
	  V_CLASICO                      VARCHAR2(2);
    V_CANTIDAD                     VARCHAR2(2);
    V_IDENTIFICACION               VARCHAR2(20);
    V_EXISTE                       VARCHAR2(1);
    V_TIPO_ARCHIVO                 VARCHAR2(1);
    V_LIQ_ACTIVA                   VARCHAR2(1);
    V_VALOR_FACTURA                VARCHAR2(30);
    
		CURSOR CLASE_OBJETO IS
      
      -- Recupera las placas nuevas para sap
			SELECT DISTINCT(NRO_PLACA), 
            ID_MARCA,
            NOMBRE_MARCA,
            ID_LINEA,
            NOMBRE_LINEA,
            MODELO,
            ID_CLASE,
            NOMBRE_CLASE,
            ID_SERVICIO,
            NOMBRE_SERVICIO,
            ID_CARROCERIA,
            NOMBRE_CARROCERIA,
            NRO_PUERTAS,
            ID_COMBUSTIBLE,
            NOMBRE_COMBUSTIBLE,
            ID_BATERIA,
            NOMBRE_BATERIA,
            POTENCIA,
            ID_SECRETARIA,
            NOMBRE_SECRETARIA,
            CILINDRAJE,
            CAP_PASAJEROS,
            CAP_TONELADAS,
            VALOR_FACTURA,
            BLINDADO,
            IMPORTADO_NACIONAL,
            ID_ESTADO,
            NOMBRE_ESTADO,
            CLASICO_ANTIGUO,
            FECHA_MATRICULO
      from correccion_datos.oc_runt ocr
      --where NRO_PLACA IN (SELECT CEDULA FROM TEMP_CEDULAS)
      where NRO_PLACA IN  ('HEZ856', 'HAN405', 'HAL022', 'HXW340', 'HFM964')
      ;
      
  BEGIN

		FOR XCLASE IN CLASE_OBJETO LOOP
	  
			-- RECUPERO LAS VARIABLES A USAR

			V_PLACA := XCLASE.NRO_PLACA;
			V_MARCA := XCLASE.ID_MARCA;
			V_TIPO_CUENTA_CONTRATO := '02';
			V_GRUPO_AUTORIZACIONES := 'RE02';
			V_FACTURA_SEPARADA := 'X';
			V_TIPO_FACTURA := '02';
			V_PERIODICIDAD_CORRESPONDENCIA := 'INMEDIATAMENTE';
			V_CILINDRAJE := XCLASE.CILINDRAJE;
			V_LINEA := XCLASE.ID_LINEA;
			V_CLASE := XCLASE.ID_CLASE;
			V_MODELO := XCLASE.MODELO;
			V_CARROCERIA := XCLASE.ID_CARROCERIA;
			V_USO := XCLASE.ID_SERVICIO;
			V_FECHA_FACTURA := XCLASE.FECHA_MATRICULO;
			V_IMPORTADO_NACIONAL := XCLASE.IMPORTADO_NACIONAL;
			V_NUMERO_MANIFIESTO := 'CI';
			V_CAP_TONELADAS := XCLASE.CAP_TONELADAS;
			V_CAP_PASAJEROS := XCLASE.CAP_PASAJEROS;
			V_SECRETARIA := XCLASE.ID_SECRETARIA;
      V_CLASICO := XCLASE.CLASICO_ANTIGUO;
      V_VALOR_FACTURA:= XCLASE.VALOR_FACTURA;
    
			-- REALIZO LA ACTUALIZACION DEL CAMPO CLASE_OBJETO EN LA PLANTILLA DE SAP
			V_CLASE_OBJETO := FT_PLACA(V_PLACA);
      
      V_IDENTIFICACION := FT_NRO_IDENTIFICACION(V_PLACA);
      
			BEGIN
        
        SELECT COUNT(1)
        INTO V_CANTIDAD
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE OBJETO_CONTRATO = V_PLACA;
        
        IF V_CANTIDAD = 0 THEN
          INSERT INTO CORRECCION_DATOS.PLANTILLA_OC
          (OBJETO_CONTRATO, CLASE_OBJETO) 
          VALUES 
          (V_PLACA, V_CLASE_OBJETO);
          
        ELSE
        
          UPDATE CORRECCION_DATOS.PLANTILLA_OC
          SET CLASE_OBJETO = V_CLASE_OBJETO
          WHERE OBJETO_CONTRATO = V_PLACA;
          
			  END IF;
        
        COMMIT;
        
			EXCEPTION
			WHEN OTHERS THEN
				ROLLBACK;
			END;
      
      BEGIN
         --VALIDO SI EXISTE EL VEHICULO EN SAP
        SELECT COUNT(1)
        INTO V_EXISTE
        FROM CORRECCION_DATOS.OC
        WHERE OC.OBJ_CONTR = V_PLACA;
        
        IF V_EXISTE > 0 THEN
          V_TIPO_ARCHIVO := 'M';
          V_LIQ_ACTIVA := 'S';
        ELSE
          V_TIPO_ARCHIVO := 'N';
          V_LIQ_ACTIVA := '';
        END IF;
        
      EXCEPTION
			WHEN OTHERS THEN
				ROLLBACK;
			END;
      
			-- REALIZO LA ACTUALIZACION DEL CAMPO DENOMINACION_OBJETO EN LA PLANTILLA DE SAP
			SP_DENOMINACION_OBJETO(V_PLACA, V_MARCA, V_CILINDRAJE, V_LINEA, V_CLASE);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO CLASE EN LA PLANTILLA DE SAP
			SP_CLASE (V_PLACA, V_CLASE);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO CARROCERIA EN LA PLANTILLA DE SAP
			SP_CARROCERIA (V_PLACA, V_CARROCERIA);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO USO EN LA PLANTILLA DE SAP
			V_USO := FT_USO(V_USO);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO AVALUO EN LA PLANTILLA DE SAP
			SP_AVALUO (V_PLACA, V_VALOR_FACTURA, V_TIPO_ARCHIVO);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO TIPO_CARGA EN LA PLANTILLA DE SAP
			V_TIPO_DE_CARGA := FT_TIPO_DE_CARGA (V_CAP_PASAJEROS, V_CAP_TONELADAS);
			
			-- REALIZO LA ACTUALIZACION DEL CAMPO TIPO_CARGA EN LA PLANTILLA DE SAP
			SP_UNIDAD_TRANSITO (V_PLACA , V_SECRETARIA);
			
      IF V_CLASICO IN ('A','C') THEN
        V_CLASICO := 'X';
      ELSIF V_CLASICO = 'N' THEN
        V_CLASICO := '';
      END IF;
			
      BEGIN
				-- REALIZO LA ACTUALIZACION DE LAS CONSTANTES EN LA PLANTILLA DE SAP
				UPDATE CORRECCION_DATOS.PLANTILLA_OC
				SET TIPO_CUENTA_CONTRATO = V_TIPO_CUENTA_CONTRATO,
					GRUPO_AUTORIZACIONES = V_GRUPO_AUTORIZACIONES,
					FACTURA_SEPARADA = V_FACTURA_SEPARADA,
					TIPO_FACTURA = V_TIPO_FACTURA,
					PERIODICIDAD_CORRESPONDENCIA = V_PERIODICIDAD_CORRESPONDENCIA,
					NRO_PLACA = V_PLACA,
					CILINDRAJE = V_CILINDRAJE,
					MODELO = V_MODELO,
					SERVICIO = V_USO,
					F_FACTURA_VEHICULO = V_FECHA_FACTURA,
					IMPORTADO = V_IMPORTADO_NACIONAL,
					NRO_MANIFIESTO = V_NUMERO_MANIFIESTO,
					TIPO_CARGA = V_TIPO_DE_CARGA,
					CAPACIDAD_CARGA = V_CAP_TONELADAS,
					CAPACIDAD_PSJ = V_CAP_PASAJEROS,
          CLASICO = V_CLASICO,
          NRO_IDENTIFICACION = V_IDENTIFICACION,
          TIPO_ARCHIVO = V_TIPO_ARCHIVO,
          LIQ_ACTIVA = V_LIQ_ACTIVA
				WHERE OBJETO_CONTRATO = V_PLACA;
				COMMIT;
			
			EXCEPTION
			WHEN OTHERS THEN 
				ROLLBACK;
			END;
      
		END LOOP;
		
    -- REALIZO LAS VALIDACIONES DE LA PLANTILLA DE OC
    SP_VALIDACIONES_PLANTILLA;
    
	END SP_GENERAR_PLANTILLA_OC;

	-- FUNCION QUE SE ENCARGA DE INGRESAR LA CLASE_OBJETO DE ACUERDO AL NUMERO DE PLACA EN LA PLANTILLA DE SAP CAMPO: (CLASE_OBJETO)
	FUNCTION FT_PLACA( NRO_PLACA VARCHAR2 ) RETURN VARCHAR2 AS

		V_PLACA VARCHAR2(8);
	  
	BEGIN
		
		-- ASIGNO EL NUMERO DE PLACA
		V_PLACA := NRO_PLACA;
		
		--LA PONGO EN MAYUSCULA
		V_PLACA := UPPER(V_PLACA);
		
		--REMPLAZO CARACTERES LETRAS POR "~" Y NUMEROS POR "@" PARA COMPARAR MAS FACILMENTE EL FORMATO
		V_PLACA := TRANSLATE(V_PLACA,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
		V_PLACA := TRANSLATE(V_PLACA,'0123456789','@@@@@@@@@@');
		V_PLACA := TRANSLATE(V_PLACA,'*','#');
		
		IF V_PLACA IN ('~~~@@@', '#~~~@@@','~~@@@@', '#~~@@@@','~~~@@', '#~~~@@', '~~~@@~', '#~~~@@~','~~@@@', '#~~@@@') THEN
			RETURN '002A';
		ELSIF V_PLACA IN ('@@@@', '#@@@@') THEN
			RETURN '002D';
		ELSIF V_PLACA IN ('@@@~', '#@@@~', '@@@~~~', '#@@@~~~', '@@@~~') THEN
			RETURN '002N';
		ELSE
			RETURN '';
		END IF;
		
	END FT_PLACA;

	-- PROCEDIMIENTO QUE SE ENCARGA DE INGRESAR LA DENOMINACION_OBJETO DE ACUERDO A LA LINEA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: DENOMINACION_OBJETO)
	PROCEDURE SP_DENOMINACION_OBJETO( NRO_PLACA  VARCHAR2, ID_MARCA   VARCHAR2, CILINDRAJE VARCHAR2, LINEA VARCHAR2, CLASE VARCHAR2 ) AS

	  V_PLACA      VARCHAR2(8);
	  V_ID_MARCA   VARCHAR2(10);
	  V_DES_MARCA  VARCHAR2(80);
	  V_CILINDRAJE VARCHAR2(10);
	  V_LINEA      VARCHAR2(10);
	  V_CLASE      VARCHAR2(10);
	  
	BEGIN

		BEGIN
		
			-- ASIGNO EL NUMERO DE PLACA
			V_PLACA := NRO_PLACA;
			
			--LA PONGO EN MAYUSCULA
			V_PLACA := UPPER(V_PLACA);
			
			-- ASIGNO EL ID MARCA ENVIADO POR RUNT
			V_ID_MARCA := ID_MARCA;
			
			-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
			V_CILINDRAJE := CILINDRAJE;
			
			-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
			V_LINEA := LINEA;
			
			-- ASIGNO LA CLASE ENVIADA POR RUNT
			V_CLASE := CLASE;
		
			SELECT DISTINCT (SM.DESC_MARCA_SAP),
				   SM.ID_MARCA_SAP
			INTO V_DES_MARCA,
				 V_ID_MARCA
			FROM QUIPUX.QX_TIPO_MARCA QTM
			INNER JOIN DEPURACION.SAP_MARCAS SM
				ON QTM.ID_MARCA_QX = SM.ID_MARCA_QX
			WHERE QTM.RUNT_MARCA = V_ID_MARCA;
			
		EXCEPTION
		WHEN OTHERS THEN
			V_DES_MARCA := '';
			V_ID_MARCA  := '';
		END;
		
		BEGIN
		
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET DENOMINACION_OBJETO = V_DES_MARCA,
				MARCA = V_ID_MARCA
			WHERE OBJETO_CONTRATO = V_PLACA;
			COMMIT;
		
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
		
		-- REALIZO LA ACTUALIZACION DE LA LINEA
		SP_LINEA (V_PLACA, V_ID_MARCA, V_CILINDRAJE, V_LINEA, V_CLASE);
	  
	END SP_DENOMINACION_OBJETO;

	-- FUNCION QUE SE ENCARGA DE ASIGNAR EL NUMERO DE IDENTIFICACION DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: NRO_IDENTIFICACION)
	FUNCTION FT_NRO_IDENTIFICACION( NRO_PLACA VARCHAR2 ) RETURN VARCHAR2 AS
    
    V_PLACA VARCHAR2(8);
    V_IDENTIFICACION VARCHAR2(20);
    
	BEGIN
    
    BEGIN
    
      -- ASIGNO EL NUMERO DE PLACA
      V_PLACA := NRO_PLACA;
      
      --LA PONGO EN MAYUSCULA
      V_PLACA := UPPER(V_PLACA);
      
      SELECT IDENTIFICACION
      INTO V_IDENTIFICACION
      FROM CORRECCION_DATOS.TEMP_PLANTILLA_IC_A_OC TPI
      WHERE TPI.NRO_PLACA = V_PLACA;
      
    EXCEPTION
      WHEN OTHERS THEN
        V_IDENTIFICACION := '';
        RETURN V_IDENTIFICACION;
		END; 
		
    RETURN V_IDENTIFICACION;
    
	END FT_NRO_IDENTIFICACION;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR LA LINEA DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: LINEA)
	PROCEDURE SP_LINEA( NRO_PLACA  VARCHAR2, ID_MARCA VARCHAR2, CILINDRAJE VARCHAR2, LINEA VARCHAR2, CLASE VARCHAR2 ) AS

	  V_PLACA          VARCHAR2(8);
	  V_ID_MARCA       VARCHAR2(10);
	  V_CILINDRAJE     VARCHAR2(10);
	  V_LINEA          VARCHAR2(10);
	  V_LINEA_SAP      VARCHAR2(8);
	  V_CILINDRAJE_RED VARCHAR2(8);
	  V_TIPO_VEHICULO  VARCHAR2(8);
	  V_CLASE          VARCHAR2(10);
	  
	BEGIN

		BEGIN
		
			-- ASIGNO EL NUMERO DE PLACA
			V_PLACA := NRO_PLACA;
			
			--LA PONGO EN MAYUSCULA
			V_PLACA := UPPER(V_PLACA);
			
			-- ASIGNO EL ID MARCA ENVIADO POR RUNT
			V_ID_MARCA := ID_MARCA;
			
			-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
			V_CILINDRAJE := CILINDRAJE;
			
			-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
			V_LINEA := LINEA;
			
			-- ASIGNO LA CLASE ENVIADA POR RUNT
			V_CLASE := CLASE;
			
			BEGIN
			
				SELECT DISTINCT(SL.ID_LINEA_SAP)
        INTO V_LINEA_SAP
        FROM QX_TIPO_MARCA QXM
        INNER JOIN MARCA_VEHICULOS MV
          ON QXM.ID_MARCA_QX = MV.ID_MARCA_QX
        INNER JOIN QX_TIPO_LINEA QXL
          ON QXM.ID_MARCA_QX = QXL.ID_MARCA_QX
        INNER JOIN TIPO_LINEA TL
          ON QXL.ID_LINEA_QX = TL.ID_LINEA_QX
        INNER JOIN SAP_LINEAS SL
          ON QXL.ID_LINEA_QX =SL.ID_LINEA_QX
        WHERE QXL.RUNT_LINEA = V_LINEA AND
            SL.ID_MARCA_SAP = V_ID_MARCA AND
            SL.CILINDRAJE_SAP = V_CILINDRAJE AND
            ROWNUM = 1;
			
			EXCEPTION
			WHEN OTHERS THEN
      
        BEGIN
        
        IF V_CLASE = '10' OR V_CLASE = '14' OR V_CLASE = '17' OR V_CLASE = '19' THEN
					V_TIPO_VEHICULO := '2';
				ELSE
					V_TIPO_VEHICULO := '1';
				END IF;
				
				-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
				SELECT CILINDRAJE
				INTO V_CILINDRAJE_RED
				FROM DEPURACION.SAP_CILINDRAJES
				WHERE TIPO_VEHICULO = V_TIPO_VEHICULO AND
					  V_CILINDRAJE BETWEEN RANGO_DESDE AND RANGO_HASTA;
        
        SELECT DISTINCT(SL.ID_LINEA_SAP)
        INTO V_LINEA_SAP
        FROM QX_TIPO_MARCA QXM
        INNER JOIN MARCA_VEHICULOS MV
          ON QXM.ID_MARCA_QX = MV.ID_MARCA_QX
        INNER JOIN QX_TIPO_LINEA QXL
          ON QXM.ID_MARCA_QX = QXL.ID_MARCA_QX
        INNER JOIN TIPO_LINEA TL
          ON QXL.ID_LINEA_QX = TL.ID_LINEA_QX
        INNER JOIN SAP_LINEAS SL
          ON QXL.ID_LINEA_QX =SL.ID_LINEA_QX
        WHERE QXL.RUNT_LINEA = V_LINEA AND
            SL.ID_MARCA_SAP = V_ID_MARCA AND
            SL.CILINDRAJE_SAP = V_CILINDRAJE_RED AND
            ROWNUM = 1;
        
        EXCEPTION
        WHEN OTHERS THEN 
        
          BEGIN
            
            V_CILINDRAJE_RED:= '0';
            
            SELECT DISTINCT(SL.ID_LINEA_SAP)
            INTO V_LINEA_SAP
            FROM QX_TIPO_MARCA QXM
            INNER JOIN MARCA_VEHICULOS MV
              ON QXM.ID_MARCA_QX = MV.ID_MARCA_QX
            INNER JOIN QX_TIPO_LINEA QXL
              ON QXM.ID_MARCA_QX = QXL.ID_MARCA_QX
            INNER JOIN TIPO_LINEA TL
              ON QXL.ID_LINEA_QX = TL.ID_LINEA_QX
            INNER JOIN SAP_LINEAS SL
              ON QXL.ID_LINEA_QX =SL.ID_LINEA_QX
            WHERE QXL.RUNT_LINEA = V_LINEA AND
                SL.ID_MARCA_SAP = V_ID_MARCA AND
                SL.CILINDRAJE_SAP = V_CILINDRAJE_RED AND
                ROWNUM = 1;
          
          EXCEPTION
          WHEN OTHERS THEN
            V_LINEA := '';
          END; 
        END;
        
			END;
			
			/*-- RECUPERO EL ID LINEA SAP BUSCANDO POR LA LINEA QX, MARCA SAP Y EL CILINDRAJE ENVIADIO POR RUNT
			
			SELECT DISTINCT(ID_LINEA_SAP)
      INTO V_LINEA_SAP
      FROM DEPURACION.SAP_LINEAS
      WHERE ID_MARCA_SAP = V_ID_MARCA AND
          CILINDRAJE_SAP = V_CILINDRAJE AND
          ID_LINEA_QX = V_LINEA AND
          ROWNUM = 1;
			
		EXCEPTION
		WHEN OTHERS THEN
			V_LINEA_SAP := '0';
		END;
		
		-- RECUPERO EL ID LINEA SAP BUSCANDO POR LA LINEA QX, MARCA SAP Y EL CILINDRAJE REDONDEADO
		IF V_LINEA_SAP = '0' THEN
		
			BEGIN
			
				IF V_CLASE = '10' OR V_CLASE = '14' OR V_CLASE = '17' OR V_CLASE = '19' THEN
					V_TIPO_VEHICULO := '2';
				ELSE
					V_TIPO_VEHICULO := '1';
				END IF;
				
				-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
				SELECT CILINDRAJE
				INTO V_CILINDRAJE_RED
				FROM DEPURACION.SAP_CILINDRAJES
				WHERE TIPO_VEHICULO = V_TIPO_VEHICULO AND
					  V_CILINDRAJE BETWEEN RANGO_DESDE AND RANGO_HASTA;
					  
				SELECT DISTINCT(ID_LINEA_SAP)
				INTO V_LINEA_SAP
				FROM DEPURACION.SAP_LINEAS
				WHERE ID_MARCA_SAP = V_ID_MARCA AND
					  CILINDRAJE_SAP = V_CILINDRAJE_RED AND
					  ID_LINEA_QX = V_LINEA AND
            ROWNUM = 1;
				
			EXCEPTION
			WHEN OTHERS THEN
				V_LINEA_SAP := '0';
			END;
			
		END IF;
	  
		-- RECUPERO EL ID LINEA SAP BUSCANDO POR LA LINEA QX, MARCA SAP Y EL CILINDRAJE EN CERO (0)
		IF V_LINEA_SAP = '0' THEN
		
			BEGIN
			
				-- ASIGNO EL CILINDRAJE ENVIADO POR RUNT
				V_CILINDRAJE := '0';
				
				SELECT DISTINCT(ID_LINEA_SAP)
				INTO V_LINEA_SAP
				FROM DEPURACION.SAP_LINEAS
				WHERE ID_MARCA_SAP = V_ID_MARCA AND
              CILINDRAJE_SAP = V_CILINDRAJE AND
              ID_LINEA_QX = V_LINEA AND
              ROWNUM = 1;
				
			EXCEPTION
			WHEN OTHERS THEN
				V_LINEA_SAP := '';
			END;
			
		END IF;*/
		
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET LINEA = V_LINEA_SAP
			WHERE OBJETO_CONTRATO = V_PLACA;
			COMMIT;
			
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
		
	END SP_LINEA;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR LA CLASE DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: CLASE)
	PROCEDURE SP_CLASE( NRO_PLACA VARCHAR2, CLASE VARCHAR2 ) AS

	  V_PLACA VARCHAR2(8);
	  V_CLASE VARCHAR2(10);
	  
	BEGIN

		BEGIN
		
			-- ASIGNO EL NUMERO DE PLACA
			V_PLACA := NRO_PLACA;
			
			--LA PONGO EN MAYUSCULA
			V_PLACA := UPPER(V_PLACA);
			
			-- ASIGNO LA CLASE ENVIADA POR RUNT
			V_CLASE := CLASE;
			
			SELECT SC.ID_CLASE_SAP
			INTO V_CLASE
			FROM SAP_CLASE SC
			INNER JOIN QX_TIPO_CLASE QTC
				ON SC.ID_CLASE_QX = QTC.ID_CLASE_QX
			WHERE QTC.RUNT_CLASE = V_CLASE;
			
			EXCEPTION
			WHEN OTHERS THEN
				V_CLASE := '';
			END;
			
		BEGIN
	  
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET CLASE = V_CLASE
			WHERE OBJETO_CONTRATO = V_PLACA;
			COMMIT;
      
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
	  
	END SP_CLASE;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR LA CARROCERIA DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: CARROCERIA)
	PROCEDURE SP_CARROCERIA( NRO_PLACA  VARCHAR2, CARROCERIA VARCHAR2 ) AS

	  V_PLACA      VARCHAR2(8);
	  V_CARROCERIA VARCHAR2(10);
	  
	BEGIN

		BEGIN
		
			-- ASIGNO EL NUMERO DE PLACA
			V_PLACA := NRO_PLACA;
			
			--LA PONGO EN MAYUSCULA
			V_PLACA := UPPER(V_PLACA);
			
			-- ASIGNO LA CLASE ENVIADA POR RUNT
			V_CARROCERIA := CARROCERIA;
			
			SELECT SC.ID_CARROCERIA_SAP
			INTO V_CARROCERIA
			FROM SAP_CARROCERIA SC
			INNER JOIN QX_TIPO_CARROCERIA QTC
				ON SC.ID_CARROCERIA_QX = QTC.ID_CARROCERIA_QX
			WHERE QTC.RUNT_CARROCERIA = V_CARROCERIA AND
            ROWNUM = 1;
		
		EXCEPTION
		WHEN OTHERS THEN
			V_CARROCERIA := '';
		END;
		
		BEGIN
		
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET CARROCERIA = V_CARROCERIA
			WHERE OBJETO_CONTRATO = V_PLACA;
			COMMIT;
      
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
		
	END SP_CARROCERIA;

	-- FUNCION QUE SE ENCARGA DE ACTUALIZAR EL USO DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: USO)
	FUNCTION FT_USO( ID_SERVICIO VARCHAR2 ) RETURN VARCHAR2 AS

	  V_USO VARCHAR2(5);
	  
	BEGIN

		V_USO := ID_SERVICIO;
		
		BEGIN
		
			SELECT ID_SERVICIO
			INTO V_USO
			FROM QUIPUX.TIPO_SERVICIO
			WHERE RUNT_SERVICIO = V_USO;
			
		EXCEPTION
		WHEN OTHERS THEN
			V_USO := '';
		END;
		
		-- SE CONSULTA EL SERVICIO
		CASE V_USO
			WHEN '1' THEN    -- PARTICULAR PARA QX
			V_USO := '03'; -- PARTICULAR PARA SAP
			WHEN '2' THEN    -- P�BLICO PARA QX
			V_USO := '02'; -- P�BLICO PARA SAP
			WHEN '3' THEN    -- OFICIAL PARA QX
			V_USO := '01'; -- OFICIAL PARA SAP
			WHEN '4' THEN    -- DIPLOM�TICO PARA QX
			V_USO := '04'; -- DIPLOM�TICO PARA SAP
			WHEN '5' THEN    -- ELECTRICO PARA QX
			V_USO := '05'; -- ELECTRICO PARA SAP
			WHEN '7' THEN    -- OFICIAL_EMP IND Y CIAL PARA QX
			V_USO := '06'; -- OFICIAL_EMP IND Y CIAL PARA SAP
		END CASE;
		
		RETURN V_USO;
	  
	END FT_USO;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR LA TARIFA DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: TARIFA)
	PROCEDURE SP_TARIFA( NRO_PLACA VARCHAR2, AVALUO VARCHAR2 ) AS

	  V_PLACA                 VARCHAR2(8);
	  V_AVALUO                VARCHAR2(15);
	  V_ANNO                  VARCHAR2(5);
	  V_MILLONES_DESDE_RANGO1 VARCHAR2(15);
	  V_MILLONES_HASTA_RANGO1 VARCHAR2(15);
	  V_MILLONES_DESDE_RANGO2 VARCHAR2(15);
	  V_MILLONES_HASTA_RANGO2 VARCHAR2(15);
	  V_MILLONES_DESDE_RANGO3 VARCHAR2(15);
	  V_MILLONES_HASTA_RANGO3 VARCHAR2(15);
	  V_MILLONES_DESDE_RANGO4 VARCHAR2(15);
	  V_MILLONES_HASTA_RANGO4 VARCHAR2(15);
	  V_MODELO                VARCHAR2(5);
	  V_MODELO_SIGUIENTE      VARCHAR2(5);
	  
	BEGIN

		-- ASIGNO EL NUMERO DE PLACA
		V_PLACA := NRO_PLACA;
		--LA PONGO EN MAYUSCULA
		V_PLACA := UPPER(V_PLACA);
		--LA PONGO EN MAYUSCULA
		V_AVALUO := AVALUO;
		-- CALCULO EL A�O ACTUAL
		V_ANNO := (TO_CHAR(SYSDATE,'YYYY'));
		
		SELECT MILLONES_DESDE,
			   MILLONES_HASTA
		INTO V_MILLONES_DESDE_RANGO1,
			 V_MILLONES_HASTA_RANGO1
		FROM QUIPUX.RANGO_IMPTO_UNIFICADO
		WHERE ANNO = V_ANNO
		AND TIPO_VEHICULO = 1
		AND PORCENTAJE = 1.5;
		
		SELECT MILLONES_DESDE,
			   MILLONES_HASTA
		INTO V_MILLONES_DESDE_RANGO2,
			 V_MILLONES_HASTA_RANGO2
		FROM QUIPUX.RANGO_IMPTO_UNIFICADO
		WHERE ANNO = V_ANNO
		AND TIPO_VEHICULO = 2
		AND PORCENTAJE = 1.5;
		
		SELECT MILLONES_DESDE,
			   MILLONES_HASTA
		INTO V_MILLONES_DESDE_RANGO3,
			 V_MILLONES_HASTA_RANGO3
		FROM QUIPUX.RANGO_IMPTO_UNIFICADO
		WHERE ANNO = V_ANNO
		AND TIPO_VEHICULO = 2
		AND PORCENTAJE = 2.5;
	  
		SELECT MILLONES_DESDE,
			   MILLONES_HASTA
		INTO V_MILLONES_DESDE_RANGO4,
			 V_MILLONES_HASTA_RANGO4
		FROM QUIPUX.RANGO_IMPTO_UNIFICADO
		WHERE ANNO = V_ANNO
		AND TIPO_VEHICULO = 2
		AND PORCENTAJE = 3.5;
	  
		V_MILLONES_DESDE_RANGO1 := V_MILLONES_DESDE_RANGO1 * 1000000;
		V_MILLONES_DESDE_RANGO1 := ROUND (V_MILLONES_DESDE_RANGO1, 0);
		V_MILLONES_HASTA_RANGO1 := V_MILLONES_HASTA_RANGO1 * 1000000;
		V_MILLONES_HASTA_RANGO1 := ROUND (V_MILLONES_HASTA_RANGO1, 0);
		
		V_MILLONES_DESDE_RANGO2 := V_MILLONES_DESDE_RANGO2 * 1000000;
		V_MILLONES_DESDE_RANGO2 := ROUND (V_MILLONES_DESDE_RANGO2, 0);
		V_MILLONES_HASTA_RANGO2 := V_MILLONES_HASTA_RANGO2 * 1000000;
		V_MILLONES_HASTA_RANGO2 := ROUND (V_MILLONES_HASTA_RANGO2, 0);
		
		V_MILLONES_DESDE_RANGO3 := V_MILLONES_DESDE_RANGO3 * 1000000;
		V_MILLONES_DESDE_RANGO3 := ROUND (V_MILLONES_DESDE_RANGO3, 0);
		V_MILLONES_HASTA_RANGO3 := V_MILLONES_HASTA_RANGO3 * 1000000;
		V_MILLONES_HASTA_RANGO3 := ROUND (V_MILLONES_HASTA_RANGO3, 0);
		
		V_MILLONES_DESDE_RANGO4 := V_MILLONES_DESDE_RANGO4 * 1000000;
		V_MILLONES_DESDE_RANGO4 := ROUND (V_MILLONES_DESDE_RANGO4, 0);
		V_MILLONES_HASTA_RANGO4 := V_MILLONES_HASTA_RANGO4 * 1000000;
		V_MILLONES_HASTA_RANGO4 := ROUND (V_MILLONES_HASTA_RANGO4, 0);
		
		V_MODELO := V_ANNO;
		V_MODELO_SIGUIENTE := V_MODELO + 1;
		
		-- ARREGLAR LA TARIFA SEGUN EL AVALUO
		BEGIN
		
			-- TARIFA 1.5
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET TARIFA = '1.5'
			WHERE NRO_PLACA IN
				  (SELECT NRO_PLACA
				  FROM CORRECCION_DATOS.PLANTILLA_OC
				  WHERE AVALUO IS NOT NULL
				  AND TARIFA IS NULL
				  AND CLASE IN ('10', '14', '17', '19')
				  AND TO_NUMBER(AVALUO) <= TO_NUMBER(V_MILLONES_HASTA_RANGO1));
      
      -- TARIFA 1.5
      UPDATE CORRECCION_DATOS.PLANTILLA_OC
      SET TARIFA = '1.5'
      WHERE NRO_PLACA IN
          (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE AVALUO IS NOT NULL
          AND TARIFA IS NULL
          AND CLASE NOT IN('10', '14', '17', '19')
          AND TO_NUMBER(AVALUO) <= TO_NUMBER(V_MILLONES_HASTA_RANGO2));
      
      -- TARIFA 2.5
      UPDATE CORRECCION_DATOS.PLANTILLA_OC
      SET TARIFA = '2.5'
      WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE AVALUO IS NOT NULL
        AND TARIFA IS NULL
        AND TO_NUMBER(AVALUO) > TO_NUMBER(V_MILLONES_DESDE_RANGO3)
        AND TO_NUMBER(AVALUO) <= TO_NUMBER(V_MILLONES_HASTA_RANGO3));
      
      -- TARIFA 3.5
      UPDATE CORRECCION_DATOS.PLANTILLA_OC
      SET TARIFA = '3.5'
      WHERE NRO_PLACA IN
          (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE AVALUO IS NOT NULL
          AND TARIFA IS NULL
          AND TO_NUMBER(AVALUO) > TO_NUMBER(V_MILLONES_DESDE_RANGO4));
                
    EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
    END;  
			
    COMMIT;
		
	END SP_TARIFA;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR EL AVALUO DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: AVALUO)
	PROCEDURE SP_AVALUO( NRO_PLACA VARCHAR2, VALOR_FACTURA VARCHAR2, TIPO_ARCHIVO VARCHAR2) AS

	  V_PLACA   VARCHAR2(10);
	  V_AVALUO  VARCHAR2(15);
    V_TIPO_ARCHIVO VARCHAR2(1);
    
	BEGIN
    
    -- ASIGNO EL NUMERO DE PLACA
    V_PLACA := NRO_PLACA;
    
    --LA PONGO EN MAYUSCULA
    V_PLACA := UPPER(V_PLACA);
    
    V_AVALUO:= VALOR_FACTURA;
    
    V_TIPO_ARCHIVO:= TIPO_ARCHIVO;
    
    IF ((V_AVALUO IS NULL) OR (V_AVALUO = '') OR (V_AVALUO = '0')) THEN
        
      IF V_TIPO_ARCHIVO = 'M' THEN
        V_AVALUO := '1';
      ELSIF V_TIPO_ARCHIVO = 'N' THEN
        V_AVALUO := '';
      END IF;
      
    END IF;
    
		SP_TARIFA (NRO_PLACA, V_AVALUO);
		
		BEGIN
      
      UPDATE CORRECCION_DATOS.PLANTILLA_OC
      SET AVALUO = V_AVALUO,
          VLR_FACTURA_VEHICULO = V_AVALUO
      WHERE OBJETO_CONTRATO  = V_PLACA;
      COMMIT;
      
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
		
	END SP_AVALUO;

	-- FUNCION QUE SE ENCARGA DE ACTUALIZAR EL TIPO_DE_CARGA DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: TIPO_DE_CARGA)
	FUNCTION FT_TIPO_DE_CARGA( CAP_PASAJEROS VARCHAR2, CAP_TONELADAS VARCHAR2 ) RETURN VARCHAR2 AS

	  V_CAP_PASAJEROS VARCHAR2(10);
	  V_CAP_TONELADAS VARCHAR2(10);
	  V_TIPO_DE_CARGA VARCHAR2(1);
	  
	BEGIN

		V_CAP_PASAJEROS := CAP_PASAJEROS;
		V_CAP_TONELADAS := CAP_TONELADAS;
		
		IF V_CAP_TONELADAS = '0' THEN
			V_CAP_TONELADAS := '';
		END IF;

		IF V_CAP_PASAJEROS = '0' THEN
			V_CAP_PASAJEROS := '';
		END IF;
		  
		-- SE VALIDA SI LA CAPACIDAD DE CARGA ES 0 SE ENVIA UN NULL
		IF ((V_CAP_TONELADAS) IS NOT NULL ) AND ((V_CAP_PASAJEROS) IS NULL) THEN
			V_TIPO_DE_CARGA := 'C';
		ELSIF ((V_CAP_TONELADAS) IS NOT NULL) AND ((V_CAP_PASAJEROS)IS NOT NULL) THEN
			V_TIPO_DE_CARGA := 'C';
		END IF;
		
    IF ((V_CAP_TONELADAS) IS NULL ) AND ((V_CAP_PASAJEROS) IS NULL) THEN
      V_TIPO_DE_CARGA := 'P';
		ELSIF ((V_CAP_PASAJEROS) IS NOT NULL ) AND ((V_CAP_TONELADAS) IS NULL) THEN
			V_TIPO_DE_CARGA := 'P';
		ELSIF ((V_CAP_TONELADAS) IS NOT NULL) AND (V_CAP_PASAJEROS = '0') THEN
			V_TIPO_DE_CARGA :='P';
		END IF;
		
		RETURN V_TIPO_DE_CARGA;
		
	END FT_TIPO_DE_CARGA;

	-- PROCEDIMIENTO QUE SE ENCARGA DE ACTUALIZAR LA UNIDAD DE TRANSITP Y EL DEPTO MATRICULA DE ACUERDO A LA PLACA DEL VEHICULO EN LA PLANTILLA DE SAP (CAMPO: UNIDAD_TRANSITO, DEPTO_MATRICULA)
	PROCEDURE SP_UNIDAD_TRANSITO( NRO_PLACA  VARCHAR2, SECRETARIA VARCHAR2) AS

	  V_PLACA           VARCHAR2(8);
	  V_UNIDAD_TRANSITO VARCHAR2(10);
	  V_DEPTO_MATRICULA VARCHAR2(10);
	  
	BEGIN

		BEGIN
		
			-- ASIGNO EL NUMERO DE PLACA
			V_PLACA := NRO_PLACA;
			
			--LA PONGO EN MAYUSCULA
			V_PLACA := UPPER(V_PLACA);
			
			V_UNIDAD_TRANSITO := SECRETARIA;
			
			SELECT DISTINCT(SS.ID_SECRETARIA_SAP),
				   SD.ID_DEPARTAMENTO_SAP
			INTO V_UNIDAD_TRANSITO,
				 V_DEPTO_MATRICULA
			FROM QUIPUX.SECRETARIAS_TTO STT
			INNER JOIN DEPURACION.SAP_SECRETARIA SS
				ON STT.ID_SECRETARIA = SS.ID_SECRETARIA_QX
			INNER JOIN DEPURACION.SAP_DEPARTAMENTOS SD
				ON SS.ID_SECRETARIA_SAP = SD.ID_CIUDAD_SAP
			WHERE STT.RUNT_SECRETARIA = V_UNIDAD_TRANSITO;
			
		EXCEPTION
		WHEN OTHERS THEN
			V_UNIDAD_TRANSITO := '0';
		END;
		
		IF V_UNIDAD_TRANSITO = '0' THEN
			V_UNIDAD_TRANSITO := '';
			V_DEPTO_MATRICULA := '';
		END IF;
		
		BEGIN
		
			UPDATE CORRECCION_DATOS.PLANTILLA_OC
			SET UNIDAD_TRANSITO = V_UNIDAD_TRANSITO,
				DEPTO_MATRICULA = V_DEPTO_MATRICULA
			WHERE OBJETO_CONTRATO = V_PLACA;
			COMMIT;
      
		EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
		END;
		
	END SP_UNIDAD_TRANSITO;
  
  PROCEDURE SP_VALIDACIONES_PLANTILLA AS
  
  BEGIN
    
    -- BORRO LOS ERRORES DE LA PLANTILLA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = NULL
    WHERE REGISTRO_ERROR IS NOT NULL;

    -- VALORES NULOS CAMPOS QUE NO DEBEN IR EN LA PLANTILLA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET INTERLOCUTOR_COMERCIAL = NULL
    WHERE INTERLOCUTOR_COMERCIAL IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CTA_CONTRATO = NULL
    WHERE CTA_CONTRATO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET PARAMETRO_PAGO_ACTIVO = NULL
    WHERE PARAMETRO_PAGO_ACTIVO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET DATOS_BANCARIOS_PPIOS = NULL
    WHERE DATOS_BANCARIOS_PPIOS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET RECEPTOR_ALTERNATIVO = NULL
    WHERE RECEPTOR_ALTERNATIVO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET VIA_PAGO_RECIBIDO = NULL
    WHERE VIA_PAGO_RECIBIDO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ID_DATOS_RECIBIDOS = NULL
    WHERE ID_DATOS_RECIBIDOS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ID_TARJETA_PAGO_RECIBIDO = NULL
    WHERE ID_TARJETA_PAGO_RECIBIDO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET RECEPTOR_ALTERNATIVO1 = NULL
    WHERE RECEPTOR_ALTERNATIVO1 IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET VIA_PAGO_EFECTUADO = NULL
    WHERE VIA_PAGO_EFECTUADO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ID_DATOS_EFECTUADOS = NULL
    WHERE ID_DATOS_EFECTUADOS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ID_TARJETA_PAGO_EFECTUADO = NULL
    WHERE ID_TARJETA_PAGO_EFECTUADO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET PARAMETRO_CORRESPONDENCIA = NULL
    WHERE PARAMETRO_CORRESPONDENCIA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET RECEPTOR_ALT_CORRESPONDENCIA = NULL
    WHERE RECEPTOR_ALT_CORRESPONDENCIA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CLAVE_ACTIVIDADES = NULL
    WHERE CLAVE_ACTIVIDADES IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET VARIANTE_CORRESPONDENCIA = NULL
    WHERE VARIANTE_CORRESPONDENCIA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET STATUS_RELATIVO = NULL
    WHERE STATUS_RELATIVO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET DIAS_DESPLAZAMIENTO = NULL
    WHERE DIAS_DESPLAZAMIENTO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET MESES_DESPLAZAMIENTO = NULL
    WHERE MESES_DESPLAZAMIENTO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET PROCEDIMIENTO_RECLAMACION = NULL
    WHERE PROCEDIMIENTO_RECLAMACION IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET PRIMER_PERIODO_VALIDO = NULL
    WHERE PRIMER_PERIODO_VALIDO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ANNO_PRIMER_PERIODO = NULL
    WHERE ANNO_PRIMER_PERIODO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ULTIMO_PERIODO_VALIDO = NULL
    WHERE ULTIMO_PERIODO_VALIDO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET ANNO_ULTIMO_PERIODO_VALIDO = NULL
    WHERE ANNO_ULTIMO_PERIODO_VALIDO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_AUTORIZACION_BLINDAJE = NULL
    WHERE F_AUTORIZACION_BLINDAJE IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_AUTORIZACION_BLINDAJE = NULL
    WHERE NRO_AUTORIZACION_BLINDAJE IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NOMBRE_EMPRESA = NULL
    WHERE NOMBRE_EMPRESA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_MOTOR = NULL
    WHERE NRO_MOTOR IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_CHASIS = NULL
    WHERE NRO_CHASIS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CANTIDAD_SILLAS = NULL
    WHERE CANTIDAD_SILLAS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET COD_TIPO_BUS = NULL
    WHERE COD_TIPO_BUS IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET COD_TIPO_SERVICIO = NULL
    WHERE COD_TIPO_SERVICIO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NIVEL_SERVICIO = NULL
    WHERE NIVEL_SERVICIO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_CAMBIO_SERVICIO = NULL
    WHERE F_CAMBIO_SERVICIO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_RESOLUCION_CAMB_SERVICIO = NULL
    WHERE NRO_RESOLUCION_CAMB_SERVICIO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TRANSITO_ORIGEN = NULL
    WHERE TRANSITO_ORIGEN IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_TRASLADO = NULL
    WHERE F_TRASLADO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TRANSITO_TRASLADO = NULL
    WHERE TRANSITO_TRASLADO IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_CANCELACION_MATRICULA = NULL
    WHERE F_CANCELACION_MATRICULA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_CANCELACION_MATRICULA = NULL
    WHERE NRO_CANCELACION_MATRICULA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET MOTIVO_CANCELACION = NULL
    WHERE MOTIVO_CANCELACION IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_REMATRICULA = NULL
    WHERE F_REMATRICULA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NOMBRE_CIA_ASEGURADORA = NULL
    WHERE NOMBRE_CIA_ASEGURADORA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET NRO_POLIZA = NULL
    WHERE NRO_POLIZA IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_VENCE_SOAT = NULL
    WHERE F_VENCE_SOAT IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_INGRESO_ET = NULL
    WHERE F_INGRESO_ET IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_INGRESO_INTERNACION = NULL
    WHERE F_INGRESO_INTERNACION IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_SALIDA_INTERNACION = NULL
    WHERE F_SALIDA_INTERNACION IS NOT NULL;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET F_SALIDA_INTERNACION = NULL
    WHERE F_SALIDA_INTERNACION IS NOT NULL;
    
    --------------------------------------------------------------------------------
    
    -- VALIDACION CAMPOS NULL QUE SI DEBEN IR EN LA PLANTILLA
    
    -- CLASE_OBJETO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CLASE_OBJETO_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE_OBJETO IS NULL);
    
    -- GRUPO_AUTORIZACIONES
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET GRUPO_AUTORIZACIONES = 'RE02'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE GRUPO_AUTORIZACIONES != 'RE02');
    
    -- OBJETO_CONTRATO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'OBJETO_CONTRATO_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE OBJETO_CONTRATO IS NULL);
    
    -- DENOMINACION_OBJETO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'DENOMINACION_OBJETO_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE DENOMINACION_OBJETO IS NULL);
    
    -- NRO_IDENTIFICACION
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO_IDENTIFICACION_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE NRO_IDENTIFICACION IS NULL
          AND TIPO_ARCHIVO='N');
    
    -- TIPO_CUENTA_CONTRATO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CUENTA_CONTRATO = '02'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE TIPO_CUENTA_CONTRATO != '02');
    
    -- FACTURA_SEPARADA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET FACTURA_SEPARADA = 'X'
    WHERE FACTURA_SEPARADA != 'X';
    
    -- TIPO FACTURA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_FACTURA = '02'
    WHERE TIPO_FACTURA != '02';
    
    -- PERIODICIDAD_CORRESPONDENCIA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET PERIODICIDAD_CORRESPONDENCIA = 'Inmediatamente'
    WHERE PERIODICIDAD_CORRESPONDENCIA != 'Inmediatamente';
    
    -- NRO_PLACA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO_PLACA_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE NRO_PLACA IS NULL);
    
    -- MARCA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'MARCA_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE MARCA IS NULL);
        
    -- LINEA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'LINEA_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE LINEA IS NULL);
    
    -- MARCAS Y LINEAS
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'LINEA NO PERTENECE A MARCA, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE (MARCA <> SUBSTR(LINEA,0,2))
          AND (MARCA <> SUBSTR(LINEA,0,3)) );
    
    -- CILINDRAJE
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CILINDRAJE IS NULL);
    
    -- CILINDRAJES MALOS DIFERENTES A MOTOCICLETAS
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE INFERIOR 599, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CILINDRAJE < 599
        AND CLASE NOT IN ('10','15','16','17') );
      
    -- MOTO, MOTOCICLETA Y MOTOTRICICLO INFERIOR A 125
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE INFERIOR 126, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CILINDRAJE< 126
        AND CLASE IN ('10','15','16'));
    
    -- MODELO 
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'MODELO, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA 
         FROM CORRECCION_DATOS.PLANTILLA_OC 
         WHERE MODELO < 1900);
       
    -- CLASE
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CLASE_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE IS NULL);
    
    -- CARROCERIA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA_NULL, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CARROCERIA IS NULL
        AND CLASE NOT IN ('10','16','17'));
        
    -- TIPO CARROCERIA X CLASE
    -- CLASE VEHICULO 01
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 01, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        where clase = '01'
        and carroceria not in('04','05','06','14', '23','39','46','47','76','77'));
        
    -- CLASE 02
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 02, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '02'
        AND CARROCERIA NOT IN('01','02','16'));
       
    -- CLASE 03
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 03, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE  = '03'
        AND CARROCERIA NOT IN('02','16','17','48'));
        
    -- CLASE 04
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 04, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '04'
        AND CARROCERIA NOT IN('069','02','07','08','09','11','12','13','15','18','19','21','22','26','27','30','31','32','38','40','42','49','57',
                              '60','61','62','63','64','33','73','92','94','119','140','141','231','237','241','276'));
        
     -- CLASE 05
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 05, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '05'
        AND CARROCERIA NOT IN('02','03','06','07','08','09','10','11','12','13','14','16','17','19','20','23','24','25','28','29','34','35','42','50','56','57','58','59','65',
                              '66','72','73','74','75','77','41','94','200','241'));
                              
      -- CLASE 79(CAMIONETAS ESPECIALES)
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 79, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '79'
        AND CARROCERIA NOT IN('41'));                         
        
    -- CLASE 06
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 06, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '06'
        AND CARROCERIA NOT IN('02','03','06','07','08','09','10','13','14','16','20','39','77','95'));
        
    -- CLASE 07
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 07, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '07'
        AND CARROCERIA NOT IN('01','02','16','17','41'));
        
    -- CLASE 08
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 08, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '08'
        AND CARROCERIA NOT IN('13','21'));
        
    -- CLASE 09
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 09, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '09'
        AND CARROCERIA NOT IN('07','08','09','11','12','13','15','19','21','22','26','27','30','31','32','36','38','60','61','62','63','64','72','140',
                              '276'));
        
    -- CLASE 10
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 10, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ('10')
        AND CARROCERIA NOT IN('00','51','52','55','76'));
    
    -- CLASE 11
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 11, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE  = '11'
        AND CARROCERIA NOT IN('70'));
    
    -- CLASE 12
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 12, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '12'
        AND CARROCERIA NOT IN('00'));
        
    -- CLASE 14
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 14, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '14'
        AND CARROCERIA NOT IN('09','27'));
        
    -- CLASE 15
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 15, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '15'
        AND CARROCERIA NOT IN('00','02','03','07','08','10','13','19','37','52','54','55','66','76','241'));
        
    -- CLASE 16
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 16, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '16'
        AND CARROCERIA NOT IN('00','52','53','54','76','55'));
        
    -- CLASE 17
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 17, '
    WHERE NRO_PLACA IN
        (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '17'
        AND CARROCERIA NOT IN ('00'));
        
    -- EL SERVICIO (USO) 
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET SERVICIO = 0 || SERVICIO
    WHERE NRO_PLACA IN
          (SELECT NRO_PLACA 
          FROM CORRECCION_DATOS.PLANTILLA_OC 
          WHERE SERVICIO NOT LIKE'0%');
    
    -- CLASICO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CLASICO = 'X'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASICO IS NOT NULL
          AND CLASICO != 'X');	  
        
    -- TARIFA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'TARIFA_NULL, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE TARIFA IS NULL
          AND TIPO_ARCHIVO ='N');  
    
    -- AVALUO_MODELO_ACTUAL
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'AVALUO_NULL, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE AVALUO IS NULL
        AND TIPO_ARCHIVO ='N');
     
     -- F_FACTURA_VEHICULO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'VLR_FACTURA_VEHICULO_NULL, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE VLR_FACTURA_VEHICULO IS NULL
        AND TIPO_ARCHIVO ='N');  
    
    -- IMPORTADO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET IMPORTADO = 'N'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE IMPORTADO NOT IN ('I', 'N'));
    
    -- NRO_MANIFIESTO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO_MANIFIESTO, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE NRO_MANIFIESTO IS NULL);
    
    -- UNIDAD DE TRANSITO DESCONOCIDAS
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'DEPTOMATRICULA_NULL, '
    WHERE NRO_PLACA IN
          (SELECT NRO_PLACA 
          FROM CORRECCION_DATOS.PLANTILLA_OC 
          WHERE DEPTO_MATRICULA IS NULL);
        
    -- UNIDAD DE TRANSITO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'TRANSITO NO PERTENECE AL DEPARTAMENTO, '
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE LENGTH (UNIDAD_TRANSITO) = 5
          AND DEPTO_MATRICULA <> SUBSTR(UNIDAD_TRANSITO,0,2)
          OR LENGTH (UNIDAD_TRANSITO) = 4
          AND DEPTO_MATRICULA <> SUBSTR('0'||UNIDAD_TRANSITO,0,2));
    
    -- TIPO CARGA POR CLASE
    -- CLASE VEHICULO 01 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '4'
    WHERE NRO_PLACA  IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE = '01'
          AND TIPO_CARGA != 'P'  );
    
    -- CLASE 02 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '32'
    WHERE NRO_PLACA  IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE = '02'
          AND TIPO_CARGA != 'P');
    
    -- CLASE DE VEHICULO 03 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '20'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE = '03'
          AND TIPO_CARGA != 'P');
    
    -- CLASE DE VEHICULO 04 C
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C',
      CAPACIDAD_CARGA = '7' ,
      CAPACIDAD_PSJ = '3'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE = '04'
          AND TIPO_CARGA != 'C');
    
    -- CLASE VEHICULO 04,05,06 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_PSJ = '4' ,
      CAPACIDAD_CARGA = NULL
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE IN ('04','05','06')
          AND CAPACIDAD_CARGA IS NULL
          AND CAPACIDAD_PSJ IS NULL );
      
    -- CLASE DE VEHICULO 06 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '4'
    WHERE NRO_PLACA IN
         (SELECT NRO_PLACA
          FROM CORRECCION_DATOS.PLANTILLA_OC
          WHERE CLASE = '06'
          AND TIPO_CARGA != 'P' );
    
    -- CLASE DE VEHICULO 07 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '10'
    WHERE NRO_PLACA IN
      (SELECT NRO_PLACA
      FROM CORRECCION_DATOS.PLANTILLA_OC
      WHERE CLASE = '07'
      AND TIPO_CARGA != 'P');
      
    -- CLASE DE VEHICULO 08 C
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C',
      CAPACIDAD_CARGA = '12',
      CAPACIDAD_PSJ = NULL
    WHERE NRO_PLACA IN
      (SELECT NRO_PLACA
      FROM CORRECCION_DATOS.PLANTILLA_OC
      WHERE CLASE = '08'
      AND TIPO_CARGA != 'C' );
     
    -- CLASE DE VEHICULO 09 C
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA  = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '2'
    WHERE NRO_PLACA IN
      (SELECT NRO_PLACA
      FROM CORRECCION_DATOS.PLANTILLA_OC
      WHERE CLASE = '09'
      AND TIPO_CARGA != 'P' );
     
    -- CLASE DE VEHICULO 10 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
      CAPACIDAD_CARGA = NULL,
      CAPACIDAD_PSJ = '1'
    WHERE NRO_PLACA IN
      (SELECT NRO_PLACA
      FROM CORRECCION_DATOS.PLANTILLA_OC
      WHERE CLASE = '10'
      AND TIPO_CARGA != 'P');
      
    -- CLASE DE VEHICULO 11
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'MAQ AGRICOLA, '
    WHERE CLASE = '11';
     
    -- CLASE DE VEHICULO 12
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'MAQ INDUSTRIAL, '
    WHERE CLASE = '12';
    
    -- CLASE VEHICULO 15 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
        CAPACIDAD_CARGA = NULL ,
        CAPACIDAD_PSJ = '5'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '15'
        AND TIPO_CARGA != 'P');
      
    -- CLASE VEHICULO 16 P
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
        CAPACIDAD_CARGA = NULL,
        CAPACIDAD_PSJ = '2'
    WHERE NRO_PLACA  IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE = '16'
        AND TIPO_CARGA != 'P');
      
    -- TIPO CARGA VALIDAR TIPO CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C',
        CAPACIDAD_CARGA = '12'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ('08')
        AND TIPO_CARGA != 'C');
    
    -- TIPO PASAJERO VALIDAR TIPO CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P',
        CAPACIDAD_CARGA = NULL
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN('01','02','03','07','10','15','16')
        AND TIPO_CARGA != 'P');
      
    -- CAPACIDAD DE PASAJERO NULL � 0
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CAPACIDAD_PSJ = '2' ,
        TIPO_CARGA = 'P',
        CAPACIDAD_CARGA = NULL
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN('01','02','03','07','10','15','16')
        AND (CAPACIDAD_PSJ IS NULL
        OR CAPACIDAD_PSJ <= 0));
     
    -- CAPACIDAD DE CARGA NULL � 0 REVISAR
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C' ,
        CAPACIDAD_CARGA = '12'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ('08')
        AND CAPACIDAD_CARGA IS NULL);
      
    -- TIPO CARGA VERIFICACION  CAPACIDAD_CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C' ,
        CAPACIDAD_CARGA = '1'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE TIPO_CARGA = 'C'
        AND CAPACIDAD_CARGA IS NULL );
    
    -- TIPO PASAJERO VERIFICACION CAPACIDAD_PSJ
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'P' ,
        CAPACIDAD_PSJ = '2'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE TIPO_CARGA = 'P'
        AND CAPACIDAD_PSJ IS NULL);
    
    -- VALIDAR CAMPOS EN TIPO_CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'TIPO CARGA DIFERENTE DE P � C, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE (TIPO_CARGA NOT IN ('P','C')
        OR TIPO_CARGA IS NULL)
        AND CLASE NOT IN ('00','11','12'));
    
    -- CAPACIDAD DE PASAJERO SIN CAPACIDAD DE CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET CAPACIDAD_CARGA = NULL
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN('01','02','03','07','10','15','16')
        AND TIPO_CARGA = 'P'
        AND CAPACIDAD_CARGA IS NOT NULL);
    
    -- CLASE DE VEHICULO DE CARGA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET TIPO_CARGA = 'C' ,
        CAPACIDAD_PSJ = NULL ,
        CAPACIDAD_CARGA = '12'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE TIPO_CARGA IS NULL
        AND CLASE IN ('08'));
    
    -- CAPACIDAD DE CARGA, CAPACIDAD DE PASAJERO NULL
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'CAPACIDAD NULL, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CAPACIDAD_CARGA IS NULL
        AND CAPACIDAD_PSJ IS NULL);
    
    -- VALIDACIONES POR CLASE
    -- PASAJEROS
    -- CLASE 01, 05, 06 -- AUTOMOVIL, CAMIONETA, CAMPERO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 01 � 05 � 06 '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ( '01' , '05', '06' )
        AND TIPO_CARGA = 'P'
        AND ( MODELO  IS NULL
        OR MARCA IS NULL
        OR LINEA IS NULL
        OR SERVICIO IS NULL
        OR CILINDRAJE IS NULL ));
    
    -- CLASE 02, 03, 07 -- BUS, BUSETA, MICROBUS
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 02 � 03 � 07, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ( '02' , '03', '07' )
        AND TIPO_CARGA    = 'P'
        AND (MODELO IS NULL
        OR MARCA IS NULL
        OR LINEA IS NULL
        OR SERVICIO IS NULL
        OR CAPACIDAD_PSJ IS NULL));
    
    -- CARGA
    -- CLASE 04, 05, 08, 09, 14 -- CAMION, CAMIONETA, VOLQUETA, TRACTO-CAMION, GRUA
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 04 � 05 � 08 � 09 � 14, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ( '04' , '05', '08', '09', '14' )
        AND TIPO_CARGA = 'C'
        AND (MODELO IS NULL
        OR MARCA IS NULL
        OR LINEA IS NULL
        OR SERVICIO IS NULL
        OR CAPACIDAD_CARGA IS NULL));
      
    -- MOTOCARRO
    -- CLASE 10, 15, 16 -- MOTOCICLETA, MOTOCARRO, CUATRIMOTO
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 10 � 15 � 16, '
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
        WHERE CLASE IN ('10','15','16')
        AND ( MODELO IS NULL
        OR MARCA IS NULL
        OR LINEA IS NULL
        OR SERVICIO IS NULL
        OR CILINDRAJE IS NULL));
    
    -- MARCAR LOS QUE SE ENTREGARON
    UPDATE CORRECCION_DATOS.PLANTILLA_OC
    SET REGISTRO_ERROR = 'ENTREGAR'
    WHERE NRO_PLACA IN
       (SELECT NRO_PLACA
        FROM CORRECCION_DATOS.PLANTILLA_OC
       /* WHERE AVALUO IS NOT NULL
        AND TARIFA IS NOT NULL AND */
         WHERE REGISTRO_ERROR IS NULL);
 
    COMMIT;
    
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
  END SP_VALIDACIONES_PLANTILLA;

END PKG_PLANTILLA_OC;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_PROPIETARIOS" AS

/*
***SUMMARY***
		Nombre: Asociar propietario a vehiculo.
		Descripci�n: Este Cursor permite registrar el propietario de aquellos veh�culos que tienen 
				     tramites de traspaso y que no tienen un propietario asociado
		Autor: Elvis Alexis Betancur L�pez
		Fecha: 08/09/2016
*/
PROCEDURE PS_ACTUALIZAR_DE_TRASPASO AS

V_COMPRADOR VARCHAR2(20);
V_PORCENTAJE NUMBER;
V_FECHA_MAX DATE;
V_CANTIDAD NUMBER;

CURSOR PLACA IS
       SELECT NRO_PLACA FROM QUIPUX.LIC_TTO LT 
       WHERE LT.NRO_PLACA NOT IN (SELECT NRO_PLACA FROM QUIPUX.PROPIETARIOS_VEHICULO PV
                                  WHERE PV.NRO_PLACA = LT.NRO_PLACA)
         AND LT.NRO_PLACA IN (SELECT NRO_PLACA FROM QUIPUX.HISTORIALES_TRASPASOS PV
                                  WHERE PV.NRO_PLACA = LT.NRO_PLACA);
           --AND LT.NRO_PLACA IN ('MNZ296','MNZ314','MNZ854');
 --                          70903638  80088339  8164316
CURSOR HISTORIAL (V_NRO_PLACA VARCHAR2, V_FECHA DATE)IS
        SELECT ID_COMPRADOR, SUM(PORCENTAJE) AS PORCENTAJE
        FROM QUIPUX.HISTORIALES_TRASPASOS 
        WHERE NRO_PLACA = V_NRO_PLACA AND FECHA = V_FECHA GROUP BY ID_COMPRADOR;                                
 
BEGIN

FOR X IN PLACA LOOP
 --Consulto el ultimo traspaso
 SELECT MAX(FECHA) INTO V_FECHA_MAX FROM QUIPUX.HISTORIALES_TRASPASOS WHERE NRO_PLACA = X.NRO_PLACA;
 --valido cuantos propietarios tiene para la fecha
 SELECT COUNT(DISTINCT(ID_COMPRADOR)) INTO V_CANTIDAD FROM QUIPUX.HISTORIALES_TRASPASOS WHERE NRO_PLACA = X.NRO_PLACA AND FECHA = V_FECHA_MAX;
 
 IF V_CANTIDAD = 1 THEN
 
   SELECT ID_COMPRADOR, SUM(PORCENTAJE) INTO V_COMPRADOR, V_PORCENTAJE
   FROM QUIPUX.HISTORIALES_TRASPASOS 
   WHERE NRO_PLACA = X.NRO_PLACA AND FECHA = V_FECHA_MAX GROUP BY ID_COMPRADOR;
   
   INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) VALUES(X.NRO_PLACA, V_COMPRADOR, V_PORCENTAJE);
   
 ELSE
 
    FOR Y IN HISTORIAL (X.NRO_PLACA, V_FECHA_MAX) LOOP    
   
      INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) 
           VALUES(X.NRO_PLACA, Y.ID_COMPRADOR, Y.PORCENTAJE);
           
    END LOOP;
    
 END IF; 

END LOOP;
COMMIT;

END PS_ACTUALIZAR_DE_TRASPASO;


PROCEDURE PS_ACTUALIZAR_DE_DSTRAMITE AS

V_USUARIO VARCHAR2(20);
V_DOCUMENTO VARCHAR2(4);
V_PORCENTAJE NUMBER;
V_FECHA_MAX DATE;
V_CANTIDAD NUMBER;
V_RADICADO NUMBER:=0;
V_TRAMITE NUMBER:=0;

CURSOR PLACA IS
       SELECT LT.NRO_PLACA FROM QUIPUX.LIC_TTO LT 
       WHERE LT.NRO_PLACA NOT IN (SELECT PV.NRO_PLACA FROM QUIPUX.PROPIETARIOS_VEHICULO PV
                                  WHERE PV.NRO_PLACA = LT.NRO_PLACA)
         AND LT.NRO_PLACA IN (SELECT DISTINCT dv.NRO_PLACA FROM DEPURACION.DS_VEHICULO dv
                                  WHERE dv.NRO_PLACA = LT.NRO_PLACA);

BEGIN

FOR X IN PLACA LOOP

 --Consulto el ultimo radicado de la placa
 SELECT MAX(PR.ID_RADICADO) INTO V_RADICADO 
 FROM DEPURACION.DS_PROPIETARIO PR
 INNER JOIN DEPURACION.DS_MAESTRO MA ON MA.ID_RADICADO = PR.ID_RADICADO
 WHERE MA.TIPO_REGISTRO = 'N' AND NRO_PLACA = X.NRO_PLACA;
   
 --Valido si tiene tr�mites de traspaso
 SELECT COUNT(1) INTO V_CANTIDAD
 FROM DEPURACION.DS_TRAMITE 
 WHERE ID_TRAMITE IN (16,65) AND NRO_PLACA = X.NRO_PLACA 
   AND ID_RADICADO = V_RADICADO;

IF V_CANTIDAD = 0 THEN 
    --valido cuantos propietarios tiene
    SELECT COUNT(1) INTO V_CANTIDAD 
    FROM DEPURACION.DS_PROPIETARIO 
    WHERE NRO_PLACA = X.NRO_PLACA AND ID_RADICADO = V_RADICADO;  

    IF V_CANTIDAD = 1 THEN
      
        SELECT ID_USUARIO INTO V_USUARIO
        FROM DEPURACION.DS_PROPIETARIO
        WHERE NRO_PLACA = X.NRO_PLACA AND ID_RADICADO = V_RADICADO;  
        
        INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) 
             VALUES(X.NRO_PLACA, V_USUARIO, 100);     
    
    END IF; 

ELSIF V_CANTIDAD = 1 THEN
    
    SELECT ID_TRAMITE, ID_USUARIO_NUEVO, ID_DOCUMENTO_NUEVO INTO V_TRAMITE, V_USUARIO, V_DOCUMENTO
    FROM DEPURACION.DS_TRAMITE 
    WHERE ID_TRAMITE IN (16,65) AND NRO_PLACA = X.NRO_PLACA 
    AND ID_RADICADO = V_RADICADO;
    
    IF V_TRAMITE = 65 THEN
         INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) 
             VALUES(X.NRO_PLACA, 5134, 100);
             
    ELSE
         --Si es nit agrego el digito de verificaci�n
        IF V_DOCUMENTO = '2' AND (LENGTH(V_USUARIO) = 9) THEN            
                V_USUARIO := V_USUARIO || PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_USUARIO);      
        END IF;
        
        INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO (NRO_PLACA, ID_USUARIO, PORCENTAJE_PROP) 
             VALUES(X.NRO_PLACA, V_USUARIO, 100);    
    END IF;

END IF;    

END LOOP;
COMMIT;

END PS_ACTUALIZAR_DE_DSTRAMITE;








END PKG_PROPIETARIOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PROPIETARIO_X_VIGENCIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_PROPIETARIO_X_VIGENCIA" AS

PROCEDURE DETERMINAR_PROPIETARIO AS
V_NRO_PLACA VARCHAR2(6);
V_EXISTE NUMBER := 0;
V_PROPIETARIO VARCHAR2(15);
V_TIPO_DOC VARCHAR (4);
V_CONTADOR NUMBER := 0;
V_PORCENTAJE NUMBER:=0;
V_MIN_FECHA DATE;
V_MAX_FECHA DATE;
V_VIGENCIA NUMBER;

CURSOR PLACAS IS
SELECT DISTINCT NRO_PLACA, VIGENCIA FROM DQ_PROPIETARIO_X_VIGENCIA WHERE PROPIETARIO IS NULL;

BEGIN

FOR X IN PLACAS LOOP

  V_NRO_PLACA := X.NRO_PLACA;
  V_VIGENCIA := X.VIGENCIA;
  --V_CONTADOR := V_CONTADOR +1;
  
  IF V_VIGENCIA = 2014 THEN    
    -- 1. validar si tiene traspaso en 2014.
    SELECT COUNT(1) INTO V_EXISTE
    FROM TRAMITES_RUNT_TOTAL
    WHERE NRO_PLACA = V_NRO_PLACA
      AND ID_TRAMITE IN (16,65);--Traspaso y traspaso indeterminado
    
    --Si no tiene tramite ingreso el reportado en propietarios
    IF V_EXISTE = 0 THEN
       SP_PROPIETARIO_2014(V_NRO_PLACA, 2014);     
    
     ELSE --Si tiene tramites de traspaso traigo el primer vendedor
      --Obtengo la fecha menor
      SELECT MIN(TO_DATE(FECHA_TRAMITE)) INTO V_MIN_FECHA
      FROM TRAMITES_RUNT_TOTAL 
      WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE IN (16,65);
      --AND FECHA_TRAMITE LIKE '%2014';     
      
      SP_VENDEDOR_2014(V_NRO_PLACA,V_MIN_FECHA, V_VIGENCIA,'');
       
    END IF;    
    
  ELSIF V_VIGENCIA = 2015 THEN
  
--1. VALIDO SI REALIZO TRAMITE DE TRASPASO EN 2014
    SELECT COUNT(1) INTO V_EXISTE
    FROM TRAMITES_RUNT_TOTAL RT
    WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE IN (16,65)
      AND FECHA_TRAMITE LIKE '%2014';
    
    --Si tiene tramite valido cual es el ultimo propietario
    IF V_EXISTE > 0 THEN
    
      --Obtengo la fecha mayor
      SELECT MAX(TO_DATE(FECHA_TRAMITE)) INTO V_MAX_FECHA
      FROM TRAMITES_RUNT_TOTAL 
      WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE IN (16,65)
      AND FECHA_TRAMITE LIKE '%2014';
      
      SP_VENDEDOR_2014(V_NRO_PLACA,V_MAX_FECHA, V_VIGENCIA,'MAX');     
    
--2.VALIDO SI TIENE OTRO TRAMITE DIFERENTE    
    ELSE
    
     SELECT COUNT(1) INTO V_EXISTE
     FROM TRAMITES_RUNT_TOTAL RT
     WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE NOT IN (16,65)
       AND FECHA_TRAMITE LIKE '%2014';
     
      --Si tiene tramite ingreso el propietario
      IF V_EXISTE > 0 THEN     
          SP_PROPIETARIO_2014(V_NRO_PLACA, V_VIGENCIA);          
                      
--3.VALIDO SI FUE REPORTADO ENTRE ENERO Y MARZO DE 2015         
      ELSE
          --Valido si tiene tramite de traspaso
          SELECT COUNT(1) INTO V_EXISTE FROM TRAMITES_RUNT_TOTAL RT
          WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE IN (16,65)
            AND TO_DATE(FECHA_TRAMITE) BETWEEN '01/01/2015' AND '31/03/2015';
         
          --Si tiene tramite traspaso para esa fecha
          IF V_EXISTE > 0 THEN             
          
            SELECT MIN(TO_DATE(FECHA_TRAMITE)) INTO V_MIN_FECHA FROM TRAMITES_RUNT_TOTAL 
            WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE IN (16,65)
            AND TO_DATE(FECHA_TRAMITE) BETWEEN '01/01/2015' AND '31/03/2015'; 
            
             SP_VENDEDOR_2014(V_NRO_PLACA,V_MIN_FECHA, V_VIGENCIA,'');
             
          ELSE--Valido si otro tramite diferente  
          
            SELECT COUNT(1) INTO V_EXISTE FROM TRAMITES_RUNT_TOTAL RT
            WHERE NRO_PLACA = V_NRO_PLACA AND ID_TRAMITE NOT IN (16,65)
            AND TO_DATE(FECHA_TRAMITE) BETWEEN '01/01/2015' AND '31/03/2015';
            
            IF V_EXISTE > 0 THEN
               SP_PROPIETARIO_2014(V_NRO_PLACA, V_VIGENCIA);  /******************/
               
--4. VALIDAMOS EN HISTORIALES TRASPASO
           ELSE
           
             SELECT COUNT(1) INTO V_EXISTE
             FROM QUIPUX.HISTORIALES_TRASPASOS WHERE NRO_PLACA = V_NRO_PLACA;
             
             IF V_EXISTE > 1 THEN
             --Sacamos el de menor fecha de traspaso.
             SELECT MIN(FECHA) INTO V_MIN_FECHA
             FROM QUIPUX.HISTORIALES_TRASPASOS
             WHERE NRO_PLACA = V_NRO_PLACA AND FECHA BETWEEN '01/04/2015' AND '31/12/2015';
             
             SP_VENDEDOR_HT(V_NRO_PLACA, V_MIN_FECHA,V_VIGENCIA);
             ELSE
                SP_PROPIETARIO_VEHICULO(V_NRO_PLACA, V_VIGENCIA);                
             END IF;
            
            END IF;
          END IF;
     
     END IF;
     
    END IF;
 
  END IF;
  
  UPDATE TMP_SECUENCIA
  SET SECUENCIA = SECUENCIA +1;
  
  IF V_CONTADOR = 200 THEN
    V_CONTADOR := 0;
    COMMIT;
  ELSE
    V_CONTADOR := V_CONTADOR +1;
  END IF;  
  
END LOOP;
commit;

END DETERMINAR_PROPIETARIO;


--DETERMINA EL PRIMER O ULTIMO VENDEDOR DE 2014 SOLO SI TIENE TRAMITE DE TRASPASO
PROCEDURE SP_VENDEDOR_2014(V_NRO_PLACA VARCHAR2, V_FECHA VARCHAR2, V_VIGENCIA NUMBER, PARAMETRO VARCHAR2) AS

V_PROPIETARIO VARCHAR2(15);
V_TIPO_DOC VARCHAR (4);
V_CONTADOR NUMBER := 0;
V_PORCENTAJE NUMBER:=0; 

CURSOR TRAMITES (PLACA VARCHAR2, FECHA DATE) IS
SELECT DISTINCT(ID_USUARIO_ANTERIOR),ID_DOCUMENTO_ANTERIOR, FECHA_TRAMITE,PORCENTAJE_PROP, NRO_PLACA FROM TRAMITES_RUNT_TOTAL 
WHERE NRO_PLACA = PLACA AND FECHA_TRAMITE = FECHA AND ID_TRAMITE IN (16,65) 
  AND ID_USUARIO_ANTERIOR || ID_DOCUMENTO_ANTERIOR NOT IN (SELECT ID_USUARIO_NUEVO || ID_DOCUMENTO_NUEVO
                                                           FROM TRAMITES_RUNT_TOTAL
                                                           WHERE NRO_PLACA = PLACA AND FECHA_TRAMITE = FECHA AND ID_TRAMITE IN (16,65));

CURSOR TRAMITESII (PLACA VARCHAR2, FECHA DATE) IS
SELECT DISTINCT(ID_USUARIO_NUEVO),ID_DOCUMENTO_NUEVO, FECHA_TRAMITE,PORCENTAJE_PROP, NRO_PLACA FROM TRAMITES_RUNT_TOTAL 
WHERE NRO_PLACA = PLACA AND FECHA_TRAMITE = FECHA AND ID_TRAMITE IN (16,65)
  AND ID_USUARIO_NUEVO || ID_DOCUMENTO_NUEVO NOT IN (SELECT ID_USUARIO_ANTERIOR || ID_DOCUMENTO_ANTERIOR
                                                           FROM TRAMITES_RUNT_TOTAL
                                                           WHERE NRO_PLACA = PLACA AND FECHA_TRAMITE = FECHA AND ID_TRAMITE IN (16,65));

BEGIN
   
  IF PARAMETRO = 'MAX' THEN
  
   FOR Z IN TRAMITESII (V_NRO_PLACA, V_FECHA) LOOP              
     
      V_PROPIETARIO := Z.ID_USUARIO_NUEVO;
      V_TIPO_DOC := Z.ID_DOCUMENTO_NUEVO;
      V_PORCENTAJE := Z.PORCENTAJE_PROP;
   
    IF V_CONTADOR = 0 THEN
       UPDATE DQ_PROPIETARIO_X_VIGENCIA 
          SET TIPO_DOC = V_TIPO_DOC, PROPIETARIO = V_PROPIETARIO,
          PORCENTAJE = V_PORCENTAJE, FUENTE = 'Tramite Runt 2014'
        WHERE NRO_PLACA = V_NRO_PLACA AND VIGENCIA = V_VIGENCIA;   
        V_CONTADOR :=1;
    ELSE
        INSERT INTO DQ_PROPIETARIO_X_VIGENCIA (NRO_PLACA, PROPIETARIO,TIPO_DOC, PORCENTAJE, VIGENCIA, FUENTE)
             VALUES (V_NRO_PLACA, V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE, V_VIGENCIA, 'Tramite Runt 2014');            
    END IF;                 
                  
  END LOOP;
  
 ELSE
 
  FOR Z IN TRAMITES (V_NRO_PLACA, V_FECHA) LOOP              
     
      V_PROPIETARIO := Z.ID_USUARIO_ANTERIOR;
      V_TIPO_DOC := Z.ID_DOCUMENTO_ANTERIOR;
      V_PORCENTAJE := Z.PORCENTAJE_PROP;
   
    IF V_CONTADOR = 0 THEN
       UPDATE DQ_PROPIETARIO_X_VIGENCIA 
          SET TIPO_DOC = V_TIPO_DOC, PROPIETARIO = V_PROPIETARIO,
          PORCENTAJE = V_PORCENTAJE, FUENTE = 'Tramite Runt 2014'
        WHERE NRO_PLACA = V_NRO_PLACA AND VIGENCIA = V_VIGENCIA;   
        V_CONTADOR :=1;
    ELSE
        INSERT INTO DQ_PROPIETARIO_X_VIGENCIA (NRO_PLACA, PROPIETARIO,TIPO_DOC, PORCENTAJE, VIGENCIA, FUENTE)
             VALUES (V_NRO_PLACA, V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE, V_VIGENCIA, 'Tramite Runt 2014');            
    END IF;                 
                  
  END LOOP; 
 
 END IF; 
 
  V_CONTADOR := 0;

END SP_VENDEDOR_2014;


--DETERMINA EL PRIMER O ULTIMO VENDEDOR DE HISTORIALES TRASPASO
PROCEDURE SP_VENDEDOR_HT(V_NRO_PLACA VARCHAR2, V_FECHA VARCHAR2, V_VIGENCIA NUMBER) AS

V_PROPIETARIO VARCHAR2(15);
V_TIPO_DOC VARCHAR (4);
V_CONTADOR NUMBER := 0;
V_PORCENTAJE NUMBER:=0; 

CURSOR TRAMITES (PLACA VARCHAR2, FECHA DATE) IS
SELECT DISTINCT(HT.ID_USUARIO),TD.ABREV_DOCUMENTO,PORCENTAJE
FROM QUIPUX.HISTORIALES_TRASPASOS HT
INNER JOIN QUIPUX.USUARIOS_TTO UT ON UT.ID_USUARIO = HT.ID_USUARIO
INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
WHERE HT.NRO_PLACA = PLACA AND HT.FECHA = FECHA;

BEGIN
         
  FOR Z IN TRAMITES (V_NRO_PLACA, V_FECHA) LOOP                
      
      V_PROPIETARIO := Z.ID_USUARIO;
      V_TIPO_DOC := Z.ABREV_DOCUMENTO;
      V_PORCENTAJE := Z.PORCENTAJE;
      
    IF V_CONTADOR = 0 THEN
       UPDATE DQ_PROPIETARIO_X_VIGENCIA 
          SET TIPO_DOC = V_TIPO_DOC, PROPIETARIO = V_PROPIETARIO,
          PORCENTAJE = V_PORCENTAJE, FUENTE = 'Historiales traspaso'
        WHERE NRO_PLACA = V_NRO_PLACA AND VIGENCIA = V_VIGENCIA;    
        V_CONTADOR :=1;
    ELSE
        INSERT INTO DQ_PROPIETARIO_X_VIGENCIA (NRO_PLACA, PROPIETARIO,TIPO_DOC, PORCENTAJE, VIGENCIA, FUENTE)
             VALUES (V_NRO_PLACA, V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE, V_VIGENCIA, 'Historiales traspaso');            
    END IF;                 
                  
  END LOOP;
  V_CONTADOR := 0;

END SP_VENDEDOR_HT;


--DETERMINA CUAL ES EL PROPIETARIO PARA LA VIGENCIA 2014
PROCEDURE SP_PROPIETARIO_2014(V_NRO_PLACA VARCHAR2, V_VIGENCIA NUMBER) AS

V_PROPIETARIO VARCHAR2(15);
V_TIPO_DOC VARCHAR (4);
V_CONTADOR NUMBER := 0;
V_PORCENTAJE NUMBER:=0; 

CURSOR PROPIETARIOS (PLACA VARCHAR2) IS
SELECT DISTINCT(ID_USUARIO),ID_DOCUMENTO,PORCENTAJE_PROP, NRO_PLACA   
FROM PROPIETARIOS_RUNT WHERE NRO_PLACA = PLACA/* AND FECHA_ARCHIVO LIKE '2014%'*/ ;

BEGIN

--Si son varios propietarios 
FOR X IN PROPIETARIOS(V_NRO_PLACA) LOOP            

 V_PROPIETARIO := X.ID_USUARIO;
 V_TIPO_DOC := X.ID_DOCUMENTO;
 V_PORCENTAJE := X.PORCENTAJE_PROP;
 
  IF V_CONTADOR = 0 THEN
     UPDATE DQ_PROPIETARIO_X_VIGENCIA 
        SET TIPO_DOC = V_TIPO_DOC, PROPIETARIO = V_PROPIETARIO,
            PORCENTAJE = V_PORCENTAJE, FUENTE = 'Propietarios Runt'
      WHERE NRO_PLACA = V_NRO_PLACA AND VIGENCIA = V_VIGENCIA;    
      V_CONTADOR :=1;
  ELSE
      INSERT INTO DQ_PROPIETARIO_X_VIGENCIA (NRO_PLACA, PROPIETARIO,TIPO_DOC, PORCENTAJE, VIGENCIA, FUENTE)
           VALUES (V_NRO_PLACA, V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE, V_VIGENCIA, 'Propietarios Runt');            
  END IF;          

END LOOP;
V_CONTADOR := 0;

END SP_PROPIETARIO_2014;

--SACA EL PROPIETARIO RELACIONADO EN PROPIETARIOS VEHICULO
PROCEDURE SP_PROPIETARIO_VEHICULO (V_NRO_PLACA VARCHAR2, V_VIGENCIA NUMBER) AS 

V_PROPIETARIO VARCHAR2(15);
V_TIPO_DOC VARCHAR (4);
V_CONTADOR NUMBER := 0;
V_PORCENTAJE NUMBER:=0; 

CURSOR PROPIETARIO_VEHICULO IS
SELECT PV.ID_USUARIO,TD.ABREV_DOCUMENTO, PV.PORCENTAJE_PROP 
  INTO V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE
FROM QUIPUX.PROPIETARIOS_VEHICULO  PV
INNER JOIN QUIPUX.USUARIOS_TTO UT ON UT.ID_USUARIO = PV.ID_USUARIO
INNER JOIN QUIPUX.TIPO_DOCUMENTO TD ON TD.ID_DOCUMENTO = UT.ID_DOCUMENTO
WHERE PV.NRO_PLACA = V_NRO_PLACA;

BEGIN

FOR X IN PROPIETARIO_VEHICULO LOOP
 V_PROPIETARIO := X.ID_USUARIO;
 V_TIPO_DOC := X.ABREV_DOCUMENTO;
 V_PORCENTAJE := X.PORCENTAJE_PROP;
 
  IF V_CONTADOR = 0 THEN
     UPDATE DQ_PROPIETARIO_X_VIGENCIA 
        SET TIPO_DOC = V_TIPO_DOC, PROPIETARIO = V_PROPIETARIO,
            PORCENTAJE = V_PORCENTAJE, FUENTE = 'Propietarios Vehiculo'
      WHERE NRO_PLACA = V_NRO_PLACA AND VIGENCIA = V_VIGENCIA;    
      V_CONTADOR :=1;
  ELSE
      INSERT INTO DQ_PROPIETARIO_X_VIGENCIA (NRO_PLACA, PROPIETARIO,TIPO_DOC, PORCENTAJE, VIGENCIA, FUENTE)
           VALUES (V_NRO_PLACA, V_PROPIETARIO, V_TIPO_DOC, V_PORCENTAJE, V_VIGENCIA, 'Propietarios Vehiculo');            
  END IF;          

END LOOP;
V_CONTADOR := 0;

END SP_PROPIETARIO_VEHICULO;


END PKG_PROPIETARIO_X_VIGENCIA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_QAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_QAS" AS
PROCEDURE QAS_CARACTERISTICAS2 AS

/*Lv_Placa Varchar2(100);
LV_NOMBRE_MARCA Varchar2(100);
LV_NOMBRE_LINEA Varchar2(100);
LV_MODELO Varchar2(10);
LV_NOMBRE_CLASE Varchar2(100);
LV_NOMBRE_SERVICIO Varchar2(100);
LV_NOMBRE_CARROCERIA Varchar2(100);
LV_NRO_PUERTAS Varchar2(100);
LV_CILINDRAJE Varchar2(100);
LV_CAP_PASAJEROS Varchar2(100);
LV_CAP_TONELADAS Varchar2(100);
LV_ID_RADICADO Varchar2(100);
LV_NOMBREtto Varchar2(100);*/
Ln_Contador Number := 0;
Transito Number:=0;

Cursor  consulta_placas Is
Select NRO_PLACA,ROWID From CORRECCION_DATOS.QAS_CARACTERISTICAS;

Begin

For Ln_Index In consulta_placas Loop

Begin

Delete Qas_Caracteristicas
Where Nro_placa = Ln_index.Nro_placa And RowId = Ln_Index.RowId;
        --Retorno el radicado maximo 
        Transito:=SP_ID_RADICADO_MAX(Ln_Index.Nro_Placa);


Insert Into Qas_Caracteristicas (NRO_PLACA,NOMBRE_MARCA,NOMBRE_LINEA,MODELO,NOMBRE_CLASE,NOMBRE_SERVICIO,NOMBRE_CARROCERIA,
NRO_PUERTAS,CILINDRAJE,CAP_PASAJEROS,CAP_TONELADAS,ID_RADICADO,NOMBRETTO )
select St.Nro_placa,St.NOMBRE_MARCA,St.NOMBRE_LINEA,St.MODELO,St.NOMBRE_CLASE,St.NOMBRE_SERVICIO,St.NOMBRE_CARROCERIA,
St.NRO_PUERTAS,St.CILINDRAJE,St.CAP_PASAJEROS,St.CAP_TONELADAS,St.ID_RADICADO,ot.NOMBRE 
from BD_TRANSITOS.ST_VEHICULOS St
Inner join BD_TRANSITOS.ST_MAESTRO M on M.Id_Radicado = St.Id_Radicado
Inner join correccion_datos.runt_organismos_tto Ot on ot.divipo = M.Id_Secretaria
where St.NRO_PLACA =Ln_Index.Nro_Placa And St.Id_Radicado = Transito;

/*Update QAS_CARACTERISTICAS Lt Set 
LT.NOMBRE_MARCA=LV_NOMBRE_MARCA,
LT.NOMBRE_LINEA=LV_NOMBRE_LINEA,
LT.MODELO=LV_MODELO,
LT.NOMBRE_CLASE=LV_NOMBRE_CLASE,
LT.NOMBRE_SERVICIO=LV_NOMBRE_SERVICIO,
LT.NOMBRE_CARROCERIA=LV_NOMBRE_CARROCERIA,
LT.NRO_PUERTAS=LV_NRO_PUERTAS,
LT.CILINDRAJE=LV_CILINDRAJE,
LT.CAP_PASAJEROS=LV_CAP_PASAJEROS,
LT.CAP_TONELADAS=LV_CAP_TONELADAS,
LT.ID_RADICADO=LV_ID_RADICADO,
LT.NOMBRETTO=LV_NOMBRETTO
Where Lt.Nro_Placa = Lv_Placa;*/

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

    Exception
    When Others Then
    Update CORRECCION_DATOS.QAS_CARACTERISTICAS Lt  Set LT.NOMBRE_MARCA = 'NO ESTA EN BD'
    Where LT.Nro_Placa = Ln_Index.Nro_Placa;
    End;
    End Loop;
    END QAS_CARACTERISTICAS2;

FUNCTION SP_ID_RADICADO_MAX (Placa Varchar) Return Number
As
Transito Number:=0;
Begin
Select Max(Id_Radicado) Into Transito From Bd_Transitos.St_Vehiculos
Where Nro_Placa = Placa;

Return Transito;


END SP_ID_RADICADO_MAX;


PROCEDURE QAS_NOVEDADES AS

Ln_Contador Number:=0;

Cursor  consulta_placas Is
Select NRO_PLACA,ROWID From CORRECCION_DATOS.QAS_NOVEDADES;

Begin

For Ln_Index In consulta_placas Loop

Begin

Insert Into Qas_NOVEDADES(NRO_PLACA,ID_TRAMITE,NOMBRE_TRAMITE,FECHA_TRAMITE,TIPO_CANCELACION,ID_SECRETARIA_DESTINO,ID_SECRETARIA_ORIGEN,ID_CARROCERIA_ANTERIOR,
NOMBRE_CARROCERIA_ANTERIOR,ID_CARROCERIA_NUEVA,NOMBRE_CARROCERIA_NUEVA,ID_SERVICIO_ANTERIOR,NOMBRE_SERVICIO_ANTERIOR,ID_SERVICIO_NUEVO,NOMBRE_SERVICIO_NUEVO,	
ID_DOCUMENTO_ANTERIOR,ID_USUARIO_ANTERIOR,ID_DOCUMENTO_NUEVO,ID_USUARIO_NUEVO,PORCENTAJE_PROP,CLASICO_ANTIGUO,BLINDADO,NIVEL_BLINDADO,DESBLINDAJE,CILINDRAJE,	
CAP_PASAJEROS,CAP_TONELADAS,ID_RADICADO)
select NRO_PLACA,ID_TRAMITE,NOMBRE_TRAMITE,FECHA_TRAMITE,TIPO_CANCELACION,ID_SECRETARIA_DESTINO,ID_SECRETARIA_ORIGEN,ID_CARROCERIA_ANTERIOR,
NOMBRE_CARROCERIA_ANTERIOR,ID_CARROCERIA_NUEVA,NOMBRE_CARROCERIA_NUEVA,ID_SERVICIO_ANTERIOR,NOMBRE_SERVICIO_ANTERIOR,ID_SERVICIO_NUEVO,NOMBRE_SERVICIO_NUEVO,	
ID_DOCUMENTO_ANTERIOR,ID_USUARIO_ANTERIOR,ID_DOCUMENTO_NUEVO,ID_USUARIO_NUEVO,PORCENTAJE_PROP,CLASICO_ANTIGUO,BLINDADO,NIVEL_BLINDADO,DESBLINDAJE,CILINDRAJE,	
CAP_PASAJEROS,CAP_TONELADAS,ID_RADICADO from BD_TRANSITOS.st_tramites
where nro_placa IN ('LLJ611') and id_tramite not in (16,65);

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

Exception
When Others Then
Update CORRECCION_DATOS.QAS_NOVEDADES Lt  Set LT.NOMBRE_TRAMITE = 'NO ESTA EN BD'
Where LT.Nro_Placa = Ln_Index.Nro_Placa;
End;
End Loop;
END QAS_NOVEDADES;
END PKG_QAS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACIONES_REGISTRO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDACIONES_REGISTRO" AS

/*  
========================================================================================================================
========================================================================================================================

                              VALIDACIONES DE NEGOCIO PARA CONTRIBUYENTES
  
========================================================================================================================
========================================================================================================================
*/  

/****************************************************************************/
/*ESTA FUNCION VERIFICA SI EL NUMERO DE IDENTIFICACION YA EXISTE EN LA BD.*/
FUNCTION FT_EXISTE_CONTRIBUYENTE(A_ID_USUARIO VARCHAR2, A_NRO_PLACA VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN AS
  V_EXISTE NUMBER := 0;
BEGIN    
  
  SELECT COUNT(1)
  INTO V_EXISTE
  FROM DEPURACION.DS_CONTRIBUYENTE DC
  INNER JOIN DEPURACION.DS_PROPIETARIO DP ON ( DP.ID_DOCUMENTO = DC.ID_DOCUMENTO AND
                                               DP.ID_USUARIO = DC.ID_USUARIO AND 
                                               DP.NRO_PLACA = A_NRO_PLACA)
  WHERE DC.ID_USUARIO = A_ID_USUARIO;
  
  --SI YA EXISTE RETORNO TRUE SINO RETORNO FALSE
  IF V_EXISTE = 0 THEN
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 79,V_ID);
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END FT_EXISTE_CONTRIBUYENTE;

/****************************************************************************/
/*ESTA FUNCION VALIDA QUE EL TIPO DE DOCUMENTO REPORTADO SEA UN TIPO VALIDO.*/
FUNCTION FT_VALIDAR_TIPO_DOCUMENTO(A_ID_DOCUMENTO NUMBER,V_ID VARCHAR2) RETURN BOOLEAN AS
  V_EXISTE NUMBER := 0;
BEGIN
  
  --VALIDO LOS TIPOS DE DOUMENTOS
  IF A_ID_DOCUMENTO NOT IN (1,2,3,4,6) THEN
    --SP_EXCEPCION('EL TIPO DE IDENTIFICAI�N REPORTADO NO ES UN TIPO DE IDENTIFICACION VALIDO.');
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 18,V_ID);
    V_EXISTE := 1;
  END IF;
  
  --VERIFICO SI HAY EXCEPCIONES
  IF V_EXISTE = 1 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END FT_VALIDAR_TIPO_DOCUMENTO;


FUNCTION FT_VALIDAR_APELLIDOS(A_ID_DOCUMENTO NUMBER, A_APELLIDOS VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN AS
  BEGIN
  
  IF ( A_ID_DOCUMENTO <> 2 AND A_APELLIDOS IS NULL ) THEN
      RETURN TRUE;
  ELSE
      RETURN FALSE;
  END IF;
END FT_VALIDAR_APELLIDOS;

/****************************************************************************/
/*ESTA FUNCION REALIZA LAS VALIDACIONES DE LA DIRECCION.*/
FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER, V_ID VARCHAR2 ) RETURN BOOLEAN AS
  V_DIRECCION_TEMPORAL VARCHAR2(100);
  V_DIRECCION VARCHAR2(100);
  V_CONSONANTES VARCHAR2(100);
  V_LONGITUD NUMBER;
  V_TIENE_NUMEROS NUMBER := 0;
  V_TIENE_CARACTERES NUMBER := 0;
  V_POSICION NUMBER;
  V_EXISTE NUMBER := 0;
BEGIN
   
  --LA DIRECCION NO PUEDE TENER UNA LONGITUD MENOR A 7 CARACTERES
  IF LENGTH(A_DIRECCION) <= 7 THEN
    --SP_EXCEPCION('LA DIRECCION DEBE TENER MAS DE 7 CARACTERES.');
    IF OPCIONDIR = 0 THEN
        SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 21,V_ID);
    END IF;
    V_EXISTE := 1;
  END IF;
  
  --VALIDO QUE NO TENGA SOLO NUMEROS Y QUE NO TENGA SOLO LETRAS A NO SER QUE SEA VEREDA
  V_DIRECCION_TEMPORAL := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ELIMINAR_ESPACIOS(A_DIRECCION);
  V_LONGITUD := LENGTH(V_DIRECCION_TEMPORAL);
  V_TIENE_CARACTERES := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^0-9]',''));
  V_TIENE_NUMEROS    := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]',''));

  --SOLO NUMEROS
  IF V_TIENE_CARACTERES = 0 OR V_TIENE_CARACTERES IS NULL THEN
    --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO NUMEROS.');
    V_POSICION := 0;
    V_POSICION := INSTR(V_DIRECCION_TEMPORAL,'VRD');
    IF V_POSICION = 0 THEN
       --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO LETRAS A NO SER QUE SEA VEREDA.');
       IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 23,V_ID);
       END IF;
       V_EXISTE := 1;
    END IF;      
  END IF;
  --SOLO LETRAS
  IF V_TIENE_NUMEROS = 0 OR V_TIENE_NUMEROS IS NULL THEN
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 22,V_ID); 
      END IF;
      V_EXISTE := 1;
  END IF;
  
  --VALIDO QUE NO TENGA TRES CONSONANTES SEGUIDAS, VALIDAS(VRD, BRR, CRV, CRT, BLV, APTDO, CRG, DPTO, CTRAL)
  V_CONSONANTES := A_DIRECCION;
  V_CONSONANTES := UPPER(V_CONSONANTES);
  V_CONSONANTES := REPLACE(V_CONSONANTES,'VRD','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'BRR','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'CRV','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'CRT','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'BLV','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'APTDO','*****');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'CRG','***');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'DPTO','****');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'CTRAL','*****');
  V_CONSONANTES := REPLACE(V_CONSONANTES,'STR','***');--INDUSTRIAL
  V_CONSONANTES := REPLACE(V_CONSONANTES,'NDR','***');--ANDRES
  V_CONSONANTES := REPLACE(V_CONSONANTES,'NTR','***');--ENTRE
  V_CONSONANTES := TRANSLATE(V_CONSONANTES,'BCDFGHJKLMNPQRSTVWXYZ','~~~~~~~~~~~~~~~~~~~~~');
  
  IF INSTR(V_CONSONANTES,'~~~') > 0 THEN
    --SP_EXCEPCION('LA DIRECCI�N NO PUEDE CONTENER TRES CONSONANTES SEGUIDAS.');
    IF OPCIONDIR = 0 THEN
        SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 24,V_ID); 
    END IF;
    V_EXISTE := 1;
  END IF;
  
  --VALIDO SI HUBIERON EXEPCIONES.
  IF V_EXISTE = 1 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
  
END FT_VALIDAR_DIRECCION;

/****************************************************************************/
/*ESTA FUNCION HACE LAS VALIDACIONES DEL TELEFONO.
  EL TIPO INDICA SI ES TELEFONO(T) O FAX(F)*/
FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER,V_ID VARCHAR2) RETURN BOOLEAN AS
  V_TELEFONO_TEMP VARCHAR2(14);
  V_POSICION NUMBER;
  V_CONTADOR NUMBER;
  V_LONGITUD NUMBER;
  V_CARACTER VARCHAR2(1);
  V_EXCEPCION BOOLEAN;
  V_EXISTE NUMBER := 0;
BEGIN
  
 --VALIDO QUE TENGA UN NUMERO DE TELEFONO VALIDO POR LO MENOS 7 DIGITOS SEGUIDOS Y LOS UNICOS CARACTERES PERMITIDOS SON "EXT"
  V_TELEFONO_TEMP := NVL(A_TELEFONO,' ');
  V_TELEFONO_TEMP := TRANSLATE(V_TELEFONO_TEMP,'0123456789()','**********~~');
  V_TELEFONO_TEMP := REPLACE(V_TELEFONO_TEMP,'EXT','~~~');
  V_POSICION := INSTR(V_TELEFONO_TEMP, '*******');
  IF V_POSICION = 0 THEN
    IF A_TIPO = 'T' THEN
--        SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 25,V_ID); 
      END IF;
      V_EXISTE := 1;                  
    ELSE
--        SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 33,V_ID); 
      END IF;
      V_EXISTE := 1;                  
    END IF;
  END IF;
  
  V_LONGITUD := LENGTH(V_TELEFONO_TEMP);
  V_CONTADOR := 1;
  V_EXCEPCION := FALSE;
  WHILE V_CONTADOR <= V_LONGITUD
  LOOP
    V_CARACTER := '';
    V_CARACTER := SUBSTR(V_TELEFONO_TEMP, V_CONTADOR, 1);
    IF V_CARACTER <> '*' AND V_CARACTER <> '~' THEN
      V_EXCEPCION := TRUE;
    END IF;
    V_CONTADOR := V_CONTADOR + 1;
  END LOOP;
  
  IF V_EXCEPCION THEN
    IF A_TIPO = 'T' THEN
      --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
      IF OPCIONDIR = 0 THEN        
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 26,V_ID); 
      END IF;
      V_EXISTE := 1;         
    ELSE
      --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
      IF OPCIONDIR = 0 THEN        
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 34,V_ID); 
      END IF;
      V_EXISTE := 1; 
    END IF;
  END IF;
  
  V_POSICION := 0;
  V_POSICION := INSTR(A_TELEFONO, '0000000')+INSTR(A_TELEFONO, '1111111')+INSTR(A_TELEFONO, '2222222')+INSTR(A_TELEFONO, '3333333')+INSTR(A_TELEFONO, '4444444')+INSTR(A_TELEFONO, '5555555')+INSTR(A_TELEFONO, '6666666')+INSTR(A_TELEFONO, '7777777')+INSTR(A_TELEFONO, '8888888')+INSTR(A_TELEFONO, '9999999')+INSTR(A_TELEFONO, '1234567')+INSTR(A_TELEFONO, '7654321');
  IF V_POSICION > 0 THEN
    IF A_TIPO = 'T' THEN
      --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 27,V_ID); 
      END IF;
      V_EXISTE := 1;         
    ELSE
      --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 35,V_ID); 
      END IF;
      V_EXISTE := 1; 
    END IF;
  END IF;
  
  --VERIFICO SI HUBIERON EXCEPCIONES
  IF V_EXISTE = 1 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
  
END FT_VALIDAR_TELEFONO_FAX;

/****************************************************************************/
/*ESTA FUNCION VALIDA EL DATO DE EMP O PART.*/
FUNCTION FT_VALIDAR_EMP_PART(A_EMP_PART VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN AS
   V_EXISTE NUMBER := 0;
BEGIN
    
  --VALIDO QUE EL DATO SEA UNA LETRA "E" O "P"
  IF A_EMP_PART <> 'E' AND A_EMP_PART <> 'P' THEN
    --SP_EXCEPCION('EL VALOR DEL CAMPO EMP_O_PART DEBE SER UNA "E" O UNA "P".');
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 28,V_ID); 
    V_EXISTE := 1;       
  END IF;
  
  --VERIFICO SI HUBIERON EXCEPCIONES
  IF V_EXISTE = 1 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
  
END FT_VALIDAR_EMP_PART;


/****************************************************************************/
/*ESTA FUNCION VALIDA EL DATO DEL CAMPO SEXO.*/
FUNCTION FT_VALIDAR_SEXO(A_SEXO VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN  AS   
  V_EXISTE NUMBER := 0;
BEGIN
  
     --VALIDO QUE EL DATO SEA UNA LETRA "M" O "F"
  IF A_SEXO <> 'M' AND A_SEXO <> 'F' THEN
    --SP_EXCEPCION('EL VALOR DEL CAMPO SEXO DEBE SER UNA "M" O UNA "F".');
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 29,V_ID); 
    V_EXISTE := 1;      
  END IF;
  
  --VERIFICO SI HUBIERON EXCEPCIONES
  IF V_EXISTE = 1 THEN
   RETURN TRUE;

  ELSE
   RETURN FALSE;
 
  END IF;
  
END FT_VALIDAR_SEXO;

/****************************************************************************/
/*ESTA FUNCION VALIDA LA FECHA DE NACIMIENTO.*/
FUNCTION FT_VALIDAR_FECHA_NACIMIENTO(A_FECHA_NACIMIENTO VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN AS
   V_EXISTE NUMBER := 0;
BEGIN

    BEGIN    
        --VALIDO QUE LA FECHA NO SEA MENOR A 01/01/1900 O MAYOR A LA FECHA ACTUAL
        IF A_FECHA_NACIMIENTO IS NOT NULL AND TO_DATE(A_FECHA_NACIMIENTO,'DD/MM/YYYY') < TO_DATE('01/01/1900','DD/MM/YYYY') THEN
          --SP_EXCEPCION('LA FECHA DE NACIMIENTO NO ES VALIDA, ES MENOR AL 01 DE ENERO DE 1900.');
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 30, V_ID); 
          V_EXISTE := 1;        
        END IF;
        
        IF TO_DATE(A_FECHA_NACIMIENTO,'DD/MM/YYYY') > SYSDATE THEN
          --SP_EXCEPCION('LA FECHA DE NACIMIENTO NO ES VALIDA, ES MAYOR A LA FECHA ACTUAL.');
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 31,V_ID); 
          V_EXISTE := 1;  
        END IF;
        
        --VERIFICO SI HUBIERON EXCEPCIONES
        IF V_EXISTE = 1 THEN
          RETURN TRUE;
        ELSE
          RETURN FALSE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
          SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 31,V_ID); 
          RETURN TRUE;
    END;
  
END FT_VALIDAR_FECHA_NACIMIENTO;

/****************************************************************************/
/*ESTA FUNCION VALIDA LOS DATOS DEL CAMPO EMAIL.*/
FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2, V_ID VARCHAR2) RETURN BOOLEAN AS
  V_POSICION NUMBER;
  V_EMAIL_RETORNA VARCHAR2(50);
  V_EXISTE NUMBER := 0;
  
BEGIN

  
  V_EMAIL_RETORNA := REPLACE(A_EMAIL,' ','');
  
  --VALIDO QUE TENGA @
  V_POSICION := INSTR(V_EMAIL_RETORNA, '@');
  IF V_EMAIL_RETORNA IS NOT NULL AND V_POSICION = 0 THEN
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 61, V_ID); 
    V_EXISTE := 1;  
  END IF;
  
  --VALIDO QUE LA LONGITUD SEA MAYOR A 7
  IF V_EMAIL_RETORNA IS NOT NULL AND LENGTH(V_EMAIL_RETORNA) <= 7 THEN
   SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 62, V_ID); 
    V_EXISTE := 1;  
  END IF;
  
  --VALIDO QUE EL EMAIL NO TENGA LAS PALABRAS NOTIENE NOREGISTRA
  IF INSTR(LOWER(V_EMAIL_RETORNA),'NOTIENE') > 0 OR INSTR(LOWER(V_EMAIL_RETORNA),'NOREGISTRA') > 0 THEN
    SP_GENERAR_EXCEPCION('DS_TMP_TRAMITES1', 63, V_ID); 
    V_EXISTE := 1;  
  END IF;
  
  --VERIFICO SI HUBIERON EXCEPCIONES
  IF V_EXISTE = 1 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
END FT_VALIDAR_EMAIL;

/****************************************************************************/
/*ESTA FUNCION VERIFICA SI EL NUMERO DE IDENTIFICACION YA EXISTE EN LA BD.*/
FUNCTION FT_VALIDA_FECHA_ACTUALIZACION(A_ID_USUARIO VARCHAR2, A_FECHA DATE) RETURN BOOLEAN AS
  V_FECHA_ULTIMA_CONFIRMACION DATE;
  V_CANT_DIAS_PARA_ACTUALIZAR NUMBER;
BEGIN
  /*VALIDO SI SE PUEDE ACTUALIZAR LA INFO DEL CONTRIBUYENTE DEACUERDO A LA 
    FECHA DE MODIFICACION REPORTADA COMPARADA CONTRA LA ULTIMA FECHA DE 
    CONFIRMACION DE FUENTES EXTERNAS*/
  
  --CONSULTO LA ULTIMA FECHA DE CONFIRMACI�N DE DIRECCION HECHA POR FUENTE EXTERNA
  BEGIN
    SELECT MAX(UTDF.FECHA_FUENTE)
    INTO V_FECHA_ULTIMA_CONFIRMACION
    FROM QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE UTDF,
          QUIPUX.USUARIOS_TTO_DIRECCIONES UTD
    WHERE UTDF.ID_USUARIO = UTD.ID_USUARIO AND
          UTDF.CONSECUTIVO_DIRECCION = UTD.CONSECUTIVO_DIRECCION AND
          UTD.ID_CONFIRMACION_CONTACTO = 2 AND
          UTDF.ID_FUENTE_DIRECCION = 16 AND
          UTD.ID_USUARIO = A_ID_USUARIO;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    --SI NO LA ENCUENTRO ES PORQUE NO HAN HECHO CONFIRMACION CON FUENTE EXTERNA Y PUEDO ACTUALIZAR
    V_FECHA_ULTIMA_CONFIRMACION := NULL;
  END;
  
  IF V_FECHA_ULTIMA_CONFIRMACION IS NULL THEN
    RETURN TRUE;
  END IF;
  
  --SI SE ENCONTRO LA FECHA DE CONFIRMACION ENTONCES VALIDO SI YA HAN PASADO LOS
  --DIAS PARAMETRIZADOS PARA PODER REALIZAR LA ACTUALIZACION DE LOS DATOS
  
  --CONSULTO LA CANTIDAD DE DIAS PARAMETRIZADA (60,5)
  BEGIN
    SELECT QXPPT.VALOR
    INTO V_CANT_DIAS_PARA_ACTUALIZAR
    FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO QXPPT
    WHERE QXPPT.ID_PROCESO = 60 AND
          QXPPT.ID_PARAMETRO = 5;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    --SI NO ENCUENTRO EL PARAMETRO LO DEJO EN 0 DIAS
    V_CANT_DIAS_PARA_ACTUALIZAR := 0;
  END;
        
  --SUMO LA CANTIDAD DE DIAS A LA ULTIMA FECHA DE CONFIRMACION.
  V_FECHA_ULTIMA_CONFIRMACION := V_FECHA_ULTIMA_CONFIRMACION + V_CANT_DIAS_PARA_ACTUALIZAR;
  
  --SI LA FECHA PASADA COMO PARAMETRO ES MAYOR A ESTA FECHA ENTONCES PUEDE REALIZAR LA ACTUALIZACION.
  IF A_FECHA >= V_FECHA_ULTIMA_CONFIRMACION THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;
  
END FT_VALIDA_FECHA_ACTUALIZACION;
  
/*PERMITE REGISTRAR LAS INCONSISTENCIAS DE LOS REGISTROS*/  
PROCEDURE SP_GENERAR_EXCEPCION (V_TABLA VARCHAR2, V_INCONSITENCIA NUMBER, V_ID VARCHAR2) AS

V_MENSAJE_INC VARCHAR2(100);
V_TIPO_INC VARCHAR2(2);

BEGIN

  SELECT MENSAJE, TIPO_INCONSISTENCIA 
    INTO V_MENSAJE_INC, V_TIPO_INC
  FROM DEPURACION.DS_TIPO_INCONSISTENCIA
  WHERE ID_INCONSISTENCIA = V_INCONSITENCIA;

  UPDATE DS_TMP_CONTRIBUYENTES2
  SET VALIDACION = V_MENSAJE_INC,
      TIPO_INCONSISTENCIA = V_TIPO_INC
  WHERE ID = V_ID;  

END SP_GENERAR_EXCEPCION;


PROCEDURE  SP_INCONSISTENCIA2 AS
Inco_Linea varchar2 (10);
Inco_Cilindraje varchar2 (10);
Inco_Direccion  varchar2 (50);
Inco_Usuario  VARCHAR2 (2);

cursor  SP_INCONSISTENCIA is 
select nro_placa from temp_placas;

begin

for Ln_Index in  SP_INCONSISTENCIA loop

begin 

select LT.ID_LINEA,lt.CILINDRAJE,UT.DIRECCION,UT.ID_DOCUMENTO
into 
Inco_Linea,
Inco_Cilindraje,
Inco_Direccion, 
Inco_Usuario
from quipux.lic_tto lt
full outer join quipux.PROPIETARIOS_VEHICULO PV ON LT.NRO_PLACA = PV.NRO_PLACA
full outer JOIN quipux.USUARIOS_TTO UT ON UT.ID_USUARIO = PV.ID_USUARIO
WHERE LT.NRO_PLACA = Ln_Index.Nro_placa AND ROWNUM <=1;

UPDATE TEMP_PLACAS TP SET  TP.LINEA = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND Inco_Linea IS NULL;

UPDATE TEMP_PLACAS TP SET  TP.CILINDRAJE = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND (Inco_Cilindraje IS NULL or Inco_Cilindraje = '0') ;

UPDATE TEMP_PLACAS TP SET  TP.DIRECCION = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA and (Inco_Direccion is null  or  LENGTH (Inco_Direccion)<12) ;


UPDATE TEMP_PLACAS TP SET  TP.USUARIO = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND Inco_Usuario = '4';



END;
END LOOP;
COMMIT;
END  SP_INCONSISTENCIA2;
  
END PKG_VALIDACIONES_REGISTRO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_IDENTIFICACION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDACION_IDENTIFICACION" AS

PROCEDURE SP_VALIDAR_IDENTIFICACION AS

V_IDENT1 VARCHAR2(50);
V_IDENT2 VARCHAR2(50);

V_LONGITUD1 NUMBER :=0;
V_LONGITUD2 NUMBER :=0;
V_EXISTE NUMBER:=0;
V_DIFERENCIA NUMBER :=0;
V_ESTADO VARCHAR2(100);


CURSOR IDENT1 IS
SELECT *
FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_N
WHERE REGISTRO_ERROR IS NULL;
--AND INTERLOCUTOR_COMERCIAL = '1000108175';

CURSOR IDENT2 IS
SELECT *
FROM CORRECCION_DATOS.PROPIETARIOS_SAP_19112015;
/*
CURSOR IDENT2 (V_NOMBRE VARCHAR2, V_APELLIDO VARCHAR2) IS
SELECT *
FROM CORRECCION_DATOS.IC_CON_NOMBRE_SAP INS
WHERE (INS.NOMBRE = V_NOMBRE AND INS.APELLIDO = V_APELLIDO)
   OR (INS.NOMBRE = V_APELLIDO AND INS.APELLIDO = V_NOMBRE);
--WHERE ESTADO IS NULL;
--WHERE INTERLOCUTOR IN ('1000003151','1000003152','1000003153');
*/

BEGIN

FOR X IN IDENT1 LOOP

  V_IDENT1 := X.NRO_IDENTIFICACION;
  V_LONGITUD1 := LENGTH(V_IDENT1);
 
  
--BEGIN
-- FOR Y IN IDENT2 (X.NOMBRE_PILA_INTERLOCUTOR, X.APELLIDO_INTERLOCUTOR ) LOOP
 FOR Y IN IDENT2 LOOP
   --BEGIN
    V_IDENT2 := Y.IDENTIFICACION;
    V_LONGITUD2 := LENGTH(V_IDENT2);
    
    V_DIFERENCIA := (V_LONGITUD1 - V_LONGITUD2);
    
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(V_IDENT1,V_IDENT2,1)>0;
    
    IF (V_EXISTE = 0) THEN
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_IDENT2,V_IDENT1,1)>0;
    END IF;
    
    IF (V_EXISTE = 1) AND (V_DIFERENCIA <= 2 AND V_DIFERENCIA >= -2) THEN
         V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito) Interlocutor ' || Y.INTERLOCUTOR;
    ELSE    
   
   --INICIO VALIDACIONES CARACTER A CARACTER
   -- IF (V_LONGITUD1 = V_LONGITUD2) THEN    
    
      V_EXISTE := FT_DESGLOSAR_ID(V_IDENT1, V_IDENT2);
      IF V_EXISTE > 0 THEN 
        V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito) Interlocutor ' || Y.INTERLOCUTOR ;
      /*ELSE
        V_EXISTE := FT_ORDENAR_ID(V_IDENT1, V_IDENT2);*/
      END IF;
   -- END IF; 
    
  END IF; 
  
  IF V_ESTADO IS NOT NULL THEN  
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_N
    SET REGISTRO_ERROR = V_ESTADO,
        TIPO_ARCHIVO = Y.IDENTIFICACION
    --WHERE IDENTIFICACION1 = V_IDENT1; 
    WHERE INTERLOCUTOR_COMERCIAL = X.INTERLOCUTOR_COMERCIAL;
    COMMIT;
    V_ESTADO := NULL;
    EXIT;
  ELSE
    UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS_N
    SET REGISTRO_ERROR = 'ACTUALIZAR'
       --WHERE IDENTIFICACION1 = V_IDENT1; 
    WHERE INTERLOCUTOR_COMERCIAL = X.INTERLOCUTOR_COMERCIAL;
    COMMIT;
  END IF;  
  
  /*EXCEPTION
  WHEN OTHERS THEN
   V_ESTADO := NULL;
    CONTINUE;
  END;*/
  
  END LOOP;

/*EXCEPTION
  WHEN OTHERS THEN
   V_ESTADO := NULL;
    CONTINUE;
  END;*/

END LOOP;

END SP_VALIDAR_IDENTIFICACION;

--
PROCEDURE SP_VALIDAR_IDENTIFICACION_II AS

V_IDENT1 VARCHAR2(50);
V_IDENT2 VARCHAR2(50);
V_LONGITUD1 NUMBER :=0;
V_LONGITUD2 NUMBER :=0;
V_EXISTE NUMBER:=0;
V_CONTADOR NUMBER:=0;
V_DIFERENCIA NUMBER :=0;
V_ESTADO VARCHAR2(100);


CURSOR IDENT1 IS
SELECT *
FROM CORRECCION_DATOS.TMP_ERROR_DIGITO
WHERE VALIDACION IS NULL;
--AND ROWNUM <1000;
--AND INTERLOCUTOR_COMERCIAL = '1000108175';

BEGIN

FOR X IN IDENT1 LOOP
V_CONTADOR := V_CONTADOR +1;
 --BEGIN
  V_IDENT1 := X.IDENTIFICACION_RUNT;
  V_LONGITUD1 := LENGTH(V_IDENT1); 
  
    V_IDENT2 := X.IDENTIFICACION_SAP;
    V_LONGITUD2 := LENGTH(V_IDENT2);
    
    V_DIFERENCIA := (V_LONGITUD1 - V_LONGITUD2);
    
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(V_IDENT1,V_IDENT2,1)>0;
    
    IF (V_EXISTE = 0) THEN
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_IDENT2,V_IDENT1,1)>0;
    END IF;
    
    IF (V_EXISTE = 1) AND (V_DIFERENCIA <= 2 AND V_DIFERENCIA >= -2) THEN
         V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito) Interlocutor ';
    ELSE    
   
   --INICIO VALIDACIONES CARACTER A CARACTER
   -- IF (V_LONGITUD1 = V_LONGITUD2) THEN    
    
      V_EXISTE := FT_DESGLOSAR_ID(V_IDENT1, V_IDENT2);
      IF V_EXISTE > 0 THEN 
        V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito) Interlocutor ';
      /*ELSE
        V_EXISTE := FT_ORDENAR_ID(V_IDENT1, V_IDENT2);*/
      END IF;
   -- END IF; 
    
  END IF; 
  
  IF V_ESTADO IS NOT NULL THEN  
    UPDATE CORRECCION_DATOS.TMP_ERROR_DIGITO
    SET VALIDACION = V_ESTADO
          --WHERE IDENTIFICACION1 = V_IDENT1; 
    WHERE IDENTIFICACION_SAP = X.IDENTIFICACION_SAP
      AND IDENTIFICACION_RUNT = X.IDENTIFICACION_RUNT;
    
    V_ESTADO := NULL;
  
  ELSE
    UPDATE CORRECCION_DATOS.TMP_ERROR_DIGITO
    SET VALIDACION = 'ACTUALIZAR'
       --WHERE IDENTIFICACION1 = V_IDENT1; 
    WHERE IDENTIFICACION_SAP = X.IDENTIFICACION_SAP
      AND IDENTIFICACION_RUNT = X.IDENTIFICACION_RUNT;

  END IF;  
  
 IF V_CONTADOR = 500 THEN
  COMMIT;
  V_CONTADOR :=0;
 END IF; 
/*EXCEPTION
  WHEN OTHERS THEN
   V_ESTADO := NULL;
    CONTINUE;
  END;*/
 V_ESTADO := NULL;
END LOOP;
COMMIT;

END SP_VALIDAR_IDENTIFICACION_II;

FUNCTION FT_DESGLOSAR_ID(V_ID1 VARCHAR2, V_ID2 VARCHAR2) RETURN NUMBER AS

V_N_IDENT1 VARCHAR2(50);--Nueva identificaci�n
V_N_IDENT2 VARCHAR2(50);--Nueva identificaci�n
V_ID_1 VARCHAR2(50);--Nueva identificaci�n
V_ID_2 VARCHAR2(50);
V_CADENA1 VARCHAR2(50);
V_CADENA2 VARCHAR2(50);
V_CONTADOR1 NUMBER :=1;
V_CONTADOR2 NUMBER :=1;
V_REMPLAZO NUMBER :=1;
V_LONGITUD1 NUMBER :=0;
V_LONGITUD2 NUMBER :=0;
V_CARACTER1 VARCHAR2(50);
V_CARACTER2 VARCHAR2(50);
V_EXISE NUMBER :=0;
V_MAX_LONG NUMBER :=0;

BEGIN
  
V_LONGITUD1 := LENGTH(V_ID1);
V_LONGITUD2 := LENGTH(V_ID2);
V_ID_1 := V_ID1;
V_ID_2 := V_ID2;

IF (V_LONGITUD1 > V_LONGITUD2) THEN 
 V_MAX_LONG := V_LONGITUD1;
ELSE
  V_MAX_LONG :=V_LONGITUD2; 
END IF;
 
 WHILE V_CONTADOR1 <= V_MAX_LONG
    LOOP      
         
      SELECT SUBSTR(V_ID_1,V_CONTADOR1,1) INTO V_CARACTER1 FROM DUAL;
      SELECT SUBSTR(V_ID_2,V_CONTADOR1,1) INTO V_CARACTER2 FROM DUAL;
            
        IF(V_CARACTER1 = V_CARACTER2) THEN
          V_CADENA1 := V_CADENA1 || V_CARACTER1;
          V_CADENA2 := V_CADENA2 || V_CARACTER2;
          --EXIT;
        ELSE
        
          IF (V_LONGITUD1 = V_LONGITUD2) THEN
          
              V_CADENA1 := V_CADENA1 || '-';
              V_CADENA2 := V_CADENA2 || '-';             
              
              SELECT SUBSTR(V_ID_1,V_CONTADOR1+1,V_LONGITUD1) INTO V_CARACTER1 FROM DUAL;
              SELECT SUBSTR(V_ID_2,V_CONTADOR1+1,V_LONGITUD2) INTO V_CARACTER2 FROM DUAL;
              
              V_N_IDENT1 := V_CADENA1 || V_CARACTER1;
              V_N_IDENT2 := V_CADENA2 || V_CARACTER2;
          ELSE
            
            IF (V_LONGITUD1 > V_LONGITUD2) THEN
                SELECT SUBSTR(V_ID_1,V_CONTADOR1+1,V_LONGITUD1) INTO V_CARACTER1 FROM DUAL;
                V_N_IDENT1 := V_CADENA1 || V_CARACTER1;
                V_ID_1 := V_N_IDENT1;
                V_N_IDENT2 := V_ID_2;
                V_LONGITUD1 := V_LONGITUD1 -1;
                V_CONTADOR1 := V_CONTADOR1 -1;
            ELSE
                SELECT SUBSTR(V_ID_2,V_CONTADOR1+1,V_LONGITUD2) INTO V_CARACTER2 FROM DUAL;
                 V_N_IDENT2 := V_CADENA2 || V_CARACTER2;
                 V_ID_2 := V_N_IDENT2;
                 V_N_IDENT1 := V_ID_1;
                 V_LONGITUD2 := V_LONGITUD2 -1;
                 V_CONTADOR1 := V_CONTADOR1 -1;
            END IF;
          
          END IF;    
          
          --VALIDO CUANTOS REEMPLAZOS SE HAN REALIZADO, SI SON MAS DE 2 TERMINO EL CICLO
            IF V_REMPLAZO <= 2 THEN
            V_REMPLAZO := V_REMPLAZO +1; 
            ELSE 
             EXIT;
            END IF; 
          
        END IF;  
                         
          IF (V_N_IDENT1 = V_N_IDENT2) AND (V_REMPLAZO <=2) THEN            
            --V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito)';
            V_EXISE := 1;
            EXIT;
          END IF;
          
      V_CONTADOR1 := V_CONTADOR1 + 1;
    END LOOP;
    
   RETURN V_EXISE;  

END  FT_DESGLOSAR_ID;

FUNCTION FT_ORDENAR_ID (V_ID1 VARCHAR2, V_ID2 VARCHAR2) RETURN NUMBER AS

V_N_IDENT1 VARCHAR2(20);--Nueva identificaci�n
V_N_IDENT2 VARCHAR2(20);--Nueva identificaci�n
V_CADENA1 VARCHAR2(20);
V_CADENA2 VARCHAR2(20);
V_RESTO VARCHAR2(20);
V_CHAR1 VARCHAR2(20);
V_CHAR2 VARCHAR2(2);
V_CHAR3 VARCHAR2(2);
V_CONTADOR1 NUMBER :=1;
V_CONTADOR2 NUMBER :=1;
V_REMPLAZO NUMBER :=0;
V_LONGITUD1 NUMBER :=0;
V_LONGITUD2 NUMBER :=0;
V_CARACTER1 VARCHAR2(20);
V_CARACTER2 VARCHAR2(20);
V_EXISE NUMBER :=0;
V_MAX_LONG NUMBER :=0;
IDENT1 VARCHAR2(20);
IDENT2 VARCHAR2(20);

BEGIN
V_LONGITUD1 := LENGTH(V_ID1);
V_LONGITUD2 := LENGTH(V_ID2);

IDENT1 := V_ID1;
IDENT2 := V_ID2;

IF (V_LONGITUD1 > V_LONGITUD2) THEN 
 V_MAX_LONG := V_LONGITUD1;
ELSE
  V_MAX_LONG :=V_LONGITUD2; 
END IF;
 
 WHILE V_CONTADOR1 <= V_MAX_LONG
    LOOP      
         
      SELECT SUBSTR(IDENT1,V_CONTADOR1,1) INTO V_CARACTER1 FROM DUAL;
      SELECT SUBSTR(IDENT2,V_CONTADOR1,1) INTO V_CARACTER2 FROM DUAL;
            
        IF(V_CARACTER1 = V_CARACTER2) THEN
          V_CADENA1 := V_CADENA1 || V_CARACTER1;
          V_CADENA2 := V_CADENA2 || V_CARACTER2;
          --EXIT;
        ELSE
               
          
              V_CHAR1 := V_CARACTER1;
              --Valido si el siguiente caracter es igual al de la otra cadena
              SELECT SUBSTR(IDENT1,V_CONTADOR1+1,1) INTO V_CARACTER1 FROM DUAL;
              --V_CADENA2 := V_CARACTER1;             
              
              IF(V_CARACTER1 = V_CARACTER2) THEN
                SELECT SUBSTR(IDENT1,V_CONTADOR1+1,V_LONGITUD1) INTO V_CARACTER1 FROM DUAL;
                IDENT1 := V_CADENA1 || V_CARACTER1;   
               
              ELSE
                
                SELECT SUBSTR(V_ID2,V_CONTADOR1+1,1) INTO V_CARACTER2 FROM DUAL;
                                
                IF(V_CARACTER1 = V_CARACTER2) THEN
                  SELECT SUBSTR(IDENT2,V_CONTADOR1+1,V_LONGITUD2) INTO V_CARACTER2 FROM DUAL;
                  IDENT2 := V_CADENA2 || V_CARACTER2;   
                  --V_LONGITUD1 := V_LONGITUD1 -1;
                END IF;
              END IF;
                        
                  
          --VALIDO CUANTOS REEMPLAZOS SE HAN REALIZADO, SI SON MAS DE 2 TERMINO EL CICLO
            IF V_REMPLAZO < 3 THEN
            V_REMPLAZO := V_REMPLAZO +1; 
            ELSE 
             EXIT;
            END IF;         
          
          IF (V_N_IDENT1 = V_N_IDENT2) AND (V_REMPLAZO <3) THEN            
            --V_ESTADO := 'Los Id presentan una peque�a diferencia (Error digito)';
            V_EXISE := 1;
            EXIT;
          END IF;
       
        END IF;                       
      V_CONTADOR1 := V_CONTADOR1 + 1;
    END LOOP;
    
   RETURN V_EXISE;  


END FT_ORDENAR_ID;

PROCEDURE SP_DIVIDIR_NOMBRE_SAP AS

V_NOMBRE VARCHAR2(100);
V_APELLIDO VARCHAR2(100);
V_NOMBRE1 VARCHAR2(50);
V_NOMBRE2 VARCHAR2(50);
V_APELLIDO1 VARCHAR2(50);
V_APELLIDO2 VARCHAR2(50);
V_POSICION NUMBER:=0;
V_POSICION2 NUMBER:=0;
V_LARGO NUMBER:=0;
V_CONTADOR NUMBER :=0;

CURSOR INTERLOCUTOR IS
SELECT *
FROM CORRECCION_DATOS.PROPIETARIOS_SAP_19112015
WHERE (NOMBRE1 IS NULL AND NOMBRE2 IS NOT NULL)
  OR  (APELLIDO1 IS NULL AND APELLIDO2 IS NOT NULL);
--WHERE INTERLOCUTOR = '1000000027';

BEGIN

FOR X IN INTERLOCUTOR LOOP

  V_NOMBRE := TRIM(X.NOMBRE);
  V_APELLIDO := TRIM(X.APELLIDO);
  
  IF (V_NOMBRE IS NOT NULL) THEN
      --SEPARO LOS NOMBRES
      V_LARGO := LENGTH (V_NOMBRE);  
      V_POSICION := INSTR(V_NOMBRE,' ');  
      IF V_POSICION > 0 THEN
        V_NOMBRE1 := SUBSTR(V_NOMBRE,1,V_POSICION-1);
        V_NOMBRE2 := SUBSTR(V_NOMBRE,V_POSICION+1,V_LARGO);
      ELSE  
        V_NOMBRE1 := SUBSTR(V_NOMBRE,1,V_LARGO);
      END IF;
  END IF;
  
  IF (V_APELLIDO IS NOT NULL) THEN
      --SEPARO LOS APELLIDO
      V_LARGO := LENGTH (V_APELLIDO);  
      V_POSICION := INSTR(V_APELLIDO,' ');  
      IF V_POSICION > 0 THEN
        V_APELLIDO1 := SUBSTR(V_APELLIDO,1,V_POSICION-1);
        V_APELLIDO2 := SUBSTR(V_APELLIDO,V_POSICION+1,V_LARGO);
      ELSE  
        V_APELLIDO1 := SUBSTR(V_APELLIDO,1,V_LARGO);
      END IF;
  END IF;   
  
  IF (V_NOMBRE IS NOT NULL) OR (V_APELLIDO IS NOT NULL) THEN
      UPDATE PROPIETARIOS_SAP_19112015
         SET NOMBRE1 = V_NOMBRE1,
             NOMBRE2 = V_NOMBRE2,
             APELLIDO1 = V_APELLIDO1,
             APELLIDO2 = V_APELLIDO2
       WHERE INTERLOCUTOR = X.INTERLOCUTOR;
   END IF;
   
   IF V_CONTADOR = 500 THEN
    V_CONTADOR := 0;
    COMMIT;
   END IF; 

END LOOP;
COMMIT;

END SP_DIVIDIR_NOMBRE_SAP;


PROCEDURE SP_DIVIDIR_NOMBRE_RUNT AS --IC NUEVOS A CREAR

V_NOMBRE VARCHAR2(100);
V_APELLIDO VARCHAR2(100);
V_NOMBRE1 VARCHAR2(100);
V_NOMBRE2 VARCHAR2(100);
V_APELLIDO1 VARCHAR2(100);
V_APELLIDO2 VARCHAR2(100);
V_POSICION NUMBER:=0;
V_POSICION2 NUMBER:=0;
V_LARGO NUMBER:=0;
V_CONTADOR NUMBER :=0;

CURSOR INTERLOCUTOR IS
SELECT *
FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONASII;
--WHERE NRO_IDENTIFICACION = '9847797';


BEGIN

FOR X IN INTERLOCUTOR LOOP
  V_NOMBRE1 := NULL;
  V_NOMBRE2 := NULL;
  V_APELLIDO1:= NULL;
  V_APELLIDO2:= NULL;
  
  V_NOMBRE := TRIM(X.NOMBRE_PILA_INTERLOCUTOR);
  V_APELLIDO := TRIM(X.APELLIDO_INTERLOCUTOR);
  
  IF (V_NOMBRE IS NOT NULL) THEN
      --SEPARO LOS NOMBRES
      V_LARGO := LENGTH (V_NOMBRE);  
      V_POSICION := INSTR(V_NOMBRE,' ');  
      IF V_POSICION > 0 THEN
        V_NOMBRE1 := SUBSTR(V_NOMBRE,1,V_POSICION-1);
        V_NOMBRE2 := SUBSTR(V_NOMBRE,V_POSICION+1,V_LARGO);
      ELSE  
        V_NOMBRE1 := SUBSTR(V_NOMBRE,1,V_LARGO);
      END IF;
  END IF;
  
  IF (V_APELLIDO IS NOT NULL) THEN
      --SEPARO LOS APELLIDO
      V_LARGO := LENGTH (V_APELLIDO);  
      V_POSICION := INSTR(V_APELLIDO,' ');  
      IF V_POSICION > 0 THEN
        V_APELLIDO1 := SUBSTR(V_APELLIDO,1,V_POSICION-1);
        V_APELLIDO2 := SUBSTR(V_APELLIDO,V_POSICION+1,V_LARGO);
      ELSE  
        V_APELLIDO1 := SUBSTR(V_APELLIDO,1,V_LARGO);
      END IF;
  END IF;   
  
  IF (V_NOMBRE IS NOT NULL) OR (V_APELLIDO IS NOT NULL) THEN
     INSERT INTO TMP_NOMBRE_SEPARADO (IDENTIFICACION, TIPO_DOCUMENTO, NOMBRE1, NOMBRE2, APELLIDO1,APELLIDO2)
          VALUES (X.NRO_IDENTIFICACION, X.CLASE_IDENTIFICACION, V_NOMBRE1, V_NOMBRE2, V_APELLIDO1, V_APELLIDO2);         
   END IF;
   
   IF V_CONTADOR = 500 THEN
    V_CONTADOR := 0;
    COMMIT;
   END IF; 

END LOOP;
COMMIT;

END SP_DIVIDIR_NOMBRE_RUNT;


PROCEDURE SP_INSERT_ERROR_DIGITO AS

BEGIN
 INSERT INTO TMP_ERROR_DIGITO
 SELECT PS.IDENTIFICACION, NS.IDENTIFICACION, PS.DOCUMENTO_SAP, NS.TIPO_DOCUMENTO, PS.NOMBRE1 || ' ' || PS.NOMBRE2, 
        NS.NOMBRE1 || ' ' || NS.NOMBRE2,  PS.APELLIDO1 || ' ' || PS.APELLIDO2, NS.APELLIDO1 || ' ' || NS.APELLIDO2, NULL
 FROM CORRECCION_DATOS.PROPIETARIOS_SAP_19112015 PS
  INNER JOIN CORRECCION_DATOS.TMP_NOMBRE_SEPARADO NS
          ON (PS.NOMBRE1 = NS.NOMBRE1 AND PS.APELLIDO1 = NS.APELLIDO1)--Cuando sean completamente igual
         AND (PS.NOMBRE2 = NS.NOMBRE2 AND PS.APELLIDO2 = NS.APELLIDO2)--igual
          OR (PS.NOMBRE1 = NS.NOMBRE1 AND (PS.APELLIDO1 = NS.APELLIDO1 AND PS.APELLIDO2 = NS.APELLIDO2))--Diferencia en un nombre
          OR (PS.NOMBRE2 = NS.NOMBRE2 AND (PS.APELLIDO1 = NS.APELLIDO1 AND PS.APELLIDO2 = NS.APELLIDO2))--pero con apellidos
          OR (PS.NOMBRE1 = NS.NOMBRE2 AND (PS.APELLIDO1 = NS.APELLIDO1 AND PS.APELLIDO2 = NS.APELLIDO2))--iguales
          OR (PS.NOMBRE2 = NS.NOMBRE1 AND (PS.APELLIDO1 = NS.APELLIDO1 AND PS.APELLIDO2 = NS.APELLIDO2))--iguales
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO1 = NS.APELLIDO1 AND PS.APELLIDO2 IS NULL)) --Diferencia en un apelldio
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO2 = NS.APELLIDO2 AND PS.APELLIDO1 IS NULL)) -- pero con nombre igual
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO1 = NS.APELLIDO1 AND NS.APELLIDO2 IS NULL)) --Diferencia en un apelldio
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO2 = NS.APELLIDO2 AND NS.APELLIDO1 IS NULL))
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO1 = NS.APELLIDO2 AND NS.APELLIDO1 IS NULL))
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO2 = NS.APELLIDO1 AND NS.APELLIDO2 IS NULL))
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO1 = NS.APELLIDO2 AND PS.APELLIDO1 IS NULL))
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO2 = NS.APELLIDO1 AND PS.APELLIDO2 IS NULL))
          OR ((PS.NOMBRE1 = NS.NOMBRE1 AND PS.NOMBRE2 = NS.NOMBRE2) AND (PS.APELLIDO1 = NS.APELLIDO2 AND PS.APELLIDO2 = NS.APELLIDO1));

END SP_INSERT_ERROR_DIGITO;  

END PKG_VALIDACION_IDENTIFICACION;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_NOVEDADES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDACION_NOVEDADES" AS


PROCEDURE SP_VALIDAR_PAGOS AS
  
        V_FECHA DATE;
        V_PLACA VARCHAR2(8);
        V_VIGENCIA  VARCHAR2(4);
        
        V_EXISTE          NUMBER :=0;
        V_CONTADOR_COMMIT NUMBER :=0;
        V_EXEPCION        NUMBER;
        
        -- PARAMETIZAR HASTA QUE VIGENCIA SE VA A VALIDAR
        V_VIGENCIA_FIN    NUMBER :=2016;
         
        CURSOR CONSULTAR_PLACAS IS
          SELECT NRO_PLACA, TO_CHAR(FECHA_MATRICULA,'YYYY')AS MATRICULO
          FROM DQ_VALIDAR_PLACAS
         -- WHERE NRO_PLACA= '342ABS';
         WHERE ESTADO IS NULL;
             
        BEGIN
        
        DELETE DQ_NOVEDADES_SAP WHERE TIPO_NOVEDAD IN('2','5','10','11','15','16','18'); -- ELIMINO NOVEDADES QUE NO SE REQUIEREN VALIDAR
        
        -- ACTUALIZO LOS ESTADOS DE LIQUIDA Y NO LIQUIDA VIGENCIA ACTUAL
        UPDATE DQ_NOVEDADES_SAP SET LIQUIDA_VIGENCIA = 'SI' WHERE LIQUIDA_VIGENCIA = 'X';
        UPDATE DQ_NOVEDADES_SAP SET LIQUIDA_VIGENCIA = 'NO' WHERE LIQUIDA_VIGENCIA IS NULL;
        
        V_CONTADOR_COMMIT :=0;
        FOR Placa_index in CONSULTAR_PLACAS LOOP
        BEGIN
        
        IF V_CONTADOR_COMMIT = 100 THEN
        COMMIT;
         V_CONTADOR_COMMIT :=0;
        END IF;
        
         V_CONTADOR_COMMIT :=V_CONTADOR_COMMIT+1;
         
         V_PLACA := Placa_index.NRO_PLACA;
         V_VIGENCIA := Placa_index.MATRICULO;
         
                  IF V_VIGENCIA  <1999 THEN
                  V_VIGENCIA := 1999;
                  END IF;
                 
      
        WHILE V_VIGENCIA <= V_VIGENCIA_FIN LOOP
        
            SELECT COUNT(1) INTO V_EXISTE
            FROM DQ_SAP_PAGOS PG 
            WHERE PG.PLACA = V_PLACA
            AND PG.VIGENCIA = V_VIGENCIA;
        
        IF V_EXISTE > 0 THEN
          IF V_VIGENCIA = V_VIGENCIA_FIN THEN
          V_VIGENCIA := V_VIGENCIA_FIN + 1;
 
           --- PLACA CON PAGOS
           
              UPDATE DQ_VALIDAR_PLACAS
              SET ESTADO = 'P'
              WHERE NRO_PLACA = V_PLACA;
              COMMIt;
           END IF;
           V_VIGENCIA := V_VIGENCIA + 1;
           
        ELSE
        
        --ENVIO A CONSULTAR SI EXISTE NOVEDAD QUE INHABILITE EL COBRO PARA LA VIGENCIA
        
           V_EXEPCION :=  FT_VALIDO_NOVEDAD(V_PLACA,V_VIGENCIA);
  
          --- NO FUE POSIBLE DETERMINAR ESTADO DE LA PLACA       
          IF V_EXEPCION = 0 THEN
              UPDATE DQ_VALIDAR_PLACAS SET ESTADO = 'I',TRAMITE ='X' WHERE NRO_PLACA = V_PLACA;
              V_VIGENCIA := V_VIGENCIA_FIN + 1;
          END IF;

          --- PLACA CON PAGOS
          IF V_EXEPCION = 1 THEN
                IF V_VIGENCIA = V_VIGENCIA_FIN THEN
                  UPDATE DQ_VALIDAR_PLACAS SET ESTADO = 'P',TRAMITE ='X' WHERE NRO_PLACA = V_PLACA;
                  V_VIGENCIA := V_VIGENCIA_FIN + 1;
                END IF;
            V_VIGENCIA := V_VIGENCIA + 1;
          END IF;
          
          --- PLACA CON DEUDA
          IF V_EXEPCION = 2 THEN
              UPDATE DQ_VALIDAR_PLACAS SET ESTADO = 'D',TRAMITE ='X' WHERE NRO_PLACA = V_PLACA;
              V_VIGENCIA := V_VIGENCIA_FIN + 1;
          END IF;
        END IF;
        
        END LOOP;
        
        END;
        END LOOP;
        END SP_VALIDAR_PAGOS;
        
        
        FUNCTION FT_VALIDO_NOVEDAD (J_PLACA VARCHAR2, J_VIGECIA VARCHAR2)RETURN NUMBER AS
       
        V_EXEPCION NUMBER :=3 ;
        V_PLACA VARCHAR2(7);
        V_VIGENCIA VARCHAR2(4);
        V_EXISTE NUMBER;
        V_EXISTE1 NUMBER;
        V_EXISTE_SERV_PUB NUMBER;
        V_FECHA_ACT_PUPA DATE; 
        V_EXISTE_NOV_PAPU NUMBER;
        V_FECHA_NOVEDAD DATE;
        V_FECHA_ACTO_ADM_PAPU DATE;
        V_NOVEDAD NUMBER;
        V_NOVEDAD1 NUMBER;
        V_VIG_ACTIVA VARCHAR2(3);
        V_FECHA_VALIDO_INICIO DATE;
        V_FECHA_VALIDO_FIN DATE;
        V_FECHA_ACT_ADM DATE;
        
         CURSOR CONSULTAR_NOVEDAD (PLACA VARCHAR2) IS
                                SELECT FECHA_NOVEDAD
                                FROM DQ_NOVEDADES_SAP
                                WHERE NRO_PLACA = PLACA AND TIPO_NOVEDAD = '14';
        
        BEGIN
            V_PLACA :=J_PLACA;
            V_VIGENCIA :=J_VIGECIA;
      
      -- VALIDO SI LA PLACA TIENE CONDONACION O PRESCRIPCION
       SELECT COUNT (1) INTO V_EXISTE FROM DQ_NOVEDADES_SAP WHERE NRO_PLACA = V_PLACA AND TIPO_NOVEDAD IN ('9','13','17');
       
       IF V_EXISTE >= 1 THEN
       V_FECHA_NOVEDAD := TO_DATE('01/01/1900','DD/MM/YYYY');
       V_EXEPCION := FT_VALIDA_CONDONACION_PRESCR(V_PLACA,V_VIGENCIA);
       END IF;
       
       BEGIN
                 -- VALIDO SE EL VEHICULO ES DE SERVICIO PUBLICO
                  SELECT FECHA_NOVEDAD INTO V_FECHA_ACT_PUPA
                  FROM DQ_NOVEDADES_SAP 
                  WHERE NRO_PLACA = V_PLACA
                  AND TO_CHAR(FECHA_NOVEDAD,'YYYY')> V_VIGENCIA
                  AND TIPO_NOVEDAD = '8'
                  AND ROWNUM = 1
                  ORDER BY FECHA_NOVEDAD ;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_FECHA_ACT_PUPA:= TO_DATE('01/01/2999','DD/MM/YYYY');
        END;
                  
          IF V_FECHA_ACT_PUPA != TO_DATE('01/01/2999','DD/MM/YYYY') THEN
                  
                        SELECT COUNT(1) INTO V_EXISTE_NOV_PAPU FROM DQ_NOVEDADES_SAP WHERE NRO_PLACA = V_PLACA AND TIPO_NOVEDAD = '14';
                        
                    IF V_EXISTE_NOV_PAPU = 0  THEN ---NI NO EXISTE NOVEDAD DE PA A PU MENOR A FECHA DE CAMBIO DE PU A PA
                           --INACTIVO EL COBRO DE LA VIGENCIA
                           V_EXEPCION :=1;    
                           
                          
                          
                             FOR Placa_nove_index in CONSULTAR_NOVEDAD (V_PLACA) LOOP
                             
                             
                             V_FECHA_ACTO_ADM_PAPU := Placa_nove_index.FECHA_NOVEDAD;
                             
                             IF V_FECHA_ACTO_ADM_PAPU > V_FECHA_ACT_PUPA THEN
                             -- INACTIVO LA VIGENCIA
                             V_EXEPCION :=1;
                             END IF;
                             
                             IF V_FECHA_ACTO_ADM_PAPU <= V_FECHA_ACT_PUPA THEN
                             -- ACTIVO LA VIGENCIA
                             V_EXEPCION :=2;
                             -- VALIDAR COMO SE LLEVA EL CURSOR AL ULTIMO REGISTRO
                             END IF;

                            END LOOP;
                             
                              V_FECHA_NOVEDAD := TO_DATE('01/01/1900','DD/MM/YYYY');                          
                 END IF;                      
        END IF;
   
      -- SI NO SE A PLIACDO NINGUNA NOVEDAD 
  IF V_EXEPCION = 3 THEN
      
            SELECT COUNT (1) INTO V_EXISTE FROM DQ_NOVEDADES_SAP WHERE NRO_PLACA = V_PLACA AND TIPO_NOVEDAD NOT IN ('9','13','17');
            
            IF V_EXISTE = 0 THEN    -- SI NO EXISTE NINGUNA NOVEDAD DIFERENTE A 9,13,17
                 -- ACTIVO LA VIGENCIA
                  V_EXEPCION :=2;    
                  
            ELSE 
                IF V_EXISTE = 1 THEN -- SI EXISTE UNA NOVEDAD
                
                  SELECT TIPO_NOVEDAD,LIQUIDA_VIGENCIA,FECHA_DESDE,FECHA_HASTA,FECHA_NOVEDAD
                  INTO V_NOVEDAD,V_VIG_ACTIVA,V_FECHA_VALIDO_INICIO,V_FECHA_VALIDO_FIN,V_FECHA_NOVEDAD
                  FROM DQ_NOVEDADES_SAP 
                  WHERE NRO_PLACA = V_PLACA 
                  AND TIPO_NOVEDAD NOT IN ('9','13','17');
                  
                  
                  V_EXEPCION := FT_DETERMINA_ESTADO(V_NOVEDAD ,V_VIGENCIA ,V_FECHA_NOVEDAD,V_VIG_ACTIVA,V_FECHA_VALIDO_INICIO,V_FECHA_VALIDO_FIN);
                  
                  ELSE  ---SI EXISTE MAS DE UNA NOVEDAD Y NO ES 9 13 17 
                  IF V_EXISTE > 1 THEN
                 ---- PREGUNTO SI EXISTE  NOVEDAD EN EL MISMO A�O DE LA VIGENCIA
                  SELECT COUNT(1)INTO V_EXISTE1 FROM DQ_NOVEDADES_SAP WHERE NRO_PLACA = V_PLACA AND TO_CHAR(FECHA_NOVEDAD,'YYYY') = V_VIGENCIA;
                  
                    -- SI NO EXISTE
                  IF V_EXISTE1 = 0 THEN
                    
                  BEGIN
                    SELECT TIPO_NOVEDAD,FECHA_NOVEDAD INTO V_NOVEDAD1,V_FECHA_ACT_ADM
                    FROM DQ_NOVEDADES_SAP
                    WHERE NRO_PLACA = V_PLACA
                    AND TO_CHAR(FECHA_NOVEDAD,'YYYY') < V_VIGENCIA
                    AND TIPO_NOVEDAD NOT IN ('9','13','17')
                    AND ROWNUM = 1
                    ORDER BY FECHA_NOVEDAD DESC;
                    
                  EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                  V_NOVEDAD1 := 99;
                  V_FECHA_ACT_ADM := TO_DATE('01/01/2999','DD/MM/YYYY');
                  END;
                     
                        IF V_NOVEDAD1 = 99 THEN
                         V_NOVEDAD :=999;
                        END IF; 
                  ELSE
                  
                    SELECT TIPO_NOVEDAD,FECHA_NOVEDAD,LIQUIDA_VIGENCIA,FECHA_DESDE,FECHA_HASTA INTO V_NOVEDAD1,V_FECHA_ACT_ADM,V_VIG_ACTIVA,V_FECHA_VALIDO_INICIO,V_FECHA_VALIDO_FIN
                    FROM DQ_NOVEDADES_SAP
                    WHERE NRO_PLACA = V_PLACA
                    AND TO_CHAR(FECHA_NOVEDAD,'YYYY') = V_VIGENCIA
                    AND TIPO_NOVEDAD NOT IN ('9','13','17')
                    AND ROWNUM = 1
                    ORDER BY FECHA_NOVEDAD ASC;
                  
                        IF V_NOVEDAD1 IS  NULL THEN
                         V_NOVEDAD :=999;
                        END IF; 
                  END IF;
                
                -- VALIDO SI EL VEHICULO TIENE MAS DE UNA NOVEDAD PERO LOS REGISTROS SON POSTERIORES A LA VIGENCIA DE RECLAMACION.
                
                    IF V_NOVEDAD != 999 THEN
                        V_EXEPCION := FT_DETERMINA_ESTADO(V_NOVEDAD1 ,V_VIGENCIA ,V_FECHA_ACT_ADM,V_VIG_ACTIVA,V_FECHA_VALIDO_INICIO,V_FECHA_VALIDO_FIN);
                    ELSE
                        --- ACTIVO EL COBRO DE LA VIGENCIA
                       V_EXEPCION := 2;
                    END IF; 
              
                END IF;
                END IF;
                END IF;
          
      END IF;
            
        RETURN V_EXEPCION;
        END FT_VALIDO_NOVEDAD;
        
         FUNCTION FT_DETERMINA_ESTADO(J_NOVEDAD NUMBER,J_VIGENCIA VARCHAR2,J_FECHA_NOVEDAD DATE,J_VIG_ACTIVA VARCHAR2,J_DESDE DATE,J_HASTA DATE)RETURN NUMBER AS
          V_EXEPCION NUMBER :=3;  
          V_VIGENCIA VARCHAR2(4);
          V_VIG_ACTIVA VARCHAR2(4);
          V_FECHA_ACT_ADM DATE ;
          V_FECHA_LIMITE_PAGO DATE;
          V_FECHA_INICIO DATE;
          V_FECHA_FIN DATE;
          V_NOVEDAD NUMBER;
            
            BEGIN
            V_VIGENCIA :=J_VIGENCIA;
            V_FECHA_ACT_ADM :=J_FECHA_NOVEDAD;
            V_NOVEDAD :=J_NOVEDAD;
            V_VIG_ACTIVA := J_VIG_ACTIVA;
            V_FECHA_INICIO:=J_DESDE;
            V_FECHA_FIN:=J_HASTA;
            
            CASE V_NOVEDAD
            
              --- MATRICULA INICIAL
                    WHEN 0 THEN   
                          --ACTIVO EL COBRO
                          V_EXEPCION :=2;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY')>V_VIGENCIA THEN
                             --INACTIVO EL COBRO
                             V_EXEPCION :=1;
                          END IF;
                          
              --- CANCELACION
                    WHEN 3 THEN
                          --INACTIVO EL COBRO
                          V_EXEPCION :=1;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY')>= V_VIGENCIA THEN
                             --ACTIVO EL COBRO
                             V_EXEPCION :=2;
                          END IF;
      
              --- REATRICULA
                    WHEN 4 THEN
                          --ACTIVO EL COBRO
                          V_EXEPCION :=2;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY')> V_VIGENCIA THEN
                             --INACTIVO EL COBRO
                             V_EXEPCION :=1;
                          END IF;
       
              --- RADICACION
                    WHEN 6 THEN
                          --ACTIVO EL COBRO
                          V_EXEPCION :=2;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY') = V_VIGENCIA  AND  V_VIG_ACTIVA = 'NO' THEN
                             --INACTIVO EL COBRO
                             V_EXEPCION :=1;
                          ELSIF TO_CHAR(V_FECHA_ACT_ADM,'YYYY') > V_VIGENCIA THEN
                             --INACTIVO EL COBRO
                             V_EXEPCION :=1;                  
                          END IF;                  
      
              --- TRASLADO
                    WHEN 7 THEN
                          --INACTIVO EL COBRO
                          V_EXEPCION :=1;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY') = V_VIGENCIA  THEN
                             --ACTIVO EL COBRO
                             V_EXEPCION :=2;
                          ELSIF TO_CHAR(V_FECHA_ACT_ADM,'YYYY') > V_VIGENCIA THEN
                             --NO ES POSIBLE DEFINIR EL COBRO
                             V_EXEPCION :=0;
                          END IF;
                          
              --- CAMBIO DE PU A PA
                    WHEN 8 THEN
                           --ACTIVO EL COBRO
                          V_EXEPCION :=2;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY')> V_VIGENCIA THEN
                             --INACTIVO EL COBRO
                             V_EXEPCION :=1;
                          END IF ; 
                          
              -- CONDONACION CON RECUPERACION
                    WHEN 9 THEN
                            --INACTIVO EL COBRO
                          V_EXEPCION :=1;
                          
                          V_FECHA_LIMITE_PAGO:= TO_DATE(CONCAT('31/12/',V_VIGENCIA));
                          
                          IF V_FECHA_INICIO <= V_FECHA_LIMITE_PAGO AND V_FECHA_FIN >= V_FECHA_LIMITE_PAGO THEN
                            --INACTIVO EL COBRO
                          V_EXEPCION :=1 ;                   
                          ELSE
                            --ACTIVO EL COBRO
                          V_EXEPCION :=2;                   
                          END IF;
      
            -- CONDONACION SIN RECUPERACION
                    WHEN 13 THEN
                    
                             --INACTIVO EL COBRO
                          V_EXEPCION :=1;
      
                        IF TO_CHAR(V_FECHA_INICIO,'YYYY') <= V_VIGENCIA AND TO_CHAR(V_FECHA_FIN,'YYYY')>= V_VIGENCIA THEN
                              --INACTIVO EL COBRO
                          V_EXEPCION :=1;                   
                          ELSE
                            --ACTIVO EL COBRO
                          V_EXEPCION :=2;  
                        END IF;
                        
              -- CAMB SERVI PA PU      
                    WHEN 14 THEN
                    
                           --INACTIVO EL COBRO
                          V_EXEPCION :=1;
                          
                          IF TO_CHAR(V_FECHA_ACT_ADM,'YYYY')>= V_VIGENCIA THEN
                             --ACTIVO EL COBRO
                             V_EXEPCION :=2;
                          END IF;
                          
              -- PRESCRIPCION
                    WHEN 17 THEN
        
                        --INACTIVO EL COBRO
                          V_EXEPCION :=1;  
                          
                      IF TO_CHAR(V_FECHA_INICIO,'YYYY')= V_VIGENCIA THEN  
                          --INACTIVO EL COBRO
                          V_EXEPCION :=1;  
                      ELSE
                          --ACTIVO EL COBRO
                          V_EXEPCION :=2;  
                      END IF;
            
            END CASE;
            
      RETURN V_EXEPCION;
            
         END FT_DETERMINA_ESTADO;
        
        
        FUNCTION FT_VALIDA_CONDONACION_PRESCR(J_PLACA VARCHAR2, J_VIGECIA VARCHAR2)RETURN NUMBER AS
        V_EXEPCION NUMBER :=3;
        V_EXISTE_COND_PRE NUMBER;
        V_PLACA VARCHAR2(7);
        V_VIGENCIA VARCHAR2(4);
        V_FECHA_LIMITE_PAGO DATE ;
        BEGIN
            V_PLACA :=J_PLACA;
            V_VIGENCIA :=J_VIGECIA;
        
        -- VALIDO SI SE APLICA ALGUNA PRESCRIPCION
        SELECT COUNT(1) INTO V_EXISTE_COND_PRE FROM DQ_NOVEDADES_SAP WHERE NRO_PLACA = V_PLACA AND TO_CHAR(FECHA_DESDE,'YYYY') = V_VIGENCIA AND TIPO_NOVEDAD = '17';
        
        IF V_EXISTE_COND_PRE >= 1 THEN
         --VIGENCIA INACTIVA
         V_EXEPCION := 1;
        ELSE
        -- VALIDO SI SE APLCA UNA CONDONACION CON RECUPERACION - INACTIVA EN UN PERIODO DE TIEMPO Y NO TIENE CANCELACION, EL VEHICULO CONTINUA ACTIVO
          V_FECHA_LIMITE_PAGO := TO_CHAR(CONCAT('31/12/',V_VIGENCIA));
          
          SELECT COUNT(1) INTO V_EXISTE_COND_PRE 
          FROM DQ_NOVEDADES_SAP 
          WHERE NRO_PLACA = V_PLACA 
          AND FECHA_DESDE <= V_FECHA_LIMITE_PAGO 
          AND FECHA_HASTA >= V_FECHA_LIMITE_PAGO 
          AND TIPO_NOVEDAD = '9' ;
          
              IF V_EXISTE_COND_PRE >=1 THEN
                -- INACTIVO LA VGENCIA 
                V_EXEPCION := 1;
              ELSE 
               -- VALIDO SI SE APLICA CONDONACION SIN RECUPERACION   --- INACTIVA EN UN PERIOSO DE TIEMPO DEBE EXISTIR UNA CANCELACION
                
                SELECT COUNT(1) INTO  V_EXISTE_COND_PRE FROM DQ_NOVEDADES_SAP 
                WHERE NRO_PLACA = V_PLACA
                AND TO_CHAR(FECHA_DESDE,'YYYY') <= V_VIGENCIA 
                AND TO_CHAR(FECHA_HASTA,'YYYY') >= V_VIGENCIA
                AND TIPO_NOVEDAD = '13';
                
                 IF V_EXISTE_COND_PRE >=1 THEN
                -- INACTIVO LA VGENCIA 
                V_EXEPCION := 1;
                END IF;
                
             END IF;
        END IF;
      
        RETURN V_EXEPCION;
      
        END FT_VALIDA_CONDONACION_PRESCR;

END PKG_VALIDACION_NOVEDADES;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_PLANTILLAS_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDACION_PLANTILLAS_SAP" AS

PROCEDURE SP_VALIDAR_IC AS

V_DIRECCION_SAP VARCHAR2(100);
V_DPTO_SAP VARCHAR2(20);
V_MUNICIPIO_SAP VARCHAR2(20);
V_TELEFONO_SAP VARCHAR2(20);
V_EMAIL_SAP VARCHAR2(100);
V_DIRECCION_RUNT VARCHAR2(100);
V_DPTO_RUNT VARCHAR2(20);
V_MUNICIPIO_RUNT VARCHAR2(20);
V_TELEFONO_RUNT VARCHAR2(20);
V_EMAIL_RUNT VARCHAR2(100);
V_ACTUALIZADO_POR VARCHAR2(500);
V_ERROR VARCHAR2(1000);
V_IDENT VARCHAR2(20);
V_TIPO VARCHAR2(20);
V_NOMBRE_SAP VARCHAR2(50);
V_APELLIDO_SAP VARCHAR2(50);
V_NOMBRE_RUNT VARCHAR2(50);
V_APELLIDO_RUNT VARCHAR2(50);
V_RAZON_SAP VARCHAR2(50);
V_RAZON_RUNT VARCHAR2(50);
V_EXISTE NUMBER;
V_OPCION VARCHAR2(50);
V_CELULAR_RUNT VARCHAR2(50);
V_ERROR_SAP NUMBER;
V_ERROR_RUNT NUMBER;
V_ERROR_SAP_T NUMBER;
V_ERROR_RUNT_T NUMBER;
V_ERROR_RUNT_C NUMBER;
V_ERROR_SAP_E NUMBER;
V_ERROR_RUNT_E NUMBER;
V_LARGO_SAP NUMBER;
V_LARGO_RUNT NUMBER;
V_LARGO_RUNT_T NUMBER;
V_MENSAJE_SAP VARCHAR2(20);
V_MENSAJE_RUNT VARCHAR2(20);
V_CONTADOR NUMBER:=0;
ERRORE VARCHAR(200);


CURSOR IC_SAP (V_IDE VARCHAR2, V_TIP VARCHAR2) IS SELECT * FROM CORRECCION_DATOS.IC_SAP
                  WHERE IDENTIFICACION = V_IDE
                    AND TIPO = V_TIP;
                         
CURSOR IC_RUNT IS SELECT * FROM CORRECCION_DATOS.PLANTILLA_IC_RUNT
                     --WHERE NRO_IDENTIFICACION = '3350184' AND CLASE_IDENTIFICACION = 'CC';
                     WHERE VAL_DIR_DEFAULT = 'RUNT > SAP' AND VAL_DIR_VEHICULO = 'RUNT > SAP';
                      

BEGIN
 
--RECORRO LA INFORMACION DE LA PLANTILLA DE IC A ACTUALIZAR
FOR RUNT IN IC_RUNT LOOP
 BEGIN 
  V_DIRECCION_RUNT :=  TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION (RUNT.DIRECCION_CORRESP)));
  V_DPTO_RUNT := TRIM(RUNT.REGION);
  V_MUNICIPIO_RUNT := TRIM(RUNT.POBLACION);
  V_TELEFONO_RUNT := TRIM(RUNT.TELEFONO);
  V_CELULAR_RUNT := TRIM(RUNT.TELEFONO_MOVIL);
  V_EMAIL_RUNT := TRIM(LOWER(RUNT.E_MAIL));   
  V_IDENT := TRIM(RUNT.NRO_IDENTIFICACION);
  V_TIPO := TRIM(RUNT.CLASE_IDENTIFICACION);
  V_NOMBRE_RUNT := TRIM(UPPER(RUNT.NOMBRE_PILA_INTERLOCUTOR));
  V_APELLIDO_RUNT := TRIM(UPPER(RUNT.APELLIDO_INTERLOCUTOR));
  V_RAZON_RUNT := TRIM(UPPER(RUNT.NOMBRE1_ORGANIZACION));
  
  --RECORRO LA INFORMACION DE SAP ANTES DE ACTUALIZAR
  FOR SAP IN IC_SAP (V_IDENT,V_TIPO) LOOP
   
   BEGIN
   V_CONTADOR := V_CONTADOR+1;
   
    V_ACTUALIZADO_POR:=NULL;
    V_ERROR:='';
    
    --ESTANDARIZO DIRECCI�N DE SAP PARA PODER COMPARAR
    V_DIRECCION_SAP := TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(SAP.DIRECCION)));
    V_DPTO_SAP := TRIM(SAP.DEPTO);
    V_MUNICIPIO_SAP := TRIM(SAP.MUNICIPIO);
    V_TELEFONO_SAP :=TRIM(SAP.TELEFONO);
    V_EMAIL_SAP := TRIM(LOWER(SAP.EMAIL));
    V_NOMBRE_SAP := TRIM(UPPER(SAP.NOMBRE));
    V_APELLIDO_SAP := TRIM(UPPER(SAP.APELLIDO));
    V_RAZON_SAP := TRIM(UPPER(SAP.RAZON_SOCIAL));

    --ACTUALIZO DIRECCION SAP.
    UPDATE CORRECCION_DATOS.IC_SAP
       SET DIRECCION = V_DIRECCION_SAP
     WHERE IDENTIFICACION = SAP.IDENTIFICACION
       AND TIPO = SAP.TIPO
       AND TIPO_DIR =SAP.TIPO_DIR;
     --ACTUALIZO DIRECCION RUNT  
    IF V_CONTADOR = 1 THEN
     UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
        SET DIRECCION_CORRESP =  V_DIRECCION_RUNT,
            DIRECCION_NOT_VEH = V_DIRECCION_RUNT,
            DIRECCION_RESIDENCIA = V_DIRECCION_RUNT    
      WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
        AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;   
    END IF; 
    COMMIT;  
    
    /*================================INICIO VALIDACION DE DATOS=================================*/
      
      SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,'NO REPORTA',1)>0;
      
        --Si la direcci�n es diferente valido cual de las dos es la mejor
          V_ERROR_SAP:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_SAP,0);
          V_ERROR_RUNT:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_RUNT,0);      
     --------------------****************************************----------------------------------
     IF INSTR(V_DIRECCION_SAP,'#',1) = 0 THEN
        V_DIRECCION_SAP := FT_ASIGNAR_#(V_DIRECCION_SAP);
     END IF;   
     
     IF INSTR(V_DIRECCION_RUNT,'#',1) = 0 THEN
        V_DIRECCION_RUNT := FT_ASIGNAR_#(V_DIRECCION_RUNT);
     END IF;      
     -------------------******************************************---------------------------------
      IF V_EXISTE > 0 THEN
                 
          IF V_ERROR_SAP IN (2,4) THEN    
            V_ERROR := V_ERROR || 'DIR RUNT NO REPORTA, DIR SAP('||V_DIRECCION_SAP||'), ';
          ELSIF (V_ERROR_SAP = 0) THEN
           V_ERROR := 'SAP > RUNT';
          END IF;
          
        V_EXISTE :=0;
      ELSE
      
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,V_DIRECCION_SAP,1)>0;
      
      IF V_EXISTE = 0 THEN   
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_SAP,V_DIRECCION_RUNT,1)>0;       
      END IF;
      
      IF (V_EXISTE = 1) AND (V_DPTO_SAP = V_DPTO_RUNT) AND (V_MUNICIPIO_SAP = V_MUNICIPIO_RUNT) 
         AND ((V_ERROR_SAP = 4) OR ( V_ERROR_SAP = V_ERROR_RUNT)) THEN      
        V_ERROR := V_ERROR || 'RUNT = SAPII';
      ELSE
        
                 
          IF V_ERROR_SAP = 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP = 0 AND V_ERROR_RUNT > 0 THEN
            V_ERROR := 'SAP > RUNT'; --EN ESTE CASO NO ACTUALIZAR
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT > 0 THEN
                       
            --DIRECCION<7            SOLO LETRAS         3 CONSONANTES SEGUIDAS
            IF (V_ERROR_SAP = 1 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
             V_ERROR := 'RUNT > SAP'; 
                 
                  --SOLO LETRAS         DIRECCION<7          SOLO NUMEROS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
                 --SOLO LETRAS          3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP';  
              
                --3 CONSONANTES SEGUIDAS   SOLO LETRAS
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 2)) THEN
              V_ERROR := 'RUNT > SAP?';  
                 
                  --SOLO NUMEROS         SOLO LETRAS         3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 3 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP'; 
              
             --3 CONSONANTES SEGUIDAS    DIRECCION<7         SOLO NUMEROS  
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
              --SI SE REPORTA EL MISMO ERROR PREVALECE RUNT
             ELSIF (V_ERROR_SAP = V_ERROR_RUNT) THEN
               V_ERROR := 'RUNT > SAP'; 
            END IF;       
      
    END IF;
    
    END IF; 
    END IF;  
    
    --V_ACTUALIZADO_POR := V_ERROR;
    
    --VALIDO QUE EL TELEFONO RUNT NO SEA NULL DE SERLO LO ACTUALIZO CON SAP
      V_ERROR_SAP_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_SAP,'T',0);
      V_ERROR_RUNT_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_RUNT,'T',0);
      V_ERROR_RUNT_C := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_CELULAR_RUNT,'T',0);
      V_ERROR_SAP_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_SAP);
      V_ERROR_RUNT_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_RUNT);
     
    --IDENTIFICO EL LARGO PARA DETERMINAR SI EL CELULAR O TELEFONO
      V_LARGO_SAP := NVL(LENGTH(V_TELEFONO_SAP),0);
      V_LARGO_RUNT := NVL(LENGTH(V_CELULAR_RUNT),0);
      V_LARGO_RUNT_T := NVL(LENGTH(V_TELEFONO_RUNT),0);
    
   -- IF V_ERROR = 'RUNT > SAP' THEN
        
     --ACTUALIZO EL TELEFONO SI ES NECESARIO
     
      --IF V_LARGO_SAP = 7 THEN
      
        IF (V_LARGO_SAP = 7) AND (V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0 OR V_LARGO_RUNT_T >7) AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL)THEN      
                 
              UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
               SET TELEFONO = V_TELEFONO_SAP
             WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
               AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;
            
               
               V_TELEFONO_RUNT := V_TELEFONO_SAP;
               V_ACTUALIZADO_POR :=  'TELEFONO SAP, ';     
     --    END IF;     
                 
         ELSIF (V_LARGO_SAP > 9) AND (V_CELULAR_RUNT IS NULL OR  V_ERROR_RUNT_C > 0 OR V_LARGO_RUNT < 10)
                AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL) THEN  
         
        --  IF /*(V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0) AND*/THEN 
          
              UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
                 SET TELEFONO_MOVIL = V_TELEFONO_SAP
               WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                 AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;  
               
                 
                 V_CELULAR_RUNT := V_TELEFONO_SAP;
                 V_ACTUALIZADO_POR := 'CELULAR SAP, ';
         -- END IF;      
                   
        END IF;
      --END IF;
      
      --VALIDACIONES PARA ACTUALIZAR E_MAIL
      IF (V_ERROR_RUNT_E = 0 OR V_ERROR_SAP_E = 0) THEN
       
       SELECT COUNT(1) INTO  V_ERROR_RUNT_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_RUNT),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sincorreo') > 0
          OR LENGTH(V_EMAIL_RUNT)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_RUNT,1,INSTR(V_EMAIL_RUNT,'@')-1))<=3
          OR INSTR(V_EMAIL_RUNT, '@')                = 0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sdf') > 0;
      
       SELECT COUNT(1) INTO  V_ERROR_SAP_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_SAP),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sincorreo') > 0
          OR LENGTH(V_EMAIL_SAP)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_SAP,1,INSTR(V_EMAIL_SAP,'@')-1))<=3
          OR INSTR(V_EMAIL_SAP, '@')                =0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sdf') > 0;
          
      END IF;      
      
      IF (V_EMAIL_RUNT IS NULL OR V_ERROR_RUNT_E > 0) AND (V_ERROR_SAP_E = 0 AND V_EMAIL_SAP IS NOT NULL)THEN
      
         UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
            SET E_MAIL = V_EMAIL_SAP
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;
        
          
          V_EMAIL_RUNT := V_EMAIL_SAP; 
          V_ACTUALIZADO_POR :=  V_ACTUALIZADO_POR || 'EMAIL SAP, ';
      
      END IF;
      
    /*ELS*/IF (V_ERROR = 'SAP > RUNT') OR (V_ERROR = 'RUNT = SAP') THEN
    
    --SE VALIDA SI EL NOMBRE ES IGUAL
      IF RUNT.CLASE_IDENTIFICACION != 'NIT' THEN
      
        IF (V_NOMBRE_RUNT != V_NOMBRE_SAP) OR (V_APELLIDO_RUNT != V_APELLIDO_SAP) THEN
           --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
           UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
              SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES'
            WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
              AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
              AND INCONSISTENCIA NOT LIKE '%NOMBRE%';  
               
        END IF;
      
      ELSE
      
        IF (V_RAZON_RUNT != V_RAZON_SAP) THEN
             --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
             UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
                SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES, '
              WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;  
                 
          END IF;
          
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_TELEFONO_RUNT IS NOT NULL AND V_ERROR_RUNT_T = 0) AND (V_ERROR_SAP_T > 0 OR V_TELEFONO_SAP IS NULL)THEN
        
         UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
            SET ACTUALIZADO_POR = ACTUALIZADO_POR || 'TELEFONO RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION; 
            
      
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_EMAIL_RUNT IS NOT NULL AND V_ERROR_RUNT_E = 0) AND (V_ERROR_SAP_E > 0 OR V_EMAIL_SAP IS NULL) THEN
        
         UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
            SET ACTUALIZADO_POR =  ACTUALIZADO_POR ||'EMIAL RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION; 
       
      
      END IF;
            
    END IF;
    COMMIT;
      
   IF (SAP.TIPO_DIR ='XXDEFAULT') THEN  
    
      UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
       SET VAL_DIR_DEFAULT = V_ERROR,
           ACTUALIZADO_POR = ACTUALIZADO_POR || V_ACTUALIZADO_POR 
     WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
       AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;  
  

    ELSIF (SAP.TIPO_DIR ='ZRESIDVEHI') THEN
    
      UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
         SET VAL_DIR_VEHICULO = V_ERROR,
             ACTUALIZADO_POR = ACTUALIZADO_POR || V_ACTUALIZADO_POR
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;  
   
    
    END IF; 

  EXCEPTION
    WHEN OTHERS THEN  
          ERRORE := SQLERRM;
         UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
           SET ACTUALIZADO_POR = ERRORE
         WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
           AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;         
       COMMIT;         
      CONTINUE;
  END;
   
END LOOP;
  V_CONTADOR :=0;
 EXCEPTION
  WHEN OTHERS THEN  
        ERRORE := SQLERRM;
       UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT
         SET ACTUALIZADO_POR = ERRORE
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;         
     COMMIT;         
    CONTINUE;
  END;
  COMMIT;

END LOOP;

 COMMIT;
END SP_VALIDAR_IC;


--VALIDACION DE OC SAP vs OC RUNT
PROCEDURE SP_VALIDAR_OC AS

/*===============================================================================
  Este procedimiento valida que la informaci�n que se va a actulizar de los OC reportados
  por RUNT no esta ya ingresada en SAP.*/

V_ERROR VARCHAR2(500);
V_CONTADOR NUMBER := 0;
  
CURSOR OC_RUNT IS
       SELECT * FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT;
       
CURSOR OC_SAP (V_PLACA VARCHAR2) IS
       SELECT * FROM CORRECCION_DATOS.OC_SAP 
       WHERE OBJ_CONTRATO = V_PLACA;   
  
BEGIN

FOR RUNT IN OC_RUNT LOOP

    /*UPDATE CORRECCION_DATOS.PLANTILLA_OC_RUNT PR
      SET PR.FECHA_MATRICULA = (SELECT R.FECHA_MATRICULO
                                FROM CORRECCION_DATOS.OC_RUNT R
                                WHERE PR.OBJETO_CONTRATO = R.NRO_PLACA
                                AND ROWNUM = 1)
    WHERE  PR.OBJETO_CONTRATO = RUNT.OBJETO_CONTRATO;
    COMMIT;*/


  FOR SAP IN OC_SAP (RUNT.OBJETO_CONTRATO) LOOP
    
    V_CONTADOR := V_CONTADOR + 1;
    
    V_ERROR:= NULL;
    
    IF RUNT.MODELO != SAP.MODELO THEN
      V_ERROR := 'MODELO <>, ';
    END IF;  
    
    IF RUNT.MARCA != SAP.COD_MARCA THEN
      V_ERROR :=  V_ERROR || 'MARCA <>, ';
    END IF;  
  
    IF RUNT.LINEA != SAP.COD_LINEA THEN
      V_ERROR := V_ERROR || 'LINEA <>, ';
    END IF;    
    
    IF RUNT.CLASE != SAP.COD_CLASE THEN
      V_ERROR := V_ERROR || 'CLASE <>, ';
    END IF;  
    
    IF RUNT.SERVICIO != SAP.COD_USO THEN
      V_ERROR := V_ERROR || 'USO <>, ';
    END IF;  
    
    IF RUNT.CARROCERIA != SAP.COD_CARROCERIA THEN
      V_ERROR := V_ERROR || 'CARROCERIA <>, ';
    END IF; 
      
    IF RUNT.TIPO_CARGA != SAP.TIPO_CARGA THEN
      V_ERROR := V_ERROR || 'TIPO_CARGA <>, ';
    END IF;  
    
    IF RUNT.CILINDRAJE != SAP.CILINDRAJE THEN
      V_ERROR := V_ERROR || 'CILINDRAJE <>, ';
    END IF;
    
    IF RUNT.CAPACIDAD != SAP.CAPACIDAD THEN
      V_ERROR := V_ERROR || 'CAPACIDAD <>, ';
    END IF;
    
    IF RUNT.UNIDAD_TRANSITO != SAP.POBLACION THEN
      V_ERROR := V_ERROR || 'POBLACION <>, ';
    END IF;
    
    IF RUNT.DEPTO_MATRICULA != SAP.DEPTO THEN
      V_ERROR := V_ERROR || 'DEPTO <>, ';
    END IF;
    
    IF TO_DATE(RUNT.FECHA_MATRICULA,'DDMMYYYY') != TO_DATE(REPLACE(SAP.F_MATRICULA,'.'),'DDMMYYYY') THEN
      V_ERROR := V_ERROR || 'MATRICULA <>, ';
    END IF;
    
    IF V_ERROR IS NULL THEN
      V_ERROR := 'RUNT = SAP';
    END IF;
    
    
    
    UPDATE CORRECCION_DATOS.PLANTILLA_OC_RUNT
       SET INCONSISTENCIA = V_ERROR
    WHERE OBJETO_CONTRATO = RUNT.OBJETO_CONTRATO;  
    
    IF V_CONTADOR = 100 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;  
  
  END LOOP;

END LOOP;
COMMIT;


END SP_VALIDAR_OC;

--RESULTADOS DEL ANALISIS 
PROCEDURE SP_ANALISIS AS

V_ANALISIS2 VARCHAR2(100);
V_ANALISIS VARCHAR2(100);
V_DEFAULT VARCHAR(100);
V_VEHICULO VARCHAR(100);

CURSOR RUNT IS
SELECT * FROM CORRECCION_DATOS.PLANTILLA_IC_RUNT;

BEGIN

FOR X IN  RUNT LOOP

V_DEFAULT :=X.VAL_DIR_DEFAULT;
V_VEHICULO :=X.VAL_DIR_VEHICULO;

IF (V_VEHICULO = 'RUNT > SAP' AND V_DEFAULT != 'RUNT = SAP') OR 
   (V_DEFAULT = 'RUNT > SAP' AND V_VEHICULO = 'RUNT = SAP') THEN
  
   V_ANALISIS := 'Actualizar linea SAP';

END IF;

--
IF (V_VEHICULO = 'RUNT > SAP' AND V_DEFAULT != 'RUNT = SAP') THEN
  
  V_ANALISIS := 'Actualizar linea SAP';

ELSIF (V_VEHICULO = 'RUNT = SAP' OR V_DEFAULT = 'RUNT = SAP') THEN
  
  V_ANALISIS := 'La direcci�n reportada es igual a SAP DEFAULT O DIR_VEHICULO';
  
ELSIF (V_VEHICULO = 'SAP > RUNT' OR V_DEFAULT = 'SAP > RUNT') THEN
  
  V_ANALISIS := 'Direcci�n SAP mejor que la reportada por RUNT';  

ELSIF (V_VEHICULO = 'RUNT > SAP?' OR V_DEFAULT = 'RUNT > SAP?') THEN
  
  V_ANALISIS := 'Validar si es mejor RUNT que SAP';  
  
ELSIF (V_VEHICULO LIKE 'DIR RUNT%' OR V_DEFAULT LIKE 'DIR RUNT%') THEN
  
  V_ANALISIS := 'Validar si es mejor RUNT que SAP';    
  
END IF;  

IF (X.INCONSISTENCIA LIKE 'NOMBRE%') THEN
  
  V_ANALISIS2 := 'Validar Nombres';    
  
END IF;   

END LOOP;

END SP_ANALISIS;

--QA OC SAP DESPUES DE ACTUALIZAR
PROCEDURE SP_QA_ACTUALIZACION_OC_SAP AS

 V_ERROR VARCHAR2(1000);
 V_CONTADOR NUMBER := 0;
 V_DIFERENCIA NUMBER := 0;

CURSOR CURRUNT (V_PLACA VARCHAR2) IS
SELECT * FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT
WHERE OBJETO_CONTRATO = V_PLACA;

CURSOR CURSAP IS
SELECT * FROM CORRECCION_DATOS.OC_SAP_ACTUALIZADO --;
--WHERE INCONSISTENCIA != 'RUNT = SAP';
WHERE INCONSISTENCIA IS NULL;
--AND NRO_PLACA ='MNP969';

BEGIN

FOR SAP IN CURSAP LOOP

  FOR RUNT IN CURRUNT (SAP.NRO_PLACA) LOOP
    
     V_CONTADOR := V_CONTADOR + 1;
    
    V_ERROR:= NULL;
    
    IF TRIM(RUNT.MODELO) != TRIM(SAP.MODELO) THEN
      V_ERROR := 'MODELO <>, ';
    END IF;  
    
    IF TRIM(RUNT.MARCA) != TRIM(SAP.MARCA) THEN
      V_ERROR :=  V_ERROR || 'MARCA <>, ';
    END IF;  
  
    IF TRIM(RUNT.LINEA) != TRIM(SAP.LINEA) THEN
      V_ERROR := V_ERROR || 'LINEA <>, ';
    END IF;    
    
    IF TRIM(RUNT.CLASE) != TRIM(SAP.CLASE) THEN
      V_ERROR := V_ERROR || 'CLASE <>, ';
    END IF;  
    
    IF TRIM(RUNT.SERVICIO) != TRIM(SAP.SERVICIO) THEN
      V_ERROR := V_ERROR || 'USO <>, ';
    END IF;  
    
    IF TRIM(RUNT.CARROCERIA) != TRIM(SAP.CARROCERIA) THEN
      V_ERROR := V_ERROR || 'CARROCERIA <>, ';
    END IF; 
      
    IF TRIM(RUNT.TIPO_CARGA) != TRIM(SAP.TIPO_CARGA) THEN
      IF TRIM(SAP.CLASE) = '10' AND TRIM(SAP.TIPO_CARGA) IS NULL THEN
        NULL;
      ELSE
        V_ERROR := V_ERROR || 'TIPO_CARGA <>, ';
      END IF;
    END IF;  
    
    IF TRIM(RUNT.CILINDRAJE) != TRIM(SAP.CILINDRAJE) THEN
    
      V_DIFERENCIA := TO_NUMBER(RUNT.CILINDRAJE) - TO_NUMBER(SAP.CILINDRAJE);
      IF V_DIFERENCIA < 0 THEN
        V_DIFERENCIA := TO_NUMBER(SAP.CILINDRAJE) - TO_NUMBER(RUNT.CILINDRAJE);
      END IF;
      IF V_DIFERENCIA > 10 THEN
         V_ERROR := V_ERROR || 'CILINDRAJE <>, ';
      END IF;
      
    END IF;
    
    IF TO_NUMBER(RUNT.CAPACIDAD) != TO_NUMBER(TRIM(SAP.CAPACIDAD)) THEN
      V_ERROR := V_ERROR || 'CAPACIDAD <>, ';
    END IF;
    
    IF TRIM(RUNT.UNIDAD_TRANSITO) != TRIM(SAP.UNIDAD_TRANSITO) THEN
      V_ERROR := V_ERROR || 'POBLACION <>, ';
    END IF;
    
    IF TRIM(RUNT.DEPTO_MATRICULA) != TRIM(SAP.DEPTO_MATRICULA) THEN
      V_ERROR := V_ERROR || 'DEPTO <>, ';
    END IF;
    
    IF TO_DATE(TRIM(RUNT.FECHA_MATRICULA),'DDMMYYYY') != TO_DATE(REPLACE(TRIM(SAP.FECHA_MATRICULA),'.'),'DDMMYYYY') THEN
      V_ERROR := V_ERROR || 'MATRICULA <>, ';
    END IF;
    
     IF TRIM(RUNT.LIQ_ACTIVA) != TRIM(SAP.LIQ_ACTIVA) THEN
      V_ERROR := V_ERROR || 'LIQ_ACTIVA <>, ';
    END IF;
    
    IF V_ERROR IS NULL THEN
      V_ERROR := 'RUNT = SAP';
    END IF;
    
    
    
    UPDATE CORRECCION_DATOS.OC_SAP_ACTUALIZADO
       SET INCONSISTENCIA = V_ERROR
    WHERE NRO_PLACA = RUNT.OBJETO_CONTRATO;  
    
    IF V_CONTADOR = 100 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;  
  
  
  END LOOP;

COMMIT;
END LOOP;


END SP_QA_ACTUALIZACION_OC_SAP;

--================================================================================================
--============================VALIDACION IC SAP = A IC REPORTADO POR RUNT=========================

/*Descripci�n: Este procedimiento permite validar que la informaci�n generada en plantilla IC RUNT 
               si halla quedado actualizada correctamente en SAP.
               
  Autor: Elvis Alexis Betancur L�pez
  Fecha: 19-10-2015*/
  
PROCEDURE SP_QA_ACTUALIZACION_IC_SAP AS

V_ERROR VARCHAR2(100);
V_CONTADOR NUMBER := 0;
V_DIRECCION_SAP VARCHAR2(100);
V_DIRECCION_RUNT VARCHAR2(100);
V_EXISTE NUMBER :=0;
V_EXISTE# NUMBER :=0;

CURSOR IC_SAP IS
SELECT *
FROM CORRECCION_DATOS.IC_SAP_ACTUALIZADO
WHERE VALIDACION IS NULL;
/*WHERE VALIDACION  LIKE '%DIRE%' 
  OR VALIDACION  LIKE '%POBL%'
  OR VALIDACION  LIKE '%REG%'
  ;*/ 
  --AND INTERLOCUTOR = '1000039245';

--CURSOR IC_RUNT (V_CLASE_IDENTIFICACION VARCHAR2, V_NRO_IDENTIFICACION VARCHAR2)IS
CURSOR IC_RUNT (V_INTERLOCUTOR VARCHAR2)IS
SELECT *
FROM CORRECCION_DATOS.PLANTILLA_IC_RUNT
/*WHERE CLASE_IDENTIFICACION = V_CLASE_IDENTIFICACION
  AND NRO_IDENTIFICACION = V_NRO_IDENTIFICACION;*/
  WHERE INTERLOCUTOR_COMERCIAL = V_INTERLOCUTOR;

BEGIN

FOR SAP IN IC_SAP LOOP
  
  --FOR RUNT IN IC_RUNT (SAP.CLASE_IDENTIFICACION, SAP.IDENTIFICACION) LOOP
  FOR RUNT IN IC_RUNT (SAP.INTERLOCUTOR) LOOP
    V_ERROR:= NULL;
    V_CONTADOR := V_CONTADOR + 1;
    
    
    V_DIRECCION_SAP := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(SAP.DIRECCION_RESIDENCIA);
    V_DIRECCION_RUNT := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(RUNT.DIRECCION_RESIDENCIA);
    
    V_DIRECCION_SAP := TRANSLATE(TRIM(V_DIRECCION_SAP), ' ', '_');
    V_DIRECCION_RUNT := TRANSLATE(TRIM(V_DIRECCION_RUNT), ' ', '_');
    V_DIRECCION_SAP := REPLACE(V_DIRECCION_SAP,'_NO_','_#_');
    V_DIRECCION_RUNT := REPLACE(V_DIRECCION_RUNT,'_NO_','_#_');
    
    V_DIRECCION_SAP := TRANSLATE(TRIM(V_DIRECCION_SAP), '_', ' ');
    V_DIRECCION_RUNT := TRANSLATE(TRIM(V_DIRECCION_RUNT), '_', ' ');
        
      SELECT COUNT (1) INTO V_EXISTE# FROM DUAL
      WHERE INSTR(V_DIRECCION_SAP,'#',1)>0;
      
      BEGIN
      
        IF V_EXISTE# = 0 THEN
          V_DIRECCION_SAP := FT_ASIGNAR_#(V_DIRECCION_SAP);
        END IF;
        
        V_EXISTE# := 0;
        SELECT COUNT (1) INTO V_EXISTE# FROM DUAL
        WHERE INSTR(V_DIRECCION_RUNT,'#',1)>0;
        
        IF V_EXISTE# = 0 THEN
          V_DIRECCION_RUNT := FT_ASIGNAR_#(V_DIRECCION_RUNT);
        END IF;
      
      EXCEPTION
      WHEN OTHERS THEN
        NULL;
      END;
      
      
    
    IF TRIM(SAP.IDENTIFICACION) != TRIM(RUNT.NRO_IDENTIFICACION) THEN
       V_ERROR := V_ERROR || 'IDENTIFICACION <>, ';
    END IF;
    
    IF TRIM(SAP.CLASE_IDENTIFICACION) != TRIM(RUNT.CLASE_IDENTIFICACION) THEN
       V_ERROR := V_ERROR || 'CLASE_IDENTIFICACION <>, ';
    END IF;
       
    IF TRIM(SAP.APELLIDOS) != TRIM(RUNT.APELLIDO_INTERLOCUTOR) THEN
      V_ERROR := V_ERROR || 'APELLIDO <>, ';
    END IF;
    
    IF TRIM(SAP.NOMBRES) != TRIM(RUNT.NOMBRE_PILA_INTERLOCUTOR) THEN
      V_ERROR := V_ERROR || 'NOMBRES <>, ';
    END IF;
    
    IF TRIM(SAP.RAZON_SOCIAL) != TRIM(RUNT.NOMBRE1_ORGANIZACION) THEN
      V_ERROR := V_ERROR || 'ORGANIZACION <>, ';
    END IF;
     
      SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,V_DIRECCION_SAP,1)>0;
      
      IF V_EXISTE = 0 THEN   
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_SAP,V_DIRECCION_RUNT,1)>0;       
      END IF;
           
    IF V_EXISTE = 0 THEN
      V_ERROR := V_ERROR || 'DIRECCION <>, ';
    END IF;
    
    IF TRIM(SAP.REGION) != TRIM(RUNT.REGION) THEN
      V_ERROR := V_ERROR || 'REGION <>, ';
    END IF;
    
    IF TRIM(SAP.POBLACION) != TRIM(RUNT.POBLACION) THEN
      V_ERROR := V_ERROR || 'POBLACION <>, ';
    END IF;
    
    IF TRIM(SAP.TELEFONO) != TRIM(RUNT.TELEFONO) THEN
      V_ERROR := V_ERROR || 'TELEFONO <>, ';
    END IF;
    
    IF TRIM(SAP.EMAIL) != TRIM(RUNT.E_MAIL) THEN
      V_ERROR := V_ERROR || 'EMAIL <>';
    END IF;
    
    IF V_ERROR IS NULL THEN
      V_ERROR := 'SAP = RUNT';
    END IF;
    
    UPDATE CORRECCION_DATOS.IC_SAP_ACTUALIZADO
       SET VALIDACION = V_ERROR
     WHERE INTERLOCUTOR = SAP.INTERLOCUTOR;
       
    
    IF V_CONTADOR = 100 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;
        
  END LOOP;

END LOOP;
COMMIT;


END SP_QA_ACTUALIZACION_IC_SAP;


--================================================================================================
--============================VALIDACION IC SAP = A IC NUEVOS REPORTADO POR RUNT=========================

/*Descripci�n: Este procedimiento permite validar que la informaci�n generada en plantilla IC RUNT 
               si halla quedado actualizada correctamente en SAP.
               
  Autor: Elvis Alexis Betancur L�pez
  Fecha: 10-11-2015*/
  
PROCEDURE SP_QA_ACTUALIZACION_IC_SAP_N AS

V_ERROR VARCHAR2(100);
V_CONTADOR NUMBER := 0;
V_DIRECCION_SAP VARCHAR2(100);
V_DIRECCION_RUNT VARCHAR2(100);
V_EXISTE NUMBER :=0;
V_EXISTE# NUMBER :=0;

/*
--================================CURSOR POR INTERLOCUTOR ============================
CURSOR IC_SAP IS
SELECT SN.*
FROM CORRECCION_DATOS.IC_SAP_ACTUALIZADO_N SN
INNER JOIN CORRECCION_DATOS.PLANTILLA_IC_RUNT_N RN
ON SN.INTERLOCUTOR = RN.INTERLOCUTOR_COMERCIAL
WHERE (RN.INCONSISTENCIA != 'SAP = RUNT') OR (RN.INCONSISTENCIA IS NULL);

--CURSOR IC_RUNT (V_CLASE_IDENTIFICACION VARCHAR2, V_NRO_IDENTIFICACION VARCHAR2)IS
CURSOR IC_RUNT (V_INTERLOCUTOR VARCHAR2)IS
SELECT *
FROM CORRECCION_DATOS.PLANTILLA_IC_RUNT_N
WHERE CLASE_IDENTIFICACION = V_CLASE_IDENTIFICACION
  AND NRO_IDENTIFICACION = V_NRO_IDENTIFICACION;
  WHERE INTERLOCUTOR_COMERCIAL = V_INTERLOCUTOR;
--=====================================================================================*/

--================================CURSOR POR DOCUMENTO ============================
CURSOR IC_SAP IS
SELECT SN.*
FROM CORRECCION_DATOS.IC_SAP_ACTUALIZADO_N SN
INNER JOIN CORRECCION_DATOS.PLANTILLA_IC_RUNT_N RN
ON SN.IDENTIFICACION = RN.NRO_IDENTIFICACION
AND SN.CLASE_IDENTIFICACION = RN.CLASE_IDENTIFICACION
WHERE (RN.INCONSISTENCIA != 'SAP = RUNT') OR (RN.INCONSISTENCIA IS NULL);

--CURSOR IC_RUNT (V_CLASE_IDENTIFICACION VARCHAR2, V_NRO_IDENTIFICACION VARCHAR2)IS
CURSOR IC_RUNT (V_CLASE_IDENTIFICACION VARCHAR2, V_NRO_IDENTIFICACION VARCHAR2)IS
SELECT *
FROM CORRECCION_DATOS.PLANTILLA_IC_RUNT_N
WHERE CLASE_IDENTIFICACION = V_CLASE_IDENTIFICACION
  AND NRO_IDENTIFICACION = V_NRO_IDENTIFICACION;
 -- WHERE INTERLOCUTOR_COMERCIAL = V_INTERLOCUTOR;
--=====================================================================================


BEGIN

FOR SAP IN IC_SAP LOOP
  
 
  FOR RUNT IN IC_RUNT (SAP.CLASE_IDENTIFICACION, SAP.IDENTIFICACION) LOOP
    V_ERROR:= NULL;
    V_CONTADOR := V_CONTADOR + 1;
    
    
    V_DIRECCION_SAP := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(SAP.DIRECCION_RESIDENCIA);
    V_DIRECCION_RUNT := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(RUNT.DIRECCION_RESIDENCIA);
    
    V_DIRECCION_SAP := TRANSLATE(TRIM(V_DIRECCION_SAP), ' ', '_');
    V_DIRECCION_RUNT := TRANSLATE(TRIM(V_DIRECCION_RUNT), ' ', '_');
    V_DIRECCION_SAP := REPLACE(V_DIRECCION_SAP,'_NO_','_#_');
    V_DIRECCION_RUNT := REPLACE(V_DIRECCION_RUNT,'_NO_','_#_');
    
    V_DIRECCION_SAP := TRANSLATE(TRIM(V_DIRECCION_SAP), '_', ' ');
    V_DIRECCION_RUNT := TRANSLATE(TRIM(V_DIRECCION_RUNT), '_', ' ');
        
      SELECT COUNT (1) INTO V_EXISTE# FROM DUAL
      WHERE INSTR(V_DIRECCION_SAP,'#',1)>0;
      
      BEGIN
      
        IF V_EXISTE# = 0 THEN
          V_DIRECCION_SAP := FT_ASIGNAR_#(V_DIRECCION_SAP);
        END IF;
        
        V_EXISTE# := 0;
        SELECT COUNT (1) INTO V_EXISTE# FROM DUAL
        WHERE INSTR(V_DIRECCION_RUNT,'#',1)>0;
        
        IF V_EXISTE# = 0 THEN
          V_DIRECCION_RUNT := FT_ASIGNAR_#(V_DIRECCION_RUNT);
        END IF;
      
      EXCEPTION
      WHEN OTHERS THEN
        NULL;
      END;
      
      
    
    IF TRIM(SAP.IDENTIFICACION) != TRIM(RUNT.NRO_IDENTIFICACION) THEN
       V_ERROR := V_ERROR || 'IDENTIFICACION <>, ';
    END IF;
    
    IF TRIM(SAP.CLASE_IDENTIFICACION) != TRIM(RUNT.CLASE_IDENTIFICACION) THEN
       V_ERROR := V_ERROR || 'CLASE_IDENTIFICACION <>, ';
    END IF;
       
    IF TRIM(SAP.APELLIDOS) != TRIM(RUNT.APELLIDO_INTERLOCUTOR) THEN
      V_ERROR := V_ERROR || 'APELLIDO <>, ';
    END IF;
    
    IF TRIM(SAP.NOMBRES) != TRIM(RUNT.NOMBRE_PILA_INTERLOCUTOR) THEN
      V_ERROR := V_ERROR || 'NOMBRES <>, ';
    END IF;
    
    IF TRIM(SAP.RAZON_SOCIAL) != TRIM(RUNT.NOMBRE1_ORGANIZACION) THEN
      V_ERROR := V_ERROR || 'ORGANIZACION <>, ';
    END IF;
     
      SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,V_DIRECCION_SAP,1)>0;
      
      IF V_EXISTE = 0 THEN   
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_SAP,V_DIRECCION_RUNT,1)>0;       
      END IF;
           
    IF V_EXISTE = 0 THEN
      V_ERROR := V_ERROR || 'DIRECCION <>, ';
    END IF;
    
    IF TRIM(SAP.REGION) != TRIM(RUNT.REGION) THEN
      V_ERROR := V_ERROR || 'REGION <>, ';
    END IF;
    
    IF TRIM(SAP.POBLACION) != TRIM(RUNT.POBLACION) THEN
      V_ERROR := V_ERROR || 'POBLACION <>, ';
    END IF;
    
    IF TRIM(SAP.TELEFONO) != TRIM(RUNT.TELEFONO) THEN
      V_ERROR := V_ERROR || 'TELEFONO <>, ';
    END IF;
    
    IF TRIM(SAP.EMAIL) != TRIM(RUNT.E_MAIL) THEN
      V_ERROR := V_ERROR || 'EMAIL <>';
    END IF;
    
    IF V_ERROR IS NULL THEN
      V_ERROR := 'SAP = RUNT';
    END IF;
    
    UPDATE CORRECCION_DATOS.PLANTILLA_IC_RUNT_N
       SET INCONSISTENCIA = V_ERROR
     WHERE CLASE_IDENTIFICACION = SAP.CLASE_IDENTIFICACION
       AND NRO_IDENTIFICACION = SAP.IDENTIFICACION;
    
    IF V_CONTADOR = 100 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;
        
  END LOOP;

END LOOP;
COMMIT;


END SP_QA_ACTUALIZACION_IC_SAP_N;



--ESTA FUNCION PERMITE COLOCAR EL # A LAS DIRECCIONES QUE NO LO TIENEN
FUNCTION FT_ASIGNAR_# (V_CADENA VARCHAR2)RETURN VARCHAR2 AS

V_LONGITUD NUMBER := 0;
V_POSICION NUMBER := 0;
V_CONTADOR NUMBER := 1;
V_CARACTER VARCHAR2(2);
V_CADENA_RETORNO2 VARCHAR2(100);
V_ESTANDAR VARCHAR2(100);
V_TIPO VARCHAR2(10);
V_ANTERIOR VARCHAR2(10):='1';
V_ESPACIO VARCHAR2(10);
V_CADENA_RETORNO VARCHAR2(100);
V_BANDERA NUMBER :=0;

BEGIN

BEGIN

 V_CADENA_RETORNO := V_CADENA;
    
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    
  V_LONGITUD := LENGTH (V_CADENA_RETORNO);

WHILE V_CONTADOR <= V_LONGITUD
LOOP
  V_CARACTER := SUBSTR(V_CADENA_RETORNO,V_CONTADOR,1);
  
  IF V_CARACTER = ' ' THEN
    V_TIPO := 'Espacio';
    IF V_TIPO <> V_ANTERIOR THEN
        V_ESTANDAR := V_ESTANDAR || 'Espacio';
    END IF;
  ELSIF PKG_DS_ESTANDARIZA_RUNT.FT_ES_NUMERO(V_CARACTER)> 0 THEN
    V_TIPO := 'Numero';
    IF V_TIPO <> V_ANTERIOR THEN
      V_ESTANDAR := V_ESTANDAR || 'Numero';
    END IF;
  ELSE
    V_TIPO := 'Texto';
    IF V_TIPO <> V_ANTERIOR THEN
      V_ESTANDAR := V_ESTANDAR || 'Texto';
    END IF;
  END IF;  
   
  IF V_ESTANDAR = 'TextoEspacioNumeroEspacioNumero' OR -- CLL 10 12 30 debe quedar CLL 10 # 12 30
     V_ESTANDAR = 'TextoEspacioNumeroEspacioTextoEspacioNumero' THEN -- CLL 10 B 12 30 debe quedar CLL 10 B # 12 30
    
     V_CADENA_RETORNO2 := SUBSTR(V_CADENA_RETORNO2,1,V_CONTADOR-1);
     V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || '# ';
     V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || SUBSTR(V_CADENA_RETORNO,V_CONTADOR,V_LONGITUD);
     V_BANDERA := 1;
  END IF;
  
  IF V_BANDERA = 0 THEN
  V_CADENA_RETORNO2 :=  V_CADENA_RETORNO2 || V_CARACTER;
  ELSE
    RETURN V_CADENA_RETORNO2;
    EXIT;--TERMINO EL CICLO
  END IF;
  
  
  V_ANTERIOR := V_TIPO; 
  V_TIPO := NULL;
  V_CONTADOR := V_CONTADOR + 1;
  
  
END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    RETURN V_CADENA;
  END;

END FT_ASIGNAR_#;

--INSERTAR OC EN PLANTILLA OC RUNT
PROCEDURE SP_INSERTAR_PLANTILLA_OC_RUNT AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_PLANTILLA_OC_RUNT;
--WHERE OBJETO_CONTRATO IN ('AAA740');
BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT
  WHERE OBJETO_CONTRATO = X.OBJETO_CONTRATO;

  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.PLANTILLA_OC_RUNT 
    (OBJETO_CONTRATO,	DENOMINACION_OBJETO,	MODELO,	MARCA,	CLASE,	TIPO_CARGA,	SERVICIO,	LINEA,	CARROCERIA,	
     CILINDRAJE,	CAPACIDAD,	UNIDAD_TRANSITO,	DEPTO_MATRICULA,	FECHA_MATRICULA,	LIQ_ACTIVA) 
    VALUES (X.OBJETO_CONTRATO,	X.DENOMINACION_OBJETO,	X.MODELO,	X.MARCA,	X.CLASE,	X.TIPO_CARGA,	X.SERVICIO,	
            X.LINEA,	X.CARROCERIA,	X.CILINDRAJE,	X.CAPACIDAD,	X.UNIDAD_TRANSITO,	X.DEPTO_MATRICULA,	X.FECHA_MATRICULA,	
            X.LIQ_ACTIVA);
  
  ELSE
  
    UPDATE CORRECCION_DATOS.PLANTILLA_OC_RUNT
       SET DENOMINACION_OBJETO = X.DENOMINACION_OBJETO,
           MODELO = X.MODELO,
           MARCA = X.MARCA,
           CLASE = X.CLASE,
           TIPO_CARGA = X.TIPO_CARGA,
           SERVICIO = X.SERVICIO,
           LINEA = X.LINEA,
           CARROCERIA = X.CARROCERIA,
           CILINDRAJE = X.CILINDRAJE,
           CAPACIDAD = X.CAPACIDAD,
           UNIDAD_TRANSITO = X.UNIDAD_TRANSITO,
           DEPTO_MATRICULA = X.DEPTO_MATRICULA,
           FECHA_MATRICULA = X.FECHA_MATRICULA,
           LIQ_ACTIVA = X.LIQ_ACTIVA,
           INCONSISTENCIA = NULL
    WHERE OBJETO_CONTRATO = X.OBJETO_CONTRATO;    
  
  END IF;

  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;

END LOOP;
COMMIT;
END SP_INSERTAR_PLANTILLA_OC_RUNT;

--INSERTAR IC ACTUALIZADOS EN  IC_AP_ACTUALIZADO
PROCEDURE SP_INSERTAR_IC_SAP_ACTUALIZADO AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_IC_SAP_ACTUALIZADO;
--WHERE INTERLOCUTOR = '1002094903';

BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.IC_SAP_ACTUALIZADO
  WHERE INTERLOCUTOR = X.INTERLOCUTOR;
  
  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.IC_SAP_ACTUALIZADO (INTERLOCUTOR,	IDENTIFICACION,	CLASE_IDENTIFICACION,	NOMBRES,	
                APELLIDOS,	RAZON_SOCIAL,	DIRECCION_RESIDENCIA,	REGION,	POBLACION,	TIPO_DIRECCION,	TELEFONO,	EMAIL)
         VALUES (X.INTERLOCUTOR,	X.IDENTIFICACION,	X.CLASE_IDENTIFICACION,	X.NOMBRES,	X.APELLIDOS,	X.RAZON_SOCIAL,	
                 X.DIRECCION_RESIDENCIA,	X.REGION,	X.POBLACION,	X.TIPO_DIRECCION,	X.TELEFONO,	X.EMAIL);

  ELSE
  
  UPDATE CORRECCION_DATOS.IC_SAP_ACTUALIZADO
     SET IDENTIFICACION = X.IDENTIFICACION,
         CLASE_IDENTIFICACION = X.CLASE_IDENTIFICACION,
         NOMBRES = X.NOMBRES,
         APELLIDOS = X.APELLIDOS,
         RAZON_SOCIAL = X.RAZON_SOCIAL,
         DIRECCION_RESIDENCIA = X.DIRECCION_RESIDENCIA,
         REGION = X.REGION,
         POBLACION = X.POBLACION,
         TIPO_DIRECCION = X.TIPO_DIRECCION,
         TELEFONO = X.TELEFONO,
         EMAIL = X.EMAIL,
         VALIDACION = NULL
  WHERE  INTERLOCUTOR = X.INTERLOCUTOR;   
 
  END IF;
  
  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;
  
  END LOOP;
  COMMIT;
  

END SP_INSERTAR_IC_SAP_ACTUALIZADO;




--INSERTAR DATOS EN OC_SAP_ACTUALIZADO
PROCEDURE SP_INSERTAR_OC_SAP_ACTUALIZADO AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_OC_SAP_ACTUALIZADO;
--WHERE NRO_PLACA IN ('COY35B');
BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.OC_SAP_ACTUALIZADO
  WHERE NRO_PLACA = X.NRO_PLACA;

  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.OC_SAP_ACTUALIZADO 
    (NRO_PLACA,	MODELO,	MARCA,	CLASE,	TIPO_CARGA,	SERVICIO,	LINEA,	CARROCERIA,	CILINDRAJE,	CAPACIDAD, UNIDAD_TRANSITO,
     DEPTO_MATRICULA,	FECHA_MATRICULA,	LIQ_ACTIVA) 
    VALUES (X.NRO_PLACA,	X.MODELO,	X.MARCA,	X.CLASE,	X.TIPO_CARGA,	X.SERVICIO,	X.LINEA,	X.CARROCERIA,	X.CILINDRAJE,	
     X.CAPACIDAD, X.UNIDAD_TRANSITO, X.DEPTO_MATRICULA,	X.FECHA_MATRICULA, X.LIQ_ACTIVA);
  
  ELSE
  
    UPDATE CORRECCION_DATOS.OC_SAP_ACTUALIZADO
       SET MODELO = X.MODELO,
           MARCA = X.MARCA,
           CLASE = X.CLASE,
           TIPO_CARGA = X.TIPO_CARGA,
           SERVICIO = X.SERVICIO,
           LINEA = X.LINEA,
           CARROCERIA = X.CARROCERIA,
           CILINDRAJE = X.CILINDRAJE,
           CAPACIDAD = X.CAPACIDAD,
           UNIDAD_TRANSITO = X.UNIDAD_TRANSITO,
           DEPTO_MATRICULA = X.DEPTO_MATRICULA,
           FECHA_MATRICULA = X.FECHA_MATRICULA,
           LIQ_ACTIVA = X.LIQ_ACTIVA,
           INCONSISTENCIA = NULL
    WHERE NRO_PLACA = X.NRO_PLACA;    
  
  END IF;

  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;

END LOOP;
COMMIT;
END SP_INSERTAR_OC_SAP_ACTUALIZADO;


--INSERTAR IC ACTUALIZADOS EN  IC_AP_ACTUALIZADO_N
PROCEDURE SP_INSERT_IC_SAP_ACTUALIZA_N AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_IC_SAP_ACTUALIZADO;
--WHERE INTERLOCUTOR = '1002094903';

BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.IC_SAP_ACTUALIZADO_N
  WHERE INTERLOCUTOR = X.INTERLOCUTOR;
  
  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.IC_SAP_ACTUALIZADO_N (INTERLOCUTOR,	IDENTIFICACION,	CLASE_IDENTIFICACION,	NOMBRES,	
                APELLIDOS,	RAZON_SOCIAL,	DIRECCION_RESIDENCIA,	REGION,	POBLACION,	TIPO_DIRECCION,	TELEFONO,	EMAIL)
         VALUES (X.INTERLOCUTOR,	X.IDENTIFICACION,	X.CLASE_IDENTIFICACION,	X.NOMBRES,	X.APELLIDOS,	X.RAZON_SOCIAL,	
                 X.DIRECCION_RESIDENCIA,	X.REGION,	X.POBLACION,	X.TIPO_DIRECCION,	X.TELEFONO,	X.EMAIL);

  ELSE
  
  UPDATE CORRECCION_DATOS.IC_SAP_ACTUALIZADO_N
     SET IDENTIFICACION = X.IDENTIFICACION,
         CLASE_IDENTIFICACION = X.CLASE_IDENTIFICACION,
         NOMBRES = X.NOMBRES,
         APELLIDOS = X.APELLIDOS,
         RAZON_SOCIAL = X.RAZON_SOCIAL,
         DIRECCION_RESIDENCIA = X.DIRECCION_RESIDENCIA,
         REGION = X.REGION,
         POBLACION = X.POBLACION,
         TIPO_DIRECCION = X.TIPO_DIRECCION,
         TELEFONO = X.TELEFONO,
         EMAIL = X.EMAIL,
         VALIDACION = NULL
  WHERE  INTERLOCUTOR = X.INTERLOCUTOR;   
 
  END IF;
  
  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;
  
  END LOOP;
  COMMIT;
  

END SP_INSERT_IC_SAP_ACTUALIZA_N;

--================================================================================================
--============================VALIDACION IC SAP = A IC NUEVOS REPORTADO POR RUNT=========================

/*Descripci�n: Este procedimiento permite validar que la informaci�n cargada a SAP si halla 
               cargado correctamente.               
  Autor: Elvis Alexis Betancur L�pez
  Fecha: 18-12-2015*/
PROCEDURE SP_QA_ACTUALIZACION_OC_SAP2015 AS

 V_ERROR VARCHAR2(1000);
 V_CONTADOR NUMBER := 0;
 V_DIFERENCIA NUMBER := 0;

CURSOR CURRUNT (V_PLACA VARCHAR2) IS
SELECT * FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015
WHERE OBJETO_CONTRATO = V_PLACA;

CURSOR CURSAP IS
SELECT * FROM CORRECCION_DATOS.OC_SAP_ACTUALIZADO_2015 --;
--WHERE INCONSISTENCIA != 'RUNT = SAP';
WHERE INCONSISTENCIA IS NULL;
--AND NRO_PLACA ='MNP969';

BEGIN

FOR SAP IN CURSAP LOOP

  FOR RUNT IN CURRUNT (SAP.NRO_PLACA) LOOP
    
     V_CONTADOR := V_CONTADOR + 1;
    
    V_ERROR:= NULL;
    
    IF TRIM(RUNT.MODELO) != TRIM(SAP.MODELO) THEN
      V_ERROR := 'MODELO <>, ';
    END IF;  
    
    IF TRIM(RUNT.MARCA) != TRIM(SAP.MARCA) THEN
      V_ERROR :=  V_ERROR || 'MARCA <>, ';
    END IF;  
  
    IF TRIM(RUNT.LINEA) != TRIM(SAP.LINEA) THEN
      V_ERROR := V_ERROR || 'LINEA <>, ';
    END IF;    
    
    IF TRIM(RUNT.CLASE) != TRIM(SAP.CLASE) THEN
      V_ERROR := V_ERROR || 'CLASE <>, ';
    END IF;  
    
    IF TRIM(RUNT.SERVICIO) != TRIM(SAP.SERVICIO) THEN
      V_ERROR := V_ERROR || 'USO <>, ';
    END IF;  
    
    IF TRIM(RUNT.CARROCERIA) != TRIM(SAP.CARROCERIA) THEN
      V_ERROR := V_ERROR || 'CARROCERIA <>, ';
    END IF; 
      
    IF TRIM(RUNT.TIPO_CARGA) != TRIM(SAP.TIPO_CARGA) THEN
      IF TRIM(SAP.CLASE) = '10' AND TRIM(SAP.TIPO_CARGA) IS NULL THEN
        NULL;
      ELSE
        V_ERROR := V_ERROR || 'TIPO_CARGA <>, ';
      END IF;
    END IF;  
    
    IF TRIM(RUNT.CILINDRAJE) != TRIM(SAP.CILINDRAJE) THEN
    
      V_DIFERENCIA := TO_NUMBER(RUNT.CILINDRAJE) - TO_NUMBER(SAP.CILINDRAJE);
      IF V_DIFERENCIA < 0 THEN
        V_DIFERENCIA := TO_NUMBER(SAP.CILINDRAJE) - TO_NUMBER(RUNT.CILINDRAJE);
      END IF;
      IF V_DIFERENCIA > 10 THEN
         V_ERROR := V_ERROR || 'CILINDRAJE <>, ';
      END IF;
      
    END IF;
    
    BEGIN
      IF TO_NUMBER(RUNT.CAPACIDAD) != TO_NUMBER(TRIM(SAP.CAPACIDAD)) THEN
        V_ERROR := V_ERROR || 'CAPACIDAD <>, ';
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      NULL;
    END;
    
    IF TRIM(RUNT.UNIDAD_TRANSITO) != TRIM(SAP.UNIDAD_TRANSITO) THEN
      V_ERROR := V_ERROR || 'POBLACION <>, ';
    END IF;
    
    IF TRIM(RUNT.DEPTO_MATRICULA) != TRIM(SAP.DEPTO_MATRICULA) THEN
      V_ERROR := V_ERROR || 'DEPTO <>, ';
    END IF;
    
    BEGIN
      IF TO_DATE(TRIM(RUNT.FECHA_MATRICULA),'DDMMYYYY') != TO_DATE(REPLACE(TRIM(SAP.FECHA_MATRICULA),'.'),'DDMMYYYY') THEN
        V_ERROR := V_ERROR || 'MATRICULA <>, ';
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
      NULL;
    END;
    
     IF TRIM(RUNT.LIQ_ACTIVA) != TRIM(SAP.LIQ_ACTIVA) THEN
      V_ERROR := V_ERROR || 'LIQ_ACTIVA <>, ';
    END IF;
    
    IF V_ERROR IS NULL THEN
      V_ERROR := 'RUNT = SAP';
    END IF;  
    
    UPDATE CORRECCION_DATOS.OC_SAP_ACTUALIZADO_2015
       SET INCONSISTENCIA = V_ERROR
    WHERE NRO_PLACA = RUNT.OBJETO_CONTRATO;  
    
    IF V_CONTADOR = 100 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;  
  
  
  END LOOP;

COMMIT;
END LOOP;


END SP_QA_ACTUALIZACION_OC_SAP2015;


--INSERTAR DATOS EN OC_SAP_ACTUALIZADO_2015
PROCEDURE SP_INSERTAR_OC_SAP_ACT_2015 AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_OC_SAP_ACTUALIZADO;
--WHERE NRO_PLACA IN ('COY35B');
BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.OC_SAP_ACTUALIZADO_2015
  WHERE NRO_PLACA = X.NRO_PLACA;

  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.OC_SAP_ACTUALIZADO_2015 
    (NRO_PLACA,	MODELO,	MARCA,	CLASE,	TIPO_CARGA,	SERVICIO,	LINEA,	CARROCERIA,	CILINDRAJE,	CAPACIDAD, UNIDAD_TRANSITO,
     DEPTO_MATRICULA,	FECHA_MATRICULA,	LIQ_ACTIVA) 
    VALUES (X.NRO_PLACA,	X.MODELO,	X.MARCA,	X.CLASE,	X.TIPO_CARGA,	X.SERVICIO,	X.LINEA,	X.CARROCERIA,	X.CILINDRAJE,	
     X.CAPACIDAD, X.UNIDAD_TRANSITO, X.DEPTO_MATRICULA,	X.FECHA_MATRICULA, X.LIQ_ACTIVA);
  
  ELSE
  
    UPDATE CORRECCION_DATOS.OC_SAP_ACTUALIZADO_2015
       SET MODELO = X.MODELO,
           MARCA = X.MARCA,
           CLASE = X.CLASE,
           TIPO_CARGA = X.TIPO_CARGA,
           SERVICIO = X.SERVICIO,
           LINEA = X.LINEA,
           CARROCERIA = X.CARROCERIA,
           CILINDRAJE = X.CILINDRAJE,
           CAPACIDAD = X.CAPACIDAD,
           UNIDAD_TRANSITO = X.UNIDAD_TRANSITO,
           DEPTO_MATRICULA = X.DEPTO_MATRICULA,
           FECHA_MATRICULA = X.FECHA_MATRICULA,
           LIQ_ACTIVA = X.LIQ_ACTIVA,
           INCONSISTENCIA = NULL
    WHERE NRO_PLACA = X.NRO_PLACA;    
  
  END IF;

  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;

END LOOP;
COMMIT;
END SP_INSERTAR_OC_SAP_ACT_2015;


--INSERTAR OC EN PLANTILLA OC RUNT
PROCEDURE SP_INSERTAR_PLANT_OC_RUNT_15 AS

V_EXISTE NUMBER := 0;
V_CONTADOR NUMBER := 0;

CURSOR OC IS
SELECT * FROM CORRECCION_DATOS.TMP_PLANTILLA_OC_RUNT;
--WHERE OBJETO_CONTRATO IN ('965AAB');
BEGIN

FOR X IN OC LOOP

V_CONTADOR := V_CONTADOR + 1;

  SELECT COUNT(1) 
  INTO V_EXISTE
  FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015
  WHERE OBJETO_CONTRATO = X.OBJETO_CONTRATO;

  IF V_EXISTE = 0 THEN
  
    INSERT INTO CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015 
    (OBJETO_CONTRATO,	DENOMINACION_OBJETO,	MODELO,	MARCA,	CLASE,	TIPO_CARGA,	SERVICIO,	LINEA,	CARROCERIA,	
     CILINDRAJE,	CAPACIDAD,	UNIDAD_TRANSITO,	DEPTO_MATRICULA,	FECHA_MATRICULA,	LIQ_ACTIVA) 
    VALUES (X.OBJETO_CONTRATO,	X.DENOMINACION_OBJETO,	X.MODELO,	X.MARCA,	X.CLASE,	X.TIPO_CARGA,	X.SERVICIO,	
            X.LINEA,	X.CARROCERIA,	X.CILINDRAJE,	X.CAPACIDAD,	X.UNIDAD_TRANSITO,	X.DEPTO_MATRICULA,	X.FECHA_MATRICULA,	
            X.LIQ_ACTIVA);
  
  ELSE
  
    UPDATE CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015
       SET DENOMINACION_OBJETO = X.DENOMINACION_OBJETO,
           MODELO = X.MODELO,
           MARCA = X.MARCA,
           CLASE = X.CLASE,
           TIPO_CARGA = X.TIPO_CARGA,
           SERVICIO = X.SERVICIO,
           LINEA = X.LINEA,
           CARROCERIA = X.CARROCERIA,
           CILINDRAJE = X.CILINDRAJE,
           CAPACIDAD = X.CAPACIDAD,
           UNIDAD_TRANSITO = X.UNIDAD_TRANSITO,
           DEPTO_MATRICULA = X.DEPTO_MATRICULA,
           FECHA_MATRICULA = X.FECHA_MATRICULA,
           LIQ_ACTIVA = X.LIQ_ACTIVA,
           INCONSISTENCIA = NULL
    WHERE OBJETO_CONTRATO = X.OBJETO_CONTRATO;    
  
  END IF;

  IF V_CONTADOR = 500 THEN
    COMMIT;
    V_CONTADOR := 0;
  END IF;

END LOOP;
COMMIT;
END SP_INSERTAR_PLANT_OC_RUNT_15;

END PKG_VALIDACION_PLANTILLAS_SAP;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_PLANT_SAP_2015
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDACION_PLANT_SAP_2015" AS

PROCEDURE SP_VALIDAR_PLANTILLA_2015 AS

V_ERROR VARCHAR2(100);
V_RADICADO NUMBER:=0;
V_LINEA VARCHAR2(100);
V_MARCA VARCHAR2(100);
V_SERVICIO VARCHAR2(100);
V_CLASE VARCHAR2(100);
V_CARROCERIA VARCHAR2(100);
V_SECRETARIA VARCHAR2(100);
V_SECRETARIA_SAP VARCHAR2(100);
V_MODELO VARCHAR2(100);
V_FECHA_MATRICULA VARCHAR2(100);
V_FECHA_MATRICULA_SAP VARCHAR2(100);
V_CILINDRAJE NUMBER :=0;
V_EXISTE NUMBER :=0;
V_CONTADOR NUMBER := 0;
V_DEPTO VARCHAR(5) :=0;
V_CAP_PASAJ NUMBER :=0;
V_CAP_TON NUMBER :=0;
--V_LINEA VARCHAR2(100);

CURSOR PLANTILLA IS
SELECT DISTINCT PR.OBJETO_CONTRATO, PR.MODELO, SL.DESC_LINEA_SAP, SL.DESC_MARCA_SAP,PR.CILINDRAJE,
       SS.DESC_SERVICIO_SAP,SCL.DESC_CLASE_SAP, SCR.DESC_CARROCERIA_SAP,SC.DESC_SECRETARIA_SAP,
       PR.FECHA_MATRICULA, PR.CAPACIDAD       
FROM CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015 PR
INNER JOIN DEPURACION.SAP_LINEAS SL
ON SL.ID_LINEA_SAP = PR.LINEA
INNER JOIN DEPURACION.SAP_SERVICIO SS
ON SS.ID_SERVICIO_SAP = PR.SERVICIO
INNER JOIN DEPURACION.SAP_SECRETARIA SC
ON SC.ID_SECRETARIA_SAP = PR.UNIDAD_TRANSITO
INNER JOIN DEPURACION.SAP_CLASE SCL
ON SCL.ID_CLASE_SAP = PR.CLASE
INNER JOIN DEPURACION.SAP_CARROCERIA SCR
ON SCR.ID_CARROCERIA_SAP = PR.CARROCERIA
--WHERE OBJETO_CONTRATO = 'FHK517';
WHERE INCONSISTENCIA IS NULL;

BEGIN

FOR X IN PLANTILLA LOOP
    
    V_CONTADOR := V_CONTADOR +1;
    V_ERROR := NULL;
    V_FECHA_MATRICULA_SAP := NULL;
    V_FECHA_MATRICULA := NULL;
    V_FECHA_MATRICULA_SAP := X.FECHA_MATRICULA;
    V_SECRETARIA_SAP := X.DESC_SECRETARIA_SAP;
    V_SECRETARIA_SAP := TRANSLATE (V_SECRETARIA_SAP,'�����','AEIOU');
    
    SELECT MAX(ID_RADICADO)
    INTO V_RADICADO
    FROM DEPURACION.DS_VEHICULO
    WHERE NRO_PLACA = X.OBJETO_CONTRATO;
    
    SELECT MODELO,NOMBRE_MARCA, NOMBRE_LINEA, CILINDRAJE, NOMBRE_CLASE, NOMBRE_CARROCERIA, 
           NOMBRE_SERVICIO, NOMBRE_SECRETARIA, FECHA_MATRICULA,CAP_PASAJEROS, CAP_TONELADAS
      INTO V_MODELO,V_MARCA, V_LINEA, V_CILINDRAJE, V_CLASE, V_CARROCERIA, V_SERVICIO, V_SECRETARIA, V_FECHA_MATRICULA, V_CAP_PASAJ, V_CAP_TON
    FROM DEPURACION.DS_VEHICULO
    WHERE NRO_PLACA = X.OBJETO_CONTRATO
    AND ID_RADICADO = V_RADICADO;
    
    --Inicio validaci�n de datos
    IF ((TRIM(V_MODELO)) != (TRIM(X.MODELO))) THEN
        V_ERROR := V_ERROR || 'MODELO, ';
    END IF;
    
    IF ((UPPER(TRIM(V_MARCA))) != (UPPER(TRIM(X.DESC_MARCA_SAP))))THEN
        IF (X.DESC_MARCA_SAP != 'B.M.W' AND V_MARCA != 'BMW') AND 
           (X.DESC_MARCA_SAP != 'BRP/CAN-AM' AND V_MARCA != 'BRP/CAN AM') AND
           (X.DESC_MARCA_SAP != 'BONBARDIER' AND V_MARCA != 'BOMBARDIER') AND
           (X.DESC_MARCA_SAP != 'APE PIAGGIO' AND V_MARCA != 'AP PIAGGIO') THEN           
               V_ERROR := V_ERROR || 'MARCA, ';    
      END IF;
    END IF;
    
    IF ((TRIM(V_CILINDRAJE) != TRIM(X.CILINDRAJE)))THEN
           V_ERROR := V_ERROR || 'CILINDRAJE, '; 
    END IF;
    
    IF ((UPPER(TRIM(V_CLASE))) != (UPPER(TRIM(X.DESC_CLASE_SAP))))THEN
           IF (V_CLASE != 'CAMIONETA' AND X.DESC_CLASE_SAP NOT IN ('CAMIONETA(C)','CAMIONETA(P)'))THEN
           V_ERROR := V_ERROR || 'CLASE, '; 
           END IF;
    END IF;
        
    IF ((UPPER(TRIM(V_SERVICIO))) != (UPPER(TRIM(X.DESC_SERVICIO_SAP))))THEN
           V_ERROR := V_ERROR || 'SERVICIO, '; 
    END IF;
    
   /* IF ((TO_DATE(X.FECHA_MATRICULA,'DDMMYYYY')) != (TO_DATE(REPLACE(V_FECHA_MATRICULA,'/',''),'DDMMYYYY'))) THEN
      V_ERROR := V_ERROR || 'MATRICULA, ';
    END IF;*/
    
    BEGIN
      V_FECHA_MATRICULA_SAP:= TO_DATE(TRIM(X.FECHA_MATRICULA),'DDMMYYYY');
      V_FECHA_MATRICULA := TO_DATE(REPLACE(TRIM(V_FECHA_MATRICULA),'/'),'DDMMYYYY');
    EXCEPTION
    WHEN OTHERS THEN
      V_ERROR := 'MATRICULA RUNT '||V_FECHA_MATRICULA;
    END;    
    
    IF (V_FECHA_MATRICULA_SAP != V_FECHA_MATRICULA) THEN
      V_ERROR := V_ERROR || 'MATRICULA, ';
    END IF;
    
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(V_LINEA)),UPPER(TRIM(X.DESC_LINEA_SAP)),1)>0;
    
    IF V_EXISTE = 0 THEN   
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(X.DESC_LINEA_SAP)),UPPER(TRIM(V_LINEA)),1)>0;       
    END IF;
    
    IF V_EXISTE = 0 THEN
      V_ERROR := V_ERROR || 'LINEA, '; 
    END IF;
    
    V_EXISTE :=0;
    
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(V_SECRETARIA)),UPPER(TRIM(V_SECRETARIA_SAP)),1)>0;
    
    IF V_EXISTE = 0 THEN   
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(V_SECRETARIA_SAP)),UPPER(TRIM(V_SECRETARIA)),1)>0;       
    END IF;
    
    IF V_EXISTE = 0 THEN
      V_ERROR := V_ERROR || 'SECRETARIA, '; 
    END IF;
    
    V_EXISTE :=0;
    
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(V_CARROCERIA)),UPPER(TRIM(X.DESC_CARROCERIA_SAP)),1)>0;
    
    IF V_EXISTE = 0 THEN   
    SELECT COUNT (1) INTO V_EXISTE FROM DUAL
    WHERE INSTR(UPPER(TRIM(X.DESC_CARROCERIA_SAP)),UPPER(TRIM(V_CARROCERIA)),1)>0;       
    END IF;
    
    IF V_EXISTE = 0 THEN
      IF (X.DESC_CARROCERIA_SAP != 'HATCHBACK' AND V_CARROCERIA != 'HATCH BACK') THEN
          V_ERROR := V_ERROR || 'CARROCERIA, '; 
      END IF;
    END IF;
    
    
    IF LENGTH (V_CAP_TON)>2 THEN
       V_CAP_TON := TO_NUMBER(V_CAP_TON/1000);
    END IF;
    
    IF ((V_CAP_PASAJ != X.CAPACIDAD) AND (V_CAP_TON!= X.CAPACIDAD)) THEN
       V_ERROR := V_ERROR || 'CAPACIDAD, '; 
    END IF;   
    
    --SINO HAY ERRORES ACTUALIZO
    IF V_ERROR IS NULL THEN
      V_ERROR := 'RUNT = SAP';
    END IF;
    
    --INSERTO LA VALIDACION
    UPDATE CORRECCION_DATOS.PLANTILLA_OC_RUNT_2015
      SET INCONSISTENCIA = V_ERROR
    WHERE OBJETO_CONTRATO = X.OBJETO_CONTRATO;
  
    
    
    IF V_CONTADOR = 500 THEN
      COMMIT;
      V_CONTADOR :=0;
    END IF;    

END LOOP;
COMMIT;

/*===================================================VALIDACIONES DE NEGOCIO SAP============================================*/
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'TARIFA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TARIFA IS NULL AND TIPO_ARCHIVO ='N');
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CLASE OBJETO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE_OBJETO IS NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET GRUPO_AUTORIZACIONES = 'RE02' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE GRUPO_AUTORIZACIONES != 'RE02');
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'OBJETO CONTRATO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE OBJETO_CONTRATO IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'DENOMINACION OBJETO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE DENOMINACION_OBJETO IS NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO IDENTIFICACION NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE NRO_IDENTIFICACION IS NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'IDENTIFICACION, ' WHERE NRO_IDENTIFICACION IN (SELECT NRO_IDENTIFICACION FROM PLANTILLA_OC_RUNT_2015 WHERE INSTR(TRANSLATE(UPPER(NRO_IDENTIFICACION),''||CHR(1)||CHR(2)||CHR(3)||CHR(4)||CHR(5)||CHR(6)||CHR(7)||CHR(8)||CHR(9)||CHR(10)||CHR(11)||CHR(12)||CHR(13)||CHR(14)||CHR(15)||CHR(16)||CHR(17)||CHR(18)||CHR(19)||CHR(20)||CHR(21)||CHR(22)||CHR(23)||CHR(24)||CHR(25)||CHR(26)||CHR(27)||CHR(28)||CHR(29)||CHR(30)||CHR(31)||CHR(33)||CHR(34)||CHR(35)||CHR(36)||CHR(37)||CHR(38)||CHR(39)||CHR(40)||CHR(41)||CHR(42)||CHR(43)||CHR(44)||CHR(45)||CHR(46)||CHR(47)||CHR(58)||CHR(59)||CHR(60)||CHR(61)||CHR(62)||CHR(63)||CHR(64)||CHR(91)||CHR(92)||CHR(93)||CHR(94)||CHR(95)||CHR(96)||CHR(97)||CHR(98)||CHR(99)||CHR(100)||CHR(101)||CHR(102)||CHR(103)||CHR(104)||CHR(105)||CHR(106)||CHR(107)||CHR(108)||CHR(109)||CHR(110)||CHR(111)||CHR(112)||CHR(113)||CHR(114)||CHR(115)||CHR(116)||CHR(117)||CHR(118)||CHR(119)||CHR(120)||CHR(121)||CHR(122)||CHR(123)||CHR(124)||CHR(125)||CHR(126)||CHR(127)||CHR(128)||CHR(129)||CHR(130)||CHR(131)||CHR(132)||CHR(133)||CHR(134)||CHR(135)||CHR(136)||CHR(137)||CHR(138)||CHR(139)||CHR(140)||CHR(141)||CHR(142)||CHR(143)||CHR(144)||CHR(145)||CHR(146)||CHR(147)||CHR(148)||CHR(149)||CHR(150)||CHR(151)||CHR(152)||CHR(153)||CHR(154)||CHR(155)||CHR(156)||CHR(157)||CHR(158)||CHR(159)||CHR(160)||CHR(161)||CHR(162)||CHR(163)||CHR(164)||CHR(166)||CHR(167)||CHR(168)||CHR(169)||CHR(170)||CHR(171)||CHR(172)||CHR(173)||CHR(174)||CHR(175)||CHR(176)||CHR(177)||CHR(178)||CHR(179)||CHR(180)||CHR(181)||CHR(182)||CHR(183)||CHR(184)||CHR(185)||CHR(186)||CHR(187)||CHR(188)||CHR(189)||CHR(190)||CHR(191)||CHR(192)||CHR(193)||CHR(194)||CHR(195)||CHR(196)||CHR(197)||CHR(198)||CHR(199)||CHR(200)||CHR(201)||CHR(202)||CHR(203)||CHR(204)||CHR(205)||CHR(206)||CHR(207)||CHR(208)||CHR(209)||CHR(210)||CHR(211)||CHR(212)||CHR(213)||CHR(214)||CHR(215)||CHR(216)||CHR(217)||CHR(218)||CHR(219)||CHR(220)||CHR(221)||CHR(222)||CHR(223)||CHR(224)||CHR(225)||CHR(226)||CHR(227)||CHR(228)||CHR(229)||CHR(230)||CHR(231)||CHR(232)||CHR(233)||CHR(234)||CHR(235)||CHR(236)||CHR(237)||CHR(238)||CHR(239)||CHR(240)||CHR(241)||CHR(242)||CHR(243)||CHR(244)||CHR(245)||CHR(246)||CHR(247)||CHR(248)||CHR(249)||CHR(250)||CHR(251)||CHR(252)||CHR(253)||CHR(254)||CHR(255)||'','*********************************************************************************************************************************************************************** '),'* ') <> 0 );
--UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CUENTA_CONTRATO = '02' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TIPO_CUENTA_CONTRATO != '02');
--UPDATE PLANTILLA_OC_RUNT_2015 SET FACTURA_SEPARADA = 'X' WHERE FACTURA_SEPARADA != 'X';
--UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_FACTURA = '02' WHERE TIPO_FACTURA != '02';
--UPDATE PLANTILLA_OC_RUNT_2015 SET PERIODICIDAD_CORRESPONDENCIA = 'Inmediatamente' WHERE PERIODICIDAD_CORRESPONDENCIA != 'Inmediatamente';
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO PLACA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE OBJETO_CONTRATO IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'FORMATO PLACA, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TRANSLATE(TRANSLATE(UPPER(OBJETO_CONTRATO),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','**************************'),'0123456789','@@@@@@@@@@') NOT IN ('***@@@','***@@','***@@*', '**@@@@', '**@@@', '@@@***'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'PLACA CARAC ESPECIAL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE INSTR(TRANSLATE(UPPER(OBJETO_CONTRATO),''||CHR(1)||CHR(2)||CHR(3)||CHR(4)||CHR(5)||CHR(6)||CHR(7)||CHR(8)||CHR(9)||CHR(10)||CHR(11)||CHR(12)||CHR(13)||CHR(14)||CHR(15)||CHR(16)||CHR(17)||CHR(18)||CHR(19)||CHR(20)||CHR(21)||CHR(22)||CHR(23)||CHR(24)||CHR(25)||CHR(26)||CHR(27)||CHR(28)||CHR(29)||CHR(30)||CHR(31)||CHR(33)||CHR(34)||CHR(35)||CHR(36)||CHR(37)||CHR(38)||CHR(39)||CHR(40)||CHR(41)||CHR(42)||CHR(43)||CHR(44)||CHR(45)||CHR(46)||CHR(47)||CHR(58)||CHR(59)||CHR(60)||CHR(61)||CHR(62)||CHR(63)||CHR(64)||CHR(91)||CHR(92)||CHR(93)||CHR(94)||CHR(95)||CHR(96)||CHR(97)||CHR(98)||CHR(99)||CHR(100)||CHR(101)||CHR(102)||CHR(103)||CHR(104)||CHR(105)||CHR(106)||CHR(107)||CHR(108)||CHR(109)||CHR(110)||CHR(111)||CHR(112)||CHR(113)||CHR(114)||CHR(115)||CHR(116)||CHR(117)||CHR(118)||CHR(119)||CHR(120)||CHR(121)||CHR(122)||CHR(123)||CHR(124)||CHR(125)||CHR(126)||CHR(127)||CHR(128)||CHR(129)||CHR(130)||CHR(131)||CHR(132)||CHR(133)||CHR(134)||CHR(135)||CHR(136)||CHR(137)||CHR(138)||CHR(139)||CHR(140)||CHR(141)||CHR(142)||CHR(143)||CHR(144)||CHR(145)||CHR(146)||CHR(147)||CHR(148)||CHR(149)||CHR(150)||CHR(151)||CHR(152)||CHR(153)||CHR(154)||CHR(155)||CHR(156)||CHR(157)||CHR(158)||CHR(159)||CHR(160)||CHR(161)||CHR(162)||CHR(163)||CHR(164)||CHR(166)||CHR(167)||CHR(168)||CHR(169)||CHR(170)||CHR(171)||CHR(172)||CHR(173)||CHR(174)||CHR(175)||CHR(176)||CHR(177)||CHR(178)||CHR(179)||CHR(180)||CHR(181)||CHR(182)||CHR(183)||CHR(184)||CHR(185)||CHR(186)||CHR(187)||CHR(188)||CHR(189)||CHR(190)||CHR(191)||CHR(192)||CHR(193)||CHR(194)||CHR(195)||CHR(196)||CHR(197)||CHR(198)||CHR(199)||CHR(200)||CHR(201)||CHR(202)||CHR(203)||CHR(204)||CHR(205)||CHR(206)||CHR(207)||CHR(208)||CHR(209)||CHR(210)||CHR(211)||CHR(212)||CHR(213)||CHR(214)||CHR(215)||CHR(216)||CHR(217)||CHR(218)||CHR(219)||CHR(220)||CHR(221)||CHR(222)||CHR(223)||CHR(224)||CHR(225)||CHR(226)||CHR(227)||CHR(228)||CHR(229)||CHR(230)||CHR(231)||CHR(232)||CHR(233)||CHR(234)||CHR(235)||CHR(236)||CHR(237)||CHR(238)||CHR(239)||CHR(240)||CHR(241)||CHR(242)||CHR(243)||CHR(244)||CHR(245)||CHR(246)||CHR(247)||CHR(248)||CHR(249)||CHR(250)||CHR(251)||CHR(252)||CHR(253)||CHR(254)||CHR(255)||'','*********************************************************************************************************************************************************************** '),'* ') <> 0);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MARCA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE MARCA IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'LINEA NO PERTENECE MARCA, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE (MARCA <> SUBSTR(LINEA,0,2)) AND (MARCA <> SUBSTR(LINEA,0,3)));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MARCA XX, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE MARCA = 'XX');
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'LINEA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE LINEA IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'LINEA 000000, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE (SUBSTR(LINEA,3,8) = '000000' OR SUBSTR(LINEA,4,9) = '000000'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CILINDRAJE IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE INFERIOR 599, ' WHERE OBJETO_CONTRATO IN (SELECT TV.OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 TV INNER JOIN QUIPUX.LIC_TTO LT ON LT.NRO_PLACA = TV.OBJETO_CONTRATO WHERE TV.CILINDRAJE < 599 AND TV.CLASE NOT IN ('10','15','16','17') AND LT.ID_COMBUSTIBLE != '5');
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE INFERIOR 126, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CILINDRAJE < 126 AND CLASE IN ('10','15','16'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CILINDRAJE NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN( '01' ,'05' ,'06' ,'10' ,'15' ,'16') AND CILINDRAJE IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MODELO INFERIOR 1900, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE MODELO < 1900);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MODELO 0000, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE MODELO = 0000 );
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CLASE NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CLASE 00, ' WHERE CLASE = '00';
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CARROCERIA IS NULL AND CLASE NOT IN ('10','16','17'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA 00, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CARROCERIA = '00' AND CLASE NOT   IN ('10','15','16','17'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CAPACIDAD NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CAPACIDAD IS NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET SERVICIO = 0 || SERVICIO WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE SERVICIO NOT LIKE'0%');
--UPDATE PLANTILLA_OC_RUNT_2015 SET CLASICO = 'X' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASICO IS NOT NULL AND CLASICO != 'X');
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'AVALUO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE AVALUO IS NULL AND TIPO_ARCHIVO ='N');
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'AVALUO MENOR O IGUAL 0, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE AVALUO <= 0 AND TIPO_ARCHIVO ='N');
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'VLR FACTURA VEHICULO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE VLR_FACTURA_VEHICULO IS NULL AND TIPO_ARCHIVO ='N');
--UPDATE PLANTILLA_OC_RUNT_2015 SET IMPORTADO = 'N' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE IMPORTADO NOT IN ('I', 'N'));
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NRO MANIFIESTO NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE NRO_MANIFIESTO IS NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET NRO_MANIFIESTO = 'CI' WHERE NRO_MANIFIESTO != 'CI';
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'DEPTOMATRICULA NULL, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE DEPTO_MATRICULA IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'TRANSITO NO PERTENECE AL DEPARTAMENTO, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE LENGTH (UNIDAD_TRANSITO) = 5 AND DEPTO_MATRICULA <> SUBSTR(UNIDAD_TRANSITO,0,2) OR LENGTH (UNIDAD_TRANSITO)= 4 AND DEPTO_MATRICULA <> SUBSTR('0'||UNIDAD_TRANSITO,0,2) OR LENGTH (UNIDAD_TRANSITO) = 3 AND DEPTO_MATRICULA != '05' AND UNIDAD_TRANSITO != '999');
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'DEPTOMATRICULA 00, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE DEPTO_MATRICULA = '00');
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 01, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '01' AND CARROCERIA NOT IN('04','05','06','14', '23','39','46','47','76','77'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 02, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '02' AND CARROCERIA NOT IN('01','02','16','277'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 03, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE  = '03' AND CARROCERIA NOT IN('02','16','17','48','277'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 04, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '04' AND CARROCERIA NOT IN('069','02','07','08','09','11','12','13','15','18','19','21','22','26','27','30','31','32','38','42','49','57','60','61','62','63','64','71','73','74','92','94','119','140','141','231','237','241','276'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 05, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '05' AND CARROCERIA NOT IN('02','03','06','07','08','09','10','11','12','13','14','16','17','19','20','23','24','25','28','29','34','35','42','45','50','56','57','58','59','65','66','72','73','74','75','77','93','94','200','241','277'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 06, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '06' AND CARROCERIA NOT IN('02','03','06','07','08','09','10','13','14','16','20','39','43','77','95'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 07, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '07' AND CARROCERIA NOT IN('01','02','16','17','41','93','277'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 08, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '08' AND CARROCERIA NOT IN('13','21'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 09, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '09' AND CARROCERIA NOT IN('07','08','09','11','12','13','15','19','21','22','26','27','30','31','32','38','60','61','62','63','64','72','140','276'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 10, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('10') AND CARROCERIA NOT IN('00','51','52','55','76'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 11, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE  = '11' AND CARROCERIA NOT IN('70'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 12, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '12' AND CARROCERIA NOT IN('00'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 14, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '14' AND CARROCERIA NOT IN('09','27'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 15, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '15' AND CARROCERIA NOT IN('00','02','03','07','08','10','13','19','37','52','54','55','66','76','241'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 16, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '16' AND CARROCERIA NOT IN('00','52','53','54','76','55'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 17, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '17' AND CARROCERIA NOT IN ('00'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CARROCERIA SIN RELACION A CLASE 79, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '79' AND CARROCERIA NOT IN('41','77','03','65'));
/*UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD= '4' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '01' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '32' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '02' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '20' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '03' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'C', CAPACIDAD = '3' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '04' AND TIPO_CARGA != 'C');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '4' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('04','05','06') AND CAPACIDAD_CARGA IS NULL AND CAPACIDAD_PSJ IS NULL) ;
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '4' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '06' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '10' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '07' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'C', CAPACIDAD = '12' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '08' AND TIPO_CARGA != 'C');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '2' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '09' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P',  CAPACIDAD = '1' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '10' AND TIPO_CARGA != 'P');
*/--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MAQ AGRICOLA, ' WHERE CLASE = '11' ;
--UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'MAQ INDUSTRIAL, ' WHERE CLASE = '12' ;
/*UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD= '5' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '15' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD = '2' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE = '16' AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD= NULL WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN('01','02','03','07','10','15','16') AND TIPO_CARGA != 'P');
UPDATE PLANTILLA_OC_RUNT_2015 SET CAPACIDAD_PSJ = '2', TIPO_CARGA = 'P', CAPACIDAD_CARGA = NULL WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN('01','02','03','07','10','15','16') AND (CAPACIDAD_PSJ IS NULL OR CAPACIDAD_PSJ <= 0));
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'C', CAPACIDAD_CARGA = '12' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('08') AND CAPACIDAD_CARGA IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'C', CAPACIDAD_CARGA = '1' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TIPO_CARGA = 'C' AND CAPACIDAD_CARGA IS NULL );
UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'P', CAPACIDAD_PSJ = '2' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TIPO_CARGA = 'P' AND CAPACIDAD_PSJ IS NULL);
*/UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'TIPO CARGA DIFERENTE DE P � C, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE (TIPO_CARGA NOT IN ('P','C') OR TIPO_CARGA IS NULL) AND CLASE NOT IN ('00','11','12'));
--UPDATE PLANTILLA_OC_RUNT_2015 SET CAPACIDAD_CARGA = NULL WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN('01','02','03','07','10','15','16') AND TIPO_CARGA = 'P' AND CAPACIDAD_CARGA IS NOT NULL);
--UPDATE PLANTILLA_OC_RUNT_2015 SET TIPO_CARGA = 'C', CAPACIDAD_PSJ = NULL, CAPACIDAD_CARGA = '12' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE TIPO_CARGA IS NULL AND CLASE IN ('08'));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'CAPACIDAD NULL, ' WHERE OBJETO_CONTRATO IN (SELECT  OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CAPACIDAD IS NULL);
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 01 � 05 � 06 ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ( '01' , '05', '06' ) AND TIPO_CARGA = 'P' AND ( MODELO  IS NULL OR MARCA IS NULL OR LINEA IS NULL OR SERVICIO IS NULL OR CILINDRAJE IS NULL ));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 02 � 03 � 07, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('02', '03', '07') AND TIPO_CARGA = 'P' AND (MODELO IS NULL OR MARCA IS NULL OR LINEA IS NULL OR SERVICIO IS NULL OR CAPACIDAD IS NULL));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 04 � 05 � 08 � 09 � 14, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('04', '05', '08', '09', '14') AND TIPO_CARGA = 'C' AND (MODELO IS NULL OR MARCA IS NULL OR LINEA IS NULL OR SERVICIO IS NULL OR CAPACIDAD IS NULL));
UPDATE PLANTILLA_OC_RUNT_2015 SET REGISTRO_ERROR = REGISTRO_ERROR || 'NO CUMPLE CON LAS CARACTERISTICAS DE LA CLASE 10 � 15 � 16, ' WHERE OBJETO_CONTRATO IN (SELECT OBJETO_CONTRATO FROM PLANTILLA_OC_RUNT_2015 WHERE CLASE IN ('10', '15', '16') AND ( MODELO IS NULL OR MARCA IS NULL OR LINEA IS NULL OR SERVICIO IS NULL OR CILINDRAJE IS NULL));

COMMIT;
END SP_VALIDAR_PLANTILLA_2015;

/*Estandariza la informaci�n de los 4 mil ID que no estan en el desatrace 2014*/
PROCEDURE SP_ESTANDARIZAR_REGISTRO AS

V_DIRECCION VARCHAR2(200);
V_TELEFONO VARCHAR2(200);
V_NOMBRE VARCHAR2(1000);
V_APELLIDO VARCHAR2(200);
V_IDENTIFICACION VARCHAR2(15);
V_TIPO VARCHAR2(4);
V_DEPARTAMENTO VARCHAR2(8);
V_SECRETARIA VARCHAR2(8);
V_CIUDAD_DIR VARCHAR2(10);
V_CONTADOR NUMBER := 0;

CURSOR IC IS 
SELECT * FROM CORRECCION_DATOS.IC_4100
--WHERE IDENTIFICACION = '71291899';
WHERE A�O_REPORTA_RUNT = 2016;

BEGIN

FOR X IN IC LOOP
BEGIN
V_DIRECCION := X.NUEVA_DIRECCION;
V_NOMBRE := X.NOMBRES;
V_APELLIDO := X.APELLIDOS;
V_TELEFONO := X.TELEFONO;
V_IDENTIFICACION := X.IDENTIFICACION;
--V_TIPO := X.TIPO;
V_CIUDAD_DIR := X.ID_CIUDAD_DIR;

V_DIRECCION := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(V_DIRECCION);
V_NOMBRE := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE (V_NOMBRE,'N');
V_APELLIDO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_NOM_APE (V_APELLIDO,'A');
V_TELEFONO := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_TELEFONO (V_TELEFONO);

V_DEPARTAMENTO := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('D',V_CIUDAD_DIR);
V_SECRETARIA := PKG_GENERAR_PLANTILLA_IC.FT_HOMOLOGAR_SECRETARIA ('S',V_CIUDAD_DIR);

IF V_TIPO = 'N' AND LENGTH(V_IDENTIFICACION) = 9 THEN
  V_IDENTIFICACION := CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_CALCULAR_DIGITO_VERIFICA(V_IDENTIFICACION);
END IF;
/*
BEGIN
  SELECT MIN_DOCUMENTO
  INTO V_TIPO
  FROM QUIPUX.TIPO_DOCUMENTO
  WHERE ABREV_DOCUMENTO = X.TIPO;
EXCEPTION
WHEN OTHERS THEN
  NULL;
END;
*/


UPDATE IC_4100
SET NOMBRES = V_NOMBRE,
    APELLIDOS = V_APELLIDO,
    NUEVA_DIRECCION = V_DIRECCION,
    TELEFONO = V_TELEFONO,
    EMAIL = LOWER(EMAIL),
    SECRETARIA = V_SECRETARIA,
    DEPTO = V_DEPARTAMENTO,
    IDENTIFICACION = V_IDENTIFICACION
    --TIPO = V_TIPO
WHERE IDENTIFICACION = X.IDENTIFICACION
  AND TIPO = X.TIPO;  

IF (V_CONTADOR = 500) THEN
  COMMIT;
  V_CONTADOR := 0;
END IF;

V_CONTADOR := V_CONTADOR +1;
V_TIPO := null;


EXCEPTION
WHEN OTHERS THEN
CONTINUE;
END;


END LOOP;
COMMIT;


END SP_ESTANDARIZAR_REGISTRO;

  
PROCEDURE SP_GENERAR_EXCEPCION (IDENTIFICADOR VARCHAR2,TIPO_IDENTIFICACION VARCHAR2, PARAMETRO NUMBER) AS

MENSAJE VARCHAR2(255);

BEGIN
   MENSAJE := NULL;
   CASE PARAMETRO
          WHEN 1 THEN
              MENSAJE:='DIRECCION<7, ';
          WHEN 2 THEN
              MENSAJE:='DIRECCION SOLO LETRAS, ';
          WHEN 3 THEN
              MENSAJE:='DIRECCION SOLO NUMEROS, ';
          WHEN 4 THEN
              MENSAJE:='DIRECCION 3 CONSONANTES, ';
          WHEN 5 THEN
              MENSAJE:='EMAIL @, ';
          WHEN 6 THEN
              MENSAJE:='E-MAIL<7, ';
          WHEN 7 THEN
              MENSAJE:='E-MAIL NOREGISTRA, ';
          WHEN 8 THEN
              --'EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='TELEFONO NO VALIDO, ';
          WHEN 9 THEN
          --'EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.'
              MENSAJE:='FAX NO ES VALIDO, ';
          WHEN 10 THEN
          -- TELEFONO CON CARACTERES NO VALIDOS
              MENSAJE:='TELEFONO CARACTERES, ';
          WHEN 11 THEN
          --'EL NUMERO DE FAX CONTIENE CARACTERES NO VALIDOS.'
              MENSAJE:='FAX NO VALIDO, ';
          WHEN 12 THEN
          --'EL NUMERO DE TELEFONO NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='TELEFONO 0000000, ';
          WHEN 13 THEN
          --'EL NUMERO DE FAX NO PUEDE TENER 7 CEROS CONSECUTIVOS.'
              MENSAJE:='FAX 0000000, ';
          WHEN 14 THEN
              MENSAJE:= NULL;    
          ELSE
              MENSAJE:='ERROR EN USUARIO '||IDENTIFICADOR;
    END CASE;

    --INSERTO DESCRIPCION DEL ERROR EN TEMP_PLANTILLA_PERSONAS
    UPDATE CORRECCION_DATOS.IC_4100
    SET REGISTRO_ERROR = REGISTRO_ERROR || MENSAJE
    WHERE IDENTIFICACION = IDENTIFICADOR AND
          TIPO_IDENTIFICACION = TIPO_IDENTIFICACION;
    COMMIT;     
    
    /*UPDATE TEMP_PLANTILLA_PERSONASII
    SET REGISTRO_ERROR = REGISTRO_ERROR || MENSAJE
    WHERE NRO_IDENTIFICACION = IDENTIFICADOR AND
          CLASE_IDENTIFICACION = TIPO_IDENTIFICACION;
    COMMIT; */
    
    
          

END SP_GENERAR_EXCEPCION;

/*******************************************************************************************/
  /*ESTE PROCEDIMIENTO REALIZA LAS VALIDACIONES DE NEGOCIO DE LA PLANTILLA CONTRIBUYENTE.*/
PROCEDURE SP_VALIDACIONES_NEGOCIO AS

  V_ERROR NUMBER := 0;
   
  CURSOR CONTRIBUYENTES IS
  SELECT *
  FROM CORRECCION_DATOS.IC_4100
  WHERE A�O_REPORTA_RUNT = 2016;

BEGIN

--LIMPIO LOS ERRORES ANTERIORES
--UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS SET REGISTRO_ERROR =NULL WHERE REGISTRO_ERROR IS NOT NULL;

  FOR XB IN CONTRIBUYENTES LOOP
    
    --VALIDO LA DIRECCION
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(XB.NUEVA_DIRECCION,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
     SP_GENERAR_EXCEPCION(XB.IDENTIFICACION,XB.TIPO, V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(XB.EMAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.IDENTIFICACION,XB.TIPO, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
       SP_GENERAR_EXCEPCION(XB.IDENTIFICACION,XB.TIPO, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL FAX
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
       SP_GENERAR_EXCEPCION(XB.IDENTIFICACION,XB.TIPO, V_ERROR);
       V_ERROR := 0;
    END IF;
     --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);   
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
       SP_GENERAR_EXCEPCION(XB.IDENTIFICACION,XB.TIPO, V_ERROR);
       V_ERROR := 0;
    END IF;
  
  END LOOP;
  
 --VALIDO CAMPOS NULL EN LA PLANTILLA 
 --SP_CAMPOS_NULL;
 
 --APLICO VALIDACIONES DE NEGOCIO SAP
 --SP_VALIDACIONES_NEGOCIO_SAP;

END SP_VALIDACIONES_NEGOCIO;


/*******************************************************************************************/
  /*ESTE PROCEDIMIENTO REALIZA LAS VALIDACIONES DE NEGOCIO DE LA PLANTILLA CONTRIBUYENTE.*/
PROCEDURE SP_VALIDACIONES_NEGOCIO_II AS

  V_ERROR NUMBER := 0;
   
  CURSOR CONTRIBUYENTES IS
  SELECT *
  FROM CORRECCION_DATOS.TEMP_PLANTILLA_PERSONASII;

BEGIN

--LIMPIO LOS ERRORES ANTERIORES
--UPDATE CORRECCION_DATOS.TEMP_PLANTILLA_PERSONAS SET REGISTRO_ERROR =NULL WHERE REGISTRO_ERROR IS NOT NULL;

  FOR XB IN CONTRIBUYENTES LOOP
    
    --VALIDO LA DIRECCION
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(XB.DIRECCION_NOT_VEH,0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
     SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
      V_ERROR := 0;
    END IF;    
    --VALIDO EL EMAIL
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(XB.E_MAIL);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO,'T',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
       SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
    --VALIDO EL FAX
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.FAX,'F',0);
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
      SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
     --VALIDO EL TELEFON
    V_ERROR := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(XB.TELEFONO_MOVIL,'T',0);   
    IF V_ERROR > 0 THEN
      --INSERTO LA EXCEPCION EN EL CAMPO
       SP_GENERAR_EXCEPCION(XB.NRO_IDENTIFICACION,XB.CLASE_IDENTIFICACION, V_ERROR);
       V_ERROR := 0;
    END IF;
  
  END LOOP;
  
 --VALIDO CAMPOS NULL EN LA PLANTILLA 
 --SP_CAMPOS_NULL;
 
 --APLICO VALIDACIONES DE NEGOCIO SAP
 --SP_VALIDACIONES_NEGOCIO_SAP;

END SP_VALIDACIONES_NEGOCIO_II;


END PKG_VALIDACION_PLANT_SAP_2015;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_CARGA_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VALIDAR_CARGA_RUNT" AS

procedure sp_validar_vehiculos as

-- ------------------------------------------------------------- --
--       D E C L A R A C I O N  D E  V A R I A B L E S           --
-- ------------------------------------------------------------- --
lnCilindrajeRunt   number:=0;
lnCilindrajeSap    number:=0;
lnCapacidad        number:=0;
lnNovedadIngresada number:=0;
lnContador         number:=0;
lvTipoCarga        varchar2(1);
lvTipoNovedad      varchar2(2);
lvIdSecretariaRunt varchar2(6);
lvInconsistencia   varchar2(1000);
lvFechaRunt        varchar2(10);
lvFechaSap         varchar2(10);
lvFechaNovSap      varchar2(10);
lvProcesado        varchar2(1);
esNovSap           boolean := true;
esCarroceria       boolean := false;

type tysVehiculoRunt is table of dq_consolidado_vehiculos%Rowtype;
arrayVehiculoRunt tysVehiculoRunt;

cursor curVehiculosSap is
select * 
from dq_tmp_vehiculos_sap 
where procesado = 'P' 
  --and nro_placa like 'XXX%'
  And Rownum <50000;

cursor curVehiculoRunt(lv_nro_placa varchar2) is
    Select *
    From dq_consolidado_vehiculos    
    --Inner join dq_maestro_informacion_runt mr
       --on mr.id_radicado = cv.id_radicado
    where nro_placa = lv_nro_placa
      --and mr.anno_reporta = 2016
      and ID_RADICADO = (Select max(cv.ID_RADICADO)
                     From dq_consolidado_vehiculos cv      
                      Inner join dq_maestro_informacion_runt mr
                         on mr.id_radicado = cv.id_radicado
                      where cv.nro_placa = lv_nro_placa
                        and mr.anno_reporta = 2016); 

begin

 
for indexSap in curVehiculosSap loop

  for indexRunt in curVehiculoRunt(indexSap.nro_placa)loop  
    
    lnCilindrajeRunt   :=0;
    lnCilindrajeSap    :=0;
    lnCapacidad        :=0;
    lnNovedadIngresada :=0;
    lnContador         :=0;
    lvTipoCarga        :=null;
    lvTipoNovedad      :=null;
    lvIdSecretariaRunt :=null;
    lvInconsistencia   :=null;
    lvFechaRunt        :=null;
    lvFechaSap         :=null;
    lvFechaNovSap      :=null;
    lvProcesado        :='I';
    esNovSap           :=true;
    esCarroceria       :=false;
  
  lvInconsistencia := NULL;
  esNovSap := true;  
  
     --Validaci�n Modelo
    if Trim(Upper(indexSap.Modelo)) != Trim(Upper(indexRunt.Modelo)) then
      lvInconsistencia := lvInconsistencia || 'Modelo-';
    End if;
    
    --Validaci�n Servicio
    if Trim(Upper(indexSap.Nombre_Servicio)) != Trim(Upper(indexRunt.Nombre_Servicio)) then
     
      if Ft_Validar_Sinonimo(indexRunt.Nombre_Servicio,indexSap.Nombre_Servicio) = false then
         if(indexSap.id_Servicio in('05','5') and Trim(Upper(indexRunt.Nombre_Combustible)) = 'ELECTRICO')Then  
           Null; 
         Else
          lvInconsistencia := lvInconsistencia || 'Servicio-';
         End If;    
      end if;       
     
    End if;
      
      /*Valido si tiene tramites de cambio servicio*/
      Begin
        Select Tipo_Novedad Into lvTipoNovedad
        From DQ_Novedades_Sap
        Where Nro_Placa = indexRunt.Nro_placa
          and Tipo_Novedad in ('08','14')
          and Fecha_Novedad = (Select max(Fecha_Novedad) 
                          From DQ_Novedades_Sap
                          Where Nro_Placa = indexRunt.Nro_placa
                            and Tipo_Novedad in ('08','14'));
      Exception
      When Others Then
         lvTipoNovedad := '00';
         --Continue;
      End; 
      
      If(lvTipoNovedad = '08' and indexSap.Id_Servicio != '03' )Then
         lvInconsistencia := lvInconsistencia || 'Servicio (Cbio a PA en SAP)-';
      elsIf(lvTipoNovedad = '14' and indexSap.Id_Servicio != '02' )Then
         lvInconsistencia := lvInconsistencia || 'Servicio (Cbio a PU en SAP)-';
      End If;  
      
      Begin
        Select Id_Novedad,Id_Estado Into lvTipoNovedad, lnNovedadIngresada
        from dq_validacion_novedades
        Where nro_placa = indexRunt.Nro_placa
          and id_novedad in ('08','14')
          and Fecha = (Select max(To_Date(Fecha))
                  From dq_validacion_novedades
                 Where Nro_Placa = indexRunt.Nro_placa
                   and id_novedad in ('08','14'));
      Exception
      When Others Then
        lvTipoNovedad := '00';
        --Continue;
      End;
      
      If(lvTipoNovedad = '08' and indexSap.Id_Servicio != '03' )Then
         lvInconsistencia := lvInconsistencia || 'Servicio (08 Confirmado)-';
      elsIf(lvTipoNovedad = '14' and indexSap.Id_Servicio != '02' )Then
         lvInconsistencia := lvInconsistencia || 'Servicio (14 Confirmado)-';
      End If;   
      
    --Validaci�n Marca
    if Trim(Upper(indexSap.Nombre_Marca)) != Trim(Upper(indexRunt.Nombre_Marca)) then
      if Ft_Validar_Sinonimo(indexRunt.Nombre_Marca,indexSap.Nombre_Marca) = false then
        lvInconsistencia := lvInconsistencia || 'Marca-';
      end if;
    End if;
    
    --Validaci�n Linea
    if Trim(Upper(indexSap.Nombre_Linea)) != Trim(Upper(indexRunt.Nombre_Linea)) then
      if Ft_Validar_Sinonimo(indexRunt.Nombre_Linea,indexSap.Nombre_Linea) = false then
        lvInconsistencia := lvInconsistencia || 'Linea-';
      end if;
    End if;
    
    --Validaci�n Clase
    if Trim(Upper(indexSap.Nombre_Clase)) != Trim(Upper(indexRunt.Nombre_Clase)) then
      if Ft_Validar_Sinonimo(indexRunt.Nombre_Clase,indexSap.Nombre_Clase) = false then
        lvInconsistencia := lvInconsistencia || 'Clase-';
      end if;
    End if;
    
    --Validaci�n Carroceria
    if Trim(Upper(indexSap.Nombre_Carroceria)) != Trim(Upper(indexRunt.Nombre_Carroceria)) then
       esCarroceria := true;
       if Ft_Validar_Sinonimo(indexRunt.Nombre_Carroceria,indexSap.Nombre_Carroceria) = true then
          esCarroceria := false;
       end if;      
      -- Si en sap es doble cabina y Runt Camioneta
      if(indexSap.Id_Carroceria in (23,24,28,29,35,56,57,58,59) and indexRunt.Id_Clase =5) then
         esCarroceria := false;
      -- Si en Runt es moto chiva abierta y sap es moto 
      Elsif(indexRunt.Id_Carroceria = '226' and indexRunt.Id_Clase = '10' and indexSap.Id_Clase = '10' )then  
         esCarroceria := false;
      end if;
      
      If(esCarroceria = true) then
          lvInconsistencia := lvInconsistencia || 'Carrocer�a-';
      End if;
       
    End if;    
    
    --Validaci�n Cilindraje
    lnCilindrajeSap := to_number(Trim(Replace(indexSap.Cilindraje,'.',',')));
    lnCilindrajeRunt := to_number(Trim(Replace(indexRunt.Cilindraje,'.',',')));     
    
    if lnCilindrajeSap != lnCilindrajeRunt then
      If(lnCilindrajeRunt != 0)Then
       lvInconsistencia := lvInconsistencia || 'Cilindraje-';
      End if; 
    End if;
    
    --Validaci�n tipo carga
    lvTipoCarga := Ft_Get_TipoCarga(indexSap.Id_Carroceria, indexSap.Id_Clase);
    if  lvTipoCarga != indexSap.Tipo_Carga then
      lvInconsistencia := lvInconsistencia || 'TipoCarga-';
    end if;
    
    --Validaci�n Capacidad
    If  lvTipoCarga = 'C' then
      lnCapacidad := To_Number(indexRunt.Cap_Toneladas)/1000;
      lnCapacidad := Round(lnCapacidad,2);
    Else 
      lnCapacidad := To_Number(indexRunt.Cap_Pasajeros);
    End If;
    
    begin
    If (To_Number(Trim(indexSap.Capacidad)) != lnCapacidad 
        and lnCapacidad is not null and lnCapacidad != 0) then    
        lvInconsistencia := lvInconsistencia || 'Capacidad-';   
    End If; 
    Exception
      when others then
        lvInconsistencia := lvInconsistencia || 'Capacidad-';   
      End;
    
    --Validar Secretaria
    Begin
      Select Id_Ciudad_Sap Into lvIdSecretariaRunt 
      From  Runt_Ciudades Where Divipo = indexRunt.Id_Secretaria;
    Exception
    When Others Then
      lvInconsistencia := lvInconsistencia || 'Homol. Secretaria Runt-';
      --Continue;
    End;
    
      Begin
        Select Id_Novedad,Id_Estado Into lvTipoNovedad, lnNovedadIngresada
        from dq_validacion_novedades
        Where nro_placa = indexRunt.Nro_placa
          and id_novedad in ('06','07')
          and Fecha = (Select max(To_Date(Fecha))
                  From dq_validacion_novedades
                 Where Nro_Placa = indexRunt.Nro_placa
                   and id_novedad in ('06','07'));
      Exception
      When Others Then
        lvTipoNovedad := '00';
        --Continue;
      End;  
      
      --Si no es efectivo el traslado 
      if lvTipoNovedad = '07' And lnNovedadIngresada = 2 then
        if(indexSap.Id_Region  not in ('05','5'))then
           lvInconsistencia := lvInconsistencia || 'Secretaria (07 No efectivo)-';
        end if;

      elsif lvTipoNovedad = '07' And lnNovedadIngresada = 3 then
        if(indexSap.Id_Region not in ('05','5'))then
           lvInconsistencia := lvInconsistencia || 'Secretaria (07 interno)-';
        end if;        
    
      elsif lvTipoNovedad = '07' And lnNovedadIngresada = 1 then 
         if(indexSap.Id_Region in ('05','5'))then
           lvInconsistencia := lvInconsistencia || 'Secretaria (07 efectivo)-';
         end if;
      
      elsif lvTipoNovedad = '06' then 
         if(indexSap.Id_Region not in ('05','5'))then
           lvInconsistencia := lvInconsistencia || 'Secretaria (06 efectivo)-';
         end if; 
      End if;
      
   
    --Valido novedades SAP
      Begin
        Select Tipo_Novedad Into lvTipoNovedad
        From DQ_Novedades_Sap
        Where Nro_Placa = indexRunt.Nro_placa
          and Tipo_Novedad in ('06','07')
          and Fecha_Novedad = (Select max(Fecha_Novedad) 
                          From DQ_Novedades_Sap
                          Where Nro_Placa = indexRunt.Nro_placa
                            and Tipo_Novedad in ('06','07'));
        Exception
        When Others Then
           lvTipoNovedad := '00';
           esNovSap := false;
           --Continue;
        End;  
      
      if lvTipoNovedad = '07' then
         if(indexSap.Id_Region in('05','5'))then
             lvInconsistencia := lvInconsistencia || 'Secretaria (Traslado en SAP)-';
          end if; 
      elsif lvTipoNovedad = '06' then
         if(indexSap.Id_Region not in('05','5'))then
             lvInconsistencia := lvInconsistencia || 'Secretaria (Radicacion en SAP)-';
          end if;             
         
      elsif(indexSap.Id_Secretaria != lvIdSecretariaRunt and esNovSap = false) then
         lvInconsistencia := lvInconsistencia || 'Secretaria diferente-';
      end if;    
       
   
    
    --Validaci�n fecha Matriculo
     lvFechaSap := Trim(replace(indexSap.Fecha_Matriculo,'.',''));
     
    if lvFechaSap != Trim(indexRunt.Fecha_Matriculo) then         
       
      --Consulto fecha de novedades afectan fecha matricula
       Begin
        Select Fecha_novedad Into lvFechaNovSap
        from dq_novedades_sap
        Where nro_placa = indexRunt.Nro_placa
          and Tipo_Novedad in ('04','06','08')
          and Fecha_Novedad = (Select max(Fecha_Novedad) 
                        From DQ_Novedades_Sap
                        Where Nro_Placa = indexRunt.Nro_placa
                          and Tipo_Novedad in ('04','06','08'));
      Exception
      When Others Then
        lvFechaNovSap := '';
        --Continue;
      End;  
      
      If ( lvFechaNovSap is null or (to_date(lvFechaSap,'DDMMYYYY') !=  lvFechaNovSap)) then       
        lvInconsistencia := lvInconsistencia || 'Fecha_Matriculo-';  
      End If;
      
    End if;
    
  end loop;
  
  if lvInconsistencia = '' or lvInconsistencia is null then
    lvInconsistencia := 'Placa OK';
    lvProcesado := 'E';
  end if;
  
  update dq_tmp_vehiculos_sap set estado = lvInconsistencia,
                               procesado = lvProcesado
  where nro_placa = indexSap.Nro_placa; 
  
  if(lnContador = 200) then
      commit;
      lnContador :=0;
  else
    lnContador := lnContador + 1;
  End if;

end loop;

end sp_validar_vehiculos;

-- -------------------------------------------------------------------------- --
--         F U N C I O N   P A R A  V A L I D A R  S I N O N I M O S          --
-- -------------------------------------------------------------------------- --
Function Ft_Validar_Sinonimo(lvDescripcionRunt Varchar2, 
                             lvDescripcionSap Varchar2) Return Boolean As

lnExiste Number:=0;

Begin

Select Count(1) Into lnExiste
From Dq_Sinonimos
Where Descripcion_Runt = Trim(lvDescripcionRunt)
  And Descripcion_Sap = Trim(lvDescripcionSap);
  
If lnExiste > 0 Then
  Return True;
Else
  Return False;
End If;

End Ft_Validar_Sinonimo;

-- -------------------------------------------------------------------------- --
--     F U N C I O N   P A R A  D E T E R M I N A R  T I P O  C A R G A       --
-- -------------------------------------------------------------------------- --
Function Ft_Get_TipoCarga(lvIdCarroceria Varchar2, 
                          lvIdClase Varchar2) Return Varchar2 As

lvTipoCarga Varchar2(1);

Begin
Begin
Select Tipo_Carga Into lvTipoCarga
From Dq_Carroceria_X_Clase
Where Id_Clase = lvIdClase
  And Id_Carroceria = lvIdCarroceria;
  
Return lvTipoCarga;

Exception 
  When Others then
    return '';   
End;    

End Ft_Get_TipoCarga;

-- -------------------------------------------------------------------------- --
--       P R O C E D I M I E N T O   V A L I D A R  P R O P I E T A R I O     --
-- -------------------------------------------------------------------------- --
Procedure Sp_Validar_Propietarios as

lv_EstadoRunt  varchar2(20);
lv_EstadoSap   varchar2(30);
lv_TipoDoc varchar2(6);

Cursor curPropietarios is
Select * from Dq_Tmp_Propietarios_Runt
where Procesado = 'L';

Type tysPropietario is table of curPropietarios%RowType;
arrayProp tysPropietario;

Begin
Open curPropietarios;
  Loop Fetch curPropietarios 
     Bulk Collect into arrayProp Limit 200; 
       For lnIndex in 1..arrayProp.count() loop
       
        lv_TipoDoc := Ft_Homologar_Tipo_Documento(arrayProp(lnIndex).Id_Documento,'S');
       
        lv_EstadoRunt := Ft_Estado_Propietario(arrayProp(lnIndex).Nro_Placa, 
                arrayProp(lnIndex).Id_Usuario,arrayProp(lnIndex).Id_Documento);
                
        lv_EstadoSap := Ft_Estado_Propietario_Sap(arrayProp(lnIndex).Nro_Placa, 
                arrayProp(lnIndex).Id_Usuario, lv_TipoDoc);
        
        if(lv_EstadoSap = '4-Asociar') then
          --Valido si tiene actualizaci� posterior.
          if(Ft_Asociacion_Posterior(arrayProp(lnIndex).Nro_Placa, 
                arrayProp(lnIndex).Id_Usuario, lv_TipoDoc,
                  arrayProp(lnIndex).Fecha) = true)then
                  
            lv_EstadoSap := '5-Act. Posterior';
            
          End If;  
            
        end if;
        
        Update Dq_Tmp_Propietarios_Runt 
           set Estado_Sap = lv_EstadoSap,
               Tipo_Runt = lv_EstadoRunt,
               Procesado = 'S' 
         Where Nro_Placa =  arrayProp(lnIndex).Nro_Placa
           and Id_Usuario = arrayProp(lnIndex).Id_Usuario
           and Id_Documento = arrayProp(lnIndex).Id_Documento;     
       End Loop;
       Commit;
       Exit when arrayProp.count()<=0;       
  End Loop;
  Commit;

End Sp_Validar_Propietarios;

-- -------------------------------------------------------------------------- --
--        F U N C I O N  A C T U A L I Z A C I � N  P O S T E R I O R         --
-- Objetivo: Determinar si se hizo una actualizaci�n posterior                --
-- -------------------------------------------------------------------------- --
Function Ft_Asociacion_Posterior(lfNroPlaca varchar2, lfidPropietario varchar2,                                    
                       lftipoDocumento varchar2,lfFecha date)return boolean as                              
ln_Existe number := 0;
lv_UltimoTraspaso varchar2(10);

Begin

Select count(1) Into ln_Existe
from DQ_tmp_propietarios_sap
where nro_placa = lfNroPlaca 
  and Fecha_Asocia_Ic_Vh > lfFecha
  and (obsoleto is null or obsoleto = '')
  and (Bloqueo_Correspondencia is null or Bloqueo_Correspondencia ='')
  and ((usuario || Tipo_Documento) != (lfidPropietario || lftipoDocumento));
 
if(ln_Existe>0)then
  Return true;
else
  Return false;
end if;

End Ft_Asociacion_Posterior;


-- -------------------------------------------------------------------------- --
--             F U N C I O N  E S T A D O  P R O P I E T A R I O              --
-- Objetivo: Determinar si el propietario a validar si es propietario actual  --
-- -------------------------------------------------------------------------- --
Function Ft_Estado_Propietario(lfNroPlaca varchar2, lfidPropietario varchar2,
                               lftipoDocumento varchar2)return Varchar2 as
ln_Existe number := 0;
lv_Estado varchar2(20);
lv_UltimoTraspaso varchar2(10);

Begin
 lv_Estado:= null;
  begin-- Consulto la fecha del �ltimo tr�mite
       Select Fecha_Tramite into lv_UltimoTraspaso
      from Dq_Consolidado_Tramites ct     
     where id_tramite in (16,65)
       and Nro_placa = lfNroPlaca
       and Ct.Fecha_Tramite = 
              (Select max(to_date(decode(length(Ct.Fecha_Tramite), 7,
                                         '0'||Ct.Fecha_Tramite,
                                              Ct.Fecha_Tramite)))
                From Dq_Consolidado_Tramites ct 
               inner join Dq_Maestro_Informacion_Runt mf
                  on Mf.Id_Radicado = Ct.Id_Radicado    
               where Mf.Anno_Reporta = 2016
                 and id_tramite in (16,65)
                 and Nro_placa = lfNroPlaca);
  Exception 
    when others then
      lv_UltimoTraspaso := '';       
    end;

  if(lv_UltimoTraspaso != '' or lv_UltimoTraspaso is not null) then
      
       Select count(1) into ln_existe --Valido si es propietario actual;
        from Dq_Consolidado_Tramites ct
       inner join Dq_Maestro_Informacion_Runt mf
          on Mf.Id_Radicado = Ct.Id_Radicado    
       where Mf.Anno_Reporta = 2016
         and Nro_placa = lfNroPlaca
         and fecha_tramite = lv_UltimoTraspaso 
         and Id_Usuario_Nuevo = lfidPropietario
         and Id_Documento_Nuevo = lftipoDocumento;
       
       if(ln_existe > 0) then
        lv_Estado := 'Actual';
        
        Select count(1) into ln_existe --Valido que el usuario no haya vendido
        from Dq_Consolidado_Tramites ct
       inner join Dq_Maestro_Informacion_Runt mf
          on Mf.Id_Radicado = Ct.Id_Radicado    
       where Mf.Anno_Reporta = 2016
         and Nro_placa = lfNroPlaca
         and fecha_tramite = lv_UltimoTraspaso 
         and Id_Usuario_anterior = lfidPropietario
         and Id_Documento_anterior = lftipoDocumento;
         
         if(ln_existe>0) then
          lv_Estado := 'Vendedor';
         end if;
        
       else
        lv_Estado := 'Vendedor';
       end if;
      
      else
        lv_Estado := 'Actual';
      End if;
      
  return lv_Estado;


End Ft_Estado_Propietario;

-- -------------------------------------------------------------------------- --
--         F U N C I O N  E S T A D O  P R O P I E T A R I O  S A P           --
-- Objetivo: Determinar si el propietario a validar si es propietario actual  --
-- -------------------------------------------------------------------------- --
Function Ft_Estado_Propietario_Sap(lfNroPlaca varchar2, lfidPropietario varchar2,
                               lftipoDocumento varchar2)return Varchar2 as
ln_Existe number := 0;
lv_Obsoleto varchar2(1) := null;
lv_Correspondencia varchar2(1):= null;
lv_Placa varchar2(7):= null;
lv_Resultado varchar2(200):= null;

Begin

  Begin
    Select Nro_Placa, Obsoleto, Bloqueo_Correspondencia
      into lv_Placa, lv_Obsoleto, lv_Correspondencia 
      from Dq_Tmp_Propietarios_Sap
     where Nro_Placa = lfNroPlaca 
       and Usuario = lfidPropietario
       and Tipo_Documento = lftipoDocumento;
  Exception
    When Others Then
      null;
    End;  
    
  if lv_Obsoleto = 'X' then
    lv_Resultado := '2-Obsoleto';
  elsif lv_Correspondencia = 'X' then
    lv_Resultado := '3-Correspondencia';
  elsif lv_Placa is not null then
    lv_Resultado := '1-Activo'; 
  else
     lv_Resultado := '4-Asociar'; 
  end if;
  
  Return Lv_Resultado;

End Ft_Estado_Propietario_Sap;


-- -------------------------------------------------------------------------- --
--   F U N C I O N  H O M O L O G A R  T I P O  D O C U M E N T O  S A P      --
-- Objetivo: Homologar tipo documento Runt a SAP                              --
-- Par�metros: lfTipoDocumento, tipo de documento a homologar
--             lfParametro. tipo de homologaci�n 'S' Retorna c�dificaci�n SAP;
--                          'R' retorna c�dificaci�n Runt     
-- -------------------------------------------------------------------------- --
Function Ft_Homologar_Tipo_Documento(lfTipoDocumento varchar2, 
                                    lfParametro varchar2)return Varchar2 as
lv_Retorno varchar2(5);

Begin  

if lfParametro = 'S' then

  Select Abrev_Documento Into lv_Retorno
  From Quipux.Tipo_Documento
  Where Min_Documento = lfTipoDocumento;
  
elsif (lfParametro = 'R') then

  Select Min_Documento Into lv_Retorno
  From Quipux.Tipo_Documento
  Where Abrev_Documento = lfTipoDocumento;
  
end if;

Return lv_Retorno;
                                    
End Ft_Homologar_Tipo_Documento;                                    

-- -------------------------------------------------------------------------- --
--        P R O C E D I M I E N T O   V A L I D A R  N O V E D A D E S        --
-- -------------------------------------------------------------------------- --
Procedure Sp_Validar_Novedades as

lvNovedadSap varchar2(1000);
lnIdEstado number := 0;
lvEstado varchar2(40);
lvTipo varchar2(2);
lvResultado varchar2(100);
lvResultadoAux varchar2(100);
ldFecha date;
lnDiferenciaDias number := 0;

Cursor curNovedades is
Select * from dq_tmp_novedades_runt where PROCESO = 'P';

type tytNovedades is table of curNovedades%RowType;
arrayNov tytNovedades;

Begin

Open curNovedades;
  Loop Fetch curNovedades 
    Bulk Collect Into arrayNov Limit 200;
      For lnIndex in 1..arrayNov.count() loop      
      
      lvNovedadSap     := null;
      lnIdEstado       := 0;
      lvEstado         := null;
      lvTipo           := null;
      lvResultado      := null;
      lvResultadoAux   := null;
      ldFecha          := null;
      lnDiferenciaDias := 0;     
      
      --Case
      Case arrayNov(lnIndex).Id_Tramite
      When 1  then 
        if(arrayNov(lnIndex).desblindaje = 'S')Then
            lvTipo := '18';
        Else 
            lvTipo := '02';
        End if;       
      When 20 then 
        lvTipo := '03';
      When 13 then 
        lvTipo := '04';
      When 10 then 
        lvTipo := '06';
      When 15 then 
        lvTipo := '07';
      When 6  then 
        lvTipo := '08';
      When 15 then 
        lvTipo := '07';
      When 14 then 
        lvTipo := '11';
      else
        Continue;
      End Case;       
      
      ldFecha := To_date(arrayNov(lnIndex).Fecha_Tramite,'DDMMYYYY');
      
      lvNovedadSap := Ft_Existe_Nov_Sap (arrayNov(lnIndex).Nro_Placa,
                                          lvTipo, ldFecha);          
      
      /*If(lvNovedadSap ='N') then
        lvResultado := 'No existe novedad en SAP~0';*/
        --Buscamos en la otra tabla
        Begin
         Select Id_Estado, Nombre_Estado Into lnIdEstado, lvEstado 
          from dq_validacion_novedades
          Where nro_placa = arrayNov(lnIndex).Nro_Placa
            and id_novedad = lvTipo
            and Fecha = arrayNov(lnIndex).Fecha_Tramite;                  
        Exception 
          when others then
            lnIdEstado := 0;
          end; 
            
      If(lvNovedadSap = 'N') then        
      
        case lnIdEstado  
         when 0 then
          lvResultado := 'No existe novedad en SAP, Sin validacion~0';   
         when 1 then
          lvResultado := 'Estado efectivo sin ingreso~0'; 
         when 2 then
          lvResultado := 'Novedad no efectiva~0'; 
         when 3 then
          lvResultado := 'Tramite interno~0';   
         else
          continue;
         end case; 
          
      elsIf(lnIdEstado = 2 ) then
          lvResultado := 'Novedad no efectiva ingresada en SAP~0';
      else 
          lvResultado := lvNovedadSap;
      End if;
      
      /*else
                lvResultado := lvNovedadSap;
      End if;*/
      
      --Extraemos diferencia d�as de la cadena.
      lvResultadoAux :=  lvResultado;
      lvResultado := Substr(lvResultado,1,instr(lvResultado,'~',1,1)-1);
      lnDiferenciaDias := Substr(lvResultadoAux, length(lvResultado)+2, length(lvResultadoAux));
      
      Update dq_tmp_novedades_runt 
         set Estado = lvResultado,
             Diferencia_Dias = lnDiferenciaDias,
             Proceso = 'S'
       Where Nro_Placa     = arrayNov(lnIndex).Nro_Placa
         And Id_Tramite    = Arraynov(Lnindex).Id_Tramite
         And Fecha_Tramite = Arraynov(Lnindex).Fecha_Tramite; 
      
      End loop;
      Exit When arrayNov.count()<=0;
      Commit;
  End Loop;    
  Commit;
End Sp_Validar_Novedades;

-- -------------------------------------------------------------------------- --
--          F U N C T I O N  E X I S T  N O V E D A D  I N  S A P             --
-- -------------------------------------------------------------------------- --
Function Ft_Existe_Nov_Sap (lfNroPlaca varchar2, lfTipo varchar2, lfFecha date) return varchar2 as

lnExiste number := 0;
lnDiferenciaDias number :=0;
ldFechaSap DATE;
lvReturn varchar2(100);
lvTipo varchar2(2);
lnAnnoNovSap  number := 0;
lnAnnoNovRunt number := 0;
esNovedadSAP boolean := true;

Begin

Select count(1) into lnExiste
from dq_novedades_sap
Where Nro_Placa = lfNroPlaca
  and Tipo_Novedad = lfTipo
  and Fecha_Novedad = lfFecha;
  
if lnExiste > 0 then
  lvReturn := 'Placa OK~0';
Else  
  begin
    Select Fecha_Novedad into ldFechaSap
    from dq_novedades_sap
    Where Nro_Placa = lfNroPlaca
      and Tipo_Novedad = lfTipo;
      --and extract (year from Fecha_Novedad) = extract (year from lfFecha);
      lnAnnoNovSap := extract (year from ldFechaSap);
      lnAnnoNovRunt := extract (year from lfFecha);     
  exception 
    when others then
      esNovedadSAP := false;
    end;
    
    if( esNovedadSAP = true and (lnAnnoNovSap = lnAnnoNovRunt)) then
      lnDiferenciaDias := ldFechaSap - lfFecha;
      
      if(lnDiferenciaDias < 0)then --Si la novedad es ingresada con fecha inferior
        lvReturn := 'No afecta el cobro de impuesto, ingreso fecha inferior~'||lnDiferenciaDias;
      ELSIF(lfTipo in('03','07','18'))then --Si la novedad es ingresada con fecha posterior
        lvReturn := 'No afecta el cobro de impuesto, ingreso fecha superior~'||lnDiferenciaDias;
      ELSE
        lvReturn := 'Afecta el cobro del impuesto, diferencia en fechas~'||lnDiferenciaDias;
      End if;
      Else
      lvReturn := 'N';--No existe novedad en SAP
    End if;   
End if;

Return lvReturn;

End Ft_Existe_Nov_Sap;



Procedure Sp_Validar_Traspaso as

vTipoDoc varchar2(5);
vInterlocutor varchar2(15);

vExiste Number := 0;

Cursor curVendedorAct is
Select pr.Nro_Placa, Id_Usuario, Id_Documento
from Dq_Tmp_Propietarios_Runt pr
inner join dq_tmp_propietarios_sap ps
   on ps.USUARIO = Pr.Id_Usuario
Where Tipo_Runt = 'Vendedor' and Estado_Sap = '1-Activo';

Begin

for x in curVendedorAct Loop

vTipoDoc := null;
vInterlocutor := null;
vExiste := 0;

vTipoDoc := Pkg_Validar_Carga_Runt.Ft_Homologar_Tipo_Documento(x.Id_Documento,'S');

Begin

  Select interlocutor into vInterlocutor 
  from dq_tmp_propietarios_sap
  Where usuario = x.id_usuario and tipo_documento = vTipoDoc
  and rownum = 1;
Exception 
  when others then
    Continue;
  end;

Select count(1) into vExiste
from dq_tmp_h_traspaso_sap
where nro_placa = x.nro_placa
  and interlocutor = vInterlocutor 
  and HASTA not in('2099','2299','2999');

if (vExiste>0) then

Update Dq_Tmp_Propietarios_Runt pr
   Set Estado_Sap = 'Traspaso SAP'
 where Tipo_Runt = 'Vendedor' and Estado_Sap = '1-Activo'
   and nro_placa = x.nro_placa
   and Id_Usuario = x.id_usuario
   and Id_Documento = x.Id_Documento;

end if;

End Loop;
Commit;

End Sp_Validar_Traspaso ;

END PKG_VALIDAR_CARGA_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VAL_PLANT_ANT_ACTUALIZAR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_VAL_PLANT_ANT_ACTUALIZAR" AS

/*PERMITE IDENTIFICAR CUAL REGISTRO ES MAS CONSISTENTE EN SU INFORMACI�N, REGISTRO EXISTENTE EN SAP
  O EL REGISTRO QUE SE PRETENDE ACTUALIZAR.
  08/06/2016 
  Autor : Elvis Alexis Betancur L�pez*/
  
PROCEDURE SP_CONTRIBUYNETE_SAP_VS_RUNT(V_RADICADO VARCHAR) AS

V_DIRECCION_SAP VARCHAR2(100); 
V_DPTO_SAP VARCHAR2(20);
V_MUNICIPIO_SAP VARCHAR2(20);
V_TELEFONO_SAP VARCHAR2(20);
V_EMAIL_SAP VARCHAR2(100);
V_DIRECCION_RUNT VARCHAR2(100);
V_DPTO_RUNT VARCHAR2(20);
V_MUNICIPIO_RUNT VARCHAR2(20);
V_TELEFONO_RUNT VARCHAR2(20);
V_EMAIL_RUNT VARCHAR2(100);
V_ACTUALIZADO_POR VARCHAR2(500);
V_ERROR VARCHAR2(1000);
V_IDENT VARCHAR2(20);
V_TIPO VARCHAR2(20);
V_NOMBRE_SAP VARCHAR2(50);
V_APELLIDO_SAP VARCHAR2(50);
V_NOMBRE_RUNT VARCHAR2(50);
V_APELLIDO_RUNT VARCHAR2(50);
V_RAZON_SAP VARCHAR2(50);
V_RAZON_RUNT VARCHAR2(50);
V_EXISTE NUMBER;
V_OPCION VARCHAR2(50);
V_CELULAR_RUNT VARCHAR2(50);
V_ERROR_SAP NUMBER;
V_ERROR_RUNT NUMBER;
V_ERROR_SAP_T NUMBER;
V_ERROR_RUNT_T NUMBER;
V_ERROR_RUNT_C NUMBER;
V_ERROR_SAP_E NUMBER;
V_ERROR_RUNT_E NUMBER;
V_LARGO_SAP NUMBER;
V_LARGO_RUNT NUMBER;
V_LARGO_RUNT_T NUMBER;
V_MENSAJE_SAP VARCHAR2(20);
V_MENSAJE_RUNT VARCHAR2(20);
V_CONTADOR NUMBER:=0;
V_CONTADOR2 NUMBER:=0;
RADICADO VARCHAR2(10);
ERRORE VARCHAR(200);


CURSOR IC_SAP (V_IDE VARCHAR2, V_TIP VARCHAR2, V_RAD VARCHAR2) IS 
                  SELECT * 
                  FROM CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP
                  WHERE IDENTIFICACION = V_IDE
                    AND TIPO_DOCUMENTO = V_TIP
                    AND RADICADO = V_RAD;
/*                         
CURSOR IC_RUNT IS SELECT * FROM CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                  WHERE RADICADO = V_RADICADO;*/

CURSOR IC_RUNT IS SELECT PR.* FROM CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT PR
                  INNER JOIN RS_CONTRIBUYENTES_SAP RS ON RS.IDENTIFICACION = PR.NRO_IDENTIFICACION
                                                     AND RS.RADICADO = PR.RADICADO
                  WHERE PR.RADICADO = V_RADICADO AND PR.VAL_DIR_VEHICULO IS NULL;
                  --and rownum < 101;              
                      

BEGIN
 
--RECORRO LA INFORMACION DE LA PLANTILLA DE IC A ACTUALIZAR
FOR RUNT IN IC_RUNT LOOP
 BEGIN 
  V_DIRECCION_RUNT :=  TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION (RUNT.DIRECCION_CORRESP)));
  V_DPTO_RUNT := TRIM(RUNT.REGION);
  V_MUNICIPIO_RUNT := TRIM(RUNT.POBLACION);
  V_TELEFONO_RUNT := TRIM(RUNT.TELEFONO);
  V_CELULAR_RUNT := TRIM(RUNT.TELEFONO_MOVIL);
  V_EMAIL_RUNT := TRIM(LOWER(RUNT.E_MAIL));   
  V_IDENT := TRIM(RUNT.NRO_IDENTIFICACION);
  V_TIPO := TRIM(RUNT.CLASE_IDENTIFICACION);
  V_NOMBRE_RUNT := TRIM(UPPER(RUNT.NOMBRE_PILA_INTERLOCUTOR));
  V_APELLIDO_RUNT := TRIM(UPPER(RUNT.APELLIDO_INTERLOCUTOR));
  V_RAZON_RUNT := TRIM(UPPER(RUNT.NOMBRE1_ORGANIZACION));
  --RADICADO := RUNT.RADICADO;
  
   IF V_CONTADOR2 = 50 THEN
      V_CONTADOR2:=0;
      COMMIT;
    ELSE
      V_CONTADOR2 := V_CONTADOR2 + 1;
    END IF;
  
  
  --RECORRO LA INFORMACION DE SAP ANTES DE ACTUALIZAR
  FOR SAP IN IC_SAP (V_IDENT,V_TIPO,V_RADICADO) LOOP
   
   BEGIN
   V_CONTADOR := V_CONTADOR+1;
   
    V_ACTUALIZADO_POR:=NULL;
    V_ERROR:='';
    V_EXISTE :=0;
    --ESTANDARIZO DIRECCI�N DE SAP PARA PODER COMPARAR
    V_DIRECCION_SAP := TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(SAP.DIRECCION)));
    V_DPTO_SAP := TRIM(SAP.DEPARTAMENTO);
    V_MUNICIPIO_SAP := TRIM(SAP.MUNICIPIO);
    V_TELEFONO_SAP :=TRIM(SAP.TELEFONO);
    V_EMAIL_SAP := TRIM(LOWER(SAP.EMAIL));
    V_NOMBRE_SAP := TRIM(UPPER(SAP.NOMBRES));
    V_APELLIDO_SAP := TRIM(UPPER(SAP.APELLIDOS));
    V_RAZON_SAP := TRIM(UPPER(SAP.RAZON_SOCIAL));

    --ACTUALIZO DIRECCION SAP.
    UPDATE CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP
       SET DIRECCION = V_DIRECCION_SAP
     WHERE IDENTIFICACION = SAP.IDENTIFICACION
       AND TIPO_DOCUMENTO = SAP.TIPO_DOCUMENTO
       AND TIPO_DIRECCION = SAP.TIPO_DIRECCION
       AND RADICADO = SAP.RADICADO;  
     --ACTUALIZO DIRECCION RUNT  
    IF V_CONTADOR = 1 THEN
     UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
        SET DIRECCION_CORRESP =  V_DIRECCION_RUNT,
            DIRECCION_NOT_VEH = V_DIRECCION_RUNT,
            DIRECCION_RESIDENCIA = V_DIRECCION_RUNT    
      WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
        AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
        AND RADICADO = RUNT.RADICADO;     
    END IF; 
   -- COMMIT;  
    
    /*================================INICIO VALIDACION DE DATOS=================================*/
      
      SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,'NO REPORTA',1)>0;
      
        --Si la direcci�n es diferente valido cual de las dos es la mejor
          V_ERROR_SAP:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_SAP,0);
          V_ERROR_RUNT:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_RUNT,0);      
     --------------------****************************************----------------------------------
     IF INSTR(V_DIRECCION_SAP,'#',1) = 0 THEN
       BEGIN
          V_DIRECCION_SAP := FT_ASIGNAR_#(V_DIRECCION_SAP);
       EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;  
     END IF;   
     
     IF INSTR(V_DIRECCION_RUNT,'#',1) = 0 THEN
       BEGIN
          V_DIRECCION_RUNT := FT_ASIGNAR_#(V_DIRECCION_RUNT);
       EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;  
     END IF;      
     -------------------******************************************-----------------------
      IF V_EXISTE > 0 THEN
                 
          IF V_ERROR_SAP IN (2,4) THEN    
            V_ERROR := V_ERROR || 'DIR RUNT NO REPORTA, DIR SAP('||V_DIRECCION_SAP||'), ';
          ELSIF (V_ERROR_SAP = 0) THEN
           V_ERROR := 'SAP > RUNT';
          END IF;
          
        V_EXISTE :=0;
      ELSE
      
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,V_DIRECCION_SAP,1)>0;
      
      IF V_EXISTE = 0 THEN   
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_SAP,V_DIRECCION_RUNT,1)>0;       
      END IF;
      
      IF (V_EXISTE = 1) AND ( V_ERROR_SAP = 0  AND V_ERROR_RUNT = 0) AND  
         (V_DPTO_SAP = V_DPTO_RUNT) AND (V_MUNICIPIO_SAP = V_MUNICIPIO_RUNT)THEN
          V_ERROR := 'RUNT = SAP';
          
      --Direcci�n SAP tres consonantes seguidas o tanto runt como sap tienen error    
      ELSIF (V_EXISTE = 1) AND (V_DPTO_SAP = V_DPTO_RUNT) AND (V_MUNICIPIO_SAP = V_MUNICIPIO_RUNT) 
         AND ((V_ERROR_SAP = 4) OR ( V_ERROR_SAP = V_ERROR_RUNT)) THEN      
        V_ERROR := V_ERROR || 'RUNT = SAPII';
      ELSE
        
                 
          IF V_ERROR_SAP = 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP = 0 AND V_ERROR_RUNT > 0 THEN
            V_ERROR := 'SAP > RUNT'; --EN ESTE CASO NO ACTUALIZAR
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT > 0 THEN
                       
            --DIRECCION<7            SOLO LETRAS         3 CONSONANTES SEGUIDAS
            IF (V_ERROR_SAP = 1 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
             V_ERROR := 'RUNT > SAP'; 
                 
                  --SOLO LETRAS         DIRECCION<7          SOLO NUMEROS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
                 --SOLO LETRAS          3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP';  
              
                --3 CONSONANTES SEGUIDAS   SOLO LETRAS
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 2)) THEN
              V_ERROR := 'RUNT > SAP?';  
                 
                  --SOLO NUMEROS         SOLO LETRAS         3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 3 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP'; 
              
             --3 CONSONANTES SEGUIDAS    DIRECCION<7         SOLO NUMEROS  
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
              --SI SE REPORTA EL MISMO ERROR PREVALECE RUNT
             ELSIF (V_ERROR_SAP = V_ERROR_RUNT) THEN
               V_ERROR := 'RUNT > SAP'; 
            END IF;       
      
    END IF;
    
    END IF; 
    END IF;  
    
    --V_ACTUALIZADO_POR := V_ERROR;
    
    --VALIDO QUE EL TELEFONO RUNT NO SEA NULL DE SERLO LO ACTUALIZO CON SAP
      V_ERROR_SAP_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_SAP,'T',0);
      V_ERROR_RUNT_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_RUNT,'T',0);
      V_ERROR_RUNT_C := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_CELULAR_RUNT,'T',0);
      V_ERROR_SAP_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_SAP);
      V_ERROR_RUNT_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_RUNT);
     
    --IDENTIFICO EL LARGO PARA DETERMINAR SI EL CELULAR O TELEFONO
      V_LARGO_SAP := NVL(LENGTH(V_TELEFONO_SAP),0);
      V_LARGO_RUNT := NVL(LENGTH(V_CELULAR_RUNT),0);
      V_LARGO_RUNT_T := NVL(LENGTH(V_TELEFONO_RUNT),0);
    
   -- IF V_ERROR = 'RUNT > SAP' THEN
        
     --ACTUALIZO EL TELEFONO SI ES NECESARIO
     
      --IF V_LARGO_SAP = 7 THEN
      
        IF (V_LARGO_SAP = 7) AND (V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0 OR V_LARGO_RUNT_T >7) AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL)THEN      
                 
              UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
               SET TELEFONO = V_TELEFONO_SAP
             WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
               AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
               AND RADICADO = RUNT.RADICADO;  
            
               
               V_TELEFONO_RUNT := V_TELEFONO_SAP;
               V_ACTUALIZADO_POR :=  'TELEFONO SAP, ';     
     --    END IF;     
                 
         ELSIF (V_LARGO_SAP > 9) AND (V_CELULAR_RUNT IS NULL OR  V_ERROR_RUNT_C > 0 OR V_LARGO_RUNT < 10)
                AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL) THEN  
         
        --  IF /*(V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0) AND*/THEN 
          
              UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                 SET TELEFONO_MOVIL = V_TELEFONO_SAP
               WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                 AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
                 AND RADICADO = RUNT.RADICADO;    
               
                 
                 V_CELULAR_RUNT := V_TELEFONO_SAP;
                 V_ACTUALIZADO_POR := 'CELULAR SAP, ';
         -- END IF;      
                   
        END IF;
      --END IF;
      
      --VALIDACIONES PARA ACTUALIZAR E_MAIL
      IF (V_ERROR_RUNT_E = 0 OR V_ERROR_SAP_E = 0) THEN
       
       SELECT COUNT(1) INTO  V_ERROR_RUNT_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_RUNT),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sincorreo') > 0
          OR LENGTH(V_EMAIL_RUNT)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_RUNT,1,INSTR(V_EMAIL_RUNT,'@')-1))<=3
          OR INSTR(V_EMAIL_RUNT, '@')                = 0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sdf') > 0;
      
       SELECT COUNT(1) INTO  V_ERROR_SAP_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_SAP),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sincorreo') > 0
          OR LENGTH(V_EMAIL_SAP)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_SAP,1,INSTR(V_EMAIL_SAP,'@')-1))<=3
          OR INSTR(V_EMAIL_SAP, '@')                =0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sdf') > 0;
          
      END IF;      
      
      IF (V_EMAIL_RUNT IS NULL OR V_ERROR_RUNT_E > 0) AND (V_ERROR_SAP_E = 0 AND V_EMAIL_SAP IS NOT NULL)THEN
      
         UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET E_MAIL = V_EMAIL_SAP
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
            AND RADICADO = RUNT.RADICADO;  
        
          
          V_EMAIL_RUNT := V_EMAIL_SAP; 
          V_ACTUALIZADO_POR :=  V_ACTUALIZADO_POR || 'EMAIL SAP, ';
      
      END IF;
      
    /*ELS*/IF (V_ERROR = 'SAP > RUNT') OR (V_ERROR = 'RUNT = SAP') THEN
    
    --SE VALIDA SI EL NOMBRE ES IGUAL
      IF RUNT.CLASE_IDENTIFICACION != 'NIT' THEN
      
        IF (V_NOMBRE_RUNT != V_NOMBRE_SAP) OR (V_APELLIDO_RUNT != V_APELLIDO_SAP) THEN
           --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
           UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
              SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES'
            WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
              AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
              AND INCONSISTENCIA NOT LIKE '%NOMBRE%'
              AND RADICADO = RUNT.RADICADO;    
               
        END IF;
      
      ELSE
      
        IF (V_RAZON_RUNT != V_RAZON_SAP) THEN
             --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
             UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES, '
              WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
                AND RADICADO = RUNT.RADICADO;    
                 
          END IF;
          
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_TELEFONO_RUNT IS NOT NULL AND V_ERROR_RUNT_T = 0) AND (V_ERROR_SAP_T > 0 OR V_TELEFONO_SAP IS NULL)THEN
        
         UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET ACTUALIZADO_POR = ACTUALIZADO_POR || 'TELEFONO RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
            AND RADICADO = RUNT.RADICADO;   
            
      
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_EMAIL_RUNT IS NOT NULL AND V_ERROR_RUNT_E = 0) AND (V_ERROR_SAP_E > 0 OR V_EMAIL_SAP IS NULL) THEN
        
         UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET ACTUALIZADO_POR =  ACTUALIZADO_POR ||'EMIAL RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
            AND RADICADO = RUNT.RADICADO;   
       
      
      END IF;
            
    END IF;
    --COMMIT;
      
   IF (SAP.TIPO_DIRECCION ='XXDEFAULT') THEN  
    
      UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
       SET VAL_DIR_DEFAULT = V_ERROR,
           ACTUALIZADO_POR = ACTUALIZADO_POR || V_ACTUALIZADO_POR 
     WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
       AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
       AND RADICADO = RUNT.RADICADO;    
  

    ELSIF (SAP.TIPO_DIRECCION ='ZRESIDVEHI') THEN
    
      UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
         SET VAL_DIR_VEHICULO = V_ERROR,
             ACTUALIZADO_POR = ACTUALIZADO_POR || V_ACTUALIZADO_POR
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
         AND RADICADO = RUNT.RADICADO;  
   
    
    END IF; 
      

  EXCEPTION
    WHEN OTHERS THEN  
          ERRORE := SQLERRM;
         UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
           SET ACTUALIZADO_POR = ERRORE
         WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
           AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
           AND RADICADO = RUNT.RADICADO;         
       --COMMIT;         
      CONTINUE;
  END;
   
END LOOP;
  V_CONTADOR :=0;
 EXCEPTION
  WHEN OTHERS THEN  
        ERRORE := SQLERRM;
       UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
         SET ACTUALIZADO_POR = ERRORE
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
         AND RADICADO = RUNT.RADICADO;         
     --COMMIT;         
    CONTINUE;
  END;
  --COMMIT;

END LOOP;

/*Ingreso estado para los registros que no fueron generados al bajar la informaci�n
  actual de SAP.                                                                   */
UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT CR
SET CR.VAL_DIR_VEHICULO = 'EL REGISTRO NO EXISTE EN LA TABLA RS_CONTRIBUYENTES_SAP'
WHERE NOT EXISTS (SELECT 1
                  FROM CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP CS
                  WHERE CS.IDENTIFICACION = CR.NRO_IDENTIFICACION
                    AND CS. TIPO_DOCUMENTO= CR.CLASE_IDENTIFICACION
                    AND CS.RADICADO = CR.RADICADO)
  AND CR.VAL_DIR_VEHICULO IS NULL
  AND CR.RADICADO = V_RADICADO;
  
 COMMIT;
 
END SP_CONTRIBUYNETE_SAP_VS_RUNT;



PROCEDURE SP_CONTRIBUYNETE_SAP_VS_RUNT_2(V_RADICADO VARCHAR) AS

V_DIRECCION_SAP VARCHAR2(100); 
V_DPTO_SAP VARCHAR2(20);
V_MUNICIPIO_SAP VARCHAR2(20);
V_TELEFONO_SAP VARCHAR2(20);
V_EMAIL_SAP VARCHAR2(100);
V_DIRECCION_RUNT VARCHAR2(100);
V_DPTO_RUNT VARCHAR2(20);
V_MUNICIPIO_RUNT VARCHAR2(20);
V_TELEFONO_RUNT VARCHAR2(20);
V_EMAIL_RUNT VARCHAR2(100);
V_ACTUALIZADO_POR VARCHAR2(4000);
V_ERROR VARCHAR2(1000);
V_IDENT VARCHAR2(20);
V_TIPO VARCHAR2(20);
V_NOMBRE_SAP VARCHAR2(50);
V_APELLIDO_SAP VARCHAR2(50);
V_NOMBRE_RUNT VARCHAR2(50);
V_APELLIDO_RUNT VARCHAR2(50);
V_RAZON_SAP VARCHAR2(50);
V_RAZON_RUNT VARCHAR2(50);
V_EXISTE NUMBER;
V_OPCION VARCHAR2(50);
V_CELULAR_RUNT VARCHAR2(50);
V_ERROR_SAP NUMBER;
V_ERROR_RUNT NUMBER;
V_ERROR_SAP_T NUMBER;
V_ERROR_RUNT_T NUMBER;
V_ERROR_RUNT_C NUMBER;
V_ERROR_SAP_E NUMBER;
V_ERROR_RUNT_E NUMBER;
V_LARGO_SAP NUMBER;
V_LARGO_RUNT NUMBER;
V_LARGO_RUNT_T NUMBER;
V_MENSAJE_SAP VARCHAR2(20);
V_MENSAJE_RUNT VARCHAR2(20);
V_INCONSISTENCIA VARCHAR2(4000);
V_CONTADOR NUMBER:=0;
V_CONTADOR2 NUMBER:=0;
RADICADO VARCHAR2(10);
ERRORE VARCHAR(200);


CURSOR IC_SAP (V_IDE VARCHAR2, V_TIP VARCHAR2, V_RAD VARCHAR2) IS 
                  SELECT * 
                  FROM CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP
                  WHERE IDENTIFICACION = V_IDE
                    AND TIPO_DOCUMENTO = V_TIP
                    AND RADICADO = V_RAD;
/*                         
CURSOR IC_RUNT IS SELECT * FROM CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                  WHERE RADICADO = V_RADICADO;*/

CURSOR IC_RUNT IS SELECT PR.* FROM CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT PR
                  INNER JOIN RS_CONTRIBUYENTES_SAP RS ON RS.IDENTIFICACION = PR.NRO_IDENTIFICACION
                                                     AND RS.RADICADO = PR.RADICADO
                  WHERE PR.RADICADO = V_RADICADO AND PR.VAL_DIR_VEHICULO IS NULL;
                  --and rownum < 101;              
                      

BEGIN
 
--RECORRO LA INFORMACION DE LA PLANTILLA DE IC A ACTUALIZAR
FOR RUNT IN IC_RUNT LOOP
 BEGIN 
  V_DIRECCION_RUNT :=  TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION (RUNT.DIRECCION_CORRESP)));
  V_DPTO_RUNT := TRIM(RUNT.REGION);
  V_MUNICIPIO_RUNT := TRIM(RUNT.POBLACION);
  V_TELEFONO_RUNT := TRIM(RUNT.TELEFONO);
  V_CELULAR_RUNT := TRIM(RUNT.TELEFONO_MOVIL);
  V_EMAIL_RUNT := TRIM(LOWER(RUNT.E_MAIL));   
  V_IDENT := TRIM(RUNT.NRO_IDENTIFICACION);
  V_TIPO := TRIM(RUNT.CLASE_IDENTIFICACION);
  V_NOMBRE_RUNT := TRIM(UPPER(RUNT.NOMBRE_PILA_INTERLOCUTOR));
  V_APELLIDO_RUNT := TRIM(UPPER(RUNT.APELLIDO_INTERLOCUTOR));
  V_RAZON_RUNT := TRIM(UPPER(RUNT.NOMBRE1_ORGANIZACION));
  --RADICADO := RUNT.RADICADO;
  
   IF V_CONTADOR2 = 100 THEN
      V_CONTADOR2:=0;
      COMMIT;
    ELSE
      V_CONTADOR2 := V_CONTADOR2 + 1;
    END IF;
  
  
  --RECORRO LA INFORMACION DE SAP ANTES DE ACTUALIZAR
  FOR SAP IN IC_SAP (V_IDENT,V_TIPO,V_RADICADO) LOOP
   
   BEGIN
   V_CONTADOR := V_CONTADOR+1;
   
    V_ACTUALIZADO_POR:=NULL;
    V_ERROR:='';
    V_EXISTE :=0;
    --ESTANDARIZO DIRECCI�N DE SAP PARA PODER COMPARAR
    V_DIRECCION_SAP := TRIM(UPPER(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(SAP.DIRECCION)));
    V_DPTO_SAP := TRIM(SAP.DEPARTAMENTO);
    V_MUNICIPIO_SAP := TRIM(SAP.MUNICIPIO);
    V_TELEFONO_SAP :=TRIM(SAP.TELEFONO);
    V_EMAIL_SAP := TRIM(LOWER(SAP.EMAIL));
    V_NOMBRE_SAP := TRIM(UPPER(SAP.NOMBRES));
    V_APELLIDO_SAP := TRIM(UPPER(SAP.APELLIDOS));
    V_RAZON_SAP := TRIM(UPPER(SAP.RAZON_SOCIAL));

    --ACTUALIZO DIRECCION SAP.
    UPDATE CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP
       SET DIRECCION = V_DIRECCION_SAP
     WHERE IDENTIFICACION = SAP.IDENTIFICACION
       AND TIPO_DOCUMENTO = SAP.TIPO_DOCUMENTO
       AND TIPO_DIRECCION = SAP.TIPO_DIRECCION
       AND RADICADO = SAP.RADICADO;
     --ACTUALIZO DIRECCION RUNT  
    IF V_CONTADOR = 1 THEN
     UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
        SET DIRECCION_CORRESP =  V_DIRECCION_RUNT,
            DIRECCION_NOT_VEH = V_DIRECCION_RUNT,
            DIRECCION_RESIDENCIA = V_DIRECCION_RUNT    
      WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
        AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
        AND RADICADO = RUNT.RADICADO;   
    END IF; 
   -- COMMIT;  
    
    /*================================INICIO VALIDACION DE DATOS=================================*/
      
      SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,'NO REPORTA',1)>0;
      
        --Si la direcci�n es diferente valido cual de las dos es la mejor
          V_ERROR_SAP:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_SAP,0);
          V_ERROR_RUNT:= PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(V_DIRECCION_RUNT,0);      
     --------------------****************************************----------------------------------
     IF INSTR(V_DIRECCION_SAP,'#',1) = 0 THEN
       BEGIN
          V_DIRECCION_SAP := FT_ASIGNAR_#(V_DIRECCION_SAP);
       EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;  
     END IF;   
     
     IF INSTR(V_DIRECCION_RUNT,'#',1) = 0 THEN
       BEGIN
          V_DIRECCION_RUNT := FT_ASIGNAR_#(V_DIRECCION_RUNT);
       EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;  
     END IF;      
     -------------------******************************************-----------------------
      IF V_EXISTE > 0 THEN
                 
          IF V_ERROR_SAP IN (2,4) THEN    
            V_ERROR := V_ERROR || 'DIR RUNT NO REPORTA, DIR SAP('||V_DIRECCION_SAP||'), ';
          ELSIF (V_ERROR_SAP = 0) THEN
           V_ERROR := 'SAP > RUNT';
          END IF;
          
        V_EXISTE :=0;
      ELSE
      
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_RUNT,V_DIRECCION_SAP,1)>0;
      
      IF V_EXISTE = 0 THEN   
       SELECT COUNT (1) INTO V_EXISTE FROM DUAL
       WHERE INSTR(V_DIRECCION_SAP,V_DIRECCION_RUNT,1)>0;       
      END IF;
      
      IF (V_EXISTE = 1) AND ( V_ERROR_SAP = 0  AND V_ERROR_RUNT = 0) AND  
         (V_DPTO_SAP = V_DPTO_RUNT) AND (V_MUNICIPIO_SAP = V_MUNICIPIO_RUNT)THEN
          V_ERROR := 'RUNT = SAP';
          
      --Direcci�n SAP tres consonantes seguidas o tanto runt como sap tienen error    
      ELSIF (V_EXISTE = 1) AND (V_DPTO_SAP = V_DPTO_RUNT) AND (V_MUNICIPIO_SAP = V_MUNICIPIO_RUNT) 
         AND ((V_ERROR_SAP = 4) OR ( V_ERROR_SAP = V_ERROR_RUNT)) THEN      
        V_ERROR := V_ERROR || 'RUNT = SAPII';
      ELSE
        
                 
          IF V_ERROR_SAP = 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT = 0 THEN
            V_ERROR := 'RUNT > SAP';
          ELSIF V_ERROR_SAP = 0 AND V_ERROR_RUNT > 0 THEN
            V_ERROR := 'SAP > RUNT'; --EN ESTE CASO NO ACTUALIZAR
          ELSIF V_ERROR_SAP > 0 AND V_ERROR_RUNT > 0 THEN
                       
            --DIRECCION<7            SOLO LETRAS         3 CONSONANTES SEGUIDAS
            IF (V_ERROR_SAP = 1 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
             V_ERROR := 'RUNT > SAP'; 
                 
                  --SOLO LETRAS         DIRECCION<7          SOLO NUMEROS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
                 --SOLO LETRAS          3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 2 AND (V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP';  
              
                --3 CONSONANTES SEGUIDAS   SOLO LETRAS
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 2)) THEN
              V_ERROR := 'RUNT > SAP?';  
                 
                  --SOLO NUMEROS         SOLO LETRAS         3 CONSONANTES SEGUIDAS
             ELSIF (V_ERROR_SAP = 3 AND (V_ERROR_RUNT = 2 OR V_ERROR_RUNT = 4)) THEN
              V_ERROR := 'RUNT > SAP'; 
              
             --3 CONSONANTES SEGUIDAS    DIRECCION<7         SOLO NUMEROS  
             ELSIF (V_ERROR_SAP = 4 AND (V_ERROR_RUNT = 1 OR V_ERROR_RUNT = 3)) THEN
              V_ERROR := 'SAP > RUNT';
              
              --SI SE REPORTA EL MISMO ERROR PREVALECE RUNT
             ELSIF (V_ERROR_SAP = V_ERROR_RUNT) THEN
               V_ERROR := 'RUNT > SAP'; 
            END IF;       
      
    END IF;
    
    END IF; 
    END IF;  
    
    --V_ACTUALIZADO_POR := V_ERROR;
    
    --VALIDO QUE EL TELEFONO RUNT NO SEA NULL DE SERLO LO ACTUALIZO CON SAP
      V_ERROR_SAP_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_SAP,'T',0);
      V_ERROR_RUNT_T := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_TELEFONO_RUNT,'T',0);
      V_ERROR_RUNT_C := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_TELEFONO_FAX(V_CELULAR_RUNT,'T',0);
      V_ERROR_SAP_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_SAP);
      V_ERROR_RUNT_E := PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_EMAIL(V_EMAIL_RUNT);
     
    --IDENTIFICO EL LARGO PARA DETERMINAR SI EL CELULAR O TELEFONO
      V_LARGO_SAP := NVL(LENGTH(V_TELEFONO_SAP),0);
      V_LARGO_RUNT := NVL(LENGTH(V_CELULAR_RUNT),0);
      V_LARGO_RUNT_T := NVL(LENGTH(V_TELEFONO_RUNT),0);
    
   -- IF V_ERROR = 'RUNT > SAP' THEN
        
     --ACTUALIZO EL TELEFONO SI ES NECESARIO
     
      --IF V_LARGO_SAP = 7 THEN
      
        IF (V_LARGO_SAP = 7) AND (V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0 OR V_LARGO_RUNT_T >7) AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL)THEN      
                 
             /* UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
               SET TELEFONO = V_TELEFONO_SAP
             WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
               AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;*/
            
               
               V_TELEFONO_RUNT := V_TELEFONO_SAP;
               V_ACTUALIZADO_POR := V_ACTUALIZADO_POR || 'TELEFONO SAP, ';     
     --    END IF;     
                 
         ELSIF (V_LARGO_SAP > 9) AND (V_CELULAR_RUNT IS NULL OR  V_ERROR_RUNT_C > 0 OR V_LARGO_RUNT < 10)
                AND (V_ERROR_SAP_T = 0 AND V_TELEFONO_SAP IS NOT NULL) THEN  
         
        --  IF /*(V_TELEFONO_RUNT IS NULL OR V_ERROR_RUNT_T > 0) AND*/THEN 
          
             /* UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                 SET TELEFONO_MOVIL = V_TELEFONO_SAP
               WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                 AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION; */ 
               
                 
                 V_CELULAR_RUNT := V_TELEFONO_SAP;
                 V_ACTUALIZADO_POR := V_ACTUALIZADO_POR || 'CELULAR SAP, ';
         -- END IF;      
                   
        END IF;
      --END IF;
      
      --VALIDACIONES PARA ACTUALIZAR E_MAIL
      IF (V_ERROR_RUNT_E = 0 OR V_ERROR_SAP_E = 0) THEN
       
       SELECT COUNT(1) INTO  V_ERROR_RUNT_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_RUNT),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sincorreo') > 0
          OR LENGTH(V_EMAIL_RUNT)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_RUNT,1,INSTR(V_EMAIL_RUNT,'@')-1))<=3
          OR INSTR(V_EMAIL_RUNT, '@')                = 0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_RUNT),'sdf') > 0;
      
       SELECT COUNT(1) INTO  V_ERROR_SAP_E
       FROM DUAL
       WHERE INSTR(LOWER(V_EMAIL_SAP),'notiene') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'noregistra') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notine') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'notengo') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'ningun') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sin@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sincorreo') > 0
          OR LENGTH(V_EMAIL_SAP)                   <= 7
          OR LENGTH(SUBSTR(V_EMAIL_SAP,1,INSTR(V_EMAIL_SAP,'@')-1))<=3
          OR INSTR(V_EMAIL_SAP, '@')                =0
          --o@') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'asd') > 0
          OR INSTR(LOWER(V_EMAIL_SAP),'sdf') > 0;
          
      END IF;      
      
      IF (V_EMAIL_RUNT IS NULL OR V_ERROR_RUNT_E > 0) AND (V_ERROR_SAP_E = 0 AND V_EMAIL_SAP IS NOT NULL)THEN
      
         /*UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET E_MAIL = V_EMAIL_SAP
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;*/
        
          
          V_EMAIL_RUNT := V_EMAIL_SAP; 
          V_ACTUALIZADO_POR :=  V_ACTUALIZADO_POR || 'EMAIL SAP, ';
      
      END IF;
      
    /*ELS*/IF (V_ERROR = 'SAP > RUNT') OR (V_ERROR = 'RUNT = SAP') THEN
    
    --SE VALIDA SI EL NOMBRE ES IGUAL
      IF RUNT.CLASE_IDENTIFICACION != 'NIT' THEN
      
        IF (V_NOMBRE_RUNT != V_NOMBRE_SAP) OR (V_APELLIDO_RUNT != V_APELLIDO_SAP) THEN
           --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
           /*UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
              SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES'
            WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
              AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
              AND INCONSISTENCIA NOT LIKE '%NOMBRE%'; */ 
               
			V_INCONSISTENCIA := V_INCONSISTENCIA || 'APELLIDO DIFERENTES, ';	
        END IF;
      
      ELSE
      
        IF (V_RAZON_RUNT != V_RAZON_SAP) THEN
             --SI EL NOMBRE ES DIFERENTE SE DEBE VALIDAR MANUAL EN PROCURADURIA
             /*UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
                SET INCONSISTENCIA = INCONSISTENCIA || 'NOMBRE O APELLIDO DIFERENTES, '
              WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
                AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION; */ 
			
			V_INCONSISTENCIA := V_INCONSISTENCIA || 'NOMBRE DIFERENTES, ';	
                 
          END IF;
          
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_TELEFONO_RUNT IS NOT NULL AND V_ERROR_RUNT_T = 0) AND (V_ERROR_SAP_T > 0 OR V_TELEFONO_SAP IS NULL)THEN
        
         /*UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET ACTUALIZADO_POR = ACTUALIZADO_POR || 'TELEFONO RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION; */
			
        V_ACTUALIZADO_POR := V_ACTUALIZADO_POR ||  'TELEFONO RUNT > SAP, ' ;  
      
      END IF;
      
      --SE VALIDA SI RUNT TIENE TELEFONO O EMAIL MEJORES QUE SAP
      IF (V_EMAIL_RUNT IS NOT NULL AND V_ERROR_RUNT_E = 0) AND (V_ERROR_SAP_E > 0 OR V_EMAIL_SAP IS NULL) THEN
        
         /*UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
            SET ACTUALIZADO_POR =  ACTUALIZADO_POR ||'EMIAL RUNT > SAP, '
          WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
            AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION;*/
			
       V_ACTUALIZADO_POR := V_ACTUALIZADO_POR ||'EMIAL RUNT > SAP, ';  
      
      END IF;
            
    END IF;
    --COMMIT;
      
   IF (SAP.TIPO_DIRECCION ='XXDEFAULT') THEN  
    
      UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
       SET VAL_DIR_DEFAULT = V_ERROR,
		   TELEFONO = V_TELEFONO_RUNT,
		   TELEFONO_MOVIL = V_CELULAR_RUNT,
		   E_MAIL = V_EMAIL_RUNT,	
		   INCONSISTENCIA = V_INCONSISTENCIA, 		
           ACTUALIZADO_POR = V_ACTUALIZADO_POR 
     WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
       AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
       AND RADICADO = RUNT.RADICADO;  
  

    ELSIF (SAP.TIPO_DIRECCION ='ZRESIDVEHI') THEN
    
      UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
         SET VAL_DIR_VEHICULO = V_ERROR,
		     TELEFONO = V_TELEFONO_RUNT,
		     TELEFONO_MOVIL = V_CELULAR_RUNT,
		     E_MAIL = V_EMAIL_RUNT,	
		     INCONSISTENCIA = V_INCONSISTENCIA, 		
             ACTUALIZADO_POR = V_ACTUALIZADO_POR             
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
         AND RADICADO = RUNT.RADICADO;  
   
    
    END IF; 
      

  EXCEPTION
    WHEN OTHERS THEN  
          ERRORE := SQLERRM;
         UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
           SET ACTUALIZADO_POR = ERRORE
         WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
           AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
           AND RADICADO = RUNT.RADICADO;         
       --COMMIT;         
      CONTINUE;
  END;
   
END LOOP;
  V_CONTADOR :=0;
 EXCEPTION
  WHEN OTHERS THEN  
        ERRORE := SQLERRM;
       UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT
         SET ACTUALIZADO_POR = ERRORE
       WHERE NRO_IDENTIFICACION = RUNT.NRO_IDENTIFICACION
         AND CLASE_IDENTIFICACION = RUNT.CLASE_IDENTIFICACION
         AND RADICADO = RUNT.RADICADO;         
     --COMMIT;         
    CONTINUE;
  END;
  --COMMIT;

END LOOP;

/*Ingreso estado para los registros que no fueron generados al bajar la informaci�n
  actual de SAP.                                                                   */
UPDATE CORRECCION_DATOS.PL_CONTRIBUYENTES_RUNT CR
SET CR.VAL_DIR_VEHICULO = 'EL REGISTRO NO EXISTE EN LA TABLA RS_CONTRIBUYENTES_SAP'
WHERE NOT EXISTS (SELECT 1
                  FROM CORRECCION_DATOS.RS_CONTRIBUYENTES_SAP CS
                  WHERE CS.IDENTIFICACION = CR.NRO_IDENTIFICACION
                    AND CS. TIPO_DOCUMENTO= CR.CLASE_IDENTIFICACION
                    AND CS.RADICADO = CR.RADICADO)
  AND CR.VAL_DIR_VEHICULO IS NULL
  AND CR.RADICADO = V_RADICADO;
  
 COMMIT;
 
END SP_CONTRIBUYNETE_SAP_VS_RUNT_2;




--ESTA FUNCION PERMITE COLOCAR EL # A LAS DIRECCIONES QUE NO LO TIENEN
FUNCTION FT_ASIGNAR_# (V_CADENA VARCHAR2)RETURN VARCHAR2 AS

V_LONGITUD NUMBER := 0;
V_POSICION NUMBER := 0;
V_CONTADOR NUMBER := 1;
V_CARACTER VARCHAR2(2);
V_CADENA_RETORNO2 VARCHAR2(100);
V_ESTANDAR VARCHAR2(100);
V_TIPO VARCHAR2(10);
V_ANTERIOR VARCHAR2(10):='1';
V_ESPACIO VARCHAR2(10);
V_CADENA_RETORNO VARCHAR2(100);
V_BANDERA NUMBER :=0;

BEGIN

BEGIN

 V_CADENA_RETORNO := V_CADENA;
    
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    
  V_LONGITUD := LENGTH (V_CADENA_RETORNO);

WHILE V_CONTADOR <= V_LONGITUD
LOOP
  V_CARACTER := SUBSTR(V_CADENA_RETORNO,V_CONTADOR,1);
  
  IF V_CARACTER = ' ' THEN
    V_TIPO := 'Espacio';
    IF V_TIPO <> V_ANTERIOR THEN
        V_ESTANDAR := V_ESTANDAR || 'Espacio';
    END IF;
  ELSIF PKG_DS_ESTANDARIZA_RUNT.FT_ES_NUMERO(V_CARACTER)> 0 THEN
    V_TIPO := 'Numero';
    IF V_TIPO <> V_ANTERIOR THEN
      V_ESTANDAR := V_ESTANDAR || 'Numero';
    END IF;
  ELSE
    V_TIPO := 'Texto';
    IF V_TIPO <> V_ANTERIOR THEN
      V_ESTANDAR := V_ESTANDAR || 'Texto';
    END IF;
  END IF;  
   
  IF V_ESTANDAR = 'TextoEspacioNumeroEspacioNumero' OR -- CLL 10 12 30 debe quedar CLL 10 # 12 30
     V_ESTANDAR = 'TextoEspacioNumeroEspacioTextoEspacioNumero' THEN -- CLL 10 B 12 30 debe quedar CLL 10 B # 12 30
    
     V_CADENA_RETORNO2 := SUBSTR(V_CADENA_RETORNO2,1,V_CONTADOR-1);
     V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || '# ';
     V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || SUBSTR(V_CADENA_RETORNO,V_CONTADOR,V_LONGITUD);
     V_BANDERA := 1;
  END IF;
  
  IF V_BANDERA = 0 THEN
  V_CADENA_RETORNO2 :=  V_CADENA_RETORNO2 || V_CARACTER;
  ELSE
    RETURN V_CADENA_RETORNO2;
    EXIT;--TERMINO EL CICLO
  END IF;
  
  
  V_ANTERIOR := V_TIPO; 
  V_TIPO := NULL;
  V_CONTADOR := V_CONTADOR + 1;
  
  
END LOOP;

EXCEPTION
  WHEN OTHERS THEN
    RETURN V_CADENA;
  END;

END FT_ASIGNAR_#;


END PKG_VAL_PLANT_ANT_ACTUALIZAR;

/
--------------------------------------------------------
--  DDL for Package Body PKG_WS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."PKG_WS" AS

PROCEDURE SP_LINEA_RUNT AS 
ln_existe Number:=0;

CURSOR LCUR_ACTUALIZAR_lINEA_RUNT IS
Select * From Temp_Placas;
    
Begin
    For Ln_Index In LCUR_ACTUALIZAR_lINEA_RUNT Loop
        SELECT Count(1) Into ln_existe  FROM RUNT_LINEA Where CODIGO_LINEA_WS = Ln_Index.ws;     
            If ln_existe > 0 Then
                    insert into Runt_linea (CODIGO_LINEA_WS,CODIGO_LINEA, CODIGO_MARCA,DESCRIPCION)
                    Values (Ln_Index.WS,Ln_Index.COD_LINEA,Ln_Index.MARCA,Ln_Index.NOMBRE);
            End IF;
    End Loop;
END SP_LINEA_RUNT;

END PKG_WS;

/
--------------------------------------------------------
--  DDL for Package Body TAREA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."TAREA" AS

 PROCEDURE SP_INICIAR AS


Ln_Contador Number := 0;

Cursor  consulta_placas Is
Select NRO_PLACA,ROWID From CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP;

Begin

For Ln_Index In consulta_placas Loop


Insert Into TEMP_PLACAS_RUNT_SAP (NRO_PLACA, 	MODELO, 	ID_MARCA, 	DESCRIPCION_MARCA, 	ID_LINEA, 	DESCRIPCION_LINEA, 	ID_USO, 	
            DESCRIPCION_USO, 	ID_CLASE, 	DESCRIPCION_CLASE, 	ID_CARROCERIA, 	DESCRIPCION_CARROCERIA, 	GRUPO, 	ID_CILINDRAJE, 	
            CILINDRAJE, 	TIPO_CARGA, 	ID_CAPACIDAD, 	CAPACIDAD, 	ID_DEPARTAMENTO, 	DEPARTAMENTO, 	ID_MUNICIPIO, 	
            MUNICIPIO, 	BLINDAJE, 	CLASICO, 	NACIONAL_IMPORT, 	NOMBRE_ASEG, 	NINT_SOAT, 	FECHA_MATRICULA, 	NRO_POLIZA, 	
            FVT_SOAT, 	PORCENTAJE, 	MONEDA, 	AVALUO, 	VALOR_LIQUI, 	R_LIQUI_ACTIVA, 	TIPO_NOVEDAD, 	FeSaIntTem, 	
            FeSaIntTem1, 	VALOR_FACT, 	CREADO, 	FECHA_CREADO)

select *
from BD_VALIDACION_RUNT.vr_vehiculos_sap VS

where VS.NRO_PLACA =Ln_Index.Nro_Placa;



If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

      End Loop;
    END SP_INICIAR;

FUNCTION SP_ID_RADICADO_MAX (Placa Varchar) Return Number
As
Transito Number:=0;
Begin
Select Max(Id_Radicado) Into Transito From Bd_Transitos.St_Vehiculos
Where Nro_Placa = Placa;

Return Transito;


END SP_ID_RADICADO_MAX;

END TAREA;

/
--------------------------------------------------------
--  DDL for Package Body VAL_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CORRECCION_DATOS"."VAL_DATOS" AS

PROCEDURE PS_VALIDAR_REGISTROS AS
 CURSOR PLACAS IS 
  SELECT * FROM CORRECCION_DATOS.VALIDACION_DATOS;
  --WHERE NRO_PLACA = 'IAS699';


BEGIN
delete from correccion_datos.resultado_validacion;
insert into correccion_datos.resultado_validacion
select distinct vd.nro_placa,null,null,null,null,null,null,null,null,null,null,null
from correccion_datos.validacion_datos vd;
 
  FOR X IN PLACAS LOOP
  
      -- VALIDOP MODELO
      IF (X.MODELO_RT =X.MODELO_TP AND X.MODELO_RT =X.MODELO_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'MODELO','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'MODELO','FALSO');          
      END IF;
      
      -- VALIDOP MARCA
      IF (X.MARCA_RT =X.MARCA_TP AND X.MARCA_RT =X.MARCA_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'MARCA','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'MARCA','FALSO');          
      END IF;
      
       -- VALIDOP LINEA
      IF (INSTR(UPPER(X.LINEA_TP),UPPER(X.LINEA_RT))>0 AND INSTR (UPPER(X.LINEA_SAP),UPPER(X.LINEA_RT))> 0)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'LINEA','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'LINEA','FALSO');          
      END IF;
       
      -- VALIDOP LINEA2
      IF (INSTR (UPPER(X.LINEA_SAP),UPPER(X.LINEA_RT))> 0)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'LINEA2','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'LINEA2','FALSO');          
      END IF;
      
      -- VALIDOP SECRETARIA
      IF (INSTR(UPPER(X.SECRETARIA_RT), UPPER(X.SECRETARIA_TP))>0 AND INSTR (UPPER(X.SECRETARIA_RT),UPPER(X.SECRETARIA_SAP))> 0)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'SECRETARIA','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'SECRETARIA','FALSO');          
      END IF;
      
      -- VALIDOP CLASE
      IF (X.CLASE_RT =X.CLASE_TP AND X.CLASE_RT =X.CLASE_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CLASE','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CLASE','FALSO');          
      END IF;
      
      -- VALIDOP CARROCERIA
      IF (X.CARROCERIA_RT =X.CARROCERIA_TP AND UPPER(X.CARROCERIA_SAP) = UPPER(X.CARROCERIA_RT)) THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CARROCERIA','VERDADERO'); 
        ELSIF (INSTR(UPPER(X.CARROCERIA_SAP), UPPER(X.CARROCERIA_RT))>0) THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CARROCERIA','VERDADERO'); 
        ELSE  
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CARROCERIA','FALSO');          
      END IF;
      
       -- VALIDOP SERVICIO
      IF (UPPER(X.SERVICIO_RT) = X.SERVICIO_TP AND UPPER(X.SERVICIO_RT) =X.SERVICIO_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'SERVICIO','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'SERVICIO','FALSO');          
      END IF;
      
      -- VALIDOP CILINDRAJE
      IF (X.CILINDRAJE_RT =X.CILINDRAJE_TP AND X.CILINDRAJE_RT =X.CILINDRAJE_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CILINDRAJE','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'CILINDRAJE','FALSO');          
      END IF;
      
      -- VALIDOP PASAJEROS
      IF (X.PASAJEROS_RT =X.PASAJEROS_TP AND X.PASAJEROS_RT =X.PASAJEROS_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'PASAJEROS','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'PASAJEROS','FALSO');          
      END IF;
      
      -- VALIDOP TONELADAS
      IF (X.TONELADAS_RT =X.TONELADAS_TP AND X.TONELADAS_RT =X.TONELADAS_SAP)THEN
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'TONELADAS','VERDADERO'); 
        ELSE
          PS_INSERTAR_RESULTADO ('CORRECCION_DATOS.','RESULTADO_VALIDACION',X.NRO_PLACA,'TONELADAS','FALSO');          
      END IF;
      
END LOOP;

END PS_VALIDAR_REGISTROS;

PROCEDURE PS_INSERTAR_RESULTADO (ESQUEMA VARCHAR2, TABLA VARCHAR2, PLACA VARCHAR2, CAMPO VARCHAR2, MENSAJE VARCHAR2) AS

 SQLTEXT VARCHAR(255);
  BEGIN
  --FOR Z IN 1..3 LOOP
    SQLTEXT:= 'UPDATE ' ||ESQUEMA || TABLA ||
      ' SET ' || CAMPO || ' = ''' || MENSAJE ||
      ''' WHERE NRO_PLACA = '''|| PLACA || ''''; 
            
     EXECUTE IMMEDIATE SQLTEXT;
     COMMIT;
 --END LOOP; 
END PS_INSERTAR_RESULTADO;


Procedure ESTADO_ENVIO AS
ESTADO VARCHAR (20) :='M';


CURSOR ESTADO_ENVIO IS
SELECT NRO_PLACA FROM CORRECCION_DATOS.TEMP_PLACAS;

BEGIN

FOR Ln_Index in ESTADO_ENVIO loop
begin 

UPDATE DEPURACION.DS_VEHICULO  DV SET  ENVIO_SAP = ESTADO
WHERE DV.NRO_PLACA = Ln_Index.NRO_PLACA AND ID_RADICADO='487';

END;
END LOOP;
COMMIT;
END ESTADO_ENVIO;

PROCEDURE  SP_INCONSISTENCIA AS
Inco_Linea varchar2 (10);
Inco_Cilindraje varchar2 (10);
Inco_Direccion  varchar2 (50);
Inco_Usuario  VARCHAR2 (2);

cursor  SP_INCONSISTENCIA is 
select nro_placa from temp_placas;

begin

for Ln_Index in  SP_INCONSISTENCIA loop

begin 

select LT.ID_LINEA,lt.CILINDRAJE,UT.DIRECCION,UT.ID_DOCUMENTO
into 
Inco_Linea,
Inco_Cilindraje,
Inco_Direccion, 
Inco_Usuario
from quipux.lic_tto lt
full outer join quipux.PROPIETARIOS_VEHICULO PV ON LT.NRO_PLACA = PV.NRO_PLACA
full outer JOIN quipux.USUARIOS_TTO UT ON UT.ID_USUARIO = PV.ID_USUARIO
WHERE LT.NRO_PLACA = Ln_Index.Nro_placa AND ROWNUM <=1;

UPDATE TEMP_PLACAS TP SET  TP.LINEA = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND Inco_Linea IS NULL;

UPDATE TEMP_PLACAS TP SET  TP.CILINDRAJE = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND (Inco_Cilindraje IS NULL or Inco_Cilindraje = '0') ;

UPDATE TEMP_PLACAS TP SET  TP.DIRECCION = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA and (Inco_Direccion is null  or  LENGTH (Inco_Direccion)<7) ;


UPDATE TEMP_PLACAS TP SET  TP.USUARIO = 'X'
WHERE TP.NRO_PLACA = Ln_Index.NRO_PLACA AND Inco_Usuario = '4';



END;
END LOOP;
COMMIT;
END  SP_INCONSISTENCIA;

PROCEDURE SP_ACTUALIZAR_LINEA_TIPO AS 
Lv_Codigo_Tipo Varchar2(10);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
Select Tl.Id_Linea Into Lv_Codigo_Tipo
From Quipux.Lic_Tto Lt
Inner Join Quipux.Qx_Tipo_Linea Qtl On Qtl.Runt_Linea = Lt.Id_Linea_Runt
Inner Join Quipux.Tipo_Linea Tl On Tl.Id_Linea_Qx = Qtl.Id_Linea_Qx
Where Lt.Nro_Placa = Ln_Index.Nro_Placa
And Rownum = 1;

Update Quipux.Lic_Tto Lt Set Lt.Id_Linea = Lv_Codigo_Tipo
Where Lt.Nro_Placa = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.LINEA = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
end;

END SP_ACTUALIZAR_LINEA_TIPO;

END VAL_DATOS;

/
--------------------------------------------------------
--  DDL for Function FINDSUMA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."FINDSUMA" (N in number)
return varchar2
is
suma float :=0;
mostrar varchar2(4000);
begin
for I in 1..N loop
if (mod(I,3)=0 or mod (I,5)=0) then
    mostrar:= mostrar || I || ' ';
    suma:=suma + I;
end if;
end loop;
return (suma);
dbms_output.put_line(suma);
end;

/
--------------------------------------------------------
--  DDL for Function FT_ACTUALIZAR_USUARIO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."FT_ACTUALIZAR_USUARIO" (A_RADICADO NUMBER, A_ID_DOCUMENTO NUMBER,A_ID_USUARIO VARCHAR2,A_ID_CIUDAD NUMBER,A_APELLIDOS VARCHAR2,A_NOMBRES VARCHAR2,A_DIRECCION VARCHAR2,A_TELEFONO VARCHAR2,A_EMP_O_PART VARCHAR2,A_SEXO VARCHAR2,A_FECHA_NACIMIENTO VARCHAR2 ,A_PAIS NUMBER,A_FAX VARCHAR2,A_EMAIL VARCHAR2) RETURN BOOLEAN
  AS
    V_UPDATE VARCHAR2(1000);
    V_DIRECCION VARCHAR(100);
    V_CIUDAD_DIR NUMBER;
    V_PAIS NUMBER;
    SQLTEXT VARCHAR2(4000);
    FLAG_ERROR BOOLEAN := false;
    MSERROR VARCHAR2(4000);
  BEGIN

    --VALIDO LA DIRECCION QUE VA A INSERTAR
    IF LENGTH(A_DIRECCION) > 100 THEN
      V_DIRECCION := NULL;
      V_CIUDAD_DIR := NULL;
      V_PAIS := NULL;
    ELSE
      V_DIRECCION := A_DIRECCION;  
    END IF;

      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(77),'COUNT(1)','A.ID_CIUDAD')||A_ID_CIUDAD;
      EXECUTE IMMEDIATE SQLTEXT INTO V_CIUDAD_DIR;      
      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(42),'COUNT(1)','A.ID_PAIS')||A_PAIS;
      EXECUTE IMMEDIATE SQLTEXT INTO V_PAIS;    
      
    --CREO EL STRING DEL UPDATE
    V_UPDATE := '';
    
    --A�ADO EL UPDATE
    V_UPDATE := 'UPDATE QUIPUX.USUARIOS_TTO ';
    
    --A�ADO EL SET VALIDANDO QUE CAMPOS VOY A ACTULIZAR
    V_UPDATE := V_UPDATE || 'SET ID_USUARIO = ''' || A_ID_USUARIO || ''' ';
    IF A_ID_DOCUMENTO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_DOCUMENTO = ' || TO_CHAR(A_ID_DOCUMENTO) || ' ';
    END IF;
    IF A_APELLIDOS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', APELLIDOS = ''' || A_APELLIDOS || ''' ';
    END IF;
    IF A_NOMBRES IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', NOMBRES = ''' || A_NOMBRES || ''' ';
    END IF;
    IF V_DIRECCION IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', DIRECCION = ''' || V_DIRECCION || ''' ';
    END IF;
    IF V_CIUDAD_DIR IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', CIUDAD_DIR = ' || V_CIUDAD_DIR || ' ';
    END IF;
    IF A_TELEFONO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', TELEFONO = ''' || A_TELEFONO || ''' ';
    END IF;
    IF A_EMP_O_PART IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', EMP_O_PART = ''' || A_EMP_O_PART || ''' ';
    END IF;
    IF A_SEXO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', SEXO = ''' || A_SEXO || ''' ';
    END IF;
    IF A_FECHA_NACIMIENTO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', FECHA_NACIMIENTO = TO_DATE('''||A_FECHA_NACIMIENTO||''',''DD/MM/YYYY'')';
    END IF;
    IF A_PAIS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_PAIS = ' || TO_CHAR(V_PAIS) || ' ';
    END IF;
    IF A_FAX IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', FAX = ''' || A_FAX || ''' '; 
    END IF;
    IF A_EMAIL IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', EMAIL = ''' || A_EMAIL || ''' ';
    END IF;
    
    --A�ADO EL WHERE
    V_UPDATE := V_UPDATE || 'WHERE ID_USUARIO = ''' || A_ID_USUARIO || ''' AND ID_DOCUMENTO = '||TO_CHAR(A_ID_DOCUMENTO);

    -- ACTUALIZAR EL REGISTRO DEL PROPIETARIO
    EXECUTE IMMEDIATE V_UPDATE;   
    
    --INSERTO LA DIRECCION
      FLAG_ERROR := FT_INSERTAR_DIRECCION(A_RADICADO, A_ID_USUARIO, A_DIRECCION, A_ID_CIUDAD, A_TELEFONO, A_FAX);
      COMMIT;
      RETURN FLAG_ERROR;
      
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            --FLAG_ERROR := FT_LOG_ACTUALIZACION('USUARIOS_TTO',MSERROR,GV_RADICADO,A_ID_USUARIO, 'FT_ACTUALIZAR_USUARIO');
            return FLAG_ERROR;
  end FT_ACTUALIZAR_USUARIO;

/
--------------------------------------------------------
--  DDL for Function FT_INSERTAR_DIRECCION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."FT_INSERTAR_DIRECCION" (A_RADICADO NUMBER, A_ID_USUARIO VARCHAR2,A_DIRECCION VARCHAR2,A_MUNICIPIO NUMBER,A_TELEFONO VARCHAR2,A_FAX VARCHAR2) RETURN BOOLEAN
  AS
    V_CONSECUTIVO NUMBER;
    V_TIPO_ENTIDAD VARCHAR2(2);
    V_CONFIRMACION_CONTACTO NUMBER;
    V_ID_FUENTE_DIRECCION NUMBER;
    V_ID_DEPARTAMENTO NUMBER;
    V_MUNICIPIO NUMBER;
    SQLTEXT varchar2(4000 byte) := null;
    V_TABLA VARCHAR2(30);
    FLAG_ERROR BOOLEAN := false;
    MSERROR varchar2(4000 byte);
  BEGIN
    
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(77),'COUNT(1)','A.ID_CIUDAD')||A_MUNICIPIO;
    EXECUTE IMMEDIATE SQLTEXT INTO V_MUNICIPIO;
    
    --VERIFICO QUE TIPO DE ENTIDAD ES
    SELECT DSE.TIPO_ENTIDAD
        INTO V_TIPO_ENTIDAD
    FROM DS_MAESTRO DSM,
              DS_ENTIDAD DSE
    WHERE DSM.ID_ENTIDAD = DSE.ID_ENTIDAD AND
              DSM.ID_RADICADO = A_RADICADO;
    IF V_TIPO_ENTIDAD = 'EE' THEN
      V_CONFIRMACION_CONTACTO := 2;
      V_ID_FUENTE_DIRECCION := 16;
    ELSE
      V_CONFIRMACION_CONTACTO := 5;
      V_ID_FUENTE_DIRECCION := 15;
    END IF;
    
    --VALIDO SI YA EXISTE LA DIRECCION
    BEGIN
      SELECT  UTD.CONSECUTIVO_DIRECCION
      INTO  V_CONSECUTIVO
      FROM USUARIOS_TTO_DIRECCIONES UTD
      WHERE UPPER(UTD.DIRECCION) = UPPER(A_DIRECCION) AND
            UTD.ID_MUNICIPIO = V_MUNICIPIO AND
            UTD.TELEFONO = A_TELEFONO AND
            UTD.ID_USUARIO = A_ID_USUARIO;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_CONSECUTIVO := NULL;
    END;
    
    --CONSULTO EL CODIGO DEL DEPARTAMENTO PARA LA CIUDAD REPORTADA
    BEGIN
      SELECT C.ID_DEPARTAMENTO
      INTO V_ID_DEPARTAMENTO
      FROM CIUDADES C
      WHERE C.ID_CIUDAD = V_MUNICIPIO;
    EXCEPTION
    WHEN OTHERS THEN
      V_ID_DEPARTAMENTO := NULL;
    END;
          
    --SI NO EXISTE LA INSERTO SI YA EXISTE SOLO ACTUALIZO LA FECHA DE MODIFICACION
    IF V_CONSECUTIVO IS NULL THEN
      --CONSULTA EL MAXIMO CONSECUTIVO
      BEGIN
        SELECT MAX(UTD.CONSECUTIVO_DIRECCION)
        INTO V_CONSECUTIVO
        FROM USUARIOS_TTO_DIRECCIONES UTD
        WHERE UTD.ID_USUARIO = A_ID_USUARIO;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_CONSECUTIVO := 0;
      END;
      
      IF V_CONSECUTIVO = 99 THEN
        RETURN TRUE;
      END IF;
      
      IF V_CONSECUTIVO IS NULL THEN
        V_CONSECUTIVO := 0;
      END IF;
      V_CONSECUTIVO := V_CONSECUTIVO + 1;
      
      --ACTUALIZO TODAS LAS DIRECCIONES DE ESTE USUARIO A PRINCIPAL N
      UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
      SET PRINCIPAL = 'N'
      WHERE ID_USUARIO = A_ID_USUARIO;
      
      V_TABLA := 'USUARIOS_TTO_DIRECCIONES';
      --INSERTO LA NUEVA DIRECCION COMO PRINCIPAL
      INSERT INTO QUIPUX.USUARIOS_TTO_DIRECCIONES
                  (ID_USUARIO,
                  CONSECUTIVO_DIRECCION,
                  DIRECCION,
                  ID_MUNICIPIO,
                  ID_TIPO_DIRECCION,
                  PRINCIPAL,
                  TELEFONO,
                  FAX,
                  TELEFONO2,
                  ACTIVA,
                  ID_CONFIRMACION_CONTACTO,
                  ID_DEPARTAMENTO)
          VALUES (A_ID_USUARIO,
                  V_CONSECUTIVO,
                  A_DIRECCION,
                  V_MUNICIPIO,
                  '1',
                  'S',
                  A_TELEFONO,
                  A_FAX,
                  NULL,
                  'S',
                  V_CONFIRMACION_CONTACTO,
                  V_ID_DEPARTAMENTO);
                  
          V_TABLA := 'USUARIOS_TTO_DIRECCION_FUENTE';
          --INSERTO EN USUARIOS_TTO_DIRECCION_FUENTE
          INSERT INTO QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE
                      (ID_USUARIO,
                      CONSECUTIVO_DIRECCION,
                      ID_FUENTE_DIRECCION,
                      FECHA_FUENTE,
                      IDENTIFICADOR_DIRECCION)
              VALUES (A_ID_USUARIO,
                      V_CONSECUTIVO,
                      V_ID_FUENTE_DIRECCION,
                      SYSDATE,
                      A_ID_USUARIO);              
      ELSE
           V_TABLA := 'USUARIOS_TTO_DIRECCION_FUENTE'; 
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE
          SET FECHA_FUENTE = SYSDATE,
              ID_FUENTE_DIRECCION = V_ID_FUENTE_DIRECCION
          WHERE ID_USUARIO = A_ID_USUARIO AND
                CONSECUTIVO_DIRECCION = V_CONSECUTIVO;
                
          --ACTUALIZO TODAS LAS DIRECCIONES DE ESTE USUARIO A PRINCIPAL N
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
          SET PRINCIPAL = 'N'
          WHERE ID_USUARIO = A_ID_USUARIO;
          V_TABLA := 'USUARIOS_TTO_DIRECCIONES';
          --ACTUALIZO COMO PRINCIPAL LA DIRECCION EXISTENTE
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
          SET PRINCIPAL = 'S',
              ID_CONFIRMACION_CONTACTO = V_CONFIRMACION_CONTACTO
          WHERE ID_USUARIO = A_ID_USUARIO AND
                CONSECUTIVO_DIRECCION = V_CONSECUTIVO;
    END IF;

      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            --FLAG_ERROR := FT_LOG_ACTUALIZACION(V_TABLA,MSERROR,GV_RADICADO,A_ID_USUARIO, 'FT_INSERTAR_DIRECCION');
            RETURN TRUE;
    
  end FT_INSERTAR_DIRECCION;

/
--------------------------------------------------------
--  DDL for Function FT_NEW_LINEA_SAP
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."FT_NEW_LINEA_SAP" (V_ID_MARCA VARCHAR2, V_DESC_LINEA VARCHAR2) RETURN VARCHAR2 AS 

V_ID_NEW_LINEA VARCHAR2(10);
V_RETURN VARCHAR2(100);
V_CONSECUTIVO NUMBER :=0; --Lleva el consecutivo de la linea SAP.
V_NEW_CONSECUTIVO NUMBER :=0; --Lleva el nuevo consecutivo de la linea SAP.

CURSOR LINEA IS
SELECT * FROM DQ_SAP_LINEAS
WHERE ID_MARCA = V_ID_MARCA
ORDER BY CONSECUTIVO ASC;

BEGIN

FOR X IN LINEA LOOP

V_CONSECUTIVO := X.CONSECUTIVO;

  IF V_CONSECUTIVO = V_NEW_CONSECUTIVO THEN
  
      V_NEW_CONSECUTIVO := V_NEW_CONSECUTIVO +1;
      
  ELSE     
  
    V_ID_NEW_LINEA:= X.ID_MARCA ||V_NEW_CONSECUTIVO;
    
    V_RETURN := V_ID_NEW_LINEA || ' ' || V_DESC_LINEA;
    
     INSERT INTO DQ_SAP_LINEAS (ID_MARCA, DESC_MARCA, ID_LINEA, DESC_LINEA, ACCION,CONSECUTIVO)
     VALUES (X.ID_MARCA, X.DESC_MARCA,V_ID_NEW_LINEA,V_DESC_LINEA, 'Crear', V_NEW_CONSECUTIVO);
     COMMIT;    
     EXIT;     
  END IF;
  
END LOOP;
 RETURN V_RETURN;
END FT_NEW_LINEA_SAP;

/
--------------------------------------------------------
--  DDL for Function FT_VICTOR
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."FT_VICTOR" (cadena1 varchar2)
return varchar2 is

suma number:=0;
cadena2 varchar2(4000);
resultado varchar2(4000);

BEGIN

for  index1 in 0..9 loop

  cadena2 := replace(cadena1,'*',index1);
  
  if (mod(to_number(cadena2),6)=0)then
      resultado := resultado || ' ' || index1;
  end if;

end loop;

return resultado;
END FT_VICTOR;

/
--------------------------------------------------------
--  DDL for Function LEER_ARCHIVO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CORRECCION_DATOS"."LEER_ARCHIVO" (P_DIRECTORIO VARCHAR2, P_ARCHIVO VARCHAR2 ) RETURN TTB_ARCHIVO_TEXTO PIPELINED AS

  VARCHIVO    UTL_FILE.FILE_TYPE;
  VLINEA      VARCHAR2(4000);
  
BEGIN

  VARCHIVO := UTL_FILE.FOPEN (P_DIRECTORIO, P_ARCHIVO, 'R');
 
  -- LEEMOS CADA UNA DE LAS L�NEAS DEL ARCHIVO Y LA RETORNAMOS
  LOOP
    BEGIN
      UTL_FILE.GET_LINE (VARCHIVO, VLINEA);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        EXIT;
    END;
 
    PIPE ROW (VLINEA);
  END LOOP;
 
  UTL_FILE.FCLOSE (VARCHIVO);
 
  RETURN;
END;

/
