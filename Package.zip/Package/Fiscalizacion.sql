--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type TP_FECHA_DIR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_FISCALIZACION"."TP_FECHA_DIR" AS OBJECT 
(
NRO_PLACA VARCHAR2(10 BYTE), 	
ID_INTERLOCUTOR	VARCHAR2(10 BYTE), 
FECHA_PAGO DATE,	
DIRECCION VARCHAR2(255 BYTE), 	
DEPARTAMENTO VARCHAR2(30 BYTE), 
MUNICIPIO VARCHAR2(30 BYTE), 	
ESTADO VARCHAR2(255 BYTE), 

Constructor Function TP_FECHA_DIR Return Self As Result
)
/
CREATE OR REPLACE TYPE BODY "BD_FISCALIZACION"."TP_FECHA_DIR" AS

Constructor Function TP_FECHA_DIR Return Self As Result AS
TP_FECHA_DIR_1 TP_FECHA_DIR:=TP_FECHA_DIR(NULL,NULL,NULL,NULL,NULL,NULL,NULL);

BEGIN
   Self := TP_FECHA_DIR_1;
      Return;
            End TP_FECHA_DIR;
END;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_FECHA_DIR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_FISCALIZACION"."TP_LISTA_FECHA_DIR" is TABLE OF TP_FECHA_DIR;

/
--------------------------------------------------------
--  DDL for Procedure SHAREFLE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BD_FISCALIZACION"."SHAREFLE" IS
Name_File Varchar2(255 byte):='Prueba.txt';
  v_MyFileHandle UTL_FILE.FILE_TYPE;
  BEGIN
     v_MyFileHandle := UTL_FILE.FOPEN('DIR_OMISOS',Name_File,'W');  
       For Ln_Index In 1..10 Loop

        UTL_FILE.PUT_LINE(v_MyFileHandle, 'Hola blados' );
       End Loop;
        UTL_FILE.FCLOSE(v_MyFileHandle);
 EXCEPTION
      WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE
                ('ERROR ' || TO_CHAR(SQLCODE) || SQLERRM);
           NULL; 
 END; 

/
--------------------------------------------------------
--  DDL for Package PGK_VALIDACION_PROP_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PGK_VALIDACION_PROP_RUNT" AS 

Procedure Sp_Iniciar_Validacion;
--ejecutar primero antes de iniciar la actualizacion
Procedure Sp_Actualizar_Fecha;

END PGK_VALIDACION_PROP_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_ACTUALIZAR_CODIGO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_ACTUALIZAR_CODIGO" AS 

PROCEDURE sp_iniciar_proceso;

END PKG_ACTUALIZAR_CODIGO;

/
--------------------------------------------------------
--  DDL for Package PKG_ACTUALIZAR_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_ACTUALIZAR_VEHICULOS" AS 

PROCEDURE SP_INSERTAR_VEHICULOS;
PROCEDURE SP_UPDATE_CARAC;
FUNCTION FT_SI_EXISTE (vPlaca Varchar,vMarcado_archivo Varchar,vModelo Varchar,vId_marca Varchar,vId_linea Varchar,
                       vId_servicio Varchar,vId_clase Varchar,vId_carroceria Varchar,vGrupo Varchar,
                       vId_cilindraje Varchar,vTipo_carga Varchar,vTipo_caja Varchar,vN_puertas Varchar,
                       vCombustion_traccion Varchar,vId_capacidad Varchar) Return Boolean;

END PKG_ACTUALIZAR_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package PKG_BUSCAR_NOVEDAD_SAP_FINAL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_BUSCAR_NOVEDAD_SAP_FINAL" AS 

/*ISVA
Nombre     :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :nPlaca, nId_Novedad,dFecha_Novedad
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :Valida los vehiculos que son sujetos o no del impuesto
           :Vehiculos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

PROCEDURE SP_INICIAR_OMISOS (Vigencia_Anno Number);


END PKG_BUSCAR_NOVEDAD_SAP_FINAL;

/
--------------------------------------------------------
--  DDL for Package PKG_BUSCAR_NOV_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_BUSCAR_NOV_TTO" AS 
--Digitar A�o de la Vigencia y El Tramite a Validar
PROCEDURE SP_BUSCAR_NOVEDAD_ID(nVigencia Number,lnId_Tramite Number);
--Digitar A�o de la Vigencia para Validar cualquier Vigencia
PROCEDURE SP_BUSCAR_NOVEDADES(nVigencia Number);

END PKG_BUSCAR_NOV_TTO;

/
--------------------------------------------------------
--  DDL for Package PKG_BUSQUEDA_FISCA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_BUSQUEDA_FISCA" AS 
PROCEDURE SP_INSERTAR_NOVEDAD_MAX_DATE;
PROCEDURE SP_BUSCAR_PROPIETARIOS;
PROCEDURE SP_VALIDAR_MATRICULA_INICIAL;
PROCEDURE SP_ACTULIZAR_DIVIPO_PROP;
PROCEDURE SP_ACTULIZAR_DIVIPO_NOVE;
PROCEDURE SP_CARACTERISTICAS_VEHICULOS;
PROCEDURE SP_VALIDAR_PROPIETARIOS;
PROCEDURE SP_BUSQUEDA_PAGOS_DIR;
FUNCTION FT_FECHA_MAYOR_PBF(Placa Varchar2, Tramite Number, Tramite_2 number) RETURN DATE;
FUNCTION FT_ULTIMO_TRANSITO_PROP (Codigo Number, Placa Varchar2) Return Number;
FUNCTION FT_ULTIMO_TRANSITO_NOVEDAD (Codigo Number, Placa Varchar2) Return Number;
FUNCTION Ft_Radicacion (Placa Varchar2,Fecha Date) Return Number;
FUNCTION Ft_Validar_Traspaso_Indeterm (Placa Varchar2) Return Boolean;
PROCEDURE Sp_Validar_Traspaso_Indeterm;
END PKG_BUSQUEDA_FISCA;

/
--------------------------------------------------------
--  DDL for Package PKG_CILINDRAJE_MENOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_CILINDRAJE_MENOR" AS 

  PROCEDURE SP_CILINDRAJE_MENOR;

END PKG_CILINDRAJE_MENOR;

/
--------------------------------------------------------
--  DDL for Package PKG_DIRECCION_FECHA_PAGO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_DIRECCION_FECHA_PAGO" AS 

/*ISVA
Nombre     :PKG_DIRECCION_FECHA_PAGO
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Busca las direcciones de los interlocutores
           :que reportan un pago
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

PROCEDURE SP_BUSCAR_DIR_DECLARACION;

END PKG_DIRECCION_FECHA_PAGO;

/
--------------------------------------------------------
--  DDL for Package PKG_DIRECCION_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_DIRECCION_TTO" AS 

PROCEDURE SP_OBTENER_DIRECCION;

END PKG_DIRECCION_TTO;

/
--------------------------------------------------------
--  DDL for Package PKG_HISTORIALES_TRASPASOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_HISTORIALES_TRASPASOS" AS 

PROCEDURE sp_iniciar(av_vigencia NUMBER);

END PKG_HISTORIALES_TRASPASOS;

/
--------------------------------------------------------
--  DDL for Package PKG_INCONSISTENCIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_INCONSISTENCIA" AS 

PROCEDURE SP_INICIAR;

END PKG_INCONSISTENCIA;

/
--------------------------------------------------------
--  DDL for Package PKG_LUI
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_LUI" AS 

PROCEDURE sp_iniciar;

END PKG_LUI;

/
--------------------------------------------------------
--  DDL for Package PKG_TRANZABILIDAD_NOVEDAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_TRANZABILIDAD_NOVEDAD" AS 

FUNCTION SP_EJEMPLO (Placa Varchar,Fecha Date,Id_Novedad Number,Codigo_Novedad Number)Return Boolean;

END PKG_TRANZABILIDAD_NOVEDAD;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_CARACTERISTICAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_VALIDAR_CARACTERISTICAS" AS 

PROCEDURE SP_EJECUTAR_OMISOS(Vigencia Number);

END PKG_VALIDAR_CARACTERISTICAS;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_DIRECCION_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_VALIDAR_DIRECCION_RUNT" AS 


PROCEDURE SP_VALIDAR_DIR;
PROCEDURE SP_VALIDAR_ESTRUCTURA;

PROCEDURE SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada Varchar2,Usuario Varchar2, CodigoRowId Varchar2, Mensaje Varchar2);
PROCEDURE SP_DIRECCION_RUNT;

END PKG_VALIDAR_DIRECCION_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_PERSONA_INDETER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_FISCALIZACION"."PKG_VALIDAR_PERSONA_INDETER" AS 
PROCEDURE Sp_Validar_Traspaso_Indeter;
Function Ft_Validar_Persona_Inde (CC_Usuario Varchar2/*,Documento Varchar2*/) Return Boolean;
END PKG_VALIDAR_PERSONA_INDETER;

/
--------------------------------------------------------
--  DDL for Package Body PGK_VALIDACION_PROP_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PGK_VALIDACION_PROP_RUNT" AS

Function Ft_Validar_Propietario (vPlaca Varchar,vId_Usuario Varchar, vId_Documento Varchar) return Number
As
Ln_existe Number:=0;
Cursor curInterlocutor Is Select Distinct Id_Usuario, Id_Documento From Fc_Interlocutores_Sap 
                                    Where Id_Usuario = vId_Usuario And To_Date(Fecha_Asociar_Ic) = ''
                                                And Obsoleto is Null;
Begin
    For Ln_Index In curInterlocutor Loop  
                If Ln_Index.Id_Usuario = vId_Usuario And Ln_Index.Id_Documento =  vId_Documento Then 
                        Ln_existe := 1;      
                Elsif (Ln_Index.Id_Usuario = vId_Usuario And Ln_Index.Id_Documento !=  vId_Documento)
                        And Ln_existe Not In (1) Then
                        Ln_existe := 2;
                End If; 
    End Loop;          
                Return Ln_existe;      
End Ft_Validar_Propietario;

Function Ft_Validar_Digito_Verificacion (vId_Nit Number) Return Number
As 
vId_Interlocutor Number;
Begin    
    vId_Interlocutor:= Correccion_Datos.Pkg_Ds_Estandariza_Runt.Ft_Calcular_Digito_Verifica(vId_Nit);
     If vId_Interlocutor > 0 Then
        Return vId_Interlocutor;
    Else 
        Return 0;
    End If;
 Exception 
    When Others Then
        Return 0;
End Ft_Validar_Digito_Verificacion;

PROCEDURE Sp_Validacion_Propietarios (vPlaca Varchar, dFecha_Traspaso_Runt Date) AS

Ln_Existe Number:=0;
lv_Interlocutor Varchar2 (255 byte);

Cursor curProp Is Select Nro_Placa,Id_Usuario,Id_Documento,Porcentaje,Fecha_Sap From Fc_Propietarios_Runt
                            Where Nro_Placa = vPlaca And Fecha_Inicio_Propiedad = dFecha_Traspaso_runt;
Begin
     For Ln_Index In curProp Loop
        Null;
     End Loop;

       
End Sp_Validacion_Propietarios;

Procedure Sp_Iniciar_Validacion 
As

Cursor curPlacas Is Select Distinct    nro_placa,id_usuario,id_documento,fecha_runt,fecha_sap From Fc_Propietarios_Runt;
Ln_Contador Number :=0;
Ld_Fecha_Runt Date;

Type tblProp is table Of curPlacas%rowType;
ArrayProp tblProp;

Begin
    Open curPlacas;
        Loop Fetch curPlacas
            Bulk Collect Into ArrayProp Limit 500;
                For Ln_Index In 1..ArrayProp.Count() Loop
                        --Capturo la fecha mayor de los traspasos Runt
                    Select Max(Fecha_Inicio_Propiedad) Into Ld_Fecha_Runt  From Fc_Propietarios_Runt
                        Where Nro_Placa = ArrayProp(Ln_Index).Nro_Placa; 
                            Sp_Validacion_Propietarios(ArrayProp(Ln_Index).Nro_Placa,Ld_Fecha_Runt);                          
                 End Loop;  
             Exit When ArrayProp.Count()<=0;
          Commit;
        End Loop;
    Close curPlacas;
End Sp_Iniciar_Validacion;

Function Ft_Fecha_Mayor_Sap (vPlaca Varchar) Return Date
As
Ld_Fecha_Sap Date;
Begin
        --Retorno la ultmima fecha de sap de asignar interlocutor
        Select Max(Fecha_Asociar_Ic) Into Ld_Fecha_Sap  From Fc_Interlocutores_Sap
         Where Nro_Placa = vPlaca;
            Return Ld_Fecha_Sap;
END Ft_Fecha_Mayor_Sap;

--Actualiza la fecha masiva mayor de sap
Procedure Sp_Actualizar_Fecha  
As

Cursor curPlacas Is Select Distinct Nro_placa From Fc_Propietarios_Runt;
ld_Fecha_Mayor Date;
Ln_Contador Number:=0;
Begin
For Ln_Index In curPlacas Loop
Begin
        ld_Fecha_Mayor:=Ft_Fecha_Mayor_Sap (Ln_Index.Nro_placa);
            Update Fc_Propietarios_Runt Set Fecha_Sap = ld_Fecha_Mayor
                Where Nro_Placa = Ln_Index.Nro_Placa;

If Ln_Contador = 500 Then
    Ln_Contador:=0;
    Commit;
 Else
    Ln_Contador:=Ln_Contador + 1;
 End If;
  
Exception
When Others Then
    Continue;
End;
End Loop;

END Sp_Actualizar_Fecha;


END PGK_VALIDACION_PROP_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_ACTUALIZAR_CODIGO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_ACTUALIZAR_CODIGO" AS

PROCEDURE sp_iniciar_proceso AS

Cursor lcur Is select RowId, Nro_Placa, Municipio, Departamento from Fc_reporte_Pagos;
Divipio Varchar(255);
Codigo Number:=0;

ln_Cantidad Number :=0;

BEGIN
    For Ln_Index In lcur Loop
     Begin
        Divipio:=(Ln_Index.Departamento||Ln_Index.Municipio);
        Divipio:=Replace(Divipio,'�','A');
        Divipio:=Replace(Divipio,'�','E');
        Divipio:=Replace(Divipio,'�','I');
        Divipio:=Replace(Divipio,'�','O');
        Divipio:=Replace(Divipio,'�','U');
        Divipio:=Replace(Divipio,'�','U');
        Divipio:=Replace(Divipio,'�','N');
        Divipio:=Replace(Divipio,'-','');
        Divipio:=Replace(Divipio,' ','');
        
        Select Id_Tramite Into Codigo From Prueba_3 Where Nro_Placa = Divipio;
            
            Update Fc_Reporte_Pagos Rp Set Codigo_Runt = Codigo
                Where Rp.Nro_Placa = Ln_Index.Nro_Placa And Rp.RowId = Ln_Index.RowId;
                
        If ln_Cantidad = 500 Then
            ln_Cantidad:=0;
            Commit;
        Else
          ln_Cantidad:= ln_Cantidad +1;
        End If;
        
        Exception
            When Others then
                Continue;
                
     End;    
    End Loop;
END sp_iniciar_proceso;

END PKG_ACTUALIZAR_CODIGO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_ACTUALIZAR_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_ACTUALIZAR_VEHICULOS" AS

PROCEDURE SP_INSERTAR_VEHICULOS
AS
bExiste Boolean:=False;
nExiste Number:=0;
Cursor curVehiculo is Select * from Fc_Vehiculos_Temp;

Type TableCur is Table Of curVehiculo%RowType;
ArrayVehiculo TableCur;
Begin 
Open curVehiculo;
    Loop Fetch curVehiculo
        Bulk Collect Into  ArrayVehiculo Limit 100;
            For Ln_Index in 1..ArrayVehiculo.Count() Loop
            Begin
            
            
            Select Count(1) Into nExiste From Fc_Vehiculos
            Where Nro_placa = ArrayVehiculo(Ln_Index).Nro_placa; 
            
                     
            If nExiste > 0 Then                      
                     bExiste:= Ft_Si_Existe(ArrayVehiculo(Ln_Index).Nro_Placa,ArrayVehiculo(Ln_Index).Marcado_archivo,
                         ArrayVehiculo(Ln_Index).Modelo,ArrayVehiculo(Ln_Index).Id_marca,
                         ArrayVehiculo(Ln_Index).Id_linea,ArrayVehiculo(Ln_Index).Id_servicio,ArrayVehiculo(Ln_Index).Id_clase,
                         ArrayVehiculo(Ln_Index).Id_carroceria,
                         ArrayVehiculo(Ln_Index).Grupo,ArrayVehiculo(Ln_Index).Id_cilindraje,ArrayVehiculo(Ln_Index).Tipo_carga,
                         ArrayVehiculo(Ln_Index).Tipo_caja,ArrayVehiculo(Ln_Index).N_puertas,
                         ArrayVehiculo(Ln_Index).Combustion_traccion,ArrayVehiculo(Ln_Index).Id_capacidad);
                
                If bExiste = False Then
                    Delete Fc_Vehiculos
                    Where Nro_Placa = ArrayVehiculo(Ln_Index).Nro_placa;
                    Insert Into Fc_Vehiculos 
                    Select * From Fc_Vehiculos_Temp
                    Where Nro_Placa = ArrayVehiculo(Ln_Index).Nro_placa;
                End If;
            Else
                Insert Into Fc_Vehiculos 
                Select * From Fc_Vehiculos_Temp
                Where Nro_Placa = ArrayVehiculo(Ln_Index).Nro_placa;
            End If; 
         /* Exception
            When Others Then
            Insert Into Prueba (Nro_Placa)
            Values (ArrayVehiculo(Ln_Index).Nro_placa);*/
            End;
            End Loop;
        Exit When ArrayVehiculo.Count<=0;
        Commit;
    End Loop;
    Commit;
END SP_INSERTAR_VEHICULOS;

PROCEDURE SP_UPDATE_CARAC
As
Contador Number;
--Servicio
Begin

/*Delete Fc_Vehiculos_Temp Where Nro_Placa In ('HAN283','HAN284','HZL401','KHF28D','LUG53D','MXZ030')
And Marcado_Archivo = 'X';

--Error de Sap Con Duplicidad 
Insert Into Fc_Vehiculos_Temp
Select Upper(Replace(Nro_Placa,'-','')),Marcado_Archivo,Marcado_Archivo_Usuario,Modificado_Usuario,Modelo,Id_Marca,Nombre_Marca,
Id_Linea,Nombre_Linea,Id_Servicio,Nombre_Servicio,Id_Clase,Nombre_Clase,Id_Carroceria,Nombre_Carroceria,Grupo,Id_Cilindraje,
Cilindraje,Tipo_Carga,Tipo_Caja,N_Puertas,Combustion_Traccion,Id_Capacidad,Capacidad,Id_Departamento,Departamento,Id_Municipio,
Municipio,Fecha_Matricula,Avaluo,Id_Novedad,Nombre_Novedad,Valor_Factura,Creado_Usuario,Fecha_Creacion,Observacion_Exis,RADICADO 
From Fc_Vehiculos_Temp
Where Nro_Placa In ('dic-13','dic-22','dic-30','dic-32','dic-44','dic-50','dic-81','dic-83','dic-94','dic-95')
And Marcado_Archivo Is Null;
Delete Fc_Vehiculos_temp
Where Nro_Placa In ('dic-13','dic-22','dic-30','dic-32','dic-44','dic-50','dic-81','dic-83','dic-94','dic-95')
And Marcado_Archivo Is Null;
Commit;*/

Update Fc_Vehiculos_Temp Set Id_Servicio = '01'
Where Id_Servicio = '1';

Update Fc_Vehiculos_Temp Set Id_Servicio = '02'
Where Id_Servicio = '2';

Update Fc_Vehiculos_Temp Set Id_Servicio = '03'
Where Id_Servicio = '3';

Update Fc_Vehiculos_Temp Set Id_Servicio = '04'
Where Id_Servicio = '4';

Update Fc_Vehiculos_Temp Set Id_Servicio = '05'
Where Id_Servicio = '5';

Update Fc_Vehiculos_Temp Set Id_Servicio = '06'
Where Id_Servicio = '6';

Update Fc_Vehiculos_Temp Set Id_Servicio = '07'
Where Id_Servicio = '7';

Update Fc_Vehiculos_Temp Set Id_Servicio = '08'
Where Id_Servicio = '8';

Update Fc_Vehiculos_Temp Set Id_Servicio = '09'
Where Id_Servicio = '9';

--Clase
Update Fc_Vehiculos_Temp Set Id_Clase = '00'
Where Id_Clase = '0';

Update Fc_Vehiculos_Temp Set Id_Clase = '01'
Where Id_Clase = '1';

Update Fc_Vehiculos_Temp Set Id_Clase = '02'
Where Id_Clase = '2';

Update Fc_Vehiculos_Temp Set Id_Clase = '03'
Where Id_Clase = '3';

Update Fc_Vehiculos_Temp Set Id_Clase = '04'
Where Id_Clase = '4';

Update Fc_Vehiculos_Temp Set Id_Clase = '05'
Where Id_Clase = '5';

Update Fc_Vehiculos_Temp Set Id_Clase = '06'
Where Id_Clase = '6';

Update Fc_Vehiculos_Temp Set Id_Clase = '07'
Where Id_Clase = '7';

Update Fc_Vehiculos_Temp Set Id_Clase = '08'
Where Id_Clase = '8';

Update Fc_Vehiculos_Temp Set Id_Clase = '09'
Where Id_Clase = '9';

--Carroceria
Update Fc_Vehiculos_Temp Set Id_Carroceria = '00'
Where Id_Carroceria = '0';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '01'
Where Id_Carroceria = '1';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '02'
Where Id_Carroceria = '2';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '03'
Where Id_Carroceria = '3';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '04'
Where Id_Carroceria = '4';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '05'
Where Id_Carroceria = '5';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '06'
Where Id_Carroceria = '6';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '07'
Where Id_Carroceria = '7';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '08'
Where Id_Carroceria = '8';

Update Fc_Vehiculos_Temp Set Id_Carroceria = '09'
Where Id_Carroceria = '9';

--Cilindraje
Update Fc_Vehiculos_Temp Set Id_Cilindraje = '01'
Where Id_Cilindraje = '1';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '02'
Where Id_Cilindraje = '2';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '03'
Where Id_Cilindraje = '3';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '04'
Where Id_Cilindraje = '4';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '05'
Where Id_Cilindraje = '5';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '06'
Where Id_Cilindraje = '6';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '07'
Where Id_Cilindraje = '7';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '08'
Where Id_Cilindraje = '8';

Update Fc_Vehiculos_Temp Set Id_Cilindraje = '09'
Where Id_Cilindraje = '9';

--Departamento

Update Fc_Vehiculos_Temp Set Id_Departamento = '05'
Where Id_Departamento = '5';

Update Fc_Vehiculos_Temp Set Id_Departamento = '08'
Where Id_Departamento = '8';

--Novedades
Update Fc_Vehiculos_temp Set Nombre_novedad = 'MATRICULA INICIAL', Id_Novedad = '00'
Where Id_Novedad = '0';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'BLINDAJE', Id_Novedad = '02'
Where Id_Novedad = '2';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'CANCELACION', Id_Novedad = '03'
Where Id_Novedad = '3';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'REMATRICULA', Id_Novedad = '04'
Where Id_Novedad = '4' ;

Update Fc_Vehiculos_temp Set Nombre_novedad = 'REAVALUO', Id_Novedad = '05'
Where Id_Novedad = '5';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'RADICACION', Id_Novedad = '06'
Where Id_Novedad = '6';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'TRASLADO', Id_Novedad = '07'
Where Id_Novedad = '7' ;

Update Fc_Vehiculos_temp Set Nombre_novedad = 'CAMBIO SERV PU PA', Id_Novedad = '08'
Where Id_Novedad = '8' ;

Update Fc_Vehiculos_temp Set Nombre_novedad = 'COND CON RECUPE', Id_Novedad = '09'
Where Id_Novedad = '9';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'INTERNACION TEM'
Where Id_Novedad = '10';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'CAMBIO DE CARAC'
Where Id_Novedad = '11';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'COND SIN RECUPE'
Where Id_Novedad = '13';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'CAMBIO SERV PA PU'
Where Id_Novedad = '14';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'HOMOLOGACION'
Where Id_Novedad = '15';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'CLASICO ANTIGUO'
Where Id_Novedad = '16';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'PRESCRIP'
Where Id_Novedad = '17';

Update Fc_Vehiculos_temp Set Nombre_novedad = 'DESBLINDAJE'
Where Id_Novedad = '18';
Commit;


Delete From Fc_Vehiculos Where 
Nro_Placa IN (Select Nro_Placa From Fc_Vehiculos_Temp);

Insert Into Fc_Vehiculos
Select * From Fc_Vehiculos_Temp;
Commit;

END SP_UPDATE_CARAC;


FUNCTION FT_SI_EXISTE (vPlaca Varchar,vMarcado_archivo Varchar,vModelo Varchar,vId_marca Varchar,vId_linea Varchar,
                       vId_servicio Varchar,vId_clase Varchar,vId_carroceria Varchar,vGrupo Varchar,
                       vId_cilindraje Varchar,vTipo_carga Varchar,vTipo_caja Varchar,vN_puertas Varchar,
                       vCombustion_traccion Varchar,vId_capacidad Varchar) Return Boolean
As

Cursor curVehiculos Is Select Marcado_archivo,Modelo,Id_marca,Id_linea,Id_servicio,Id_clase,Id_carroceria,
                              Grupo,Id_cilindraje,Tipo_Carga,Tipo_caja,N_puertas,Combustion_traccion,Id_capacidad
From Fc_Vehiculos Where Nro_Placa = vPlaca;

Begin
For Ln_Index In curVehiculos Loop
    
    --Ln_Index.Marcado_archivo = vMarcado_archivo And
       If Ln_Index.Modelo is null And vModelo is Not null Then     
            Return False;  --Inserte
   Elsif Ln_Index.Modelo != vModelo Then     
            Return False;  --Inserte
   Else
        Return True; --No Inserte
   End If;

End Loop;
END FT_SI_EXISTE;
END PKG_ACTUALIZAR_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_BUSCAR_NOVEDAD_SAP_FINAL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_BUSCAR_NOVEDAD_SAP_FINAL" AS
--Instancias
nVigencia Number:=0;  

Procedure Sp_Generar_Archivos As

/*ISVA
Nombre     :Sp_Generar_Archivos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lcur_Novedades, lcur_Pagos
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

CURSOR lcur_Novedades Is 
SELECT
    nro_placa,
    nombre_tramite,
    fecha_tramite,
    estado
FROM    
    fc_busqueda_novedades_temp;

CURSOR lcur_Pagos IS
SELECT
    nro_placa,
    fecha_pago,
    vigencia
FROM
    fc_reporte_pagos_temp;
    
    
Name_File_1 Varchar2(255 byte):='Activas '||nVigencia||' '||To_Char(sysdate,'dd-mm-yyyy hh-mi-ss')||'.txt';
Name_File_2 Varchar2(255 byte):='Novedades '||nVigencia||' '||To_Char(sysdate,'dd-mm-yyyy hh-mi-ss')||'.txt';
Name_File_3 Varchar2(255 byte):='Pagos '||nVigencia||' '||To_Char(sysdate,'dd-mm-yyyy hh-mi-ss')||'.txt';

v_MyFileHandle_1 UTL_FILE.FILE_TYPE;
v_MyFileHandle_2 UTL_FILE.FILE_TYPE;
 BEGIN
     v_MyFileHandle_1 := UTL_FILE.FOPEN('DIR_OMISOS',Name_File_1,'W');  
     v_MyFileHandle_2 := UTL_FILE.FOPEN('DIR_OMISOS',Name_File_2,'W');  

       For Ln_Index In lcur_Novedades Loop
       BEGIN
       If Ln_Index.Estado = 'Activa' Then
        UTL_FILE.PUT_LINE(v_MyFileHandle_1,ln_index.nro_placa||';'||ln_index.nombre_tramite||';'||
                                         ln_index.fecha_tramite||';'||ln_index.estado);
       Else
        UTL_FILE.PUT_LINE(v_MyFileHandle_2,ln_index.nro_placa||';'||ln_index.nombre_tramite||';'||
                                         ln_index.fecha_tramite||';'||ln_index.estado);
       End If;
         EXCEPTION
            WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE
                ('ERROR ' || TO_CHAR(SQLCODE) || SQLERRM);
           CONTINUE;
        END;
       END LOOP;   
        UTL_FILE.FCLOSE(v_MyFileHandle_1);
        
        v_MyFileHandle_1 := UTL_FILE.FOPEN('DIR_OMISOS',Name_File_3,'W');  

       For Ln_Index_2 In lcur_Pagos Loop
       BEGIN
        UTL_FILE.PUT_LINE(v_MyFileHandle_1,ln_index_2.nro_placa||';'||ln_index_2.fecha_pago||';'||
                                         ln_index_2.vigencia);
         EXCEPTION
            WHEN OTHERS THEN 
           DBMS_OUTPUT.PUT_LINE
                ('ERROR ' || TO_CHAR(SQLCODE) || SQLERRM);
           CONTINUE;
        END;
       END LOOP;   
        UTL_FILE.FCLOSE(v_MyFileHandle_1);
 
End Sp_Generar_Archivos;

Procedure Sp_Insertar_Nov_Sap (vPlaca Varchar,vNombre_Novedad Varchar, dFecha_Novedad Date,vEstado Varchar) Is

/*ISVA
Nombre     :Sp_Insertar_Nov_Sap
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :vPlaca, vNombre_Novedad,dFecha_Novedad,vEstado
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :registar la placas validada
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
    Insert Into Fc_Busqueda_Novedades_Temp (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Estado)
            Values (vPlaca,vNombre_Novedad,dFecha_Novedad,vEstado);    
               
Exception 
When Others Then
    Update Prueba Set Estado='E'
    Where Nro_Placa = vPlaca;
END Sp_Insertar_Nov_Sap;

Procedure Sp_Insertar_Nov_Caracteristica (vPlaca Varchar,nId_Novedad Number)  Is

/*ISVA
Nombre     :Sp_Insertar_Nov_Caracteristica
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :vPlaca, nId_Novedad,vMensaje
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :asigna el mensaje de la validacion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

vMensaje Varchar2 (255 Byte);

Begin
    Case nId_Novedad
        When 0 Then
            vMensaje:='Formato de placa Errada';
        When 1 Then
            vMensaje:='Placa No Asignada';
        When 2 Then
            vMensaje:='Placa Errada';
        When 3 Then
            vMensaje:='Vehiculo Exento por Maq. Agricola';
        When 4 Then
            vMensaje:='Cilindraje Inferior';
        When 5 Then
            vMensaje:='Servicio Oficial';
        When 6 Then
            vMensaje:='Vehiculo Servicio Publico por Naturaleza';
        When 7 Then
            vMensaje:='Vehiculo Otro Departamento';
        When 8 Then
            vMensaje:='Marcada para Archivo';
        When 9 Then
             Insert Into Fc_Busqueda_Novedades_Temp (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Estado)
                Select Nro_Placa,'Matricula Inicial Sap',Fecha_Matricula,'Novedad' From Fc_Vehiculos
                    Where Nro_Placa = vPlaca;
        When 10 Then
               vMensaje:='Acuerdo de Pago para la Vigencia '||nVigencia;   
    End Case;
        If nId_Novedad != 9 Then
        Insert Into Fc_Busqueda_Novedades_Temp (Nro_Placa,Nombre_Tramite,Estado)
                Values (vPlaca,vMensaje,'Novedad');                  
        End If;
    
Exception 
When Others Then
    Update Prueba Set Estado='E'
    Where Nro_Placa = vPlaca;
END Sp_Insertar_Nov_Caracteristica;

Function Ft_Validar_Nov_Fecha_Igual (nPlaca Varchar, nId_Novedad Number, dFecha_Novedad Date)Return Number As

/*ISVA
Nombre     :Ft_Validar_Nov_Fecha_Igual
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :nPlaca, nId_Novedad,dFecha_Novedad
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :valida si dos novedades tiene la fecha de registro
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

nValidador Number;
type Array_Novedades is varray(5) of number(2);
arrayN Array_Novedades :=Array_Novedades(6,7,8,14);
Begin 

    If nId_Novedad = 3 Then                                      
         for i in 1..arrayN.count() loop
               nValidador:=0;
               
                   Select Count(1) Into nValidador From Fc_reporte_Novedades
                    Where Nro_Placa = nPlaca And Id_Novedad = ArrayN(i) And Fecha_Novedad = dFecha_Novedad ;  
                        While nValidador > 0 Loop 
                                if ArrayN(i) = 6 Then
                                    Return 1; --Radicacion Igual a Cancelacion                                    Exit;
                                Elsif ArrayN(i) = 7 Then
                                    Return 2; --Traslado Igual a Cancelacion                                    Exit;
                                Elsif ArrayN(i) In (8,14) Then
                                    Return 3;--Cambio de Servicio Igual a Cancelacion
                                End If;
                        End Loop;              
         End Loop;  
          return 0;
    Else 
        Return 0;
    End If;
END Ft_Validar_Nov_Fecha_Igual;

Procedure Sp_Validar_Novedad_Sap (vPlaca Varchar) Is

/*ISVA
Nombre     :Sp_Validar_Novedad_Sap
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :nPlaca
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :valida las novedades registradas en sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

vNro_Placa Varchar (100 Byte):='';
nId_Novedad Number:=0;
vNombre_Novedad  Varchar (100 Byte):='';
dFecha_Novedad Date;
vEstado Varchar (100 Byte):='';
nEstado Number :=0;
nExiste Number:=0;
vValidador_N Varchar2(10 Byte):='P';
dFecha_Anterior Date:='01/01/29';
nId_tramite_Anterior Number:=0;
vValidador_C Varchar2(100 byte):='P';
vValidador_T Varchar2(100 byte):='P';
vValidador_Pa_Pu Varchar2(100 byte):='P';
vValidador_Pu_Pa Varchar2(100 byte):='P';
vValidador_R Varchar2(100 byte):='P';
vDuplicidad_Novedad Varchar2(10 Byte):='P';
nValidador_Nove_Fecha Number:=0;

--vDuplicidad_Novedad_Trasl Varchar2(10 Byte):='P';

Cursor curNovedad is Select Distinct Nro_Placa,To_Number(Id_Novedad)Id_Novedad, Nombre_Novedad, Fecha_Novedad From Fc_reporte_Novedades
                       Where Nro_Placa = vPlaca And Id_Novedad In (3,4,6,7,8,9,13,14)
                       Order By 4,2 Asc;

Type TableCur is Table Of curNovedad%RowType;
ArrayNov TableCur;
Begin
 Open curNovedad;
    Loop Fetch curNovedad
     Bulk Collect Into ArrayNov;
        For Ln_Index in 1..ArrayNov.Count() Loop
            nExiste:=1;  
    If ArrayNov(Ln_Index).Id_Novedad Not In (9,13) Then                      
        Case--Radicacion
            When ArrayNov(Ln_Index).Id_Novedad = 6 Then
        If ArrayNov(Ln_Index).Fecha_Novedad != dFecha_Anterior Then  
            If vDuplicidad_Novedad Not In ('R') Then
                If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')>=nVigencia And vValidador_N !='T' And vValidador_C Not In ('C') Then    
                  If vValidador_Pa_Pu Not In ('Pa_Pu') Then 
                    vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                    vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                    dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                    vEstado:='Novedad';vValidador_R:='R';
                    nEstado :=1;    
                  End If;
                Elsif vValidador_C Not In ('C') Then
                       vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                        vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                        dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                        vEstado:='Activa';nEstado:= 1;
                End If;          
             Else
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vEstado:='Validar dos Radicaciones Consecutivas';
                nEstado :=1;
                Exit;
            End If;               
         Else
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vEstado:='Validar Fecha de Radicacion igual al Traslado';
                nEstado :=1;
                Exit;
         End If;        
                                --Cancelacion
                When ArrayNov(Ln_Index).Id_Novedad = 3 Then
                                   nValidador_Nove_Fecha:= Ft_Validar_Nov_Fecha_Igual (ArrayNov(Ln_Index).Nro_placa,
                                                                ArrayNov(Ln_Index).Id_Novedad,
                                                                ArrayNov(Ln_Index).Fecha_Novedad);
                
                If nValidador_Nove_Fecha = 0 Then   
                        If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')< nVigencia Then
                           vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                            --nId_Novedad:=ArrayNov(Ln_Index).Id_Novedad;
                            vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                            dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                            vEstado:='Novedad';
                            nEstado :=1;
                            vValidador_C:='C';
                         End If;
                 Else      
                         vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                            --nId_Novedad:=ArrayNov(Ln_Index).Id_Novedad;
                            vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                            dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad; 
                            If nValidador_Nove_Fecha = 1 Then
                                 vEstado:='Validar Cancelacion y Radicacion en las misma fecha';
                                  Exit;
                            ElsIf nValidador_Nove_Fecha = 2 Then 
                                 vEstado:='Validar Cancelacion y Traslado en las misma fecha';
                                  Exit;
                            Else
                                 vEstado:='Validar Cancelacion y Cambio Servicio en las misma fecha';
                                  Exit;
                            End If;                            
                 End If;
                    --Rematricula
            When ArrayNov(Ln_Index).Id_Novedad = 4 Then
             If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')<= nVigencia Then
                   vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                   -- nId_Novedad:=ArrayNov(Ln_Index).Id_Novedad;
                    vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                    dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                    vEstado:='Activa';
                    vValidador_C:='P';
                    nEstado :=3;
            End If;
                    --Traslado
            When ArrayNov(Ln_Index).Id_Novedad = 7 Then
             If ArrayNov(Ln_Index).Fecha_Novedad != dFecha_Anterior Then  
                 If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')< nVigencia Then
                       vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                        vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                        dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                        vEstado:='Novedad';
                        nEstado :=1;vValidador_T:='T';
                 Elsif vValidador_Pa_Pu Not In ('Pa_Pu') /*And vValidador_Pu_Pa Not In ('Pu_Pa')*/
                                And vValidador_R Not In ('R') Then
                     vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                        vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                        dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                        vEstado:='Activa';
                        vValidador_N :='T';
                        nEstado :=1;
             
                 End If;
            Else
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vEstado:='Validar Fecha de Traslado igual al Radicacion';
                nEstado :=1;
                Exit;
                
            End If;
                    --Publico a Particular
             When ArrayNov(Ln_Index).Id_Novedad = 8 Then           
          If ArrayNov(Ln_Index).Fecha_Novedad != dFecha_Anterior Then               
             If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')> nVigencia And vValidador_C Not In ('C') Then
                   vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                    --nId_Novedad:=ArrayNov(Ln_Index).Id_Novedad;
                    vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                    dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                    vEstado:='Novedad';
                    nEstado :=1;vValidador_Pu_Pa :='Pu_Pa';
              Elsif vValidador_C Not In ('C') Then
                    If vValidador_T Not In ('T') Then
                        vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                        vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                        dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                        vEstado:='Activa';nEstado:= 1;
                     End If;
              End If;
            Else
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vEstado:='Validar Cambio de Servicio en la misma Fecha';
          End If;
                    --Particular a Publico
                When ArrayNov(Ln_Index).Id_Novedad = 14 Then
          If ArrayNov(Ln_Index).Fecha_Novedad != dFecha_Anterior Then   
             If To_Char(ArrayNov(Ln_Index).Fecha_Novedad,'YYYY')< nVigencia Then
                   vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                    vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                    dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                    vEstado:='Novedad';
                    nEstado :=1;vValidador_Pa_Pu :='Pa_Pu';
               End If;
            Else
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vEstado:='Validar Cambio de Servicio en la misma Fecha';
          End If;
        Else 
            Continue;
        End Case;   
        
            If nEstado = 0 Then 
                vNro_Placa:=ArrayNov(Ln_Index).Nro_placa;
                vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
                dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;  
                vEstado:='Activa';        
            End If;   
            
            --Almaceno La Fecha y el Tramite si es Radicacion y Traslado
         If ArrayNov(Ln_Index).Id_Novedad = 6 Then
                nId_tramite_Anterior:=ArrayNov(Ln_Index).Id_Novedad; 
                dFecha_Anterior:=ArrayNov(Ln_Index).Fecha_Novedad; 
                vDuplicidad_Novedad:='R';
         Elsif ArrayNov(Ln_Index).Id_Novedad = 7 Then
                nId_tramite_Anterior:=ArrayNov(Ln_Index).Id_Novedad; 
                dFecha_Anterior:=ArrayNov(Ln_Index).Fecha_Novedad; 
               vDuplicidad_Novedad:='T'; 
         Elsif ArrayNov(Ln_Index).Id_Novedad In (8,14) Then
                nId_tramite_Anterior:=ArrayNov(Ln_Index).Id_Novedad; 
                dFecha_Anterior:=ArrayNov(Ln_Index).Fecha_Novedad; 
                --vDuplicidad_Novedad:='T';     
         Else 
                nId_tramite_Anterior:=0; 
                dFecha_Anterior:='01/01/29'; 
                vDuplicidad_Novedad:='P'; 
        End If;
    Else
          vNro_Placa:= ArrayNov(Ln_Index).Nro_placa;
          vNombre_Novedad:=ArrayNov(Ln_Index).Nombre_Novedad;
          dFecha_Novedad:=ArrayNov(Ln_Index).Fecha_Novedad;          
          vEstado:='Validar Tiene Novedad de Condonacion';
          Exit;
    End If;
   End Loop;     
        If nExiste =0 Then
        vNro_Placa:= vPlaca;
        vNombre_Novedad:='No Registra Novedad';
        vEstado:='Activa';
    End If;     
    Exit When ArrayNov.Count()<=0;
  End Loop; 
        --Insertar
        Sp_Insertar_Nov_Sap(vNro_Placa,vNombre_Novedad,dFecha_Novedad,vEstado);
           nEstado :=0;vEstado:='Activa';vNombre_Novedad:='';dFecha_Novedad:='';nExiste:=0;
           vValidador_N :='';dFecha_Anterior:='01/01/29';nId_tramite_Anterior:=0;vValidador_N:='P';
               vDuplicidad_Novedad:='P';vValidador_C:='P';vValidador_T:='P';vValidador_Pa_Pu :='P';
               vValidador_Pu_Pa :='P';vValidador_R:='R';  
Close curNovedad;   

END Sp_Validar_Novedad_Sap;

Function Ft_Validar_Caracteristicas (vPlaca Varchar,nId_Novedad Number) Return Number As

/*ISVA
Nombre     :Sp_Validar_Novedad_Sap
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :vPlaca,nId_Novedad
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :valida las caracteristicas exitentes en sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_placa Varchar2(255 byte);
nCantidad_Registro Number:=0;

Begin
     Case nId_Novedad
      When 0 Then --Formato de placa errada
        lv_placa:='';
       lv_placa := Replace(vPlaca,' ','');
        If Length(lv_placa) > 6 Then
            nCantidad_Registro:=1;
        End If;  
        
       When 1 Then--Vehiculo placa No asignada
        Select Count(1) Into nCantidad_Registro From Fc_Vehiculos
        Where Nro_Placa = vPlaca And Marcado_Archivo = 'X' And
        Observacion_Exis Like '%NO%ASIGNADA%';
        
       When 2 Then--Vehiculo placa errada
        Select Count(1) Into nCantidad_Registro From Fc_Vehiculos
        Where Nro_Placa = vPlaca And Marcado_Archivo = 'X' And
        (Observacion_Exis Like '%ERRADA%' Or Observacion_Exis Like '%CORRECTA%' 
         Or Observacion_Exis Like '%ERROR%');
        
       When 3 Then --Vehiculo Excento
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Clase In (11,12,13);
        
       When 4 Then --Cilindraje Inferior
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca And (Id_Clase In ('10','15','16','17','21','22') And To_number(Fv.Cilindraje) < 126 And Id_Servicio <> '05');
         
      When 5 Then --Vehiculo de Servicio Oficial
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Servicio in ('01','06')
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp
                                        Where Rp.Nro_Placa = vPlaca And Id_Novedad In (8,14))
        And Id_Clase Not In ('10','15','16','17','21','22');  
        
      When 6 Then --Vehiculo de Servicio Publico natural
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Servicio = '02' 
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp
                                        Where Rp.Nro_Placa = vPlaca And Id_Novedad In (8,14)); 
        
      When 7 Then --Vehiculo Registrado en Otro Departamento
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Departamento != '05'
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp 
                                        Where Rp.Nro_Placa = vPlaca And Id_Novedad = 7);
                                        
      When 8 Then--Marcada para Archivo
        Select Count(1) Into nCantidad_Registro From Fc_Vehiculos
        Where Nro_Placa = vPlaca And Marcado_Archivo = 'X' 
        And Nro_Placa not in (Select Rp.Nro_placa 
                              From Fc_Reporte_Novedades Rp
                              Where Rp.Nro_Placa =vPlaca And Id_Novedad In (3,4,6,7,8,14));
                                        
     When 9 Then --Matricula Inicial
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca And To_Char(Fecha_Matricula,'yyyy') > nVigencia
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp 
                                        Where Rp.Nro_Placa = vPlaca And Rp.Id_Novedad in (4,6,8)); 
    When 10 Then --Acuerdos de Pagos
     Select Count(1) Into nCantidad_Registro from Fc_Acuerdos_Pago
            Where Nro_Placa = vPlaca And Id_Estado In (3,5)
            And ((Fecha_Desde Between 1999 And (nVigencia - 1) And Fecha_Hasta >=nVigencia) Or Fecha_Desde = nVigencia);   
               
     Else
            Return 0;                              
     End Case;  
     
           If nCantidad_Registro > 0 Then
                Return 1; --Retorna si encuantra una de las caracteristicas 
           Else
                Return 0;
           End If;      

END Ft_Validar_Caracteristicas;

Procedure Sp_Aptualizar_registro (av_Placa Varchar) As

/*ISVA
Nombre     :Sp_Aptualizar_registro
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :av_Placa
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :registrar un estado por placa que valida
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
        Update Prueba Set Estado = 'S'
         Where Nro_placa = av_Placa;
End Sp_Aptualizar_registro;

Procedure Sp_Iniciar_Val_Omisos As

/*ISVA
Nombre     :Sp_Iniciar_Val_Omisos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :ln_Existe, lb_Existe, arrayId
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :se asigna los codigos de la novedadespara infresar a validar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

ln_Existe Number:=0;
lb_Existe Boolean:=False;
type Array_Nov is varray(11) of number(2);
--Almaceno los Codigos para validar la carateristicas 
arrayId Array_Nov:=  Array_Nov(0,1,2,3,4,5,6,7,8,9,10);
--0.Formato Placa Errada 1.Placa errada  1.Placa No Asignada  3.Vehiculo Excento  4.Cc Inferior  5.Servicio oficial  
--6.Vehiculo Publico 7.Vehiculo Registrado en Otro Departamento  8.Marcado para Archivo  9.Matricula Inicial   10. Acuerdos de Pago
Cursor curPlacas Is Select Nro_Placa From Prueba Where Estado = 'P';

Type tblPlacas Is Table Of curPlacas%RowType;
arrayPlacas tblPlacas;
Begin 
    
 Open curPlacas;
    Loop Fetch curPlacas
        Bulk Collect Into arrayPlacas Limit 500;
            For Ln_Index In 1..arrayPlacas.Count() Loop 
                    --Valido Las Caracteristicas 
                    For I In 1..ArrayId.Count() Loop
                         ln_Existe:=Ft_Validar_Caracteristicas (ArrayPlacas(Ln_Index).Nro_Placa,ArrayId(i));
                            If ln_Existe > 0 Then 
                                --Envio la placa y el Codigo para Insertar la caracteristica 
                                Sp_Insertar_Nov_Caracteristica(ArrayPlacas(Ln_Index).Nro_Placa,ArrayId(i));
                                    lb_Existe:=True;   
                                    Exit;
                            End If; 
                    End Loop; 
                    --Si no encontro un novedad en caracteristica valido si tiene novedad en sap
                            If lb_Existe = False Then
                                   Sp_Validar_Novedad_Sap (ArrayPlacas(Ln_Index).Nro_Placa);
                            End If;
                    Sp_Aptualizar_registro (ArrayPlacas(Ln_Index).Nro_Placa);
                lb_Existe:=False;
            End Loop;
          
         Exit When arrayPlacas.Count() <=0;
      Commit;
     End Loop;   
 Close curPlacas;
     
END Sp_Iniciar_Val_Omisos;

Procedure Sp_Validar_Pagos_Activas As

/*ISVA
Nombre     :Sp_Validar_Pagos_Activas
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :valida los pagos 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
    --Limpio las Tablas para insertar los Datos requeridos
    Delete Prueba;
    Delete Fc_Reporte_Pagos_Temp;
    Delete Fc_Busqueda_Novedades_Temp;
    Commit;
    
    --Inserto los Pagos de la vigencia requerida
    Insert Into Fc_Reporte_Pagos_Temp (Nro_Placa,Fecha_Pago,Vigencia)
    Select Distinct Rp.Nro_Placa,Rp.Fecha_Pago,Rp.Vigencia From Fc_Reporte_Pagos Rp
    Where Rp.Vigencia = nVigencia;
    Commit;

    --Insertamos Las placas que no presentan Pagos, las Omisas
    Insert Into Prueba (Nro_Placa)
    Select Distinct Fv.Nro_Placa from Fc_Vehiculos Fv
    Left Join Fc_Reporte_Pagos_Temp Pr On Pr.Nro_placa = Fv.Nro_Placa
    Where Pr.Fecha_Pago Is null;
    Commit;
    
End Sp_Validar_Pagos_Activas;

Procedure Sp_Validar_Inconsistencias As

/*ISVA
Nombre     :Sp_Validar_Inconsistencias
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :valida los pagos 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
Update Prueba Set Estado = 'P'
 Where Nro_Placa In (
    Select Pr.Nro_Placa From Prueba Pr
        Left Join Fc_Busqueda_Novedades_Temp Fn On Fn.Nro_placa = Pr.Nro_Placa
            Where Fn.Nro_placa is null);
        Commit;
End Sp_Validar_Inconsistencias;

Procedure Sp_Iniciar_Omisos (Vigencia_Anno Number) As

/*ISVA
Nombre     :Sp_Iniciar_Omisos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOVEDAD_SAP_FINAL
Versi�n    :1.0
Objetivo   :inicia las validaciones
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
nVigencia:= Vigencia_Anno;
        
        Sp_Validar_Pagos_Activas;
          Sp_Iniciar_Val_Omisos;
            Sp_Validar_Inconsistencias;
                 Sp_Iniciar_Val_Omisos;
                     Sp_Generar_Archivos;

END Sp_Iniciar_Omisos;



END PKG_BUSCAR_NOVEDAD_SAP_FINAL;

/
--------------------------------------------------------
--  DDL for Package Body PKG_BUSCAR_NOV_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_BUSCAR_NOV_TTO" AS

FUNCTION FT_CONFIRMAR_NOVEDAD (vPlaca Varchar, nId_tramite Number,dFecha_Tramite Date) Return Number As

/*ISVA
Nombre     :FT_CONFIRMAR_NOVEDAD
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :vPlaca, nId_tramite, dFecha_Tramite
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */

nContador Number:=0;
nServicio Number;
Begin
    
    Case 
        When nId_Tramite = 15 Then
            Select Count(1) Into nContador From Bd_Transitos.St_Tramites
                Where Nro_placa = vPlaca And Id_Tramite = 10 
                      And Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite) = dFecha_Tramite;
                    
                    If nContador > 0 Then
                       Return 1;
                    Else
                       Return 0;
                    End If;
          When nId_Tramite = 10 Then
            Select Count(1) Into nContador From Bd_Transitos.St_Tramites
                Where Nro_placa = vPlaca And Id_Tramite = 15 
                      And Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite) = dFecha_Tramite;
                    
                    If nContador > 0 Then                      
                        Return 1;
                    Else
                          Select Count(1) Into nContador From Bd_Transitos.St_Tramites
                            Where Nro_placa = vPlaca And Id_Tramite = 20 
                                And Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite) = dFecha_Tramite;
                                    If nContador > 0 Then
                                        Return 2;--retorna cancelacion igual a radicacion
                                    Else
                                        Return 0;
                                    End If;
                    End If;
        
        When nId_Tramite = 6 Then
              Select Count(1) Into nServicio From Fc_Vehiculos
                Where Nro_placa = vPlaca;
                    
                    If nServicio in (1) Then
                       Return 1;
                    Else
                       Return 0;
                    End If;       
    End Case;
END FT_CONFIRMAR_NOVEDAD;

FUNCTION FT_PU_PA_O_PA_PU_FECHA (Placa Varchar,Fecha_Novedad Date,Codigo_Servicio Number)Return Number As

/*ISVA
Nombre     :FT_PU_PA_O_PA_PU_FECHA
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Placa, Fecha_Novedad, Codigo_Servicio
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */

nValidador Number:=0;
Begin
    
        If Codigo_Servicio = 1 Then
    Select Count(1) into nValidador from Bd_Transitos.St_Tramites
        Where Nro_Placa = Placa And To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) = Fecha_Novedad
           And Id_Servicio_Anterior In (2,3,4) and Id_Servicio_Nuevo = 1;
         If nValidador > 0 Then Return 1;
            Else Return 0;
         End If;
        
    ElsIf Codigo_Servicio = 2 Then 
        Select Count(1) into nValidador from Bd_Transitos.St_Tramites
        Where Nro_Placa = Placa And To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) = Fecha_Novedad
           And Id_Servicio_Anterior = 1 and Id_Servicio_Nuevo In (2,3,4);
              If nValidador > 0 Then Return 1;
                  Else Return 0;
              End If;
    Else 
          Select Count(1) into nValidador from Bd_Transitos.St_Tramites
          Where Nro_Placa = Placa And To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) = Fecha_Novedad
           And Id_Servicio_Anterior In (2,3,4) and Id_Servicio_Nuevo = 1;
              If nValidador > 0 Then Return 1;
                  Else Return 0;
              End If;
    End If;
Exception 
When others Then 
Return 0;
END FT_PU_PA_O_PA_PU_FECHA;
--Verifica Si El Traslado Es Interno O Fuera de Antioquia
FUNCTION FT_TRASLADO_INTERNO (Codigo_Destino Number) Return Number AS

/*ISVA
Nombre     :FT_TRASLADO_INTERNO
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Codigo_Destino 
Variables  :vDepartamento
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */

vDepartamento Varchar2(100 byte);

Begin 

      Select Distinct Upper(Fcmp.Departamento) Into vDepartamento From 
        Fc_Municipio_Departamento Fcmp
            Where Fcmp.Divipo = Codigo_Destino And Rownum<=1;
              if vDepartamento = 'ANTIOQUIA' Then
                  Return 0; -- Si el traslado es en Antioquia
              Else
                  Return 1; -- Si el Traslado no es en antioquia
              End If;

Exception 
When Others Then
    Return 0;

END FT_TRASLADO_INTERNO;

FUNCTION FT_ES_NUMERO (Codigo_Runt Varchar2) Return Number as

/*ISVA
Nombre     :FT_ES_NUMERO
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Codigo_Runt 
Variables  :Numero
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */

Numero Number:=0;

Begin

    Numero := To_Number(Codigo_Runt);
        return 1;

Exception 
WHEN OTHERS then
    return 0;

END FT_ES_NUMERO;

PROCEDURE Sp_Insertar_Novedad (Placa Varchar2,Nombre_Trarmite Varchar2,Fecha_Tramite Date,Codigo_Secretaria_Destino Number,
                               Codigo_Secretaria_Origen Number,Servicio_Anterior Varchar2,Servicio_Nuevo Varchar2,
                               Vendedor Varchar2,Comprador Varchar,Transito Number,Estado Varchar2) As

/*ISVA
Nombre     :Sp_Insertar_Novedad
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Codigo_Runt 
Variables  :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */

nContador Number;
Begin
    --Para insertar si no hay una novedad registrada en OT
        Insert Into Fc_Busqueda_Novedades_Temp(Nro_Placa,Nombre_Tramite,Fecha_Tramite,Id_Secretaria_Destino,
                                               Id_Secretaria_Origen,Nombre_Servicio_Anterior,Nombre_Servicio_Nuevo,
                                               Id_Usuario_Nuevo,Id_Radicado,Estado)
            Values (Placa,Upper(Nombre_Trarmite),Fecha_Tramite,Codigo_Secretaria_Destino,Codigo_Secretaria_Origen,
                    Servicio_Anterior,Servicio_Nuevo,Comprador,Transito,Estado);
                    
                Update Prueba Set Estado = 'S'
                Where Nro_placa = Placa;
                
  If nContador = 100 Then
     nContador := 0;
     Commit;
 Else
     nContador := nContador + 1;
 End If;

END SP_INSERTAR_NOVEDAD;
--Ingresar A�o de la Vigencia Para validadar Cualquier Novedad
PROCEDURE SP_BUSCAR_NOVEDAD_ID(nVigencia Number,lnId_Tramite Number) As 

/*ISVA
Nombre     :Sp_Insertar_Novedad
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Codigo_Runt 
Variables  :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */


vPlaca Varchar2 (100 byte):='';
vNombre_Tramite Varchar2 (100 byte):='';
vFecha_Tramite Date:='';
vSecretaria_Destino Number:=0;
vSecretaria_Origen Number:=0;
vServicio_Anterior Varchar2(100 byte):='';
vServicio_Nuevo Varchar2(100 byte):='';
vVendedor Varchar2(100 byte):='';
vComprador Varchar (100 byte):='';
nTransito Number :=0;
nCod_Traslado Number:=0;
nEstado number:=0;
nContador Number :=0;
vEstado Varchar2(100 byte);
nId_Tramite number:=0;
nValidador Number:=1;
vValidador Varchar2(10 byte):='N';
vValidador_2 Varchar2(10 byte):='';
vValidador_Traslado Varchar(10 byte):='';

Cursor C1 is Select Nro_Placa From Prueba where Estado ='P';
Cursor c2 (vNro_Placa varchar2) is
Select Distinct St.Nro_Placa,to_Number(St.Id_Tramite)Id_Tramite ,St.Nombre_Tramite,
                To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite))Fecha,
                  St.Id_Secretaria_Destino,St.Id_Secretaria_Origen,St.Id_Servicio_Anterior,St.Nombre_Servicio_Anterior,
                    St.Id_Servicio_Nuevo,St.Nombre_Servicio_Nuevo,St.Id_Usuario_Anterior, St.Id_Usuario_Nuevo,
                    St.Id_Radicado From Bd_Transitos.St_Tramites St
                  Where St.Id_Tramite IN (lnId_Tramite) And Nro_Placa = vNro_Placa
                      Order By 4,2 Asc;
Begin

For Ln_Index in C1  Loop  
begin     
      for Ln_Index_2 In c2(Ln_Index.nro_placa) loop   

begin 
   Case   
      When Ln_Index_2.Id_Tramite = 9 Then  --Matricula Incial Mayor que el 2013         
           If To_Char(Ln_Index_2.Fecha,'YYYY') > nVigencia  Then  
                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                  nTransito:=Ln_Index_2.Id_Radicado; 
                  vEstado := 'Novedad';
                  nEstado:= 1;
           End If;
     When Ln_Index_2.Id_Tramite = 10 Then -- Radicacion  Mayor Igual 2013     
           If To_Char(Ln_Index_2.Fecha,'YYYY') >= nVigencia And vValidador = 'N' Then  
             nCod_Traslado:=Ft_Traslado_Interno(Ln_Index_2.Id_Secretaria_Origen);
                  If nCod_Traslado = 1 Then
                        vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                        vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                        vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                        nTransito:=Ln_Index_2.Id_Radicado; 
                        vEstado := 'Novedad';
                        nEstado:= 1;vValidador_2:='R';
                   End If;
            Elsif  vValidador<> 'C' Then  -- para que active la novedad cuando sea inferior a la fecha
                        vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
                        vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
                        vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;nTransito:=Ln_Index_2.Id_Radicado; 
                        vEstado := 'Activa';                                 
           End If;
      When Ln_Index_2.Id_Tramite = 20 Then -- Cancelacion Menor al 2013       
           If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then  
                      vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                      nTransito:=Ln_Index_2.Id_Radicado; 
                      vEstado := 'Novedad';
                      nEstado:= 1;
           End If;
      When Ln_Index_2.Id_Tramite = 13 
                    And To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia + 1 Then -- Rematricula Menor al 2013  
                            vPlaca :=Ln_Index_2.Nro_Placa; vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                            nId_Tramite:=Ln_Index_2.Id_Tramite; vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
                            vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
                            vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;nTransito:=Ln_Index_2.Id_Radicado; 
                            vEstado := 'Activa';
                            nEstado := 1;                
      When Ln_Index_2.Id_Tramite = 6  Then -- Cambio de Servicio 
                  Case
                      When Ln_Index_2.Id_Servicio_Anterior = 1 And Ln_Index_2.Id_Servicio_Nuevo in (2,3,4)   Then                           
                            If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then -- Cambio Particular a Publico o Oficial o Diplomatico
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1; vValidador:= 'C';         
                            End If;
                      When Ln_Index_2.Id_Servicio_Anterior In (2,3,4) and Ln_Index_2.Id_Servicio_Nuevo ='1'  Then 
                             If To_Char(Ln_Index_2.Fecha,'YYYY') > nVigencia Then -- Cambio Publico o Oficial o Diplomatico a Particular
                                  vPlaca :=Ln_Index_2.Nro_Placa;
                                  vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino; vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1; vValidador:= 'C';   
                             Elsif To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia And vValidador_Traslado is null  Then -- Cambio Servicio 
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';vValidador:= 'N';
                                  nEstado:= 1; 
                             End If;  
                    When  Ln_Index_2.Id_Servicio_Anterior In (2,3,4,5,6) and Ln_Index_2.Id_Servicio_Nuevo In (2,3,4,5,6)  Then 
                           vPlaca :=Ln_Index_2.Nro_Placa;
                           vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                           vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino; vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                           vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                           nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad'; nEstado:= 1;   vValidador:= 'C';             
                  End Case;              
      when Ln_Index_2.Id_Tramite = 15 Then -- Traslado Menor 2013      
           If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then 
              nValidador:=Ft_Es_Numero(Ln_Index_2.Id_Secretaria_Destino);
              if nValidador = 1 Then
               nCod_Traslado:=Ft_Traslado_Interno(Ln_Index_2.Id_Secretaria_Destino);
                If nCod_Traslado = 1 Then
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1;vValidador_Traslado:='T';  --vValidador:= 'T';
                Elsif vValidador <> 'C' Then
                    vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                    vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                    vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                    nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';
                    nEstado:= 1;  --vValidador:= 'T';
                End If;
              End If;
            Elsif  vValidador <> 'C' Or vValidador_2 <> 'R' Then
                      vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                      nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';
                      nEstado:= 1;  vValidador:= 'T';
          End If;
        when Ln_Index_2.Id_Tramite = 65 Then -- Persona Indeterminado  Menor 2013   
            If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then 
                     vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                     vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                     vVendedor := Ln_Index_2.Id_Usuario_Anterior;vComprador:= Ln_Index_2.Id_Usuario_Nuevo;
                     vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                     nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                     nEstado:= 1;
            End If;
      Else
         Continue;
  End Case; 
 
End;
  If nEstado = 0 And vValidador = 'N' /*and nId_Tramite <> 13*/  Then
      --Guardo los datos con la Novedad que Valido
      vPlaca :=Ln_Index_2.Nro_Placa;
      vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
      vFecha_Tramite:=Ln_Index_2.Fecha;
     if nValidador = 1 Then
      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
      vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
     End If;
      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
      vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
      nTransito:=Ln_Index_2.Id_Radicado; 
      vEstado := 'Activa';
  
  End If;
nValidador:= 1;
end Loop;
        if vPlaca is not null Then
        Sp_Insertar_Novedad(vPlaca,vNombre_Tramite,vFecha_Tramite,vSecretaria_Destino,vSecretaria_Origen,vServicio_Anterior,
                            vServicio_Nuevo,vVendedor,vComprador,nTransito,vEstado);
        Else
            Sp_Insertar_Novedad(Ln_Index.Nro_Placa,null,null,null,null,null,
                            null,null,null,null,'No hay Info o No registra Novedad');
            
        end If;                  
              Update Prueba Set Estado = 'S'
                  where Nro_Placa = Ln_Index.Nro_Placa;
               nEstado :=0;--Reseteo las Variables
               nContador:=0;vPlaca:='';vNombre_Tramite:='';vFecha_Tramite:='';vSecretaria_Destino:=0;vSecretaria_Origen:=0; 
               vServicio_Anterior:='';vServicio_Nuevo:='';vVendedor:='';vComprador:='';nTransito:=''; vValidador:= 'N';vValidador_Traslado:='';
Exception 
When Others Then
Update Prueba Set Estado = 'E'
            where Nro_Placa = Ln_Index.Nro_Placa;
Continue;
end;
  If nContador = 100 Then
     nContador := 0;
     Commit;
 Else
     nContador := nContador + 1;
 End If;
end Loop;

END SP_BUSCAR_NOVEDAD_ID;

PROCEDURE SP_BUSCAR_NOVEDADES(nVigencia Number) AS

/*ISVA
Nombre     :Sp_Insertar_Novedad
Autor      :Blados.Ospina
Fecha      :11/11/17
Parametros :Codigo_Runt 
Variables  :
Retorno    :          
Proyecto   :PKG_BUSCAR_NOV_TTO
Versi�n    :1.0
Objetivo   :Genera Archivos planos para exportar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
11/11/17    Blados.Ospina   1.0                     */


vPlaca Varchar2 (100 byte):='';
vNombre_Tramite Varchar2 (100 byte):='';
vFecha_Tramite Date:='';
vSecretaria_Destino Number:=0;
vSecretaria_Origen Number:=0;
vServicio_Anterior Varchar2(100 byte):='';
vServicio_Nuevo Varchar2(100 byte):='';
vVendedor Varchar2(100 byte):='';
vComprador Varchar (100 byte):='';
nTransito Number :=0;
nCod_Traslado Number:=0;
nEstado number:=0;
nContador Number :=0;
vEstado Varchar2(100 byte);
nId_Tramite number:=0;
nValidador Number:=1;
vValidador Varchar2(10 byte):='N';
vValidador_2 Varchar2(10 byte):='P';
vValidador_Traslado Varchar(10 byte):='';
bConfirmar_Nov Number :=0;
nA�o_Radicacion Number:=0;
nValidador_Servicio_Fecha Number:=0;

Cursor C1 is Select Nro_Placa From Prueba where Estado ='P';
Cursor c2 (vNro_Placa varchar2) is
Select Distinct St.Nro_Placa,to_Number(St.Id_Tramite)Id_Tramite ,St.Nombre_Tramite,
                To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite))Fecha,
                  St.Id_Secretaria_Destino,St.Id_Secretaria_Origen,St.Id_Servicio_Anterior,St.Nombre_Servicio_Anterior,
                    St.Id_Servicio_Nuevo,St.Nombre_Servicio_Nuevo,St.Id_Usuario_Anterior, St.Id_Usuario_Nuevo,
                    St.Id_Radicado From Bd_Transitos.St_Tramites St
                  Where St.Id_Tramite IN (6,9,10,13,15,20,65) And Nro_Placa = vNro_Placa
                      Order By 4,2 Asc;
Begin

For Ln_Index in C1  Loop  
begin     
      for Ln_Index_2 In c2(Ln_Index.nro_placa) loop   

begin 
   Case   
      When Ln_Index_2.Id_Tramite = 9 Then  --Matricula Incial Mayor que el 2013         
           If To_Char(Ln_Index_2.Fecha,'YYYY') > nVigencia  Then  
                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                  nTransito:=Ln_Index_2.Id_Radicado; 
                  vEstado := 'Novedad';
                  nEstado:= 1;
           End If;
     When Ln_Index_2.Id_Tramite = 10 Then -- Radicacion  Mayor Igual 2013 
     
            --Validar si Tiene Radicaion Igual a Traslado
            bConfirmar_Nov:=Ft_Confirmar_Novedad (Ln_Index_2.Nro_placa,Ln_index_2.Id_Tramite,Ln_Index_2.Fecha);
      --   If bConfirmar_Nov = False Then 
              
           If To_Char(Ln_Index_2.Fecha,'YYYY') >= nVigencia And vValidador = 'N' Then  
             nCod_Traslado:=Ft_Traslado_Interno(Ln_Index_2.Id_Secretaria_Origen);
                  If nCod_Traslado = 1 Then  
                        If bConfirmar_Nov = 0 Then 
                                vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                nTransito:=Ln_Index_2.Id_Radicado; 
                                vEstado := 'Novedad';vValidador_2 :='R';
                                nEstado:= 1;
                        
                               nA�o_Radicacion:= To_Char(Ln_Index_2.Fecha,'YYYY');
                                       If nA�o_Radicacion = nVigencia Then
                                                nA�o_Radicacion :=1;
                                       End If;
                             Else      
                                  vPlaca :=Ln_Index_2.Nro_Placa;
                                   vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                   vFecha_Tramite:=Ln_Index_2.Fecha;
                                   vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                   If bConfirmar_Nov = 1 Then
                                        vEstado := 'Validar Radicaion Igual a Traslado';   
                                   Else
                                       vEstado := 'Validar Radicaion Igual a Cancelacion';  
                                   End If;
                                   Exit;          
                             End If;                
                      Elsif  vValidador<> 'C' Then  -- para que active la novedad cuando sea inferior a la fecha
                            vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
                            vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
                            vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;nTransito:=Ln_Index_2.Id_Radicado; 
                            vEstado := 'Activa';  
                      End If;
                    Elsif  vValidador<> 'C' Then  -- para que active la novedad cuando sea inferior a la fecha          
                            If   bConfirmar_Nov > 0  Then
                             vPlaca :=Ln_Index_2.Nro_Placa;
                                   vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                   vFecha_Tramite:=Ln_Index_2.Fecha;
                                   vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                   If bConfirmar_Nov = 1 Then
                                        vEstado := 'Validar Radicaion Igual a Traslado';   
                                   Else
                                       vEstado := 'Validar Radicaion Igual a Cancelacion';  
                                   End If;
                                   Exit;  
                          Else                    
                            vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
                            vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
                            vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;nTransito:=Ln_Index_2.Id_Radicado; 
                            vEstado := 'Activa';  
                        End If;
                End If;
      When Ln_Index_2.Id_Tramite = 20 Then -- Cancelacion Menor al 2013      
      
                     --Valida si tiene una cancelacion y un cambio de servicio publico a particula en la misma fecha                
                     nValidador_Servicio_Fecha:=FT_Pu_Pa_O_Pa_Pu_Fecha(Ln_Index_2.Nro_placa,Ln_index_2.Fecha,null);                        
                                 If nValidador_Servicio_Fecha > 0 Then
                                    vPlaca :=Ln_Index_2.Nro_Placa;
                                    vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                    vEstado := 'Validar Cancelacion y cambio de Servicio Pu_Pa en la misma fecha';
                                    Exit;
                                End If;        
     
           If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then  
                      vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                      nTransito:=Ln_Index_2.Id_Radicado; 
                      vEstado := 'Novedad';
                      nEstado:= 1;nEstado:=1;
           End If;
      When Ln_Index_2.Id_Tramite = 13 
                    And To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia + 1 Then -- Rematricula Menor al 2013  
                            vPlaca :=Ln_Index_2.Nro_Placa; vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                            nId_Tramite:=Ln_Index_2.Id_Tramite; vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
                            vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
                            vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;nTransito:=Ln_Index_2.Id_Radicado; 
                            vEstado := 'Activa';
                            nEstado := 1;                
      When Ln_Index_2.Id_Tramite = 6  Then -- Cambio de Servicio      
                  Case
                      When Ln_Index_2.Id_Servicio_Anterior = 1 And Ln_Index_2.Id_Servicio_Nuevo in (2,3,4)   Then
                      
                                   nValidador_Servicio_Fecha:=FT_Pu_Pa_O_Pa_Pu_Fecha(Ln_Index_2.Nro_placa,Ln_index_2.Fecha,1);                        
                                If nValidador_Servicio_Fecha > 0 Then
                                    vPlaca :=Ln_Index_2.Nro_Placa;
                                    vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                    vEstado := 'Validar Cambio de Servicio Pu_Pa y Pa_Pu en la misma fecha';
                                    Exit;
                                End If;    
                      
                      
                            If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then -- Cambio Particular a Publico o Oficial o Diplomatico
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1; vValidador:= 'C';                                                                                                  
                            End If;
                      When Ln_Index_2.Id_Servicio_Anterior In (2,3,4) and Ln_Index_2.Id_Servicio_Nuevo ='1'  Then                       
                            nValidador_Servicio_Fecha:=FT_Pu_Pa_O_Pa_Pu_Fecha(Ln_Index_2.Nro_placa,Ln_index_2.Fecha,2);                        
                                 If nValidador_Servicio_Fecha > 0 Then
                                    vPlaca :=Ln_Index_2.Nro_Placa;
                                    vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                    vFecha_Tramite:=Ln_Index_2.Fecha;
                                    vEstado := 'Validar Cambio de Servicio Pu_Pa y Pa_Pu en la misma fecha';
                                    Exit;
                                End If;                     
                      
                             If To_Char(Ln_Index_2.Fecha,'YYYY') > nVigencia Then -- Cambio Publico o Oficial o Diplomatico a Particular
                                  vPlaca :=Ln_Index_2.Nro_Placa;
                                  vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino; vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1; vValidador:= 'C';   
                             Elsif To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia And vValidador_Traslado is null  Then -- Cambio Servicio 
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';vValidador:= 'N';
                                  nEstado:= 1; 
                             End If;  
                    When  Ln_Index_2.Id_Servicio_Anterior In (2,3,4,5,6) and Ln_Index_2.Id_Servicio_Nuevo In (2,3,4,5,6)  Then 
                           vPlaca :=Ln_Index_2.Nro_Placa;
                           vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                           vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino; vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                           vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                           nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad'; nEstado:= 1;   vValidador:= 'C';             
                  End Case;              
      when Ln_Index_2.Id_Tramite = 15 Then -- Traslado Menor 2013      
           If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia And vValidador not in ('C') Then 
              nValidador:=Ft_Es_Numero(Ln_Index_2.Id_Secretaria_Destino);
              if nValidador = 1 Then
               nCod_Traslado:=Ft_Traslado_Interno(Ln_Index_2.Id_Secretaria_Destino);
                If nCod_Traslado = 1 Then    
             bConfirmar_Nov:=Ft_Confirmar_Novedad(Ln_Index_2.Nro_Placa,Ln_Index_2.Id_Tramite,Ln_Index_2.Fecha);
                                If bConfirmar_Nov = 0 Then
                                  vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                                  vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                                  vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                                  nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                                  nEstado:= 1;vValidador_Traslado:='T';  --vValidador:= 'T';
                                Else
                                    vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
                                    vFecha_Tramite:=Ln_Index_2.Fecha;
                                    vEstado := 'Validar Traslado Igual a Radicacion';
                                    Exit;
                                End If;       
                Elsif vValidador <> 'C' And nA�o_Radicacion Not In (1) Then
                    vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                    vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                    vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                    nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';
                    nEstado:= 1;  --vValidador:= 'T';
                End If;
              End If;
            Elsif  vValidador <> 'C' Then
                    if  vValidador_2 <> 'R'  Then
                      vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                      nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Activa';
                      nEstado:= 1;  vValidador:= 'T';
                    End If;
          End If;
        when Ln_Index_2.Id_Tramite = 65 Then -- Persona Indeterminado  Menor 2013   
            If To_Char(Ln_Index_2.Fecha,'YYYY') < nVigencia Then 
                     vPlaca :=Ln_Index_2.Nro_Placa;vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;vFecha_Tramite:=Ln_Index_2.Fecha;
                     vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
                     vVendedor := Ln_Index_2.Id_Usuario_Anterior;vComprador:= Ln_Index_2.Id_Usuario_Nuevo;
                     vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
                     nTransito:=Ln_Index_2.Id_Radicado; vEstado := 'Novedad';
                     nEstado:= 1;
            End If;
      Else
         Continue;
  End Case; 
 
End;
  If nEstado = 0 And vValidador = 'N' /*and nId_Tramite <> 13*/  Then
      --Guardo los datos con la Novedad que Valido
      vPlaca :=Ln_Index_2.Nro_Placa;
      vNombre_Tramite:=Ln_Index_2.Nombre_Tramite;
      vFecha_Tramite:=Ln_Index_2.Fecha;
     if nValidador = 1 Then
      vSecretaria_Destino:=Ln_Index_2.Id_Secretaria_Destino;
      vSecretaria_Origen:=Ln_Index_2.Id_Secretaria_Origen; 
     End If;
      vServicio_Anterior:=Ln_Index_2.Nombre_Servicio_Anterior;
      vServicio_Nuevo:=Ln_Index_2.Nombre_Servicio_Nuevo;
      nTransito:=Ln_Index_2.Id_Radicado; 
      vEstado := 'Activa';
  
  End If;
nValidador:= 1;
end Loop;
        if vPlaca is not null Then
        Sp_Insertar_Novedad(vPlaca,vNombre_Tramite,vFecha_Tramite,vSecretaria_Destino,vSecretaria_Origen,vServicio_Anterior,
                            vServicio_Nuevo,vVendedor,vComprador,nTransito,vEstado);
        Else
            Sp_Insertar_Novedad(Ln_Index.Nro_Placa,null,null,null,null,null,
                            null,null,null,null,'No hay Info o No registra Novedad');
            
        end If;                  
              Update Prueba Set Estado = 'S'
                  where Nro_Placa = Ln_Index.Nro_Placa;
               nEstado :=0;--Reseteo las Variables
               nContador:=0;vPlaca:='';vNombre_Tramite:='';vFecha_Tramite:='';vSecretaria_Destino:=0;vSecretaria_Origen:=0; 
               vServicio_Anterior:='';vServicio_Nuevo:='';vVendedor:='';vComprador:='';nTransito:=''; vValidador:= 'N';vValidador_Traslado:='';
               vValidador_2 :='P';bConfirmar_Nov:=0;nA�o_Radicacion:=0;nValidador_Servicio_Fecha:=0;
               
Exception 
When Others Then
Update Prueba Set Estado = 'E'
            where Nro_Placa = Ln_Index.Nro_Placa;
end;
End Loop;

END SP_BUSCAR_NOVEDADES;





END PKG_BUSCAR_NOV_TTO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_BUSQUEDA_FISCA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_BUSQUEDA_FISCA" AS

PROCEDURE SP_INSERTAR_NOVEDAD_MAX_DATE
AS
Cantidad_Registro number:=0;
Ln_Contador number:=0;
Cursor C1 is Select P.Nro_placa,P.Id_Tramite,P.Id_Tramite2 from Prueba P where P.Estado = 'P';
begin
For Ln_Index in C1 loop
begin

Select Count(1) Into Cantidad_Registro From Bd_Transitos.St_Tramites St
Where St.Nro_Placa = Ln_Index.Nro_Placa and St.Id_Tramite in (Ln_Index.Id_Tramite,Ln_Index.Id_Tramite2);

if Cantidad_Registro > 0 then
--Inserta novedad de Radicacion
    if Ln_Index.Id_Tramite = 10 then
          insert into Fc_Busqueda_Novedades_Temp
          (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Id_Radicado)
          Select St1.Nro_Placa, St1.Nombre_tramite,ST1.Fecha_Tramite,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
          --INNER JOIN ST_PROPIETARIOS SP ON SP.ID_USUARIO = ST.ID_USUARIO_NUEVO
          Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(St1.Fecha_Tramite) = (Select Max(To_Date(St.Fecha_Tramite)) 
          FROM Bd_Transitos.St_Tramites St
          Where St.Nro_Placa = Ln_Index.Nro_placa and St.Id_tramite = Ln_Index.Id_tramite)
          and St1.Id_Tramite = Ln_Index.Id_Tramite and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);
                                            
                    Update Prueba P set P.Estado = 'S'
                    where P.Nro_Placa = Ln_Index.Nro_Placa;
     elsif Ln_Index.Id_Tramite = 20 then
          insert into Fc_Busqueda_Novedades_Temp
          (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Id_Radicado)
          Select St1.Nro_Placa, St1.Nombre_tramite,ST1.Fecha_Tramite,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
          --INNER JOIN ST_PROPIETARIOS SP ON SP.ID_USUARIO = ST.ID_USUARIO_NUEVO
          Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(St1.Fecha_Tramite) = (Select Max(To_Date(St.Fecha_Tramite)) 
          FROM Bd_Transitos.St_Tramites St
          Where St.Nro_Placa = Ln_Index.Nro_placa and St.Id_tramite = Ln_Index.Id_tramite)
          and St1.Id_Tramite = Ln_Index.Id_Tramite and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);
                        Update Prueba P set P.Estado = 'S'
                    where P.Nro_Placa = Ln_Index.Nro_Placa;
-- Tramite Traspaso             
    elsif Ln_Index.Id_Tramite = 16 Or Ln_Index.Id_Tramite2 = 65 then
          insert into Fc_Busqueda_Propietarios_Temp
          (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Id_Documento_Anterior,Id_Usuario_Anterior, Id_Documento_Nuevo, 
           Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado )
         
         Select Distinct St1.Nro_Placa, St1.Nombre_tramite,To_date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite)),
                                      St1.Id_Documento_Anterior, St1.Id_Usuario_Anterior,
          St1.Id_Documento_Nuevo, St1.Id_Usuario_Nuevo,
          St1.Porcentaje_Prop, St1.Id_Radicado From Bd_Transitos.St_Tramites St1
          Where St1.Nro_Placa = Ln_Index.Nro_Placa AND decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite)
                                                              = PKG_BUSQUEDA_FISCA.FT_FECHA_MAYOR_PBF (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite,Ln_Index.Id_Tramite2)
          and St1.Id_Tramite in (Ln_Index.Id_Tramite,Ln_Index.Id_Tramite2)
          and St1.Id_Radicado  = Ft_Max_Radicado_PBF (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite,Ln_Index.Id_Tramite2);
                                  
                        Update Prueba P set P.Estado = 'S'
                        where P.Nro_Placa = Ln_Index.Nro_Placa;
                        
--Tramite Traslado
    elsif Ln_Index.Id_Tramite = 15 then
          insert into Fc_Busqueda_Novedades_Temp
          (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Nombre_Servicio_Anterior,Nombre_Servicio_Nuevo,Id_Usuario_Nuevo, Id_Radicado)
          Select St1.Nro_Placa, St1.Nombre_tramite,ST1.Fecha_Tramite,St1.Id_Secretaria_Destino,Id_Secretaria_Origen,
                 St1.Id_Usuario_Nuevo, St1.Id_Radicado From Bd_Transitos.St_Tramites St1
          --INNER JOIN ST_PROPIETARIOS SP ON SP.ID_USUARIO = ST.ID_USUARIO_NUEVO
          Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(St1.Fecha_Tramite) = (Select Max(To_Date(St.Fecha_Tramite)) 
          FROM Bd_Transitos.St_Tramites St
          Where St.Nro_Placa = Ln_Index.Nro_placa and St.Id_tramite = Ln_Index.Id_tramite)
          and St1.Id_Tramite = Ln_Index.Id_Tramite and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);
    
                  Update Prueba P set P.Estado = 'S'
                  where P.Nro_Placa = Ln_Index.Nro_Placa;
                  
--Cambio de Servicio
  elsif Ln_Index.Id_Tramite = 6 then
         insert into Fc_Busqueda_Novedades_Temp
         (Nro_Placa,Nombre_Tramite,Fecha_Tramite,Nombre_Servicio_Anterior,Nombre_Servicio_Nuevo, Id_Radicado)
         Select St1.Nro_Placa, St1.Nombre_tramite,St1.Fecha_Tramite,St1.Nombre_Servicio_Anterior,
         St1.Nombre_Servicio_Nuevo, St1.Id_Radicado From Bd_Transitos.St_Tramites St1
         Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(St1.Fecha_Tramite) = (Select Max(To_Date(St.Fecha_Tramite)) 
         FROM Bd_Transitos.St_Tramites St
         Where St.Nro_Placa = Ln_Index.Nro_placa and St.Id_tramite = Ln_Index.Id_tramite)
         and St1.Id_Tramite = Ln_Index.Id_Tramite and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);
    
                  Update Prueba P set P.Estado = 'S'
                  where P.Nro_Placa = Ln_Index.Nro_Placa;
                  
         
-- Matricula Inicial              
    elsif Ln_Index.Id_Tramite = 9 then
        insert into Fc_Busqueda_Novedades_Temp
        (Nro_Placa,Nombre_Tramite,Fecha_Tramite, Id_Radicado)        
        Select St1.Nro_Placa, St1.Nombre_tramite,ST1.Fecha_Tramite,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
        Where St1.Nro_Placa =Ln_Index.Nro_Placa  and St1.Id_Tramite = Ln_Index.Id_Tramite
        and To_Date(St1.Fecha_Tramite) = FT_FECHA_MAYOR_PBF(Ln_Index.Nro_Placa,Ln_Index.Id_Tramite,null) 
        and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);
      
        
       /* Select St1.Nro_Placa, St1.Nombre_tramite,ST1.Fecha_Tramite,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
        --INNER JOIN ST_PROPIETARIOS SP ON SP.ID_USUARIO = ST.ID_USUARIO_NUEVO
        Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(St1.Fecha_Tramite) = (Select Max(To_Date(St.Fecha_Tramite)) 
        FROM Bd_Transitos.St_Tramites St
        Where St.Nro_Placa = Ln_Index.Nro_placa and St.Id_tramite = Ln_Index.Id_tramite)
        and St1.Id_Tramite = Ln_Index.Id_Tramite and St1.Id_Radicado = Ft_Max_Radicado (Ln_Index.Nro_Placa,Ln_Index.Id_Tramite);*/
    
                  Update Prueba P set P.Estado = 'S'
                  where P.Nro_Placa = Ln_Index.Nro_Placa;
    end if;
else
      --Este codigo valida si no hay un registro en tramite va a runt y trae la fecha de matricula
     /*Select Count(1) Into Cantidad_Registro From Fc_Automotor Fa
     where Fa.Nro_Placa = Ln_Index.Nro_Placa;
   
     if  Cantidad_Registro > 0 then
     
      insert into Fc_Busqueda_Novedades_Temp
      (Nro_Placa,Nombre_Tramite,Fecha_Tramite, Id_Radicado)
      Select Nro_Placa,'Fecha de matricula Runt',Fecha_Matricula,Id_transito From Fc_Automotor
      where Nro_Placa = Ln_Index.Nro_Placa;  */
      
      --else
          If Ln_Index.Id_Tramite = 16 Or Ln_Index.Id_Tramite2 = 65 then
               Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_Tramite)
               Values (Ln_Index.Nro_Placa, 'No hay Info');
                Update Prueba P set P.Estado = 'F'
                      where P.Nro_Placa = Ln_Index.Nro_Placa;
         Else
             Insert Into Fc_Busqueda_Novedades_Temp (Nro_Placa,Nombre_Tramite)
              Values (Ln_Index.Nro_Placa, 'No hay Info');
            
             Update Prueba P set P.Estado = 'F'
                      where P.Nro_Placa = Ln_Index.Nro_Placa;
                       Update Prueba P set P.Estado = 'F'
                      where P.Nro_Placa = Ln_Index.Nro_Placa;
      end if;
end if;
Exception 
When Others Then 
 Update Prueba P set P.Estado = 'ERROR'
                  where P.Nro_Placa = Ln_Index.Nro_Placa;
end;

if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
end loop;
END SP_INSERTAR_NOVEDAD_MAX_DATE;
--Busqueda de Propietarios
PROCEDURE SP_BUSCAR_PROPIETARIOS 
AS
Numero_Registro number:=0;
Nombre_Tramite Varchar2 (1000 byte):='';
Ln_Contador number:=0;
Actualizar number:=0;
Validador_Indeter Boolean:=False;
Cursor C1 is Select Nro_PLaca from Prueba where Estado = 'P';
begin
For Ln_Index in C1 Loop
begin
      --Valido Que Tenga Tramite Persona Indeterminado
      Validador_Indeter:=Ft_Validar_Traspaso_Indeterm(Ln_Index.Nro_Placa);
--Valido que el Tenga Tramite Traspaso
If Validador_Indeter = False Then
  select count(1) into Numero_Registro from Bd_Transitos.St_Tramites Stc
  where Stc.Nro_Placa = Ln_Index.Nro_Placa And Stc.Id_Tramite = 16;
if Numero_Registro > 0 then
            
      Select Distinct Count(1) Into Numero_registro From Bd_Transitos.St_Tramites St1
      Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite))
        = Fecha_Con_Parametros(Ln_Index.Nro_Placa,16,null)
      and Id_Tramite = 16
      and Id_Radicado  = Ft_Max_Radicado (Ln_Index.Nro_Placa,16);


              if Numero_registro > 0 Then
                    Insert into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Anterior,
                    Id_Usuario_Anterior, Id_Documento_Nuevo,
                    Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado)
                    Select Distinct St1.Nro_Placa, St1.Nombre_tramite,To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite)),
                    St1.Id_Documento_Anterior, St1.Id_Usuario_Anterior,
                    St1.Id_Documento_Nuevo, St1.Id_Usuario_Nuevo,
                    St1.Porcentaje_Prop,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
                    Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite))
                      = Fecha_Con_Parametros(Ln_Index.Nro_Placa,16,null)
                    and Id_Tramite = 16
                    and Id_Radicado  = Ft_Max_Radicado (Ln_Index.Nro_Placa,16);
                    
                                Update Prueba Set Estado = 'S'
                                        where Nro_Placa = Ln_Index.Nro_Placa; 
               Else
               
                    Insert into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Anterior,
                    Id_Usuario_Anterior, Id_Documento_Nuevo,
                    Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado)
                    Select Distinct St1.Nro_Placa, St1.Nombre_tramite,To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite)),
                    St1.Id_Documento_Anterior, St1.Id_Usuario_Anterior,
                    St1.Id_Documento_Nuevo, St1.Id_Usuario_Nuevo,
                    St1.Porcentaje_Prop,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
                    Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite))
                      = Fecha_Con_Parametros(Ln_Index.Nro_Placa,16,null)
                    and Id_Tramite = 16;
                 
                    
                                Update Prueba Set Estado = 'S'
                                        where Nro_Placa = Ln_Index.Nro_Placa; 
               End If;   
else  
      --Valida que exista un registro de Matricula Inicial
      select count(1) into Numero_Registro from Bd_Transitos.St_Tramites Stc
      where Stc.Nro_Placa = Ln_Index.Nro_Placa And Stc.Id_Tramite = 9;
      
        if Numero_Registro > 0 then
          Insert into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Anterior,
            Id_Usuario_Anterior, Id_Documento_Nuevo,
            Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado)
          Select distinct St1.Nro_Placa,Upper(St1.Nombre_tramite),To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite)),
          St1.Id_Documento_Anterior, St1.Id_Usuario_Anterior,
            St1.Id_Documento_Nuevo, St1.Id_Usuario_Nuevo,
            St1.Porcentaje_Prop,St1.Id_Radicado From Bd_Transitos.St_Tramites St1
          Where St1.Nro_Placa = Ln_Index.Nro_Placa AND To_Date(decode(length(St1.Fecha_Tramite),7,'0'||St1.Fecha_Tramite,St1.Fecha_Tramite))
                                                   = Fecha_Con_Parametros(Ln_Index.Nro_Placa,9,null)
          and Id_Tramite = 9
          and Id_Radicado  = Ft_Max_Radicado (Ln_Index.Nro_Placa,9);
          
                        Update Prueba Set Estado = 'S'
                          where Nro_Placa = Ln_Index.Nro_Placa;   
      
        else
      --Como no hay registro de Matricula inicial y traspaso, verifica que exista en propietarios
        Numero_Registro:=0;
        select count(1) into Numero_Registro from Bd_Transitos.St_Propietarios Sp
        where SP.Nro_Placa = Ln_Index.Nro_Placa And Sp.Id_radicado = (Select Max(Id_radicado) from Bd_Transitos.St_Propietarios
                                                                      where Nro_Placa = Ln_Index.Nro_Placa);
              if Numero_Registro > 0 then
                  Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_Tramite,Id_Documento_Nuevo,Id_Usuario_Nuevo,Id_Radicado,Porcentaje_Prop)
                  Select Sp.Nro_Placa,'EL TRANSITO SOLO REGISTRA PROPIETARIO',Sp.Id_Documento, Sp.Id_Usuario,Sp.Id_Radicado, Sp.Porcentaje_Prop
                  from Bd_Transitos.St_Propietarios Sp
                  where SP.Nro_Placa = Ln_Index.Nro_Placa 
                  And Sp.Id_radicado = (Select Max(Id_radicado) from Bd_Transitos.St_Propietarios
                                           where Nro_Placa = Ln_Index.Nro_Placa);
                    --Inserta radicacion
                    Update Prueba Set Estado = 'S'
                          where Nro_Placa = Ln_Index.Nro_Placa;     
                                           
            /*else
                 --Busca por ultima en los usuarios registrados por runt
                 select count(1) into Numero_Registro from Fc_Usuarios_Runt Fc
                 where Fc.Nro_Placa = Ln_Index.Nro_Placa;
                 
                   if Numero_Registro > 0 then
                     Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_Tramite, Id_Usuario_Nuevo)
                     select Fc.Nro_Placa,'SOLO REGISTRA PROPIETARIO RUNT', Fc.Id_Usuario from Fc_Usuarios_Runt Fc
                     where Fc.Nro_Placa = Ln_Index.Nro_Placa;*/
               else
                     Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_Tramite)
                     values ( Ln_Index.Nro_Placa,'No hay Informacion');
                     
                         Update Prueba Set Estado = 'S'
                          where Nro_Placa = Ln_Index.Nro_Placa; 
                   end if;
            --end if;
      end if;
end if;
End If;
end;

if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
end loop;
END SP_BUSCAR_PROPIETARIOS;
--Validar Matricula Inicial
PROCEDURE SP_VALIDAR_MATRICULA_INICIAL
AS
Procentaje number:=0;
Numero_Registro number:=0;
Transito Number:=0;
Radicado Number:=0;
Nombre_Tramite Varchar2(1000 byte):='';
Fecha_Tramite Varchar2(100 byte):='';
Ln_Contador number:=0;

Cursor C1 is Select Nro_Placa,Nombre_Tramite,Fecha_Tramite,Id_Radicado, RowId from Fc_Busqueda_Propietarios_Temp 
                                                                        where Nombre_Tramite in ('TRAMITE_MATRICULA_INICIAL','EL TRANSITO SOLO REGISTRA PROPIETARIO', 'MATRICULA INICIAL') ;
begin
For Ln_Index in C1 Loop
Begin
  
  Numero_Registro:= Ft_Radicacion(Ln_Index.Nro_Placa,Ln_Index.Fecha_Tramite);

--Validar Si tiene Radicacion
If Numero_Registro > 0 then

     -- Numero_Registro:= Ft_Radicacion(Ln_Index.Nro_Placa,Ln_Index.Fecha_Tramite);
        Radicado :=Numero_Registro;
        
        select count(1) Into Numero_Registro from Bd_Transitos.St_Propietarios
        where Nro_Placa = Ln_Index.Nro_Placa And Id_Radicado = Radicado;
      
      If Numero_registro > 0 Then
      
      
          Select St.Nombre_Tramite,To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)),
            St.Id_Radicado into Nombre_Tramite,Fecha_Tramite,Transito from Bd_Transitos.St_Tramites St
              where St.Nro_Placa = Ln_Index.Nro_Placa And Id_Tramite = 10 And St.Id_Radicado = Radicado
                 And To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) = 
                                                  FT_FECHA_MAYOR_PBF (Ln_Index.Nro_Placa,10,null);
                                                  
        Delete Fc_Busqueda_Propietarios_Temp Fct where Fct.Nro_Placa = Ln_Index.Nro_Placa;
        
            Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Nuevo,Id_Usuario_Nuevo,Id_Radicado,Porcentaje_Prop)
            Select Distinct Sp.Nro_Placa,Nombre_Tramite,Fecha_Tramite,Sp.Id_Documento, Sp.Id_Usuario,Radicado, Sp.Porcentaje_Prop From Bd_Transitos.St_Propietarios Sp
            where Sp.Nro_Placa = Ln_Index.Nro_Placa and Id_Radicado = Transito;          
      Else
                   Select Distinct Sm.Id_Secretaria Into Transito From Bd_Transitos.St_Maestro Sm
                   Where Sm.Id_Radicado = Radicado;
                   
                     Transito := Ft_Ultimo_Transito_Prop (Transito,Ln_Index.Nro_placa);    
                     
                      If Transito > 0 Then  
                      
                         Select St.Nombre_Tramite,To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)),
                         St.Id_Radicado into Nombre_Tramite,Fecha_Tramite,Transito from Bd_Transitos.St_Tramites St
                         where St.Nro_Placa = Ln_Index.Nro_Placa And Id_Tramite = 10
                         And To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) = 
                                                            FT_FECHA_MAYOR_PBF (Ln_Index.Nro_Placa,10,null)
                                                            And St.Id_Radicado = Id_Radicado;
                                                            
                        Delete Fc_Busqueda_Propietarios_Temp Fct where Fct.Nro_Placa = Ln_Index.Nro_Placa;                                  
                      
                        Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Nuevo,Id_Usuario_Nuevo,Id_Radicado,Porcentaje_Prop)
                        Select Distinct Sp.Nro_Placa,Nombre_Tramite,Fecha_Tramite,Sp.Id_Documento, Sp.Id_Usuario,Transito, Sp.Porcentaje_Prop From Bd_Transitos.St_Propietarios Sp
                        where Sp.Nro_Placa = Ln_Index.Nro_Placa;     
                      
                      Else
                           -- Delete Fc_Busqueda_Propietarios_Temp Fct where Fct.Nro_Placa = Ln_Index.Nro_Placa;  
                      -- Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Radicado)
                                         --      Values (Ln_Index.Nro_Placa,Ln_Index.Nombre_Tramite,Ln_Index.Fecha_Tramite,Ln_Index.Id_Radicado); 
                                        Continue;
                      End If;
      
      End If;
    
Else  --Validamos si reportaron los Propietarios
       select count(1) Into Numero_Registro from Bd_Transitos.St_Propietarios
          where Nro_Placa = Ln_Index.Nro_Placa;  
         If Numero_Registro > 0 then
         
         /*  Select Fc.Nombre_Tramite,Fc.Fecha_Tramite, Fc.Id_Radicado into Nombre_Tramite,Fecha_Tramite,Transito 
            from Fc_Busqueda_Propietarios_Temp Fc
              where Fc.Nro_Placa = Ln_Index.Nro_Placa And Fc.RowId = Ln_Index.RowId;*/
            
       
            
            Delete Fc_Busqueda_Propietarios_Temp Fct where Fct.Nro_Placa = Ln_Index.Nro_Placa And Rowid = Ln_Index.RowId;
            
              Select Count(1) Into Numero_Registro  From Bd_Transitos.St_Propietarios Sp
                where Sp.Nro_Placa = Ln_Index.Nro_Placa and Id_Radicado = Ln_Index.Id_Radicado; 
                              If Numero_Registro > 0 Then   
                            
                                  Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,
                                                                             Id_Documento_Nuevo,Id_Usuario_Nuevo,Id_Radicado,Porcentaje_Prop)
                                  Select Distinct Sp.Nro_Placa,Ln_Index.Nombre_Tramite,Ln_Index.Fecha_Tramite,Sp.Id_Documento, 
                                                  Sp.Id_Usuario,Ln_Index.Id_Radicado, Sp.Porcentaje_Prop 
                                         From Bd_Transitos.St_Propietarios Sp
                                   Where Sp.Nro_Placa = Ln_Index.Nro_Placa And Sp.Id_Radicado = Ln_Index.Id_Radicado;
                             Else
                                
                                Select Sm.Id_Secretaria Into Transito From Bd_Transitos.St_Maestro Sm
                                Where Sm.Id_Radicado = Ln_Index.Id_Radicado;
                                                              
                                 Transito := Ft_Ultimo_Transito_Prop (Transito,Ln_Index.Nro_placa);              
                                           If Transito > 0 Then   
                                                   Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Nuevo,
                                                                                              Id_Usuario_Nuevo,Id_Radicado,Porcentaje_Prop)
                                                   Select Distinct Sp.Nro_Placa,Ln_Index.Nombre_Tramite,Ln_Index.Fecha_Tramite,Sp.Id_Documento, Sp.Id_Usuario,Transito,
                                                                   Sp.Porcentaje_Prop 
                                                   From Bd_Transitos.St_Propietarios Sp
                                                   Where Sp.Nro_Placa = Ln_Index.Nro_Placa And Sp.Id_Radicado = Transito;
                                           Else
                                               Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Radicado)
                                               Values (Ln_Index.Nro_Placa,Ln_Index.Nombre_Tramite,Ln_Index.Fecha_Tramite,Ln_Index.Id_Radicado);                
                                           End If;
                              End If;           
         Else
             Delete Fc_Busqueda_Propietarios_Temp Fct where Fct.Nro_Placa = Ln_Index.Nro_Placa;
             Insert Into Fc_Busqueda_Propietarios_Temp (Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Radicado,Estado)
             Values (Ln_Index.Nro_Placa,Ln_Index.Nombre_Tramite,Ln_Index.Fecha_Tramite,Ln_Index.Id_Radicado,'E'); 
         End If;
End If;  
Exception 
When Others Then 
Update Fc_Busqueda_Propietarios_Temp Set Estado = 'E'
Where Nro_placa = Ln_Index.Nro_Placa;
end;

if Ln_Contador = 0 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;

end loop;
END SP_VALIDAR_MATRICULA_INICIAL;
--Actualiza Nombre del Departamento La tabla Propietarios
PROCEDURE SP_ACTULIZAR_DIVIPO_PROP
AS
Nombre_transito Varchar2(1000 byte);
Ln_Contador number:=0;
Cursor C1 is Select Nro_Placa, RowId from Fc_Busqueda_Propietarios_Temp; --where estado = 'P';
begin
For Ln_Index in C1 Loop
begin
Select Distinct Ot.Ciudad Into Nombre_transito from  Fc_Busqueda_Propietarios_Temp Fc--Fc_Busqueda_Novedades_Temp Fc
--Select Ot.Ciudad Into Nombre_transito  from Fc_Busqueda_Propietarios Fc
Inner join Bd_Transitos.St_Maestro M on M.Id_Radicado = Fc.Id_Radicado
Inner join correccion_datos.runt_organismos_tto Ot on ot.divipo = M.Id_Secretaria
where Fc.Nro_Placa =Ln_Index.Nro_Placa and Fc.RowId = Ln_Index.RowId
and rownum<=1;

Update Fc_Busqueda_Propietarios_Temp Fc Set Fc.Id_Radicado = Nombre_transito
--Update Fc_Busqueda_Propietarios_Temp Fc Set Fc.Id_Radicado = Nombre_transito
Where Fc.Nro_Placa = Ln_Index.Nro_Placa and Fc.RowId = Ln_Index.RowId;

exception
when others then
Continue;
--Update Fc_Busqueda_Propietarios_Temp Fc Set Fc.Estado = 'ERROR'
--Where Fc.Nro_Placa = Ln_Index.Nro_Placa and Fc.RowId = Ln_Index.RowId;
end;
if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
end Loop;
END SP_ACTULIZAR_DIVIPO_PROP;
--Actualiza Nombre del Departamento La tabla Novedades
PROCEDURE SP_ACTULIZAR_DIVIPO_NOVE
AS
Nombre_transito Varchar2(1000 byte);
Ln_Contador number:=0;
Cursor C1 is Select Nro_Placa, RowId from Fc_Busqueda_Novedades_Temp;
begin
For Ln_Index in C1 Loop
begin
Select Distinct Ot.Ciudad Into Nombre_transito from Fc_Busqueda_Novedades_Temp Fc
--Select Ot.Ciudad Into Nombre_transito  from Fc_Busqueda_Propietarios Fc
Inner join Bd_Transitos.St_Maestro M on M.Id_Radicado = Fc.Id_Radicado
Inner join correccion_datos.runt_organismos_tto Ot on ot.divipo = M.Id_Secretaria
where Fc.Nro_Placa =Ln_Index.Nro_Placa and Fc.RowId = Ln_Index.RowId

and rownum<=1;

Update Fc_Busqueda_Novedades_Temp Fc Set Fc.Id_Radicado = Nombre_transito
Where Fc.Nro_Placa = Ln_Index.Nro_Placa and Fc.RowId = Ln_Index.RowId;

exception
when others then
Continue;
end;
if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
end Loop;
END SP_ACTULIZAR_DIVIPO_NOVE;

PROCEDURE SP_CARACTERISTICAS_VEHICULOS
AS
Ln_Contador number :=0;
Cantidad_Registro number :=0;
Validador Boolean:=False;
Cursor C1 is Select Nro_Placa from Prueba where Estado = 'P';
begin
For Ln_Index in C1 Loop
begin

Select Count(1) Into Cantidad_Registro From Bd_Transitos.St_Vehiculos Sv
where Sv.Nro_Placa = Ln_Index.Nro_Placa;

If Cantidad_Registro > 0 Then
    Insert Into FC_CARACTERISTICAS_VEH_TEMP
    (Nro_Placa, Nombre_Clase,Linea,Nombre_Servicio,Nombre_Carroceria,Cilindraje,Modelo,Id_Radicado,Estado)
    select St.Nro_Placa, St.Nombre_Clase,Nombre_Linea, St.Nombre_Servicio,St.Nombre_Carroceria,St.Cilindraje, St.Modelo,St.Id_Radicado,'TRANSITO' 
    from Bd_Transitos.ST_VEHICULOS St
    where St.Nro_Placa = Ln_Index.Nro_Placa;
    Validador :=True;
      Update Prueba P Set P.Estado = 'T'
      where P.Nro_Placa = Ln_Index.Nro_Placa;
end If;
      Select Count(1) Into Cantidad_Registro From Fc_Automotor Fa
      where Fa.Nro_Placa = Ln_Index.Nro_Placa;
      
      if Cantidad_Registro > 0 then
      Insert Into FC_CARACTERISTICAS_VEH_TEMP
      (Nro_Placa, Nombre_Clase,Linea,Nombre_Servicio,Nombre_Carroceria,Cilindraje,Modelo,Id_Radicado,Estado)
      select Fc.Nro_Placa, Fc.Nombre_Clase,Fc.Nombre_Linea,Fc.Nombre_Servicio,Fc.Nombre_Carroceria, Fc.Cilindraje,Fc.Modelo,Fc.Nombre_Transito,'RUNT' 
      from Fc_Automotor Fc
      where Fc.Nro_Placa = Ln_Index.Nro_Placa;
      
              Update Prueba P Set P.Estado = 'R'
              where P.Nro_Placa = Ln_Index.Nro_Placa;
      elsif  Validador = False Then
              Insert Into Fc_Caracteristicas_Veh_Temp
             (Nro_Placa,Estado) values (Ln_Index.Nro_Placa, 'NO HAY INFO');
              Update Prueba P Set P.Estado = 'E'
              where P.Nro_Placa = Ln_Index.Nro_Placa;
      end If;

end;
Validador:=False;
if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
end loop;
END SP_CARACTERISTICAS_VEHICULOS;
--Validad Los Propietarios de Tramites Contra la tabla Propietarios
PROCEDURE SP_VALIDAR_PROPIETARIOS
AS
Ln_Contador number:=0;
Cursor C1 is Select P.Nro_Placa, P.Id_Usuario_Nuevo from Fc_Busqueda_Propietarios_Temp  P where Estado is null;
Begin
For Ln_Index in C1 Loop

begin
for x In( 
Select Distinct St.Nro_Placa, St.Id_Usuario from  Bd_Transitos.St_Propietarios St where Nro_Placa = Ln_Index.Nro_placa
)
Loop
begin

if  Ln_Index.Nro_placa = x.Nro_Placa  and Ln_Index.Id_Usuario_Nuevo = x.Id_Usuario then
    Update Fc_Busqueda_Propietarios_Temp P set P.Estado = 'ES EL USUARIO CORRECTO'
    where P.Nro_Placa = X.Nro_Placa and P.Id_Usuario_Nuevo = X.Id_Usuario;
    Ln_Index := null;
else
    Update Fc_Busqueda_Propietarios_Temp P set P.Estado = 'ELIMINAR REGISTRO' where P.Nro_Placa = Ln_Index.Nro_Placa 
                                                                              and P.Id_Usuario_Nuevo = Ln_Index.Id_Usuario_Nuevo;
end if;
if Ln_Contador = 100 then
Ln_Contador :=0;
commit;
else
Ln_Contador := Ln_Contador+1;
end if;
end;
end Loop;
end;
end Loop;

END SP_VALIDAR_PROPIETARIOS;
--Inserta la Direccion con la ultima fecha declarada
PROCEDURE SP_BUSQUEDA_PAGOS_DIR
AS
Numero_Registro number :=0;
Ln_Contador number :=0;

Cursor C1 is Select /*P.Nro_Placa,*/ P.Id_Usuario from Prueba P where P.Estado = 'P';
begin
For Ln_Index in C1 Loop

Begin
   
    Select Count(1) Into Numero_Registro From Fc_Reporte_Pagos Fc
    where /*Fc.Nro_placa = Ln_Index.Nro_Placa; and*/ Fc.Id_Interlocutor = Ln_Index.Id_Usuario;
    /*and Fc.Vigencia = 2017;*/
   
   if Numero_Registro > 0 then
      Insert into Fc_Contribuyentes_1 (Nro_Placa, Id_Interlocutor, Usuario_Modificacion,Direccion, Departamento, Municipio)
      Select Fcr.Nro_Placa, Fcr.Id_Interlocutor, Fcr.Fecha_Pago,Fcr.Direccion, Fcr.Departamento,   Fcr.Municipio
      From Fc_Reporte_Pagos Fcr
      where Fcr.Id_Interlocutor = Ln_Index.Id_Usuario
      and Fcr.Fecha_Pago = (Select Max(To_Date(T.Fecha_Pago)) From Fc_Reporte_Pagos T
      where T.Id_Interlocutor = Ln_Index.Id_Usuario /*and T.Vigencia = 2012*/)
      --and Fcr.Vigencia = 2012
      and rownum <=1; 
      
      Update Prueba P set P.Estado = 'S'
      where P.Id_Usuario = Ln_Index.Id_Usuario;
   else
      Insert into Fc_Contribuyentes_1 (Id_Interlocutor) values(Ln_Index.Id_Usuario);
      Update Prueba P set P.Estado = 'F'
      where P.Id_Usuario = Ln_Index.Id_Usuario;
   end if;
end;
if Ln_Contador = 100 then
   commit;
   Ln_Contador:=0;
else
Ln_Contador := Ln_Contador + 1;
end if;
End Loop;
END SP_BUSQUEDA_PAGOS_DIR;

FUNCTION FT_FECHA_MAYOR_PBF(Placa Varchar2, Tramite Number, Tramite_2 Number)
RETURN DATE
AS
Fecha_Maxima Date;
Begin

Select Max(To_Date(decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite))) Into  Fecha_Maxima
        From Bd_Transitos.St_Tramites St
Where St.Nro_Placa = Placa  and St.Id_tramite in (Tramite,Tramite_2);
Return Fecha_Maxima;

END FT_FECHA_MAYOR_PBF;

--Devuelve el ultimo Radicado 
Function Ft_Ultimo_Transito_Prop(Codigo Number, Placa Varchar2) Return Number
as 
nCodigo Number ;
nTransito Number;
nCantidad Number;
Cursor C1 is Select Id_Radicado From Bd_Transitos.St_Maestro Where Id_Secretaria = Codigo
                                                    And Produccion = 'S' Order By 1 Desc;
Begin 
For Ln_Index In C1 Loop

Select Count(1) Into nCantidad From Bd_Transitos.St_Propietarios
Where Nro_placa = Placa And Id_radicado = Ln_Index.Id_Radicado;

  If nCantidad > 0 Then
      Return Ln_Index.Id_Radicado;
      Exit;
  Else
    Continue;
  End If;
End Loop;

Return 0;

Exception 
When Others Then
Return 0;

END Ft_Ultimo_Transito_Prop;

FUNCTION FT_ULTIMO_TRANSITO_NOVEDAD (Codigo Number, Placa Varchar2) Return Number
As 
nCodigo Number ;
nTransito Number;
nCantidad Number;

Cursor C1 is Select Id_Radicado From Bd_Transitos.St_Maestro Where Id_Secretaria = Codigo
                                                   And Produccion = 'S' Order By 1 Desc;
Begin 
For Ln_Index In C1 Loop

Select Count(1) Into nCantidad From Bd_Transitos.St_Tramites
Where Nro_placa = Placa And Id_radicado = Ln_Index.Id_Radicado;

  If nCantidad > 0 Then
      Return Ln_Index.Id_Radicado;
      Exit;
  Else
    Continue;
  End If;
End Loop;

Return 0;

Exception 
When Others Then
Return 0;

END FT_ULTIMO_TRANSITO_NOVEDAD;

FUNCTION Ft_Radicacion (Placa Varchar2,Fecha Date)
Return Number
As
Fecha_Radicacion Date;
Transito Number;
Begin

 Select Fecha_Tramite,Id_radicado Into Fecha_Radicacion,Transito from Bd_Transitos.St_Tramites St
            where St.Nro_Placa = Placa And Id_Tramite = 10
              And To_Date(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) = 
                                                FT_FECHA_MAYOR_PBF (Placa,10,null);
 If Fecha < Fecha_Radicacion Then
      Return Transito;
 Elsif Fecha is null Then
      Return Transito;
 Else
     Return 0;
 End If;   
 
Exception 
When Others Then 
Return 0;

END Ft_Radicacion;

FUNCTION Ft_Validar_Traspaso_Indeterm (Placa Varchar2) Return Boolean
As
Cantidad_Registro Number;
Fecha_Indeterminado Date:='';
Fecha_Traspaso Date:='';
Begin

Select Count(1) Into Cantidad_Registro From Bd_Transitos.St_Tramites
Where Nro_Placa = Placa And Id_Tramite = 65;

  If Cantidad_Registro > 0 Then
    
    Fecha_Traspaso:=Fecha_Con_Parametros(Placa,16,null);
    Fecha_Indeterminado:=Fecha_Con_Parametros(Placa,65,null);
      
      If Fecha_Indeterminado > Fecha_Traspaso Or  Fecha_Traspaso is null Then
         Insert Into Fc_Busqueda_Propietarios_Temp(Nro_Placa,Nombre_tramite,Fecha_Tramite,Id_Documento_Anterior,
                    Id_Usuario_Anterior, Id_Documento_Nuevo,
                    Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado)
         Select Nro_Placa,Nombre_tramite,To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)),Id_Documento_Anterior,
                    Id_Usuario_Anterior, Id_Documento_Nuevo,
                    Id_Usuario_Nuevo,Porcentaje_Prop,Id_Radicado  From Bd_Transitos.St_Tramites
         Where Nro_Placa = Placa And Id_Tramite = 65 And To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) = Fecha_Indeterminado ;
         
         Update Prueba Set Estado = 'I'
         Where Nro_Placa = Placa;
         Return True;
      Else 
          Return False;
      End If;
  Else
    Return False;
  End If;
END Ft_Validar_Traspaso_Indeterm;


PROCEDURE Sp_Validar_Traspaso_Indeterm 
Is
nCantidad Number;
Cursor CurProp Is Select  Nro_placa,Id_Usuario_Nuevo, RowId From Fc_Busqueda_Propietarios_Temp;
Begin
For Ln_Index In CurProp Loop
  nCantidad:=0;
    Select Count(1) Into nCantidad 
            From Bd_Transitos.St_Contribuyentes 
                Where Id_Usuario = Ln_Index.Id_Usuario_Nuevo
                    And Upper((Nombres||Apellidos)) Like 'INDETER%';
            If nCantidad > 0 Then
                    Update Fc_Busqueda_Propietarios_Temp Set Estado = 'Indeterminado'
                        Where Nro_Placa = Ln_Index.Nro_Placa And RowId = Ln_Index.RowId;
            End If;
End Loop;
END Sp_Validar_Traspaso_Indeterm;
END PKG_BUSQUEDA_FISCA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_CILINDRAJE_MENOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_CILINDRAJE_MENOR" AS


  PROCEDURE SP_CILINDRAJE_MENOR AS
  Cilindraje number:=0;
  ncontador Number:=0;
CURSOR curcilindraje is select NRO_PLACA from  PRUEBA;

  BEGIN
    For Ln_Index In curcilindraje loop      
     SELECT Count(1) into ncontador  FROM bd_transitos.st_vehiculos 
        WHERE NRO_PLACA = Ln_Index.NRO_PLACA;
        
        If ncontador = 1 Then
                        --voy a almacenar el cilindraje para validar 
                     SELECT CILINDRAJE into Cilindraje  FROM bd_transitos.st_vehiculos 
                     WHERE NRO_PLACA = Ln_Index.NRO_PLACA;
                       
                     if CILINDRAJE< 126 then
                            --atua
                         update PRUEBA SET  ESTADO='CILINDRAJE MENOR'
                         WHERE NRO_PLACA= Ln_Index.NRO_PLACA;
                     ELSe
                         update PRUEBA SET  ESTADO='CILINDRAJE mayor'
                         WHERE NRO_PLACA= Ln_Index.NRO_PLACA;
                     end if; 
      END IF ;
                   SELECT COUNT (1)into ncontador FROM FC_AUTOMOTOR
                   WHERE NRO_PLACA = Ln_Index.NRO_PLACA;
                   
        If ncontador = 1 Then
        
        
                 SELECT CILINDRAJE into Cilindraje  FROM  FC_AUTOMOTOR
                 WHERE NRO_PLACA = Ln_Index.NRO_PLACA;
                 
                        if CILINDRAJE< 126 then
                             update PRUEBA SET  ESTADO='CILINDRAJE MENOR'
                             WHERE NRO_PLACA= Ln_Index.NRO_PLACA;
                         ELSe
                             update PRUEBA SET  ESTADO='CILINDRAJE mayor'
                             WHERE NRO_PLACA= Ln_Index.NRO_PLACA;  
                      end if;
         ELSE  
     
         update PRUEBA SET  ESTADO='No hay Info'
         WHERE NRO_PLACA= Ln_Index.NRO_PLACA;
        
     END IF ;
     
     SELECT COUNT(1)into ncontador  FROM FC_AUTOMOTOR
     WHERE NRO_PLACA = Ln_Index.NRO_PLACA;   
  
     if ncontador >  1 Then

        SELECT CILINDRAJE  into ncontador  FROM FC_AUTOMOTOR
        WHERE NRO_PLACA = Ln_Index.NRO_PLACA;
          
         if CILINDRAJE< 126 then
         INSERT INTO PRUEBA (NRO_PLACA ,ID_USUARIO) VALUES ( Ln_Index.NRO_PLACA,CILINDRAJE);
         
         ELSE
         INSERT INTO PRUEBA (NRO_PLACA ,ID_USUARIO) VALUES ( Ln_Index.NRO_PLACA,CILINDRAJE);    
        
         end if;
        
    end if ;
        
END LOOP;

END SP_CILINDRAJE_MENOR;

END PKG_CILINDRAJE_MENOR;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DIRECCION_FECHA_PAGO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_DIRECCION_FECHA_PAGO" AS

is_contador SIMPLE_INTEGER:=0;
is_commit SIMPLE_INTEGER:=100;

tp_fecha_direccion Tp_fecha_dir := tp_fecha_dir();
tp_lista_fecha_direccion tp_lista_fecha_dir := tp_lista_fecha_dir();

FUNCTION FT_VALIDAR_DEPARTAMENTO (av_codigo_direccion Varchar2) return number As

/*ISVA
Nombre     :FT_VALIDAR_DEPARTAMENTO
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros : 
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Verifica que la ciudad si este homologada
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

ln_Cantidad number:=0;
begin
    Select Count(1) into ln_Cantidad From Fc_Municipio_Departamento 
    where Divipo = av_codigo_direccion;
        Return ln_Cantidad;
        
END FT_VALIDAR_DEPARTAMENTO;

PROCEDURE SP_COMMIT As

/*ISVA
Nombre     :sp_commit
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Insertar la Direccion declarada mas reciente
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

BEGIN
    IF is_contador = is_commit THEN
        is_contador:=0;
        COMMIT;
    ELSE
        is_contador:= is_contador +1;
    END IF;
    
END SP_COMMIT;

PROCEDURE SP_INSERTAR_DIRECCION (av_placa Varchar2,av_interlocutor Varchar2,av_fecha_Pago Varchar2,av_direccion Varchar2, 
                                 av_departamento Varchar2, av_municipio Varchar2, av_mensaje Varchar2) AS
/*ISVA
Nombre     :SP_INSERTAR_DIRECCION
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Insertar la Direccion declarada mas reciente
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

BEGIN
     tp_fecha_direccion.nro_placa := av_placa;
     tp_fecha_direccion.id_interlocutor :=av_interlocutor;
     tp_fecha_direccion.fecha_pago := av_fecha_Pago;
     tp_fecha_direccion.direccion := av_direccion;
     tp_fecha_direccion.departamento := av_departamento;
     tp_fecha_direccion.municipio := av_municipio;
     tp_fecha_direccion.estado := av_mensaje;
     tp_lista_fecha_direccion.EXTEND;
     tp_lista_fecha_direccion(tp_lista_fecha_direccion.COUNT()):= tp_fecha_direccion;
     
    Update Prueba Set Estado = 'S'
    Where Id_Usuario = av_interlocutor;
        Sp_Commit();
    
END SP_INSERTAR_DIRECCION;

FUNCTION FT_VALIDAR_DIR(av_direccion varchar2) return number as

/*ISVA
Nombre     :FT_VALIDAR_DIR
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Valida que la direccion si cumpla la estructura
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1);
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnCumple Number:=0;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(av_direccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
  
  --Permite validar las direcciones con estructura CL 10 1020 o CL 10B 1020
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return 0;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
       lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  

-- Valido que la direcci�n tenga estructura v�lida
Select count(1) into lnCumple
from fc_estructura_Direccion 
where lvEstructura like '%' || Estructura ||'%';

If(lnCumple > 0)then
  Return 1;
else
  Return 0;
end if;

END FT_VALIDAR_DIR;

PROCEDURE  SP_GENERAR_ARCH_DIR_PAGOS AS

/*ISVA
Nombre     :SP_GENERAR_ARCH_DIR_PAGOS
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :crea un archivo plano de las direcciones 
           :con pagos.
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

lv_Name_File Varchar2(255 byte):='Direcciones_Con_Pagos '||Replace(To_date(sysdate,'dd-mm-yyyy'),'/','')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

lb_Abrir Boolean:=False;

BEGIN
    v_MyFileHandle := UTL_FILE.FOPEN('DIR_FECHAS',lv_Name_File,'W');
     IF tp_lista_fecha_direccion.Count()>0 THEN
        FOR ln_index IN 1..tp_lista_fecha_direccion.Count() LOOP
          If lb_Abrir = False Then
            UTL_FILE.PUT_LINE(v_MyFileHandle,'NRO_PLACA'||';'||'ID_INTERLOCUTOR'||';'||'FECHA_PAGO'||';'
                                            ||'DIRECCION'||';'||'DEPARTAMENTO'||';'||'MUNICIPIO'||';'||'ESTADO');
            
                lb_Abrir:=True;
          End If;
          
          UTL_FILE.PUT_LINE(v_MyFileHandle,
                            tp_lista_fecha_direccion(ln_index).nro_placa||';'||
                            tp_lista_fecha_direccion(ln_index).id_interlocutor||';'||
                            tp_lista_fecha_direccion(ln_index).fecha_pago||';'||
                            tp_lista_fecha_direccion(ln_index).direccion||';'||
                            tp_lista_fecha_direccion(ln_index).departamento||';'||
                            tp_lista_fecha_direccion(ln_index).municipio||';'||
                            tp_lista_fecha_direccion(ln_index).estado);
        END LOOP;
     END IF;
END SP_GENERAR_ARCH_DIR_PAGOS;

PROCEDURE SP_BUSCAR_DIR_DECLARACION AS

/*ISVA
Nombre     :SP_BUSCAR_DIR_DECLARACION
Autor      :Blados.Ospina
Fecha      :18/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_DIRECCION_FECHA_PAGO
Versi�n    :1.0
Objetivo   :Captura cada inerlocutor a validar si tiene pago
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
18/05/2018      Blados.Ospina
*/

type Array_Novedades is varray(5) of Varchar2(100 byte);
array Array_Novedades:=Array_Novedades('VRD','KM','FCA','CRG');
lb_validador boolean;
ln_Contador number:=0;
ln_posicion_busqueda number:=0;
ln_validar_transito number:=0;
lv_direccion_estandarizada Varchar2(100 byte):='';
lv_mensaje_0 Varchar2 (100 byte) := 'La Direccion Cumple la Estructura';
lv_mensaje_1 Varchar2 (100 byte) := 'La Direccion No Cumple la Estructura';
lv_mensaje_2 Varchar2 (100 byte) := 'La Ciudad No Esta Homologada';
lv_nro_placa Varchar2 (100 byte);
lv_interlocutor_comercial Varchar2(100 byte);
ld_fecha_pago Date;
lv_municipio Varchar2 (100 byte);
lv_departamento Varchar2 (100 byte); 
ln_validador_msj Number:=0;
--nCantidad Number :=0;

Cursor C1 is Select Id_Usuario from Prueba where Estado = 'P';
Cursor C2(vId_Usuario Varchar2) Is Select Distinct Nro_Placa,Id_Interlocutor,Fecha_Pago,Codigo_Runt,Direccion,Municipio,
                                          Departamento from Fc_Reporte_Pagos  where Id_Interlocutor = vId_Usuario
                                           Order By 3 Desc;
Begin 
For Ln_Index in C1 Loop
Begin

lv_interlocutor_comercial:=ln_Index.Id_Usuario;
ln_validador_msj:=0;
  For Ln_Index_2 In C2 (Ln_Index.Id_Usuario)Loop
    Begin

lv_nro_placa:=ln_Index_2.Nro_Placa;lv_interlocutor_comercial:=ln_Index_2.Id_Interlocutor;
ld_fecha_pago:=ln_Index_2.Fecha_Pago;lv_departamento:=ln_Index_2.Departamento;lv_municipio:=ln_Index_2.Municipio;ln_validador_msj:=0;
lb_validador := False;    

  --Se Estadanriza Toda La direccion y se pasa a Mayuscula
  lv_direccion_estandarizada :=Trim(Correccion_Datos.Pkg_Ds_Estandariza_Runt.Ft_Estandarizar_Direccion(Ln_Index_2.Direccion));
  lb_validador:=false;
  for i in 1..array.count loop
         --Verifica que sea Vereda,Finca,Corregimiento o Kilometro
          ln_posicion_busqueda := instr(lv_direccion_estandarizada,array(i));
             if ln_posicion_busqueda > 0 then 
               --Valido que el transito este Homologado
                ln_validar_transito:= FT_Validar_Departamento(Ln_Index_2.Codigo_Runt);
                  if ln_validar_transito > 0 then
                       Sp_Insertar_Direccion (ln_Index_2.Nro_Placa,ln_Index_2.Id_Interlocutor,
                       ln_Index_2.Fecha_Pago,lv_Direccion_Estandarizada,ln_Index_2.Departamento,ln_Index_2.Municipio,lv_Mensaje_0);
                       lb_validador := true; 
                       ln_validador_msj:=4;
                       Exit;
                 -- else                      
                     --  ln_validador_msj:=1;                   
                  end if;
             end if;       
       end loop;
      -- Valida Direccion por que no encontro CRG,FCA,VRD o KM
      if lb_validador = false then
          ln_posicion_busqueda := Ft_Validar_Dir(lv_direccion_estandarizada);          
          if ln_posicion_busqueda > 0 then
                -- Validamos Que departamento si este Homologado
                ln_validar_transito:= Ft_Validar_Departamento (Ln_Index_2.Codigo_Runt);
                if ln_validar_transito > 0 then   
                            Sp_Insertar_Direccion (ln_Index_2.Nro_Placa,ln_Index_2.Id_Interlocutor,
                                ln_Index_2.Fecha_Pago,lv_direccion_estandarizada,ln_Index_2.Departamento,ln_Index_2.Municipio,lv_mensaje_0);
                                lb_validador := True;
                                ln_validador_msj:=4;
                                Exit;
                            
                else                    
                        ln_validador_msj:=2;                
                end if; 
            Else
              ln_validador_msj:=1;        
        end if;        
    Else -- lo Saca si Ya encontro una Direccion Valida       
        Exit;
    end if;
        Exception
        When Others Then
            Continue;
  End;
  End Loop;
End;
  Case
      When ln_validador_msj = 2  Then
        Sp_Insertar_Direccion (lv_nro_placa,lv_interlocutor_comercial,
                                      ld_fecha_pago,lv_direccion_estandarizada,lv_departamento,lv_municipio,lv_mensaje_2);                                 
      When ln_validador_msj = 1 Then          
          Sp_Insertar_Direccion (lv_nro_placa,lv_interlocutor_comercial,
                                      ld_fecha_pago,lv_direccion_estandarizada,lv_departamento,lv_municipio,lv_mensaje_1);
                                      
      When ln_validador_msj = 0 Then
      Sp_Insertar_Direccion (Null,lv_interlocutor_comercial,
                                      Null,Null,Null,Null,'No Tiene Pago');                                  
    Else
      Continue;

  End Case;
      
End Loop;
    SP_GENERAR_ARCH_DIR_PAGOS();
END SP_BUSCAR_DIR_DECLARACION;

END PKG_DIRECCION_FECHA_PAGO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DIRECCION_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_DIRECCION_TTO" AS
lvResultado varchar2(1);

--Type
Type typePropietarioSap is table of fc_contribuyentes%ROWTYPE;
Type typePropietarioTto is table of bd_transitos.St_contribuyentes%ROWTYPE;


FUNCTION FT_ESTRUCTURA_DIR(lfDireccion varchar2) return number as

lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1);
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnCumple Number:=0;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(lfDireccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
  
  --Permite validar las direcciones con estructura CL 10 1020 o CL 10B 1020
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return 0;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
       lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  

-- Valido que la direcci�n tenga estructura v�lida
Select count(1) into lnCumple
from fc_estructura_Direccion 
where lvEstructura like '%' || Estructura ||'%';

If(lnCumple > 0)then
  Return 0;
else
  Return 8;
end if;

/*If((Instr(lvEstructura,'~ @ ~ @ @')>0) -- CL 10 B 14 23
   Or (Instr(lvEstructura,'~ @ @ @')>0) -- CL 10 14 23
   Or (Instr(lvEstructura,'~ @ @ ~ @')>0) -- CL 10 14 B 23   
   Or (Instr(lvEstructura,'~ @ ~ @ ~ @')>0) -- CL 10 B 14 B 23    
   ) Then
  Return 0;
Else
  Return 8;
End If;*/

END FT_ESTRUCTURA_DIR;

FUNCTION FT_INCONSISTENCIA (lnIdentificador NUMBER) RETURN VARCHAR2 AS
lvRetorno Varchar2(100);

BEGIN

Select MENSAJE into lvRetorno
from Fc_Inconsistencia
where identificador= lnIdentificador;

Return lvRetorno;

END FT_INCONSISTENCIA;

Function Ft_ProcesarUsuarioSap (lfVigencia varchar2, lfId_Usuario varchar2, lfId_Documento Varchar2) return boolean as

lvDireccionSap Varchar2(1000);
lvIdCiudadSap Varchar2(10);
lvNombreCiudadSap VArchar2(100);
lvIdDptoSap Varchar2(10);
lvNombreDptoSap Varchar2(100);
lnErrorDirSAP Number :=0;
esError boolean :=false;
lv_Incon Varchar2(255):='';

Cursor curPropietarioSap is
Select Id_Radicado,Id_Interlocutor,Id_Usuario,Id_Documento,Nombres,Apellidos,Razon_Social
       Usuario_Modificacion,Decode(Fecha_Modificacion,'','01011990',Fecha_Modificacion) Fecha_Modificacion,
       Direccion,Id_Departamento,Departamento,Id_Municipio,Municipio,Telefono,E_Mail
from fc_contribuyentes 
where Id_Usuario = lfId_Usuario and Id_Documento = lfId_Documento
Order By Id_Radicado,Fecha_Modificacion Desc;

Type tyPropietarioSap is table of curPropietarioSap%RowType;
ArrayPropietarioSap tyPropietarioSap;

begin
  Open curPropietarioSap;
    Loop
      fetch curPropietarioSap
        bulk collect into ArrayPropietarioSap limit 100; --100
          for lnIndex in 1..ArrayPropietarioSap.count() loop
            --1. Valido las direcciones
            lvDireccionSap := Trim(Upper(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(ArrayPropietarioSap(lnIndex).Direccion)));--Estandarizo la direcci�n
            lnErrorDirSAP := Correccion_Datos.PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(lvDireccionSap,0);--Valido que si sea valida.
            
            if(lnErrorDirSAP = 0) then
              -- Valido que cumpla con la esctructura
               lnErrorDirSAP := Ft_Estructura_Dir(lvDireccionSap);
            End if;            
            
            if(lnErrorDirSAP = 0) then
            --Recupero los id direci�n en codificaci�n SAP      
              Begin
                --Recupero las id direci�n en codificaci�n SAP    
                Select Sc.Id_Depto_Sap, upper(Qd.Nombre_Departamento), DESCRIPCION_CIUDAD_SAP 
                  into lvIdDptoSap, lvNombreDptoSap, lvNombreCiudadSap  
                from DEPURACION.Sap_Ciudades sc
                left join quipux.departamentos qd on Qd.Id_Departamento_Qx = Sc.Id_Depto_Qx
                where Id_Ciudad_Sap = ArrayPropietarioSap(lnIndex).Id_Municipio
                   and rownum = 1;
              exception 
                when others then
                  lnErrorDirSAP := 7;
                  --Ingreso el error
              end;                              
            end if;             
            
            if(lnErrorDirSAP = 0) then
              Begin
               Insert into fc_notificacion (Vigencia,Id_Usuario,Id_Documento,Nombres,Apellidos,Direccion,Id_Ciudad,
                           Nombre_Ciudad,Id_Departamento,Nombre_Departamento, Email,Telefono,Fuente_Direccion,Id_Radicado_Fuente)
                   values (lfVigencia, ArrayPropietarioSap(lnIndex).Id_Usuario,ArrayPropietarioSap(lnIndex).Id_Documento,
                           Upper(ArrayPropietarioSap(lnIndex).Nombres),  Upper(ArrayPropietarioSap(lnIndex).Apellidos),
                           lvDireccionSap,ArrayPropietarioSap(lnIndex).Id_Municipio, lvNombreCiudadSap,lvIdDptoSap, lvNombreDptoSap,
                           ArrayPropietarioSap(lnIndex).E_Mail, ArrayPropietarioSap(lnIndex).Telefono,'Sap', ArrayPropietarioSap(lnIndex).Id_Radicado);
           
                Delete fc_notificacion_error
                Where Id_Usuario =  ArrayPropietarioSap(lnIndex).Id_Usuario
                  and Id_Documento = ArrayPropietarioSap(lnIndex).Id_Documento
                  and Vigencia = lfVigencia;
                  
             exception 
                when others then
                 Continue;
              end; 
            esError := True;
            Return esError;
            else
               Begin
                --Ingreso el error
                    lv_Incon:=Ft_Inconsistencia(lnErrorDirSAP);
                Insert into Fc_Notificacion_error(Vigencia,Id_Usuario,Id_Documento,Nombres,Apellidos,Direccion,
                             Id_Ciudad,Nombre_Ciudad,Fuente,Id_Radicado,Inconsistencia)
                      values (lfVigencia, ArrayPropietarioSap(lnIndex).Id_Usuario,ArrayPropietarioSap(lnIndex).Id_Documento,
                             Upper(ArrayPropietarioSap(lnIndex).Nombres),  Upper(ArrayPropietarioSap(lnIndex).Apellidos),
                             lvDireccionSap, ArrayPropietarioSap(lnIndex).Id_Municipio,ArrayPropietarioSap(lnIndex).Municipio,
                             'Sap',ArrayPropietarioSap(lnIndex).Id_Radicado,lv_Incon);                             
               
                exception 
                when others then
                 Continue;
              end; 
            End if;
            Exit when ArrayPropietarioSap.Count()<=0;
          End loop;
          Exit when ArrayPropietarioSap.Count()<=0;
    End Loop;      
  Close curPropietarioSap;
  Return esError;
End Ft_ProcesarUsuarioSap;

Function Ft_ProcesarUsuarioTto (lfVigencia varchar2, lfId_Usuario varchar2, lfId_Documento Varchar2,lfId_Radicado number, lfProceso varchar2) return boolean as

lvDireccionTto Varchar2(1000);
lvIdCiudadSap Varchar2(10);
lvNombreCiudadSap VArchar2(100);
lvIdDptoSap Varchar2(10);
lvNombreDptoSap Varchar2(100);
lnErrorDirTto Number :=0;
esIngresado boolean :=false;
esProcesar boolean :=true;
lv_Incon Varchar2 (255):='';


Cursor curPropietarioTto is
  Select Id_Usuario,Id_Documento,Id_Ciudad,Nombre_Ciudad,Apellidos,Nombres,Direccion,Telefono,Emp_O_Part,Sexo,
         Fecha_Nacimiento,Id_Pais,Nombre_Pais,
         Decode(length(Fecha_Modificacion),null,'01011990',
                                              7,'0'||Fecha_Modificacion,        
                                                     Fecha_Modificacion) Fecha_Modificacion,
         Fax,Email,Fecha_Actualizacion,Id_Ciudad_Dir,Nombre_Ciudad_Dir,Id_Direccion,Id_Radicado,Celular
    --Bulk collect into ArrayPropietariosTto 
  From bd_transitos.St_contribuyentes
  Where id_Usuario = lfId_Usuario
    and Id_Documento = lfId_Documento   
    order by To_Date(Fecha_Modificacion) desc ; 

Type tyPropietarioTto is table of curPropietarioTto%RowType;
ArrayPropietariosTto tyPropietarioTto;

begin
  Open curPropietarioTto;
    Loop
      fetch curPropietarioTto
        bulk collect into ArrayPropietariosTto limit 100; --100
          for lnIndex in 1..ArrayPropietariosTto.count() loop
            --1. Valido tipo_proceso
            If (lfProceso = 'T') Then --Si se llama de tramites solo valido las de igual radicado
               if(ArrayPropietariosTto(lnIndex).Id_Radicado = lfId_Radicado)then
                  esProcesar := true;
               else   
                  esProcesar := false;
               end if;            
            End if;
             
             If (esProcesar = true) then
                --2. Valido las direcciones
                lvDireccionTto := Trim(Upper(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(ArrayPropietariosTto(lnIndex).Direccion)));--Estandarizo la direcci�n
                lnErrorDirTto := Correccion_Datos.PKG_GENERAR_PLANTILLA_IC.FT_VALIDAR_DIRECCION(lvDireccionTto,0);--Valido que si sea valida.
               
             if(lnErrorDirTto = 0) then
              -- Valido que cumpla con la esctructura
               lnErrorDirTto := Ft_Estructura_Dir(lvDireccionTto);
              End if;
            
             if(lnErrorDirTTO = 0) then
                 --Recupero los id direci�n en codificaci�n SAP      
                 Begin
                    Select Sc.Id_Depto_Sap, Upper(Qd.Nombre_Departamento), Id_Ciudad_Sap, Upper(Descripcion_Ciudad_Sap)
                           into lvIdDptoSap, lvNombreDptoSap, lvIdCiudadSap, lvNombreCiudadSap  
                    from DEPURACION.Sap_Ciudades sc
                    left join quipux.qx_ciudad qc on Qc.Id_Ciudad_Qx = Sc.Id_Ciudad_Qx
                    left join quipux.departamentos qd on Qd.Id_Departamento_Qx = Sc.Id_Depto_Qx
                    where Qc.Min_Ciudad_Qx = ArrayPropietariosTto(lnIndex).Id_Ciudad_Dir
                       and rownum = 1;              
                exception 
                when others then
                 lnErrorDirTTO := 7;
                 --Ingreso el error
                end;                                
              
              end if;  
              
              if(lnErrorDirTTO = 0) then --Guardo el propietario en las fc_notificaci�n    
              Begin
                 Insert into fc_notificacion (Vigencia,Id_Usuario,Id_Documento,Nombres,Apellidos,Direccion,Id_Ciudad,
                             Nombre_Ciudad, Id_Departamento,Nombre_Departamento, Email,Telefono,Celular,Fuente_Direccion,Id_Radicado_Fuente)
                     values (lfVigencia, ArrayPropietariosTto(lnIndex).Id_Usuario,ArrayPropietariosTto(lnIndex).Id_Documento,
                             Upper(ArrayPropietariosTto(lnIndex).Nombres),  Upper(ArrayPropietariosTto(lnIndex).Apellidos),
                             lvDireccionTto,lvIdCiudadSap,lvNombreCiudadSap, lvIdDptoSap, lvNombreDptoSap,
                             ArrayPropietariosTto(lnIndex).Email, ArrayPropietariosTto(lnIndex).Telefono,ArrayPropietariosTto(lnIndex).Celular,
                             'Tto', ArrayPropietariosTto(lnIndex).Id_Radicado);
                             
                Delete fc_notificacion_error
                Where Id_Usuario =  ArrayPropietariosTto(lnIndex).Id_Usuario
                  and Id_Documento = ArrayPropietariosTto(lnIndex).Id_Documento
                  and Vigencia = lfVigencia;
                  
                exception 
                when others then
                 Continue;
              end; 
                  esIngresado := true;        
                  Return esIngresado;         
               else
                --Ingreso el error
                Begin
                    lv_Incon:=Ft_Inconsistencia(lnErrorDirTTO);
                 Insert into Fc_Notificacion_error(Vigencia,Id_Usuario,Id_Documento,Nombres,Apellidos,Direccion,
                             Id_Ciudad,Nombre_Ciudad,Fuente,Id_Radicado,Inconsistencia)
                      values (lfVigencia, ArrayPropietariosTto(lnIndex).Id_Usuario,ArrayPropietariosTto(lnIndex).Id_Documento,
                             Upper(ArrayPropietariosTto(lnIndex).Nombres),  Upper(ArrayPropietariosTto(lnIndex).Apellidos),
                             lvDireccionTto, ArrayPropietariosTto(lnIndex).Id_Ciudad_Dir,ArrayPropietariosTto(lnIndex).Nombre_Ciudad_Dir,
                             'Tto',ArrayPropietariosTto(lnIndex).Id_Radicado,lv_Incon);    
                              exception 
                when others then
                 Continue;
              end; 
               End if;
            End if;
            
            Exit when ArrayPropietariosTto.Count()<=0;
          End loop;
          Exit when ArrayPropietariosTto.Count()<=0;
    End Loop;      
  Close curPropietarioTto;
  Return esIngresado;
End Ft_ProcesarUsuarioTto;

Function FT_ProcesarTramites(Vigencia varchar2, lfId_Usuario varchar2, lfId_Documento Varchar2) return boolean as

lnCantidad Number:=0;
lnErrorDirTTO Number :=0;
lnErrorDirSAP Number :=0;
lvDireccionTto Varchar2(1000);
lvDireccionSap Varchar2(1000);
lvIdCiudadSap Varchar2(10);
lvNombreCiudadSap VArchar2(100);
lvIdDptoSap Varchar2(10);
lvNombreDptoSap Varchar2(100);
lvInconcistencia Varchar2(1000);
esTramite boolean := false;

Cursor curTramites is
      Select Distinct Sp.Id_Usuario, Sp.Id_Documento, Sp.Nro_Placa, St.Nombre_Tramite, 
                      To_Date(Decode(length(St.Fecha_Tramite),null,'01011990',7,
                                    '0'||St.Fecha_Tramite,                                     
                                    St.Fecha_Tramite,5,null)) Fecha_Tramite, St.Id_Radicado           
        From Bd_Transitos.St_Propietarios Sp 
        Inner Join Bd_Transitos.St_Tramites St On St.Nro_Placa = Sp.Nro_Placa
        Where St.Id_Radicado > 20
          And Sp.Id_Documento = lfId_Documento
          And Sp.Id_Usuario  = lfId_Usuario       
    Union        
        Select Distinct St.Id_Usuario_Anterior, St.Id_Documento_Anterior, St.Nro_Placa,
                        St.Nombre_Tramite, To_Date(Decode(length(St.Fecha_Tramite),null,'01011990',7,
                                                    '0'||St.Fecha_Tramite,                                     
                                                    St.Fecha_Tramite,5,null)) Fecha_Tramite,
                                                    St.Id_Radicado         
        From Bd_Transitos.St_Tramites St
        Where St.Id_Radicado > 20 
          And St.Id_Documento_Anterior = lfId_Documento
          And St.Id_Usuario_Anterior  = lfId_Usuario
        Order By 5 Desc;

Type tyTramites is table of curTramites%RowType;
Type tyPropietariosTto is table of bd_transitos.St_contribuyentes%RowType;
ArrayTramites tyTramites;
ArrayPropietariosTto tyPropietariosTto;

begin
  Open curTramites;
    Loop
      fetch curTramites
        bulk collect into ArrayTramites;
        
         for lnIndex in 1.. ArrayTramites.count() loop
            --Inicio las validaciones de las direcciones por tr�mites
            --1.Recupero los contribuyentes x radicado
           esTramite:= Ft_ProcesarUsuarioTto (Vigencia, lfId_Usuario, lfId_Documento ,ArrayTramites(lnIndex).Id_Radicado, 'T');
           
           If(esTramite = true)then
            return esTramite;
           End if;           
          
          end loop;
         Exit when ArrayTramites.count()<=0;
      End Loop;
  Close CurTramites;  
  
  Return esTramite;

End FT_ProcesarTramites;

FUNCTION FT_ESTRUCTURA_DIR_1(lfDireccion varchar2) return varchar2 as

lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1);
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(lfDireccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
 
  --Permite 
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return lvEstructura;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
      lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  
--Elimino espacios dobles y caracteres del mismo tipo.

  Return lvEstructura;


END FT_ESTRUCTURA_DIR_1;

PROCEDURE SP_OBTENER_DIRECCION AS

esIngresado boolean := false;

Cursor curPropietario is
Select Id_Documento,Id_Usuario,Vigencia,Procesado 
From Fc_Propietario_Fiscalizado Where Procesado = 'P';

Type tyUsuario is table of curPropietario%ROWTYPE;
ArrayUsuario tyUsuario;


BEGIN

Open curPropietario;
  Loop Fetch curPropietario
     bulk collect into ArrayUsuario Limit 200;  --200
       for lnIndex  in 1..ArrayUsuario.count() Loop
             
             esIngresado := false;
             lvResultado:= 'F';
             
            --1. Valido el ultimo tr�mite. 
            esIngresado := FT_ProcesarTramites(ArrayUsuario(lnIndex).Vigencia,
                                ArrayUsuario(lnIndex).id_usuario, ArrayUsuario(lnIndex).id_documento);
                                
            --2. Valido Si el usuario no tiene tr�mite y fue reportado en contribuyentes
            if(esIngresado = false) then
                esIngresado := Ft_ProcesarUsuarioTto (ArrayUsuario(lnIndex).Vigencia,
                                  ArrayUsuario(lnIndex).id_usuario, ArrayUsuario(lnIndex).id_documento,0, 'P');
           
            end if;
            --3. Valido si esta en SAP
           if(esIngresado = false) then
                esIngresado:= Ft_ProcesarUsuarioSap (ArrayUsuario(lnIndex).Vigencia,
                                  ArrayUsuario(lnIndex).id_usuario, ArrayUsuario(lnIndex).id_documento);
            end if;
            
            if(esIngresado = true) then
              lvResultado:= 'E';
            end if;
            
            --4.Cambio el estado a procesado en FC_Propietario_Fiscalizado
            Update FC_Propietario_Fiscalizado set Procesado = lvResultado
            where Id_Usuario =  ArrayUsuario(lnIndex).id_usuario
              And Id_Documento = ArrayUsuario(lnIndex).id_documento;
            
       End Loop;
       Commit;
       Exit when ArrayUsuario.count()<=0;
  End Loop;
 
Close curPropietario;       

--Elimino duplicados de Fc_Notificacion_error
/*Delete From Fc_Notificacion_Error
 Where Rowid Not In
       (Select Min(Rowid)
        From Fc_Notificacion_Error
        Group By Vigencia,Id_Usuario,Id_Documento,Nombres,
        Apellidos,Direccion,Id_Ciudad,Nombre_Ciudad,Fuente,
        Id_Radicado,Inconsistencia);*/
Commit;

END SP_OBTENER_DIRECCION;

END PKG_DIRECCION_TTO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_HISTORIALES_TRASPASOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_HISTORIALES_TRASPASOS" AS

Tp_Propietario consultas.Tp_Propietarios :=consultas.Tp_Propietarios();
Tp_Lista_Propietario consultas.Tp_Lista_Propietarios :=consultas.Tp_Lista_Propietarios();
Tp_Lista_Error consultas.Tp_Lista_Errores:=consultas.Tp_Lista_Errores();
Tp_Error consultas.Tp_Errores:=consultas.Tp_Errores();
in_vigencia VARCHAR2(255 BYTE);
is_Novedad_Matricula Simple_Integer:=9;
is_Novedad_Radicacion Simple_Integer:=10;
iexception NUMBER;

PROCEDURE sp_exception (av_estado VARCHAR) AS

/*ISVA
Nombre     :Sp_Exception
Autor      :Blados.Ospina
Fecha      :05/12/2018
Variables  :lv_Name_File_Error, v_Error 
Retorno    :              
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :Capturar los errores y los almacena en archivo plano
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                     */

lv_Name_File_Error VARCHAR2(255 byte):='Error_'||av_Estado||' '||To_Char(SYSDATE,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_Error UTL_FILE.FILE_TYPE;

BEGIN
    IF Tp_Lista_Error.COUNT()>0 THEN
      v_Error:= UTL_FILE.FOPEN('DATA_FISCA',lv_Name_File_Error,'W');
            FOR Ln_Index In 1..Tp_Lista_Error.COUNT() LOOP
                UTL_FILE.PUT_LINE(v_Error,Tp_Lista_Error(Ln_Index).Nombre_Error||';'||Tp_Lista_Error(Ln_Index).Id_Error);
            END LOOP;
       UTL_FILE.FCLOSE(v_Error);  
    END IF;
END Sp_Exception;

PROCEDURE sp_reset_tp_propietario AS

/*ISVA
Nombre     :sp_reset_tp_propietario
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :resetea las variables
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion
                                                    */

BEGIN
        Tp_Propietario.Nro_Placa:='';
        Tp_Propietario.Tipo_Documento_Vendedor:='';
        Tp_Propietario.Id_Vendedor:='';
        Tp_Propietario.Tipo_Documento_Comprador:='';
        Tp_Propietario.Id_Comprador:='';
        Tp_Propietario.Porcentaje:='';
        Tp_Propietario.Fecha:='';
        Tp_Propietario.Transito:='';
        Tp_Propietario.Id_Documento_Propietario:='';
        Tp_Propietario.Id_Propieario:='';
        Tp_Propietario.estado:='';
        iexception:=0;

END sp_reset_tp_propietario;

FUNCTION ft_fecha_traspaso (av_placa VARCHAR) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_fecha_traspaso
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :av_placa
Variables  :lv_fecha
Retorno    :lv_fecha             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :recupera la fecha maxima
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion
                                                    */

lv_fecha VARCHAR2(255 BYTE):='';

BEGIN
  SELECT MAX(TO_DATE(TRANSLATE(fecha,'.AaMmPpm','      '),'DD/MM/YY HH24:MI:SS')) INTO lv_fecha FROM bd_transitos.st_historiales_traspaso
  WHERE nro_placa = av_placa AND TO_DATE(TRANSLATE(fecha,'.AaMmPpm','      '),'DD/MM/YY HH24:MI:SS') < TO_DATE(in_vigencia);
    
    RETURN lv_fecha;

EXCEPTION
WHEN OTHERS THEN

 RETURN lv_fecha;

END ft_fecha_traspaso;

PROCEDURE sp_historiales_traspaso_2 (av_placa VARCHAR) AS

/*ISVA
Nombre     :Ft_Historiales_Traspaso
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                     */

CURSOR lcur_histo_traspaso(ad_fecha VARCHAR) IS SELECT DISTINCT nro_Placa,Tipo_Documento_Usuario AS Documento_Vendedor, 
                                              Id_Usuario AS Vendedor,Tipo_Documento_Comprador AS Documento_Comprador, 
                                              Id_Comprador AS Comprador, Porcentaje AS Porcentaje,
                                              fecha As Fecha_Tramite, 
                                              Id_Radicado AS Transito
                                    FROM Bd_Transitos.St_Historiales_Traspaso
                                    WHERE Nro_Placa = av_placa
                                    AND TO_DATE(SUBSTR(fecha,1,8)) = ad_fecha;
lv_fecha VARCHAR2(255 BYTE):='';
BEGIN 
    iexception:=1;
  IF System.Pkg_Utilitario.Ft_Existe_His_Traspaso(av_placa) = TRUE THEN  
    lv_fecha:=ft_fecha_traspaso(av_placa);
    IF lv_fecha IS NOT NULL THEN
    FOR Ln_Index In lcur_histo_traspaso(lv_fecha) LOOP
        BEGIN  
        Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
        Tp_Propietario.Tipo_Documento_Vendedor:= Ln_Index.Documento_Vendedor;
        Tp_Propietario.Id_Vendedor:=Ln_Index.Vendedor;
        Tp_Propietario.Tipo_Documento_Comprador:= Ln_Index.Documento_Comprador;
        Tp_Propietario.Id_Comprador:= Ln_Index.Comprador;
        Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
        Tp_Propietario.Fecha:= Ln_Index.Fecha_Tramite;
        Tp_Propietario.Estado := 'Traspaso';
        Tp_Propietario.Transito:= SYSTEM.Pkg_Utilitario.Ft_Registrar_Transito(Ln_Index.Transito);
        
             Tp_Lista_Propietario.EXTEND;
             Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
            EXCEPTION 
                WHEN OTHERS THEN
                    Tp_Error.Id_Error:=sqlerrm;
                    Tp_Error.Nombre_Error:=ln_index.Nro_Placa||';'||Dbms_Utility.Format_Error_Backtrace;
                    Tp_Lista_Error.EXTEND;
                    Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                    CONTINUE;
        END;
    END LOOP; 
    ELSE
        Tp_Error.Id_Error:=sqlerrm;
        Tp_Error.Nombre_Error:=av_placa||';'||Dbms_Utility.Format_Error_Backtrace;
        Tp_Lista_Error.EXTEND;
        Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
    END IF;
  END IF;  
END sp_Historiales_Traspaso_2;

FUNCTION ft_historiales_traspaso (av_placa VARCHAR) RETURN Boolean AS

/*ISVA
Nombre     :Ft_Historiales_Traspaso
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                     */

lb_Existe BOOLEAN:=FALSE;

CURSOR lcur_histo_traspaso(ad_fecha VARCHAR) IS SELECT DISTINCT nro_Placa,Tipo_Documento_Usuario AS Documento_Vendedor, 
                                              Id_Usuario AS Vendedor,Tipo_Documento_Comprador AS Documento_Comprador, 
                                              Id_Comprador AS Comprador, Porcentaje AS Porcentaje,
                                              fecha As Fecha_Tramite, 
                                              Id_Radicado AS Transito
                                    FROM Bd_Transitos.St_Historiales_Traspaso
                                    WHERE Nro_Placa = av_placa
                                    AND TO_DATE(SUBSTR(fecha,1,10)) = ad_fecha;
BEGIN 
  IF System.Pkg_Utilitario.Ft_Existe_His_Traspaso(av_placa) = TRUE THEN  
    FOR Ln_Index In lcur_histo_traspaso(ft_fecha_traspaso(av_placa)) LOOP
        BEGIN  
        Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
        Tp_Propietario.Tipo_Documento_Vendedor:= Ln_Index.Documento_Vendedor;
        Tp_Propietario.Id_Vendedor:=Ln_Index.Vendedor;
        Tp_Propietario.Tipo_Documento_Comprador:= Ln_Index.Documento_Comprador;
        Tp_Propietario.Id_Comprador:= Ln_Index.Comprador;
        Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
        Tp_Propietario.Fecha:= Ln_Index.Fecha_Tramite;
        Tp_Propietario.Estado := 'Traspaso';
        Tp_Propietario.Transito:= SYSTEM.Pkg_Utilitario.Ft_Registrar_Transito(Ln_Index.Transito);
        
             Tp_Lista_Propietario.EXTEND;
             Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
            EXCEPTION 
                WHEN OTHERS THEN
                    Tp_Error.Id_Error:=sqlerrm;
                    Tp_Error.Nombre_Error:=ln_index.Nro_Placa||';'||Dbms_Utility.Format_Error_Backtrace;
                    Tp_Lista_Error.EXTEND;
                    Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                    CONTINUE;
        END;
        lb_Existe:=TRUE;
    END LOOP; 
  END IF;  
    
        RETURN lb_Existe;

END Ft_Historiales_Traspaso;

FUNCTION ft_solo_propietario (av_nro_placa VARCHAR) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_solo_propietario
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_nro_placa
Variables  :lb_Existe, lcur_prop
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/05/2018  Blados.Ospina   1.0                     */

lb_Existe Boolean:=False;

Cursor lcur_prop Is Select Distinct sp.Nro_Placa As Nro_Placa, sp.Id_Documento As documento, sp.Id_Usuario As  Usuario,
                                    sp.porcentaje_prop As Porcentaje, fmd.municipio As Transito 
                    From bd_transitos.st_propietarios sp
                    Inner join bd_transitos.st_maestro sm On sm.id_radicado = sp.id_radicado
                    Inner Join bd_fiscalizacion.fc_municipio_departamento fmd On fmd.divipo = sm.id_secretaria
                    Where sp.nro_placa = av_nro_placa;


Begin
    For ln_index In lcur_prop Loop
          Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
          Tp_Propietario.Id_Documento_Propietario := Ln_Index.documento;
          Tp_Propietario.Id_Propieario := Ln_Index.usuario; 
          Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
          Tp_Propietario.Transito := Ln_Index.Transito;
          Tp_Propietario.Estado := 'Propietarios, no registra tramite';
          
           Tp_Lista_Propietario.Extend;
           Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
          
          lb_Existe:= True;
    End Loop;
  
    
    Return lb_Existe;
    
End ft_solo_propietario;

FUNCTION ft_radica_matricul_ini (av_placa VARCHAR,as_id_novedad SIMPLE_INTEGER) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_radica_matricul_ini
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                            */

lb_Existe Boolean:=FALSE;

CURSOR lcur_radi_Maricula(ad_fecha DATE) IS SELECT DISTINCT St.Nro_Placa,Sp.Porcentaje_Prop AS Porcentaje, 
                          To_Date(CASE 
                               WHEN LENGTH(St.Fecha_Tramite) = 8 THEN
                                    St.Fecha_Tramite
                               WHEN LENGTH(St.Fecha_Tramite) > 8 THEN
                                  Substr(St.Fecha_Tramite,1,8)
                                WHEN LENGTH(St.Fecha_Tramite) = 7 THEN
                                  '0'||St.Fecha_Tramite
                              ELSE NULL END) AS Fecha_Tramite,
                                  --St.Id_Radicado As Transito_Tramite, 
                                  fmd.municipio AS Transito, 
                                  Sp.Id_Documento AS Documento, Sp.Id_Usuario AS Usuario
                          FROM Bd_Transitos.St_Tramites St
                          INNER JOIN Bd_Transitos.St_Propietarios Sp ON Sp.Nro_Placa = St.Nro_Placa
                          INNER JOIN Bd_Transitos.St_Maestro St1 ON St1.id_radicado = St.Id_Radicado
                          INNER JOIN Bd_Transitos.St_Maestro St2 ON St2.id_radicado =  Sp.Id_Radicado
                          INNER JOIN Bd_fiscalizacion.fc_municipio_departamento fmd ON fmd.divipo = st1.id_secretaria 
                          WHERE St.Nro_Placa = av_placa  And Id_Tramite = as_id_novedad AND st1.id_secretaria = st2.id_secretaria
                          AND TO_DATE(Decode(LENGTH(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) = ad_fecha;
BEGIN
   
        IF SYSTEM.Pkg_Utilitario.ft_Existe_Registro (av_placa,as_id_novedad) = TRUE THEN
                    
                FOR Ln_Index IN lcur_radi_Maricula(SYSTEM.Pkg_Utilitario.ft_Fecha_Maxima (av_Placa,as_id_novedad )) LOOP
                     Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
                     Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
                     Tp_Propietario.fecha := Ln_Index.Fecha_Tramite;
                     Tp_Propietario.Transito := Ln_Index.Transito;
                     Tp_Propietario.Id_Documento_Propietario := Ln_Index.documento;
                     Tp_Propietario.Id_Propieario := Ln_Index.usuario;
                     IF  as_id_novedad = 10 THEN
                        Tp_Propietario.Estado := 'Radicacion';
                     ELSE
                        Tp_Propietario.Estado := 'Matricula Inicial';
                     END IF;
                     
                     Tp_Lista_Propietario.EXTEND;
                     Tp_Lista_Propietario(Tp_Lista_Propietario.COUNT()):=Tp_Propietario;
                     
                    lb_Existe:= TRUE;
                END LOOP;
        END IF;
        
     RETURN lb_Existe;
     
END Ft_Radica_Matricul_Ini;

PROCEDURE Sp_Consultar_Propietarios_Tto AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Tto
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :
Variables  :lv_Name_File, v_prop, lcur_placas
Variables  :lb_Ingresado, lv_Resultado, tp_Placa
Variables  :lb_Existe
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera las placas a procesar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_Name_File VARCHAR2(255 byte):='Propietarios Tto'||' '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_prop UTL_FILE.FILE_TYPE;
ltul_read UTL_FILE.FILE_TYPE; 
lv_placa VARCHAR2(20); 

lb_Ingresado Boolean;
lv_Resultado VARCHAR2(1 BYTE);

lb_Existe Boolean:=FALSE;

BEGIN
  ltul_read := UTL_FILE.FOPEN('DATA_LOAD_FISCA','placas.csv','R');	
    LOOP
       BEGIN
        UTL_FILE.GET_LINE(ltul_read,lv_placa); 
        lb_Ingresado := FALSE;
            sp_reset_tp_propietario;
                        
                        --Valido si tiene traspaso
                        lb_Ingresado := Ft_Historiales_Traspaso(lv_placa);
                        
                        iexception:=2;
                        --Radicacion
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado :=Ft_Radica_Matricul_Ini(lv_placa,is_Novedad_Radicacion);
                        END IF;
                        
                        --Matricula Inicial
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado :=Ft_Radica_Matricul_Ini(lv_placa,is_Novedad_Matricula);
                        END IF;
                        
                        --Solo Propietario
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado:= ft_solo_propietario(lv_placa);
                        END IF;
                        
                        IF lb_Ingresado = FALSE THEN
                              Tp_Propietario.Nro_Placa:= lv_placa;
                              Tp_Propietario.Estado := 'No hay informacion';
          
                              Tp_Lista_Propietario.EXTEND;
                              Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
                        END IF; 
              EXCEPTION
              WHEN No_Data_Found THEN EXIT; 
              WHEN OTHERS THEN
                    IF iexception = 0 THEN
                        sp_historiales_traspaso_2(lv_placa);
                    ELSE
                          Tp_Error.Id_Error:='Error_Placa'||';';
                          Tp_Error.Nombre_Error:=lv_placa;
                          Tp_Lista_Error.Extend;
                          Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;
                    END IF;    
        END;
    END LOOP;
          UTL_FILE.FCLOSE(ltul_read); 
        
    If Tp_Lista_Propietario.COUNT()>0 THEN
      v_prop:= UTL_FILE.FOPEN('DATA_FISCA',lv_Name_File,'W');
            FOR Ln_Index IN 1..Tp_Lista_Propietario.COUNT() LOOP
                    IF lb_Existe = FALSE THEN
                        UTL_FILE.PUT_LINE(v_prop,'NRO_PLACA;'||'TIPO_DOCUMENTO_VENDEDOR;'||'ID_VENDECOR;'||
                                                         'TIPO_DOCUMENTO_COMPRADOR;'||'ID_COMPRADOR;'||'PORCENTAJE;'||'FECHA;'||
                                                         'TRANSITO;'||'ID_DOCUMENTO_PROPIETARIO;'||'ID_PROPIETARIOS;'||'ESTADO');
                        lb_Existe:=TRUE;
                    END IF;
                        UTL_FILE.PUT_LINE(v_prop,Tp_Lista_Propietario(Ln_Index).Nro_placa||';'
                        ||Tp_Lista_Propietario(Ln_Index).Tipo_Documento_Vendedor||';'||Tp_Lista_Propietario(Ln_Index).Id_Vendedor||';'
                        ||Tp_Lista_Propietario(Ln_Index).Tipo_Documento_Comprador||';'||Tp_Lista_Propietario(Ln_Index).Id_Comprador||';'
                        ||Tp_Lista_Propietario(Ln_Index).Porcentaje||';'||Tp_Lista_Propietario(Ln_Index).Fecha||';'
                        ||Tp_Lista_Propietario(Ln_Index).Transito||';'||Tp_Lista_Propietario(Ln_Index).Id_Documento_Propietario||';'
                        ||Tp_Lista_Propietario(ln_index).Id_Propieario||';'||Tp_Lista_Propietario(ln_index).estado);
                          
            END LOOP;
           UTL_FILE.FCLOSE(v_prop); 
         
    END IF;
        Sp_Exception('Propietarios Tto');
    
END Sp_Consultar_Propietarios_Tto;

PROCEDURE sp_iniciar(av_vigencia NUMBER) AS

/*ISVA
Nombre     :sp_iniciar
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :
Variables  :in_vigencia
Variables  :
Retorno    :             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Inicia el proceso 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

BEGIN
    in_vigencia:='01/01/'||av_vigencia;
    Sp_Consultar_Propietarios_Tto;

END sp_iniciar;

END PKG_HISTORIALES_TRASPASOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_INCONSISTENCIA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_INCONSISTENCIA" AS

lsi_existe simple_integer:=0;
lb_existe BOOLEAN:=FALSE;

FUNCTION FT_validar_linea (av_NRO_PLACA VARCHAR2)   RETURN boolean IS
BEGIN 

lb_existe:=FALSE;

    SELECT COUNT(1) INTO lsi_existe FROM LIC_TTO
    WHERE Nro_placa =  av_NRO_PLACA AND id_linea IS NULL;
      
          IF lsi_existe >0  THEN 
              lb_existe:=TRUE;
        
          END IF;
        
    RETURN lb_existe;
      
   
END FT_validar_linea; 

FUNCTION FT_validar_modelo (av_NRO_PLACA VARCHAR2)   RETURN boolean IS
BEGIN 

lb_existe:=FALSE;

    SELECT COUNT(1) INTO lsi_existe FROM LIC_TTO
    WHERE Nro_placa =  av_NRO_PLACA AND (modelo IS NULL or LENGTH(MODELO)<>4);
      
          IF lsi_existe >0  THEN 
              lb_existe:=TRUE;
        
          END IF;
        
    RETURN lb_existe;
      
   
END FT_validar_modelo ; 

FUNCTION FT_validar_cilindraje (av_NRO_PLACA VARCHAR2)   RETURN boolean IS
BEGIN 

lb_existe:=FALSE;

    SELECT COUNT(1) INTO lsi_existe FROM LIC_TTO
    WHERE Nro_placa =  av_NRO_PLACA AND ( CILINDRAJE IS NULL OR CILINDRAJE<>0);
      
          IF lsi_existe > 0  THEN 
              lb_existe:=TRUE;
        
          END IF;
        
    RETURN lb_existe;
      
   
END FT_validar_cilindraje ; 

FUNCTION FT_validar_propietario (av_NRO_PLACA VARCHAR2)   RETURN boolean IS
BEGIN 

lb_existe:=FALSE;

        Select Count(1)  INTO lsi_existe From quipux.lic_tto lt
        Inner Join quipux.propietarios_vehiculo Pv On Pv.Nro_placa = Lt.Nro_placa
        Inner Join quipux.usuarios_tto Us On Us.Id_Usuario = Pv.Id_Usuario
        Where pv.nro_placa = 'IHT072' And (pv.porcentaje_prop < 100
        Or (length(us.direccion)< 8 Or us.direccion is null) Or (us.fecha_nacimiento > '31/12/1999' or us.fecha_nacimiento is null));
              
          IF lsi_existe > 0  THEN 
              lb_existe:=TRUE;
        
          END IF;
        
    RETURN lb_existe;
      
   
END FT_validar_propietario ;

PROCEDURE SP_INICIAR AS

Cursor lcur_placas Is Select nro_placa From prueba;

Begin


    For Ln_Index In lcur_placas Loop
        
        lb_existe:=FT_validar_linea(ln_index.nro_placa);
            If lb_existe = True Then
                null;
            End If;
        lb_existe:=FT_validar_linea(ln_index.nro_placa);
            If lb_existe = True Then
                null;
            End If;
        lb_existe:=FT_validar_linea(ln_index.nro_placa);
            If lb_existe = True Then
                null;
            End If;
        lb_existe:=FT_validar_linea(ln_index.nro_placa);
            If lb_existe = True Then
                null;
            End If;
    End Loop;
    
/*Select Count(1) From quipux.lic_tto lt
Inner Join quipux.propietarios_vehiculo Pv On Pv.Nro_placa = Lt.Nro_placa
Inner Join quipux.usuarios_tto Us On Us.Id_Usuario = Pv.Id_Usuario
Where pv.nro_placa = 'IHT072' And (pv.porcentaje_prop < 100
Or (length(us.direccion)< 8 Or us.direccion is null) Or (us.fecha_nacimiento > '31/12/1999' or us.fecha_nacimiento is null));

Select Count(1) From quipux.lic_tto lt
Inner Join quipux.propietarios_vehiculo Pv On Pv.Nro_placa = Lt.Nro_placa
Inner Join quipux.usuarios_tto Us On Us.Id_Usuario = Pv.Id_Usuario
Where pv.nro_placa = 'IHT072'; */

END SP_INICIAR;

END PKG_INCONSISTENCIA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_LUI
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_LUI" AS

Procedure Sp_Generar_archivos (av_marca varchar) As

lv_Name_File_Error Varchar2(255 byte):=av_marca||'.csv';

Dato UTL_FILE.FILE_TYPE;
Cursor lcur_marca Is Select Distinct * From fc_vehiculos Where Nombre_Marca = av_marca;

Begin
    Dato:= UTL_FILE.FOPEN('DIR_OMISOS',lv_Name_File_Error,'W');
         For ln_index In lcur_marca Loop
                Begin
                 UTL_FILE.PUT_LINE(Dato,ln_index.NRO_PLACA||';'||ln_index.MODELO||';'
                                        ||ln_index.ID_MARCA||';'
                                        ||ln_index.NOMBRE_MARCA||';'
                                        ||ln_index.ID_LINEA||';'
                                        ||ln_index.NOMBRE_LINEA||';'
                                        ||ln_index.ID_SERVICIO||';'
                                        ||ln_index.NOMBRE_SERVICIO||';'
                                        ||ln_index.ID_CLASE||';'
                                        ||ln_index.NOMBRE_CLASE||';'
                                        ||ln_index.ID_CARROCERIA||';'
                                        ||ln_index.NOMBRE_CARROCERIA||';'
                                        ||ln_index.GRUPO||';'
                                        ||ln_index.ID_CILINDRAJE||';'
                                        ||ln_index.CILINDRAJE||';'
                                        ||ln_index.TIPO_CARGA||';'
                                        ||ln_index.TIPO_CAJA||';'
                                        ||ln_index.N_PUERTAS||';'
                                        ||ln_index.COMBUSTION_TRACCION||';'
                                        ||ln_index.ID_CAPACIDAD||';'
                                        ||ln_index.CAPACIDAD||';'
                                        ||ln_index.AVALUO||';'
                                        ||ln_index.VALOR_FACTURA||';');
                      Exception
                    When Others Then
                    Continue; 
            End;
         End Loop;
      
End Sp_Generar_archivos;

PROCEDURE sp_iniciar AS

Cursor lcur_marcas Is Select Distinct Nombre_Marca From fc_vehiculos Where Marcado_Archivo is null and Nombre_Marca is not null
                      Order By 1 Asc;
nombre Varchar2(255);
BEGIN
    For ln_index In lcur_marcas Loop
        Begin
           nombre:= Replace(ln_index.Nombre_Marca,'/','%');
           Sp_Generar_archivos(nombre);
            Exception
                When Others Then
                    Continue;
        End;
    End Loop;
END sp_iniciar;

END PKG_LUI;

/
--------------------------------------------------------
--  DDL for Package Body PKG_TRANZABILIDAD_NOVEDAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_TRANZABILIDAD_NOVEDAD" AS

FUNCTION SP_EJEMPLO (Placa Varchar,Fecha Date,Id_Novedad Number, Codigo_Novedad Number)Return Boolean
As

Cursor C1 Is Select To_Number(Id_Tramite) As Codigo_Tramite, 
                To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) as Fecha From Bd_Transitos.St_Tramites
                     Where Nro_placa = Placa 
                        And To_Date(Decode(Length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite))> Fecha
                            Order By 2,1 Desc;
                            

Type tblNov is Table Of C1%RowType;
arrayNov tblNov;
Begin
 Open C1;
    Loop Fetch C1
        Bulk Collect into ArrayNov Limit 100;
            For Ln_Index In 1..ArrayNov.Count() Loop 
                    
                    
                Case
                    --Validar Cancelacion y rematricula
                When Codigo_Novedad = 20 then
                
                    If ArrayNov(Ln_Index).Codigo_Tramite = 13 Then
                             Return False;
                    Else
                             Return True;
                    End If;
                
                
                        
                Else
                 return Null;
                        
                End Case; 
                  
            End Loop;
        Exit When ArrayNov.Count()<=0;
    End Loop;
Close C1;
END SP_EJEMPLO;
END PKG_TRANZABILIDAD_NOVEDAD;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_CARACTERISTICAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_VALIDAR_CARACTERISTICAS" AS
nVigencia Number;
FUNCTION Ft_Validar_Caracteristicas (vPlaca Varchar,nId_Novedad Number) Return Number
As
nCantidad_Registro Number:=0;
    Begin
     Case
      When nId_Novedad = 1 Then --Matricula Inicial
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca And To_Char(Fecha_Matricula,'yyyy') > nVigencia
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp 
                                        Where Rp.Nro_Placa = vPlaca And Rp.Id_Novedad in (4,6,8));  
      When nId_Novedad = 2 Then --Cilindraje Inferior
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca And Fv.Cilindraje < 126;
        
      When nId_Novedad = 3 Then --Vehiculo de Servicio Publico
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Servicio = '02' 
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp
                                        Where Rp.Nro_Placa = vPlaca); 
      When nId_Novedad = 4 Then --Vehiculo Excento
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Clase In (11,12,13);
        
      When nId_Novedad = 5 Then --Vehiculo Registrado en Otro Departamento
        Select Count(1) Into nCantidad_Registro
        From Fc_Vehiculos Fv
        Where Fv.Nro_Placa = vPlaca and Id_Municipio != '05'
        and Fv.Nro_Placa not in (Select Rp.Nro_placa 
                                    From Fc_Reporte_Novedades Rp 
                                        Where Rp.Nro_Placa = vPlaca);      
     Else
            Null;                              
     End Case;  
     
           If nCantidad_Registro > 0 Then
                Return 1; --Retorna si encuantra una de las caracteristicas 
           Else
                Return 0;
           End If;      

END Ft_Validar_Caracteristicas;

PROCEDURE SP_EJECUTAR_OMISOS(Vigencia Number)
As
nValidador Number;
nNro_placa Varchar2 (255 Byte):='RII47A';
Begin
nVigencia:=Vigencia;



END SP_EJECUTAR_OMISOS;
END PKG_VALIDAR_CARACTERISTICAS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_DIRECCION_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_VALIDAR_DIRECCION_RUNT" AS 

FUNCTION FT_VALIDAR_DEPARTAMENTO (Codigo_Direccion Varchar2) return number
as
Cantidad number:=0;
begin
Select Count(1) into Cantidad From Fc_Municipio_Departamento
where Divipo = Codigo_Direccion;

Return Cantidad;

END FT_VALIDAR_DEPARTAMENTO;

FUNCTION FT_VALIDAR_DIR(lfDireccion varchar2) return number as
lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1);
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnCumple Number:=0;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(lfDireccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
  
  --Permite validar las direcciones con estructura CL 10 1020 o CL 10B 1020
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return 0;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
       lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  

-- Valido que la direcci�n tenga estructura v�lida
Select count(1) into lnCumple
from fc_estructura_Direccion 
where lvEstructura like '%' || Estructura ||'%';

If(lnCumple > 0)then
  Return 1;
else
  Return 0;
end if;

END FT_VALIDAR_DIR;

PROCEDURE SP_VALIDAR_DIR
AS
type Array_Novedades is varray(5) of Varchar2(100 byte);
array Array_Novedades:=Array_Novedades('VRD','KM','FCA','CRG');

Validador boolean;
ln_Contador number:=0;
Posicion_Busqueda number:=0;
Validar_Transito number:=0;
Direccion_Estandarizada Varchar2(100 byte):='';

Mensaje_0 Varchar2 (100 byte) := 'La Direccion Cumple la Estructura';
Mensaje_1 Varchar2 (100 byte) := 'La Direccion No Cumple la Estructura';
Mensaje_2 Varchar2 (100 byte) := 'La Ciudad No Esta Homologada';

--Cursor C1 is Select Id_Interlocutor, Direccion from Fc_Contribuyentes;
Cursor C1 is Select Rowid,Id_Interlocutor, Direccion,Codigo_Runt from Fc_Contribuyentes_1;
Begin
For Ln_Index in C1 Loop
Begin
                              --Se estandariza la direccion 
Direccion_Estandarizada :=Trim(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(Ln_Index.Direccion));
      Validador:=false;
       for i in 1..array.count loop
         --Varifica 
          Posicion_Busqueda := instr(Direccion_Estandarizada,array(i));
             if Posicion_Busqueda > 0 then 
               --Valido que el transito este Homologado
                Validar_Transito:= FT_VALIDAR_DEPARTAMENTO(Ln_Index.Codigo_Runt);
                  if Validar_Transito > 0 then
                      SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_0);
                        Validador := true;
                        Posicion_Busqueda :=0;
                        Validar_Transito:=0;
                  else 
                       SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_2);
                       Validador := true;
                  end if;
             end if;       
       end loop;
    if Validador = false then
          Posicion_Busqueda := Ft_Validar_Dir(Direccion_Estandarizada);          
          if Posicion_Busqueda > 0 then
                Validar_Transito:= FT_VALIDAR_DEPARTAMENTO(Ln_Index.Codigo_Runt);
                if Validar_Transito > 0 then   
                    SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_0);
                else
                    SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_2);
                end if;
           else
              SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_1);            
          end if;
    end if;
if Ln_Contador = 100 then
   Ln_Contador :=0;
   commit;
else
  Ln_Contador := Ln_Contador + 1;
end if;
exception
when others then
Update Fc_Contribuyentes_1 Set Estado = 'Error'
where Id_Interlocutor = Ln_Index.Id_Interlocutor and Rowid = Ln_Index.RowId;   
end;
end Loop;
END SP_VALIDAR_DIR;

PROCEDURE SP_VALIDAR_ESTRUCTURA
AS

type Array_Novedades is varray(5) of Varchar2(100 byte);
array Array_Novedades:=Array_Novedades('VRD','KM','FCA','CRG');
Validador boolean;
ln_Contador number:=0;
Posicion_Busqueda number:=0;
Validar_Transito number:=0;
Direccion_Estandarizada Varchar2(100 byte):='';
Mensaje_0 Varchar2 (100 byte) := 'La Direccion Cumple la Estructura';
Mensaje_1 Varchar2 (100 byte) := 'La Direccion No Cumple la Estructura';
Mensaje_2 Varchar2 (100 byte) := 'La Ciudad No Esta Homologada';

--Cursor C1 is Select Id_Interlocutor, Direccion from Fc_Contribuyentes;
Cursor C1 is Select Rowid,Id_Interlocutor, Direccion,Codigo_Runt from Fc_Contribuyentes_1 Where Estado is null;
Begin
For Ln_Index in C1 Loop
Begin
Direccion_Estandarizada :=Trim(Upper(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(Ln_Index.Direccion)));
      Validador:=false;
       for i in 1..array.count loop
          Posicion_Busqueda := instr(Direccion_Estandarizada,array(i));
             if Posicion_Busqueda > 0 then 
               --Valido que la direccion cumpla la estructura    
                      SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_0);
                        Validador := true;
                        Posicion_Busqueda :=0;
                        Validar_Transito:=0;            
             end if;       
       end loop;
    if Validador = false then
          Posicion_Busqueda := Ft_Validar_Dir(Direccion_Estandarizada);          
          if Posicion_Busqueda > 0 then
                    SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_0);
           else
                    SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada,Ln_Index.Id_Interlocutor,Ln_Index.RowId,Mensaje_1);            
          end if;
    end if;
if Ln_Contador = 100 then
   Ln_Contador :=0;
   commit;
else
  Ln_Contador := Ln_Contador + 1;
end if;
exception
when others then
Update Fc_Contribuyentes_1 Set Estado = 'Error'
where Id_Interlocutor = Ln_Index.Id_Interlocutor and Rowid = Ln_Index.RowId;   
end;
end Loop;

END SP_VALIDAR_ESTRUCTURA;

FUNCTION FT_COUNT_REGISTRO_PVD (Placa VARCHAR2, Usuario VARCHAR2,Documento VARCHAR2) 
RETURN NUMBER
AS
Cantidad_registros Number:=0;

Begin
if Usuario is null and Documento is null and placa is not null then 
    Select Count(1) Into Cantidad_registros From Bd_Transitos.St_Tramites
    where Nro_Placa = Placa;
    Return Cantidad_registros;
Else
    Select Count(1) Into Cantidad_registros From Bd_Transitos.St_Contribuyentes Sc
    where Sc.Id_Usuario = Usuario and Sc.Id_Documento = Documento;   
    Return Cantidad_registros;
end if;
END FT_COUNT_REGISTRO_PVD;

PROCEDURE SP_ACTUALIZAR_ESTADO_PVD (Direccion_Estandarizada Varchar2,Usuario Varchar2, CodigoRowId Varchar2, Mensaje Varchar2)
AS

BEGIN

    Update Fc_Contribuyentes_1 Set Direccion = Direccion_Estandarizada, Estado = Mensaje
    where Id_Interlocutor = Usuario and RowId = CodigoRowId;
    
Exception
When Others Then 
Update Fc_Contribuyentes_1 Set Direccion = Direccion_Estandarizada, Estado = 'Error Al Actualizar SP_ACTUALIZAR_ESTADO_PVD'
    where Id_Interlocutor = Usuario and RowId = CodigoRowId;
END SP_ACTUALIZAR_ESTADO_PVD;

PROCEDURE SP_ACTUALIZAR_CIUDAD_DEPART (Nombres_Tmp Varchar2, Usuario Varchar2, T_Documento Varchar2, Codigo Varchar2,Direccion_tmp Varchar2)
AS
Departamento_Tmp Varchar2 (100 byte);
Municipio_Tmp Varchar2 (100 byte);
BEGIN
Select Rt.Departamento,Rt.Ciudad  into Departamento_Tmp, Municipio_Tmp  from Correccion_Datos.Runt_Organismos_Tto Rt
where Rt.Divipo = Codigo and Rownum <=1;

    Update Fc_Contribuyentes Fc Set  Fc.Nombres = Nombres_Tmp, Fc.Direccion = Direccion_Tmp, 
                                     Fc.Departamento =  Departamento_Tmp, Fc.Municipio = Municipio_Tmp,Fc.Id_Departamento = Codigo,
                                     fc.Estado = 'S' -- Se actualizo correctamento
    where Fc.Id_Usuario = Usuario and Fc.Id_Documento = T_Documento;   
Exception
when Others Then
Update Fc_Contribuyentes Fc Set Fc.Nombres = Nombres_Tmp, Fc.Direccion = Direccion_Tmp, Fc.Estado = 'Ciudad no esta Homologada',
                                Fc.Id_Departamento = Codigo
where Fc.Id_Usuario = Usuario and Fc.Id_Documento = T_Documento;   

END SP_ACTUALIZAR_CIUDAD_DEPART;

PROCEDURE SP_DIRECCION_RUNT
AS
Ln_Cantidad number:=0;
Ln_Contador number:=0;

Cursor C1 is Select /*Nro_Placa,*/ Id_Usuario, RowId From Prueba where Estado = 'P';

Begin
For Ln_Index in C1 Loop
Begin
Select Count(1) Into Ln_Cantidad From Fc_Usuarios_Runt
where /*Nro_Placa = Ln_Index.Nro_Placa and*/ Id_Usuario = Ln_Index.Id_Usuario;

/*if Ln_Cantidad > 0 then
      Insert Into Fc_Contribuyentes_1 (Nro_Placa,Id_Interlocutor,Nombres,Direccion,Departamento, Municipio)
      Select Distinct Fc.Nro_Placa, Fc.Id_Usuario, Fc.Nombres, Fc.Direccion, Fc.Departamento, Fc.Municipio  From Fc_Usuarios_Runt Fc
      where Fc.Nro_Placa = Ln_Index.Nro_Placa and Fc.Id_Usuario = Ln_Index.Id_Usuario; */  
      Select Count(1) Into Ln_Cantidad From Fc_Usuarios_Runt
      where Id_Usuario = Ln_Index.Id_Usuario;
          if Ln_Cantidad > 0 then    
              Insert Into Fc_Contribuyentes_1 (Nro_Placa,Id_Interlocutor,Nombres,Direccion,Departamento, Municipio)
              Select Distinct Fc.Nro_Placa, Fc.Id_Usuario, Fc.Nombres, Fc.Direccion, Fc.Departamento, Fc.Municipio From Fc_Usuarios_Runt Fc
              where Id_Usuario = Ln_Index.Id_Usuario;
              
               Update Prueba Set Estado = 'S'
               where Id_Usuario = Ln_Index.Id_Usuario;
          else
              Insert Into Fc_Contribuyentes_1 (Nro_Placa,Id_Interlocutor,Estado)
              Select P.Nro_Placa, P.Id_Usuario,'No info en la base datos Runt' From Prueba P
              where P.Id_Usuario = Ln_Index.Id_Usuario;
              
               Update Prueba Set Estado = 'F'
               where Id_Usuario = Ln_Index.Id_Usuario;
          end if;
 if Ln_Contador = 100 then 
    Ln_Contador := 0;
    Commit;
 else 
  Ln_Contador := Ln_Contador+1;
End if;
Exception 
When Others Then 
Update Prueba P Set P.Estado = 'E'
where P.Id_Usuario = Ln_Index.Id_Usuario and RowId = Ln_Index.RowId;
End;
end Loop;

END SP_DIRECCION_RUNT;

END PKG_VALIDAR_DIRECCION_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_PERSONA_INDETER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_FISCALIZACION"."PKG_VALIDAR_PERSONA_INDETER" AS

PROCEDURE Sp_Validar_Traspaso_Indeter
As 
Validador Boolean;
Ln_Contador Number:=0;
Cursor C1 is Select Id_Usuario_Nuevo,RowId From Fc_Busqueda_Propietarios_Temp;
Begin
For Ln_Index In C1 Loop
Begin
    Validador:= Ft_Validar_Persona_Inde(Ln_Index.Id_Usuario_Nuevo);
   
   If Validador = True Then  
      
      Update Fc_Busqueda_Propietarios_Temp Set Estado = 'I'
      Where Id_Usuario_Nuevo = Ln_Index.Id_Usuario_Nuevo And RowId = Ln_Index.RowId;
   Else
      Update Fc_Busqueda_Propietarios_Temp Set Estado = 'S'
      Where Id_Usuario_Nuevo = Ln_Index.Id_Usuario_Nuevo And RowId = Ln_Index.RowId;
   End If;

Exception
When Others Then 
Continue;
End;
If Ln_Contador = 100 Then
   Ln_Contador:=0;
   Commit;
Else
    Ln_Contador := Ln_Contador + 1;
End If;
End Loop;
END Sp_Validar_Traspaso_Indeter;
--Validad Si La Cedula Pertenece a Persona Indeterminada
Function Ft_Validar_Persona_Inde(CC_Usuario Varchar2/*,Documento Varchar2*/)
Return Boolean
Is

Cantidad Number:=0;
Cursor C1 Is Select Distinct  Nombres,Apellidos
                              From  Bd_Transitos.St_Contribuyentes 
                              Where Id_Usuario = CC_Usuario;-- And Id_Documento = Documento;
Begin
For Ln_Index in C1 Loop
    Cantidad:=instr(Upper(Ln_Index.Nombres||Ln_Index.Apellidos),'INDETER');    
    If Cantidad = 0 Then
       --No es Persona Indeterminada
        Return False;
        Exit;
    Else
        --Retorna 1 si es persona indeterminada
        Return True;
    End If;
End Loop;
END Ft_Validar_Persona_Inde;

END PKG_VALIDAR_PERSONA_INDETER;

/
--------------------------------------------------------
--  DDL for Function FECHA_CON_PARAMETROS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FECHA_CON_PARAMETROS" (Placa Varchar2, Tramite Varchar2,Vigencia date)
Return Date
As
Fecha Date:=null;
Begin
Case
  when Tramite = 20 then
  Select Max(To_Date(decode(length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite))) 
    into Fecha from Bd_Transitos.St_Tramites
  where To_Date(decode(length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite)) < Vigencia--fecha para validad la novedad sea igual o mayor a la fecha
  and Nro_Placa = Placa and Id_Tramite = Tramite;
  Return Fecha;
  When Tramite = 16  and Vigencia is null then
          Select Max(To_Date(decode(length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite))) into Fecha
          FROM Bd_Transitos.St_Tramites 
          where nro_Placa = Placa And Id_tramite = Tramite;
          Return Fecha;
   When Tramite = 9  and Vigencia is null then
          Select Max(To_Date(decode(length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite))) into Fecha
          FROM Bd_Transitos.St_Tramites 
          where nro_Placa = Placa And Id_tramite = Tramite;
          Return Fecha;
  When Tramite = 65  and Vigencia is null then
          Select Max(To_Date(decode(length(Fecha_Tramite),7,'0'||Fecha_Tramite,Fecha_Tramite))) into Fecha
          FROM Bd_Transitos.St_Tramites 
          where nro_Placa = Placa And Id_tramite = Tramite;
          Return Fecha;
        else
        Return Fecha;
  end case;
End;

/
--------------------------------------------------------
--  DDL for Function FECHA_MAXIMA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FECHA_MAXIMA" (Placa Varchar2)
RETURN VARCHAR2 AS 
lv_Fecha Varchar2(10 byte);
BEGIN
 Select 
        Case Length(Fecha_tramite)
            When 7 Then
               '0'||Fecha_tramite 
            Else
                Fecha_tramite
            End Into lv_Fecha  From Bd_Transitos.St_Tramites 
        Where Nro_Placa = 'HRS15C' And Id_Tramite =9;
  Return lv_Fecha;
END FECHA_MAXIMA;

/
--------------------------------------------------------
--  DDL for Function FT_CANTIDAD_DE_REGISTROS
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FT_CANTIDAD_DE_REGISTROS" (Placa Varchar2, Tramite Varchar2)
Return Number
as
Fecha_Inferior date:='01/01/2013';
Cantidad_Registro Number (4,0):=0;
Begin
case
when Tramite = 20 then
    Select Distinct Count(1) into Cantidad_Registro
    From Bd_Transitos.St_Tramites St
    where St.Nro_Placa = Placa and Fecha_Tramite =(Select Max(To_Date(Fecha_Tramite)) from Bd_Transitos.St_Tramites
                                                   where To_Date(Fecha_tramite) < Fecha_Inferior--fecha para validad la novedad sea igual o mayor a la fecha
                                                                                and Nro_Placa = Placa and Id_Tramite = Tramite)
    and St.Id_radicado = (Select Max(Id_radicado) from Bd_Transitos.St_Tramites
                          where Nro_Placa = Placa and Id_Tramite = Tramite);

Return (Cantidad_Registro);
else
Return (Cantidad_Registro);
end case;
End;

/
--------------------------------------------------------
--  DDL for Function FT_CONVERTIR_FECHA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FT_CONVERTIR_FECHA" (nFecha Number)  Return  Date AS 

dFecha_Tramite Date:='01/01/29';
Begin 
    case
     When Length(nFecha)= 8 Then
        dFecha_Tramite := To_Date(nFecha);
                Return dFecha_Tramite;
     When Length(nFecha)= 7 Then
        dFecha_Tramite := To_Date('0'||nFecha);
                Return dFecha_Tramite;
    Else 
        Return '01/01/29';
    End Case;
END FT_CONVERTIR_FECHA;

/
--------------------------------------------------------
--  DDL for Function FT_MAX_RADICADO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FT_MAX_RADICADO" (Placa Varchar2, Tramite Varchar2)
Return Varchar
as
Radicado Varchar2(100 byte);
Begin
Select Max(Id_radicado) into Radicado  from Bd_Transitos.St_Tramites
where Nro_Placa = Placa and Id_Tramite = Tramite;
Return (Radicado);
end;

/
--------------------------------------------------------
--  DDL for Function FT_MAX_RADICADO_PBF
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FT_MAX_RADICADO_PBF" (Placa Varchar2, Tramite Varchar2, Tramite_2 varchar2)
Return Varchar
as
Radicado Varchar2(100 byte);
Begin
Select Max(Id_radicado) Into Radicado  from Bd_Transitos.St_Tramites St
Where St.Nro_Placa = Placa  and St.Id_tramite  in (Tramite,Tramite_2);
Return Radicado;
end;

/
--------------------------------------------------------
--  DDL for Function FT_OBTENER_TRANSITO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_FISCALIZACION"."FT_OBTENER_TRANSITO" (Placa Varchar2)
Return Varchar2 
as
Transito Varchar2(100 byte);
BEGIN

Select Id_radicado into Transito From Bd_Transitos.St_Tramites
where Fecha_Tramite = Fecha_Maxima(Placa);
Return Transito;
END FT_OBTENER_TRANSITO;

/
