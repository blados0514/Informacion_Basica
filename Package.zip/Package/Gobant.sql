--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SP_RAIZ_DIGITAL
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "GOBERNACION_ANTIOQUIA"."SP_RAIZ_DIGITAL" (in_numero number) AS 
ln_longitud  number  :=0;
ln_carater   number  :=0;
ln_Resultado number :=0;
lv_Cadena    varchar2(255);

BEGIN

lv_Cadena := to_char(in_numero);

While length(lv_Cadena) != 1 loop

ln_longitud := length(lv_Cadena);
    for ln_index in 1 .. ln_longitud loop
        ln_carater := To_number(substr(lv_Cadena,ln_index,1));
        ln_Resultado := ln_Resultado +  ln_carater;  
    End loop;
    lv_Cadena := to_char(ln_resultado);
    ln_Resultado := 0;
End loop;

 ln_Resultado := to_number(lv_Cadena);
 DBMS_OUTPUT.put_line ('Ra�z digital: ' || ln_Resultado);
 
END SP_RAIZ_DIGITAL;

/
--------------------------------------------------------
--  DDL for Procedure SP_SERGIO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "GOBERNACION_ANTIOQUIA"."SP_SERGIO" (in_numero number) AS 
ln_longitud number  :=0;
ln_carater number  :=0;
ln_Resultado number :=0;
lv_Cadena    varchar2(255);

BEGIN

lv_Cadena := to_char(in_numero);

While length(lv_Cadena) != 1
loop
ln_longitud := length(lv_Cadena);
    for ln_index in 1 .. ln_longitud loop
        ln_carater := To_number(substr(lv_Cadena,ln_index,1));
        ln_Resultado := ln_Resultado +  ln_carater;  
    End loop;
    lv_Cadena := to_char(ln_resultado);
    ln_Resultado := 0;
End loop;
 ln_Resultado := to_number(lv_Cadena);
 DBMS_OUTPUT.put_line ('Ra�z digital: ' || ln_Resultado);
END SP_SERGIO;

/
--------------------------------------------------------
--  DDL for Package PKG_FECHAS_VALIDACION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "GOBERNACION_ANTIOQUIA"."PKG_FECHAS_VALIDACION" AS 

  Procedure Sp_Iniciar;

END PKG_FECHAS_VALIDACION;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_PA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "GOBERNACION_ANTIOQUIA"."PKG_VALIDACION_PA" AS 
PROCEDURE SP_INICIAR;
Procedure Sp_Resultado;
--Procedure Sp_GEDOC;
Procedure sp_entra_tarde;
Procedure sp_prueba_regla_novedades2(iv_placa varchar2, in_parametro number);
Procedure SP_CORRER_FISCA_QX;
END PKG_VALIDACION_PA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_FECHAS_VALIDACION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "GOBERNACION_ANTIOQUIA"."PKG_FECHAS_VALIDACION" AS

  in_contador number;    
  lnExiste    number;
  lvFecha     varchar2(10);

  
  Procedure Sp_Commit is
  
  Begin
  in_contador := in_contador +1;
  
  If in_contador = 500 then
    Commit;
    in_contador:=0;
  end if;
  
  End Sp_Commit;
  
    
  PROCEDURE SP_ERROR_FH (iv_placa varchar2,iv_vigencia number, iv_descripcion varchar2, iv_proceso varchar2) is
  
  BEGIN  
      Insert Into Gant_error_validacion_pa
           Values(0,
                  iv_placa,
                  iv_vigencia,
                  iv_descripcion,
                  iv_proceso,                  
                  Sysdate);   
  EXCEPTION 
      WHEN OTHERS THEN
          ROLLBACK;
          Dbms_Output.Put_Line(sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);      
  END SP_ERROR_FH;
  
 
 
  Procedure Sp_Fecha_Pago is
  
  Cursor lcur_Pagos is
  Select Nro_Placa, Vigencia from Gant_Resultado
  Where Pago = 'S';
  
  Begin
  
  For lnIndex in lcur_Pagos Loop
   
      Begin
          lnExiste := 0;
          lvFecha := null;
          
          Select Count(1) Into lnExiste
          From Gant_Reporte_Pagos
          Where Nro_placa = lnIndex.Nro_placa
            And Vigencia = lnIndex.Vigencia;
          
          If lnExiste > 0 Then  
              Select Max(Fecha_Pago) Into lvFecha
              From Gant_Reporte_Pagos
              Where Nro_placa = lnIndex.Nro_placa
                And Vigencia = lnIndex.Vigencia;
                --And Rownum =1; 
          Else
              Select Max(Fecha_Pago) Into lvFecha
              From Gant_Pagos_Qx
              Where Nro_placa = lnIndex.Nro_placa
                And Vigencia = lnIndex.Vigencia;
                --And Rownum =1; 
          End If;
          
          Update Gant_Resultado Set Fecha_Pago = lvFecha
          Where Nro_placa = lnIndex.Nro_placa
            And Vigencia = lnIndex.Vigencia;
            
            Sp_Commit;          
            
      Exception When Others Then  
        Sp_Error_FH (lnIndex.Nro_placa,lnIndex.Vigencia,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_PAGO');
      end;  
  End Loop;  
  
  End Sp_Fecha_Pago;
  
  
  Procedure Sp_Fecha_AutoCierre is
  
  Cursor lcur_FechaAutoCierre is
  Select Nro_Placa, Vigencia 
  From Gant_Resultado
  Where Auto_Cierre = 'S';
  
  Begin
  For lnIndex in lcur_FechaAutoCierre Loop
    Begin
    
        lvFecha := Null;
        
        Select max(Fecha_Crea) Into lvFecha
        From Gant_Auto_Cierre
        Where Nro_placa = lnIndex.Nro_placa
          And Vigencia = lnIndex.Vigencia
           AND Id_Motivo_Cierre in (17,33) -- Pago y terminacion AP
           AND (Anulado IS NULL OR Anulado ='');
           --And Rownum =1; 
           
        Update Gant_Resultado Set Fecha_Auto_Cierre = lvFecha
        Where Nro_placa = lnIndex.Nro_placa
          And Vigencia = lnIndex.Vigencia;
        
        Sp_Commit;
      
    Exception When Others then
    Sp_Error_Fh(lnIndex.Nro_placa, lnIndex.Nro_placa, Sqlerrm || ' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_AUTOCIERRE'); 
    End;
    End Loop;
  End Sp_Fecha_AutoCierre;
  
  

  Procedure Sp_Fecha_AP_Sap is
  
  Cursor lcur_Fecha_Ap_Sap is
  Select Nro_Placa, Vigencia 
  From Gant_Resultado
  Where AP_Sap = 'S';
  
  Begin
  For lnIndex in lcur_Fecha_Ap_Sap Loop
    Begin
    
        lvFecha := Null;
        
        Select max(Fecha_Crea) Into lvFecha
        From Gant_Acuerdo_Pago
        Where Nro_placa = lnIndex.Nro_placa
          And lnIndex.Vigencia Between Desde and Hasta
          And Estado in('03','3','05','5'); -- 5: Terminado, 3: PLan de Pagos         
          --And Rownum =1; 
           
        Update Gant_Resultado Set Fecha_Ap_Sap = lvFecha
        Where Nro_placa = lnIndex.Nro_placa
          And Vigencia = lnIndex.Vigencia;
        
        Sp_Commit;
      
    Exception When Others then
    Sp_Error_Fh(lnIndex.Nro_placa, lnIndex.Nro_placa, Sqlerrm || ' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_AP_SAP'); 
    End;
    End Loop;
  End Sp_Fecha_AP_Sap;
  
  
  Procedure Sp_Fecha_AP_SIAPA is
  
  Cursor lcur_Fecha_Ap_Siapa is
  Select Nro_Placa, Vigencia 
  From Gant_Resultado
  Where AP_SIAPA = 'S';
  
  Begin
   For lnIndex in lcur_Fecha_Ap_Siapa Loop
    Begin
    
        lvFecha := Null;
        
        Select max(Fecha) Into lvFecha
        From gant_acuerdo_pago_siapa
        Where Nro_Placa = lnIndex.Nro_placa
          and Vigencia = lnIndex.Vigencia;       
         -- And Rownum =1; 
           
        Update Gant_Resultado Set Fecha_Ap_SIAPA = lvFecha
        Where Nro_placa = lnIndex.Nro_placa
          And Vigencia = lnIndex.Vigencia;
        
        Sp_Commit;
      
        Exception When Others then
        Sp_Error_Fh(lnIndex.Nro_placa, lnIndex.Nro_placa, Sqlerrm || ' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_AP_SIAPA'); 
        End;
    End Loop;
  End Sp_Fecha_AP_SIAPA;
  
  
  Procedure Sp_Fecha_Indeterminado_Sap is
  
      Cursor lcur_Indeterminado_Sap is
      Select Nro_Placa, Vigencia 
      From Gant_Resultado
      Where Sap_Indeterminado = 'S';
      
  Begin
   
   For lnIndex in lcur_Indeterminado_Sap Loop
   
       Begin
       lvFecha := Null;
       
       Select max(Fecha) Into lvFecha -- Traigo la fecha M�xima
       From Gant_ht_tto
       Where Nro_placa = lnIndex.Nro_placa
         and Id_Comprador in(Select id_usuario -- B�sco solo los que el comprador contenga en su nombre o apellido INDET
                                from Gant_Contribuyentes_tto
                                    where (UPPER(nombres) like '%INDET%' OR uPPER(Apellidos) Like '%INDET%'));
                                
       Update Gant_Resultado Set Fecha_Indet_Sap = lvFecha
       Where Nro_placa = lnIndex.Nro_placa
         And Vigencia = lnIndex.Vigencia;
         
       Sp_Commit;  
                                
       Exception When Others Then
        Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia, Sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_INDETERMINADO_SAP');
       End;   
   End Loop;

  End Sp_Fecha_Indeterminado_Sap;
  
  
  Procedure Sp_Fecha_Indeterminado_Qx is
  
      Cursor lcur_Indeterminado_Qx is
      Select Nro_Placa, Vigencia 
      From Gant_Resultado
      Where Qx_Indeterminado = 'S';
      
  Begin
   
   For lnIndex in lcur_Indeterminado_Qx Loop
   
       Begin
       lvFecha := Null;
       
       Select max(Fecha) Into lvFecha -- Traigo la fecha M�xima
       From Gant_Historiales_Traspaso_Qx
       Where Nro_placa = lnIndex.Nro_placa
         and Id_Comprador in(Select id_usuario -- B�sco solo los que el comprador contenga en su nombre o apellido INDET
                                from Gant_Usuarios_tto_Qx
                                    where (UPPER(nombres) like '%INDET%' OR uPPER(Apellidos) Like '%INDET%'));
                                
       Update Gant_Resultado Set Fecha_Indet_Qx = lvFecha
       Where Nro_placa = lnIndex.Nro_placa
         And Vigencia = lnIndex.Vigencia;
         
       Sp_Commit;  
                                
       Exception When Others Then
        Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia, Sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_INDETERMINADO_QX');
       End;   
   End Loop;

  End Sp_Fecha_Indeterminado_Qx;
  
  
  Procedure Sp_Fecha_MI AS
  
      Cursor lcur_MI is
      Select Nro_Placa, Vigencia 
      From Gant_Resultado
      Where Fecha_Mi_Posterior = 'S';
      
  Begin
    For lnIndex in lcur_MI Loop
        Begin
        lvFecha := null;
        
        Select Fecha_Matricula Into lvFecha
        From Gant_Vehiculos vh
        Where Nro_placa = lnIndex.Nro_placa;        
          
        Update Gant_Resultado Set Fecha_MI = lvFecha
           Where Nro_placa = lnIndex.Nro_placa
             And Vigencia = lnIndex.Vigencia;  
        Sp_Commit;     
  
        Exception When Others Then
            Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia, Sqlerrm ||' '|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_MI');
        End;
    End Loop;

  End Sp_Fecha_MI;
  
  
  Procedure Sp_Fecha_Creacion is
  
      Cursor lcur_FechaCrea is
      Select Nro_Placa, Vigencia 
      From Gant_Resultado
      Where Tarde_BD = 'S';
  
  Begin
  For lnIndex in lcur_FechaCrea Loop
    Begin
        lvFecha :=  null;  
        
        Select Fecha_Creacion into lvFecha
        From Gant_DPSOB
        where Nro_Placa = lnIndex.Nro_placa;
        
        Update Gant_Resultado Set Fecha_Creacion = lvFecha
        Where Nro_placa = lnIndex.Nro_placa
          And Vigencia = lnIndex.Vigencia;  
        Sp_Commit;  
       
    Exception When others Then
    Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia,Sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_CREACION');
    End;
  End Loop;
  End Sp_Fecha_Creacion;


  Procedure Sp_Fecha_entrega_Tcc is
    Cursor lcur_FechaTcc is
      Select Nro_Placa, Vigencia, Identificacion 
      From Gant_Resultado
      Where Traslado_Tcc = 'S';
  Begin
    For lnIndex in lcur_FechaTcc Loop
        
        Begin
            lvFecha := null;
            Select Max(Fecha_Archivo) into lvFecha
            from gant_tcc
            where nro_placa = lnIndex.Nro_placa
              and vigencia = lnIndex.Vigencia
              and identificacion = lnIndex.Identificacion; 
    
            Update Gant_Resultado Set Fecha_Tcc = lvFecha
            Where Nro_placa = lnIndex.Nro_placa
              And Vigencia = lnIndex.Vigencia;  
            Sp_Commit; 
           
        Exception when others then
            Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia,Sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_ENTREGA_TCC');
        End;
    End Loop;
  
  End Sp_Fecha_entrega_Tcc;
  
  Procedure Sp_Fecha_Anula_Nov is
  
    Cursor lcur_FechaAnulaNov is
        Select Nro_Placa, Vigencia, Id_Nov_Anu, Fecha_Nov_Anu 
        From Gant_Resultado
        Where Novedad_Anu = 'S';
  
  Begin
    For lnIndex in lcur_FechaAnulaNov Loop
        Begin
            lvFecha := null;
            Select max(Fecha_Anulacion) into lvFecha
              from Gant_Novedades_V1
             where nro_placa = lnIndex.Nro_placa
               and Id_Novedad = lnIndex.Id_Nov_Anu
               and Fecha_Novedad = lnIndex.Fecha_Nov_Anu; 
           
            Update Gant_Resultado Set Fecha_Anu_nov = lvFecha
            Where Nro_placa = lnIndex.Nro_placa
              And Vigencia = lnIndex.Vigencia;  
            Sp_Commit;            
        
        Exception When others then
            Sp_Error_Fh(lnIndex.Nro_Placa, lnIndex.Vigencia, Sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_FECHA_ANULA_NOV');
        End;
    
    End Loop;
    
  End Sp_Fecha_Anula_Nov ;


  Procedure Sp_Iniciar AS
  BEGIN
    Sp_Fecha_Pago();
    Sp_Fecha_AutoCierre();
    Sp_Fecha_Ap_Sap();
    Sp_Fecha_Ap_SIAPA();
    Sp_Fecha_Indeterminado_Sap();
    Sp_Fecha_Indeterminado_Qx();
    Sp_Fecha_MI();
    Sp_Fecha_Creacion();
    Sp_Fecha_entrega_Tcc();
    Sp_Fecha_Anula_Nov();
    Commit;
  END Sp_Iniciar;

END PKG_FECHAS_VALIDACION;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_PA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "GOBERNACION_ANTIOQUIA"."PKG_VALIDACION_PA" AS

in_commit               NUMBER := 0;  
GN_COMMIT               NUMBER := 0;
GN_VIGENCIA             NUMBER := 0;
GN_NIVEL_RECLAMACION    NUMBER := 0;
GN_NOTIFICAR            NUMBER := 0;
GN_BLOQUE_PROCESO       NUMBER := 0;
GN_VENCE_VIGENCIA       DATE;
GN_MOTIVO_CIERRE        VARCHAR2(20);
GN_INICIO_VIGENCIA      DATE;
in_existe               number :=0;
lv_inactiva             varchar2(30) := 'N'; 
iv_Resultado            varchar2(3) := 'N';

  
  FUNCTION FT_PARAMETROS (in_parametro number) return varchar2 IS
   /*
     @SYNCRONIK - GANT
     @Nombre    : FT_PARAMETROS
     @Autor     : Elvis.Betancur
     @Fecha     : 22/02/2018
     @Parametro : Parametro Busqueda
     @Retorno   : N/A
     @Proyecto  : Validaci�n Partidas abiertas
     @Versi�n   : N/A
     Objetivo   : Retornar los parametros
     ******************************************************************************************
     @control de cambios realizados por desarrolladores
     ******************************************************************************************
     @Autor           @Fecha      @Modificaci�n
     Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
     */  
  lv_retorno varchar2(20);
  BEGIN
  
  Select valor into lv_retorno
  from gant_parametros
  where consecutivo = in_parametro;
  
  return lv_retorno;
  
  END FT_PARAMETROS;
  
  
  
  PROCEDURE SP_CARGARPARAMETROS IS
   /*
     @SYNCRONIK - GANT
     @Nombre    : SP_CARGARPARAMETROS
     @Autor     : Elvis.Betancur
     @Fecha     : 22/02/2018
     @Parametro : N/A
     @Retorno   : N/A
     @Proyecto  : Validaci�n Partidas abiertas
     @Versi�n   : N/A
     Objetivo   : Cargar los parametros
     ******************************************************************************************
     @control de cambios realizados por desarrolladores
     ******************************************************************************************
     @Autor           @Fecha      @Modificaci�n
     Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
     */  
  
  BEGIN
  
  GN_VIGENCIA          := to_number(FT_PARAMETROS(1));  
  GN_NIVEL_RECLAMACION := to_number(FT_PARAMETROS(2));
  GN_COMMIT            := to_number(FT_PARAMETROS(3));
  GN_NOTIFICAR         := to_number(FT_PARAMETROS(4));
  GN_BLOQUE_PROCESO    := to_number(FT_PARAMETROS(5));
  GN_VENCE_VIGENCIA    := to_date  (FT_PARAMETROS(6));
  GN_INICIO_VIGENCIA   := to_date  (FT_PARAMETROS(7));
  --GN_MOTIVO_CIERRE     := FT_PARAMETROS(6);
  
  END SP_CARGARPARAMETROS;
  
  
  PROCEDURE SP_ERROR_PA (iv_placa varchar2,iv_descripcion varchar2, iv_proceso varchar2) is
  
  BEGIN  
      Insert Into Gant_error_validacion_pa
           Values(0,
                  iv_placa,
                  GN_VIGENCIA,
                  iv_descripcion,
                  iv_proceso,                  
                  Sysdate);   
  EXCEPTION 
      WHEN OTHERS THEN
          ROLLBACK;
          Dbms_Output.Put_Line(sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);      
  END SP_ERROR_PA;
  
  PROCEDURE SP_COMMIT IS
    /*
     @SYNCRONIK - GANT
     @Nombre    : SP_COMMIT
     @Autor     : Elvis.Betancur
     @Fecha     : 22/02/2018
     @Parametro : N/A
     @Retorno   : N/A
     @Proyecto  : Validaci�n Partidas abiertas
     @Versi�n   : N/A
     Objetivo   : Confirmar las transacciones
     ******************************************************************************************
     @control de cambios realizados por desarrolladores
     ******************************************************************************************
     @Autor           @Fecha      @Modificaci�n
     Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
     */  
  
  BEGIN
  in_commit := in_commit + 1;  
  IF  in_commit = GN_COMMIT then
        in_commit := 0;
        COMMIT;
  END IF;  
    EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    SP_ERROR_PA ('',sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_COMMIT');
  END SP_COMMIT;
  
/******************************************************************************************
                       V A L I D A C I O N  D E N O V E D A D E S
/******************************************************************************************/ 
  
   FUNCTION FT_NOVEDADES (in_idnovedad varchar2, in_anno number, in_desde number, in_hasta number) return varchar2 as
     /*
    @SYNCRONIK - GANT
    @Nombre    : FT_NOVEDADES
    @Autor     : Elvis.Betancur
    @Fecha     : 22/02/2018
    @Parametro : Nro. Placa - a�o - desde - hasta
    @Retorno   : S/N
    @Proyecto  : Validaci�n Partidas abiertas
    @Versi�n   : N/A
    Objetivo   : Validar las novedades
    ******************************************************************************************
    @control de cambios realizados por desarrolladores
    ******************************************************************************************
    @Autor           @Fecha      @Modificaci�n
    Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
    */ 
    
   BEGIN
   --lv_inactiva := 'N';
   Case
    When in_idnovedad in ('03','07','14') then -- Cancelaci�n - Traslado - Cbio Pa a Pu
       If(GN_VIGENCIA > in_anno) Then
        lv_inactiva := 'S';
       End If;
    When in_idnovedad in ('04','08') Then -- Rematricula - Cbio Pu a Pa
       If(GN_VIGENCIA >= in_anno) Then
        lv_inactiva := 'N';
       End If;
    When in_idnovedad in ('06') Then -- Radicaci�n
       If(GN_VIGENCIA > in_anno) Then
        lv_inactiva := 'N';
       End If;  
    When in_idnovedad in ('09','13') then -- Condonaci�n Con/Sin recuperaci�n
        If(GN_VIGENCIA Between in_desde and in_hasta)then
         lv_inactiva := 'S';
        End if;  
    When in_idnovedad in ('17') then -- Prescripci�n
        If(GN_VIGENCIA = in_anno)then
         lv_inactiva := 'S';
        End if;   --Se comenta porque es el objetivo de la validaci�n  
   Else
    NULL;-- lv_inactiva := 'N';
   End Case;
   Return lv_inactiva;
   
    EXCEPTION WHEN OTHERS THEN
    SP_ERROR_PA ('',sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_NOVEDADES_SAP2');
    Return 'N';
   END FT_NOVEDADES;
   
   
  
    FUNCTION FT_NOVEDADES_SAP (lv_placa varchar2, in_activas number) return varchar2 as
    /*
    @SYNCRONIK - GANT
    @Nombre    : FT_NOVEDADES_SAP
    @Autor     : Elvis.Betancur
    @Fecha     : 22/02/2018
    @Parametro : Nro. Placa - Buscar activas o inactivas
    @Retorno   : S/N
    @Proyecto  : Validaci�n Partidas abiertas
    @Versi�n   : N/A
    Objetivo   : Validar las novedades de SAP
    ******************************************************************************************
    @control de cambios realizados por desarrolladores
    ******************************************************************************************
    @Autor           @Fecha      @Modificaci�n
    Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
    */  
  
  ln_anno       number :=0;  
  ln_anno_desde number :=0;  
  ln_anno_hasta number :=0;
  ln_Contador number :=0;
    
  Cursor lcur_novedades_act is
  select NRO_PLACA, ID_NOVEDAD,FECHA_NOVEDAD,DESDE,HASTA,DESCRIPCION_ACTO, ANULADO 
  from GANT_NOVEDADES_V1 
  where nro_placa = lv_placa
    and nombre_campo = 'CODNOV'  
    and id_novedad != '15'
    and (anulado is null or anulado ='')
  ORDER BY FECHA_NOVEDAD ASC;
  
  Cursor lcur_novedades_inact is
  select NRO_PLACA, ID_NOVEDAD, FECHA_NOVEDAD,DESDE,HASTA,DESCRIPCION_ACTO, ANULADO 
  from GANT_NOVEDADES_V1
  where nro_placa = lv_placa
    and nombre_campo = 'CODNOV'
    and id_novedad != '15'
    and anulado = 'X'
  ORDER BY FECHA_NOVEDAD ASC;
  
  BEGIN
  
  in_existe := 0;
  lv_inactiva := 'N';
  
  if(in_activas = 1)then -- Novedades Activas
  
    For ln_indexnove in lcur_novedades_act loop
    ln_anno := 0;
    ln_anno_desde := 0;
    ln_anno_hasta := 0;
    in_existe := 0;
    
    ln_Contador := ln_Contador +1;
    
    Case        
        When ln_indexnove.ID_NOVEDAD in('09','13') Then -- Condonaci�n con/sin recuperaci�n
            -- Saco el a�o desde y hasta para estas novedades
            ln_anno_desde := extract (year from ln_indexnove.DESDE);
            ln_anno_hasta := extract (year from ln_indexnove.HASTA);
            --Si la fecha desde es el primer dia del a�o se cobra el a�o de la novedad
            If(Concat(extract(day from ln_indexnove.DESDE),extract(month from ln_indexnove.DESDE))!=11) then
                ln_anno_desde:= ln_anno_desde + 1;
            End if;    
        When ln_indexnove.ID_NOVEDAD in('17') Then -- Precripci�n
            ln_anno := extract (year from ln_indexnove.DESDE);
        Else
            ln_anno := extract (year from ln_indexnove.FECHA_NOVEDAD); -- Demas novedades
    End Case;    
    
    IF(ln_indexnove.ID_NOVEDAD = '06')then
       in_existe := 0;
        --Valido si tiene activo el cobreo de la vigencia de la novedad
        Select count(1) into in_existe
        from GANT_NOVEDADES_V1
        where nro_placa = lv_placa
        and nombre_campo = 'LIQ_VIGENCIA'
        and FECHA_NOVEDAD = ln_indexnove.FECHA_NOVEDAD
        and DESCRIPCION_ACTO = ln_indexnove.DESCRIPCION_ACTO
        and (anulado is null or anulado = '');
    
        if (in_existe > 0) then
             ln_anno :=  ln_anno - 1;
        end if;
    End if;
    
    -- Si es a primera interacci�n valido si el vehiculo nace por radicaci�n o cbio pu pa
    If(ln_contador = 1) then
        IF (ln_indexnove.ID_NOVEDAD = '06')then
            If(GN_VIGENCIA <= ln_anno)Then
                lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad;  
                Exit;
            End If;
        ElsIf (ln_indexnove.ID_NOVEDAD = '08') Then
            If(GN_VIGENCIA < ln_anno)Then
                lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad; 
                Exit;
            End If;
        End If;
    End If;   
    
    -- Valido la novedad
    lv_inactiva := ft_novedades(ln_indexnove.ID_NOVEDAD,ln_anno,ln_anno_desde,ln_anno_hasta);
    
    -- Concateno el string para la ultima novedad que inactiva el cobro
    If (lv_inactiva = 'S') Then    
        lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad;    
    End if;
    
    End Loop;
  
  Else  -- Novedades Inactivas
  
 for ln_indexnove in lcur_novedades_inact loop
    ln_anno := 0;
    ln_anno_desde := 0;
    ln_anno_hasta := 0;
    in_existe := 0;
    
    ln_Contador := ln_Contador +1;
    
    Case        
        When ln_indexnove.ID_NOVEDAD in('09','13') Then -- Condonaci�n con/sin recuperaci�n
            -- Saco el a�o desde y hasta para estas novedades
            ln_anno_desde := extract (year from ln_indexnove.DESDE);
            ln_anno_hasta := extract (year from ln_indexnove.HASTA);
            --Si la fecha desde es el primer dia del a�o se cobra el a�o de la novedad
            If(Concat(extract(day from ln_indexnove.DESDE),extract(month from ln_indexnove.DESDE))!=11) then
                ln_anno_desde:= ln_anno_desde + 1;
            End if;    
        When ln_indexnove.ID_NOVEDAD in('17') Then -- Precripci�n
            ln_anno := extract (year from ln_indexnove.DESDE);
        Else
            ln_anno := extract (year from ln_indexnove.FECHA_NOVEDAD); -- Demas novedades
    End Case;    
    
    IF(ln_indexnove.ID_NOVEDAD = '06')then
       in_existe := 0;
        --Valido si tiene activo el cobreo de la vigencia de la novedad
        Select count(1) into in_existe
        from GANT_NOVEDADES_V1
        where nro_placa = lv_placa
        and nombre_campo = 'LIQ_VIGENCIA'
        and FECHA_NOVEDAD = ln_indexnove.FECHA_NOVEDAD
        and DESCRIPCION_ACTO = ln_indexnove.DESCRIPCION_ACTO
        and (anulado = 'X');
    
        if (in_existe > 0) then
             ln_anno :=  ln_anno - 1;
        end if;
    End if;
    
    -- Si es a primera interacci�n valido so el vehiculo nace por radicaci�n o cbio pu pa
    If(ln_contador = 1) then
        IF (ln_indexnove.ID_NOVEDAD = '06')then
            If(GN_VIGENCIA <= ln_anno)Then
                lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad;               
            End If;
        ElsIf (ln_indexnove.ID_NOVEDAD = '08') Then
            If(GN_VIGENCIA < ln_anno)Then
                lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad;               
            End If;
        End If;
    End If;   
    
    -- Valido la novedad
    lv_inactiva := ft_novedades(ln_indexnove.ID_NOVEDAD,ln_anno,ln_anno_desde,ln_anno_hasta);
    
    -- Concateno el string pa la ultima novedad que inactiva el cobro
    If (lv_inactiva = 'S') Then    
        lv_inactiva := 'S-' || ln_indexnove.ID_NOVEDAD || '-' || ln_indexnove.Fecha_Novedad;    
    End if;
    
    End Loop;   
    
  End If;
  
  If lv_inactiva Like 'S%' Then
    iv_Resultado := 'S';  
  End IF;
  
  Return lv_inactiva;
     EXCEPTION WHEN OTHERS THEN
     SP_ERROR_PA (lv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_NOVEDADES_SAP');
     Return 'N'; 
  END FT_NOVEDADES_SAP;  
  

FUNCTION FT_NOVEDADES_QX (iv_placa varchar2) Return varchar2 IS
 /*
    @SYNCRONIK - GANT
    @Nombre    : FT_NOVEDADES_QX
    @Autor     : Elvis.Betancur
    @Fecha     : 22/02/2018
    @Parametro : Nro. Placa
    @Retorno   : S/N
    @Proyecto  : Validaci�n Partidas abiertas
    @Versi�n   : N/A
    Objetivo   : Validar las novedades de Qx-Impuesto
    ******************************************************************************************
    @control de cambios realizados por desarrolladores
    ******************************************************************************************
    @Autor           @Fecha      @Modificaci�n
    Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
    */  

ln_anno       number :=0;  
ln_contador   number :=0;  

Cursor lcur_Novedad_QX is
Select Nro_placa, fecha,'03' Tipo from GANT_CANCELACIONES_QX
Where nro_placa = iv_placa
Union
Select Nro_placa, fecha,'04' from GANT_rematriculas_QX
Where nro_placa = iv_placa
Union
Select Nro_placa, FECHA_RADICACION as fecha, '06' from GANT_radicaciones_QX
Where nro_placa = iv_placa
Union
Select Nro_placa, FECHA_TRASLADO as fecha, '07' from GANT_traslados_QX
Where nro_placa = iv_placa
Union
Select Nro_placa, fecha,'08' from GANT_cambio_servicio_QX
Where SERVICIO_NUEVO = 1  and nro_placa = iv_placa  
Union
Select Nro_placa, fecha,'14' from GANT_cambio_servicio_QX
Where SERVICIO_NUEVO = 2 and nro_placa = iv_placa  
Order by fecha asc;

BEGIN

 lv_inactiva := 'N'; 
 ln_contador := 0;  
 For ln_index in lcur_Novedad_QX Loop
    
    ln_contador := ln_contador + 1;
    ln_anno := extract (year from ln_index.Fecha);   
    
        -- Si es a primera interacci�n valido so el vehiculo nace por radicaci�n o cbio pu pa
    If(ln_contador = 1) then
        IF (ln_index.Tipo = '06')then
            If(GN_VIGENCIA <= ln_anno)Then
                lv_inactiva := 'S-' || ln_index.Tipo || '-' || ln_index.Fecha;               
            End If;
        ElsIf (ln_index.Tipo = '08') Then
            If(GN_VIGENCIA < ln_anno)Then
                lv_inactiva := 'S-' || ln_index.Tipo || '-' || ln_index.Fecha;               
            End If;
        End If;
    End If;
 
    lv_inactiva := FT_NOVEDADES(ln_index.Tipo,ln_anno,0,0);
    
    If (lv_inactiva = 'S') Then    
        lv_inactiva := 'S-' || ln_index.Tipo || '-' || ln_index.Fecha; 
        iv_Resultado := 'S'; 
    End if;
 End Loop;
 
    If (lv_inactiva Like 'S%') Then    
        iv_Resultado := 'S'; 
    End if;
 
 Return lv_inactiva;   

EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_NOVEDADES_QX');
 Return 'N';

END FT_NOVEDADES_QX; 




  
FUNCTION FT_VALIDAR_PAGO(iv_placa varchar2) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_VALIDAR_PAGO
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si tiene pago.
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
BEGIN
 in_existe:=0;
 lv_inactiva := 'N';
 
 SELECT COUNT(1) INTO in_existe
 FROM GANT_REPORTE_PAGOS
 WHERE nro_placa = iv_placa
   AND vigencia = GN_VIGENCIA;
   
 IF (in_existe = 0) THEN  
     SELECT COUNT(1) INTO in_existe
     FROM gant_pagos_qx
     WHERE nro_placa = iv_placa
       AND vigencia = GN_VIGENCIA;
       
        IF (in_existe > 0) THEN  
            lv_inactiva := 'S';        
        END IF;
 ELSE
    lv_inactiva := 'S';
    iv_Resultado := lv_inactiva;
 END IF;
 
 Return lv_inactiva;
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_VALIDAR_PAGO');
 Return 'N';
END FT_VALIDAR_PAGO;


FUNCTION FT_VALIDAR_AUTO_CIERRE(iv_placa varchar2, in_parametro number) RETURN VARCHAR2 IS
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_VALIDAR_AUTO_CIERRE
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Placa, Parametro
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si tiene auto de cierre.
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
BEGIN
 in_existe:=0;
 lv_inactiva := 'N';
 
 If in_parametro = 1 Then -- Auto de cierre activo
     SELECT COUNT(1) INTO in_existe
     FROM GANT_AUTO_CIERRE
     WHERE NRO_PLACA = iv_placa
       AND VIGENCIA = GN_VIGENCIA 
       AND ID_MOTIVO_CIERRE in (17,33) -- Pago y terminacion AP
       AND (ANULADO IS NULL OR ANULADO =''); 
       
 elsif in_parametro = 2 Then -- Auto de cierre anulado
     SELECT COUNT(1) INTO in_existe
     FROM GANT_AUTO_CIERRE
     WHERE NRO_PLACA = iv_placa
       AND VIGENCIA = GN_VIGENCIA 
       AND ID_MOTIVO_CIERRE not in ('5','6','05','06','19','20','22','23') -- Solo los diferentes a cierres por novedad
       AND (ANULADO ='X');  
       /*   5	Cambio De Servicio
            6	Cancelaci�n De Matr�cula
            19	Prescripci�n De Acci�n De Cobro
            20	Radicado De Cuenta
            22	Re-Matr�cula
            23	Traslado De Cuenta      
       */     
 Else
     SELECT COUNT(1) INTO in_existe
     FROM GANT_AUTO_CIERRE
     WHERE NRO_PLACA = iv_placa
       AND VIGENCIA = GN_VIGENCIA
       AND (ANULADO IS NULL OR ANULADO ='');
 End If;
 
  IF (in_existe > 0) THEN
    lv_inactiva := 'S';
    iv_Resultado := lv_inactiva;
  END IF;
  
  RETURN lv_inactiva;
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_VALIDAR_AUTO_CIERRE');
 Return 'N';
END FT_VALIDAR_AUTO_CIERRE;

FUNCTION FT_ACUERDO_PAGO (iv_placa varchar2, in_parametro number) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_ACUERDO_PAGO
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa, par�metro de b�squeda
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si tiene acuerdo de pago.
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 

BEGIN
 in_existe:=0;
 lv_inactiva := 'N';
 
 Case in_parametro
     when 0 Then -- Acuerdo pago en SAP
         
         Select Count(1) Into in_existe
         from gant_acuerdo_pago
         where nro_placa = iv_placa 
           and GN_VIGENCIA between desde and hasta
           and Estado in('03','3','05','5'); -- 5: Terminado, 3: PLan de Pagos
       
     When 1 then -- Acuerdo pago SIAPA
     
        Select Count(1) Into in_existe
        From gant_acuerdo_pago_siapa
        Where Nro_Placa = iv_placa
          and Vigencia = GN_VIGENCIA;
          
     -- Crear otro estado, diferentes a 3,5  
     When 2 Then -- Otros Acuerdos de pago
         Select max(Estado) Into in_existe
         from gant_acuerdo_pago
         where nro_placa = iv_placa 
           and GN_VIGENCIA between desde and hasta
           and Estado not in('03','3','05','5'); -- 5: Terminado, 3: PLan de Pagos     
     
     Else
        Return lv_inactiva;
     End Case;
 
 IF (in_existe > 0) then
   lv_inactiva := 'S';  
   iv_Resultado := lv_inactiva;
 end if;
 
 Return  lv_inactiva; 
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_ACUERDO_PAGO');
 Return 'N';
END FT_ACUERDO_PAGO;


FUNCTION FT_CARACTERISTICAS_VH_QX (iv_placa varchar2, in_parametro number) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_CARACTERISTICAS_VH_QX
 @Autor     : Elvis.Betancur
 @Fecha     : 26/02/2018
 @Parametro : Nro. Placa, par�metro de b�squeda
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si las caracteristicas son sugeto de cobro de impuesto.
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
BEGIN

    in_existe:=0;
    lv_inactiva := 'N';
    
    Case in_parametro
    
    When 1 then -- Cilindraje Inferior
    Select Count(1) into in_existe
    From gant_lic_tto_qx
    Where Nro_Placa = iv_placa
      And id_clase in(10,14,15) --Motocicleta, MotoCarro, Cuatrimoto
      And Cilindraje < 126;
      
    When 2 then -- Veh�culo Excento
    Select count(1) into In_existe
    From Gant_lic_tto_qx
    Where Nro_Placa = iv_placa
      And Id_Clase in (11,12,13,16,19,21,22,24,26); --Maquinaria Agricola, Maquinaria Industrial, 
                                                    --Bicicleta, Tractor, Minitractor, Compactadora, 
                                                    --Montacarga, Retroexcavadora, Tracci�n animal.
      
    When 3 Then -- 3. Veh�culo naturaleza p�blica
   /* Select Count(1) into in_existe
    From Gant_Lic_tto_qx
    Where Nro_Placa = iv_placa
      and id_servicio in (0,5); -- Desconocido*/
      
    Select Count(1) into in_existe
    From Gant_Lic_tto_qx lt
    left join Gant_Cambio_Servicio_qx cs
       on lt.nro_placa = cs.nro_placa   
    Where lt.id_servicio in (2)-- Publico
      and lt.Nro_Placa = iv_placa
      and cs.nro_placa is null;

    When 4 Then -- 4. Veh�culo otro departamento
            Select Count(1) into in_existe
            From Gant_Lic_tto_qx lt
            Inner join Gant_Secretaria_tto_qx st
               on lt.id_secretaria = st.id_secretaria 
            Where st.id_departamento != 1 -- Diferente a Antioquia
              and lt.id_secretaria != 0 -- Secretaria desconocida
              And lt.nro_placa = iv_placa
              and lt.nro_placa not in(Select Nro_placa
                                        From Gant_traslados_qx
                                        Where Nro_placa = iv_placa); 
    
    Else
      Return lv_inactiva;
    End Case;
    
    If (in_existe > 0) Then
     lv_inactiva := 'S';
     iv_Resultado := lv_inactiva;
    End if;    

    Return lv_inactiva;

END FT_CARACTERISTICAS_VH_QX;


FUNCTION FT_CARACTERISTICAS_VH_SAP (iv_placa varchar2, in_parametro number) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_CARACTERISTICAS_VH_SAP
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa, tipo validaci�n
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si las caracteristicas son sugeto de cobro de impuesto.
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
 
 lv_Marca_Archivo varchar2(1);
 
BEGIN

    in_existe:=0;
    lv_inactiva := 'N';
    lv_Marca_Archivo := '';
    
    Case in_parametro
    
    When 1 Then -- 1. Cilindraje Inferior 126
    
    Select Count(1) Into in_existe
    From Gant_Vehiculos
    Where Nro_Placa = iv_placa
    And Id_Clase in ('10','15','16','17','21','22') --Motocicleta, Motocarro, Cuatrimoto, Mototriciclo
    And Cilindraje < 126;
    
    When 2 Then -- 2. Veh�culo Excento 
    
    Select Count(1) Into in_existe
    From Gant_Vehiculos
    Where Nro_Placa = iv_placa
     And Id_Clase in ('11','12','13'); -- Maquinaria agricola, Industrial y Moto tractor
    
    When 3 Then  -- 3. Veh�culo naturaleza p�blica
    
    Select Count(1) Into in_existe
    From Gant_Vehiculos vh
    Where Nro_Placa = iv_placa 
     and Id_Uso = '02'
    and Nro_Placa not in (Select Nro_placa --Valido si tiene novedad de cambio servicio
                          From Gant_Novedades_V1
                            Where (anulado is null or anulado = ''));                                                        
                              
    When 4 Then -- 4. Veh�culo otro departamento
    
    Select Count(1) Into in_existe
    From Gant_Vehiculos vh
    Where Nro_Placa = iv_placa 
      and Id_Region != '05'
      and Nro_Placa not in (Select Nro_placa --Valido que no tenga novedades registradas
                      From Gant_Novedades_V1
                        Where (anulado is null or anulado = ''));                                              
                          
     When 5 Then -- Fecha matricula Posterior
     
     Select Count(1) Into in_existe
     From Gant_Vehiculos vh
     Where Nro_Placa = iv_placa 
       and Extract(year from Fecha_Matricula) > GN_VIGENCIA
       and Nro_Placa not in (Select Nro_placa --Valido que no tenga novedades registradas
                      From Gant_Novedades_V1
                        Where Id_Novedad in ('04','06','08'));  
     
     When 6 Then -- Placa Marcada para Archivo
     
     Select Marca_Archivo, Observaciones Into lv_Marca_Archivo, lv_inactiva
     From Gant_DPSOB
     Where Nro_Placa = iv_placa
       And Observaciones is not null;     
    
    Else
     Return lv_inactiva;
    End Case;
    
    If (in_existe > 0 and in_parametro != 6) Then
     lv_inactiva := 'S';
    Elsif( in_parametro = 6) then
        lv_inactiva := lv_Marca_Archivo || '-' || lv_inactiva;
    End if;
 
    Return lv_inactiva;
    
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_CARACTERISTICAS_VH_SAP-' || in_parametro);
 Return 'N';   
END FT_CARACTERISTICAS_VH_SAP;



FUNCTION FT_ENTRA_TARDE_BD (iv_placa varchar2) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_ENTRA_TARDE_DB
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si entra tarde a la base de datos-
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 

BEGIN
 in_existe:=0;
 lv_inactiva := 'N';
 
 Select Count(1) into in_existe
 From Gant_DPSOB
 where Nro_Placa = iv_placa
   --and (extract (year from Fecha_Creacion)) > (GN_VIGENCIA + GN_NOTIFICAR);
   and Fecha_Creacion > add_months(GN_VENCE_VIGENCIA,GN_NOTIFICAR);
 
 If (in_existe > 0) Then
   lv_inactiva := 'S';  
   iv_Resultado := lv_inactiva;
 End If;
 
 Return lv_inactiva;
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_ENTRA_TARDE_BD');
 Return 'N';

END FT_ENTRA_TARDE_BD;



FUNCTION FT_EXISTE_TCC (iv_placa varchar2, iv_identificacion varchar2)RETURN VARCHAR2 IS
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_EXISTE_TCC
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa - identificaci�n
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Existe traslado a cobro coactivo
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
 ln_existe number :=0;
BEGIN

 in_existe:=0;
 lv_inactiva := 'N';
 
 Select count(1) into ln_existe -- Valido si el registro tiene documento
 from gant_tcc
 where nro_placa = iv_placa
   and vigencia = GN_VIGENCIA
   and identificacion is not null;
   
   If ln_existe > 0 Then -- Busco con identificacion
     Select count(1) into in_existe
     from gant_tcc
     where nro_placa = iv_placa
       and vigencia = GN_VIGENCIA
       and identificacion = iv_identificacion; 
   Else -- Busco sin identificaci�n
     Select count(1) into in_existe
     from gant_tcc
     where nro_placa = iv_placa
       and vigencia = GN_VIGENCIA;    
   End IF;   
 
 If (in_existe > 0) Then
   lv_inactiva := 'S';  
   iv_Resultado := lv_inactiva;
 End If;
 
 Return lv_inactiva;
 
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_EXISTE_TCC');
 Return 'N';
END FT_EXISTE_TCC;
  

FUNCTION FT_EXISTE_FISCA(iv_placa varchar2, iv_referencia varchar2, in_parametro varchar2) return varchar2 IS
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_EXISTE_FISCA
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa, Referencia, parametro
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Existe fiscalizaci�n
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
lv_fecha varchar2(10);
lv_Resultado varchar2(20);

Begin

 in_existe:=0;
 lv_Resultado := 'N';
 lv_fecha := null;

    If in_parametro = 0 Then -- Fiscalizaci�n Activa
    
        Select max(Nivel_Recl) into in_existe
        from Gant_Zfpm3
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Nivel_Recl > GN_NIVEL_RECLAMACION
          And (anulado is null or anulado = '');
          
        Select MAX(FECHA_IMPRESION) into lv_fecha
        from Gant_Zfpm3
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Nivel_Recl = in_existe
          And (anulado is null or anulado = '');
          --And Rownum = 1;         
      
    Else  -- Fiscalizaci�n Anulada
    
        Select max(Nivel_Recl) into in_existe
        from Gant_Zfpm3
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Nivel_Recl > GN_NIVEL_RECLAMACION
          And anulado = 'X';
          
        Select MAX(FECHA_IMPRESION) into lv_fecha
        from Gant_Zfpm3
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Nivel_Recl = in_existe
          And anulado = 'X';
          --And Rownum = 1;    
    
    End If;
    
    IF(in_existe > 0) Then
        lv_Resultado := 'S' || '-' || to_char(in_existe)|| '-' || lv_fecha;
        iv_Resultado := 'S';
    End If;
    
    Return lv_Resultado;
    
 EXCEPTION WHEN OTHERS THEN
  SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_EXISTE_FISCA-' || in_parametro);
  Return 'N';
 END FT_EXISTE_FISCA;
 
 
  
 FUNCTION FT_EXISTE_GEDOC (iv_placa varchar2, iv_referencia varchar2, in_interlocutor number, in_parametro number) return varchar2 is
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_EXISTE_GEDOC
 @Autor     : Elvis.Betancur
 @Fecha     : 23/02/2018
 @Parametro : Nro. Placa - Referencia - Interlocutor - Parametro
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Existe Gesti�n documental
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   26/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */
 
lv_Fecha varchar2(999);
lv_Resultado varchar2(20);

 BEGIN

 in_existe:=0;
 lv_Resultado := 'N';
 
If in_parametro = 0 Then -- Gesti�n Documental Activa
    
        Select max(NR) into in_existe
        from Gant_Zvhgestion_Doc
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Interlocutor = in_interlocutor
          And NR > GN_NIVEL_RECLAMACION
          And (Borrado is null or Borrado = '');
          
        Select MAX(Fecha_Creado) into lv_Fecha
        from Gant_Zvhgestion_Doc
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Interlocutor = in_interlocutor
          And NR = in_existe
          And (Borrado is null or Borrado = '');
          --And Rownum = 1;         
      
    Else  -- Gesti�n Documental Anulada
    
        Select max(NR) into in_existe
        from Gant_Zvhgestion_Doc
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Interlocutor = in_interlocutor
          And NR > GN_NIVEL_RECLAMACION
          And Borrado = 'X';
          
        Select MAX(Fecha_Creado)  into lv_fecha
        from Gant_Zvhgestion_Doc
        Where Nro_Placa = iv_placa
          And Vigencia = GN_VIGENCIA
          And Referencia = iv_referencia
          And Interlocutor = in_interlocutor
          And NR = in_existe
          And Borrado = 'X';
          --And Rownum = 1;    
    
    End If;
    
    IF(in_existe > 0) Then
        lv_Resultado := 'S' || '-' || to_char(in_existe)|| '-' || lv_fecha;
        iv_Resultado := 'S';
    End If;
   
    Return lv_Resultado;
 
 EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_EXISTE_GEDOC');
 Return 'N';
 END FT_EXISTE_GEDOC;  
 
 
 
 FUNCTION FT_INDETERMINADO_QX (iv_placa varchar2) Return varchar2 is
   /*
 @SYNCRONIK - GANT
 @Nombre    : FT_INDETERMINADO_QX
 @Autor     : Elvis.Betancur
 @Fecha     : 26/02/2018
 @Parametro : Nro. Placa
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si e veh�culo es indeterminado para la placa vigencia
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   26/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
 BEGIN
 in_existe:=0;
 lv_inactiva := 'N';
 
 Select Count(1) into in_existe
 From Gant_Historiales_Traspaso_qx tp
 Inner join Gant_Usuarios_Tto_qx ut
   on ut.Id_Usuario = tp.Id_Comprador
 Where tp.nro_placa = iv_placa
   and Extract(year from tp.FECHA) < GN_VIGENCIA
   and (upper(ut.nombres) Like ('%INDETERM%') 
    or upper(ut.apellidos) Like ('%INDETERM%')); 
 
 If (in_existe > 0) Then
   lv_inactiva := 'S';  
   iv_Resultado := 'S';
 End If; 
 
 Return lv_inactiva;    
 
EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_INDETERMINADO_QX');
 Return 'N';
 END FT_INDETERMINADO_QX;
 
 
 
 FUNCTION FT_INDETERMINADO_SAP (iv_placa varchar2, in_interlocutor varchar2) return varchar2 is
 /*
 @SYNCRONIK - GANT
 @Nombre    : FT_INDETERMINADO_SAP
 @Autor     : Elvis.Betancur
 @Fecha     : 26/02/2018
 @Parametro : Nro. Placa, Interlocutor
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Validar si e veh�culo es indeterminado para la placa vigencia
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   26/02/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
 BEGIN
     in_existe:=0;
     lv_inactiva := 'N';
     
   Select Count(1) into in_existe
   From Gant_Propietarios_sap
   Where Interlocutor = in_interlocutor
     And Indeterminado = 'X'
     And Rownum < 2;  

  If (in_existe > 0) Then
   lv_inactiva := 'S';  
   iv_Resultado := 'S';
 End If; 
 
 Return lv_inactiva;    
 
EXCEPTION WHEN OTHERS THEN
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_INDETERMINADO_SAP');
 Return 'N';
 END FT_INDETERMINADO_SAP;
 
 
 FUNCTION FT_ESTRUCTURA_PLACA (iv_placa varchar2) return varchar2 is
 
 lv_string varchar2(20);
 
 BEGIN
    lv_Inactiva := 'N';
    lv_string := UPPER(iv_placa);

    lv_string := TRANSLATE(lv_string,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','--------------------------');
                                                                  
    lv_string := TRANSLATE(lv_string,'0123456789','@@@@@@@@@@');
    
    --Formatos validos
    IF lv_string NOT IN ('---@@@', '---@@','---@@-', '--@@@@', '--@@@','@@@---') THEN                       
      lv_Inactiva := 'S';
      iv_Resultado := 'S';
    END IF;
 
 Return lv_inactiva;
 
 EXCEPTION WHEN OTHERS THEN    
 SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_ESTRUCTURA_PLACA');
 Return 'N';
 
 END FT_ESTRUCTURA_PLACA;
 
 PROCEDURE SP_INICIAR AS
  /*
 @SYNCRONIK - GANT
 @Nombre    : SP_INICIAR
 @Autor     : Elvis.Betancur
 @Fecha     : 22/02/2018
 @Parametro : N/A
 @Retorno   : N/A
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Permite iniciar el proceso de validaci�n
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   22/02/2018  Se realiza la creaci�n del objeto de tipo p�blico.
 */ 
    lv_Fisca_Act Varchar2(1);
    lv_Nr_Act Varchar2(3);
    lv_Fecha_Act Varchar2(10);
    lv_Fisca_Inact Varchar2(1);
    lv_Nr_Inact Varchar2(3);
    lv_Fecha_Inact Varchar2(10);
    lv_Tcc Varchar2(1);
    lv_Pago Varchar2(1);
    lv_Ap_Sap Varchar2(1);
    lv_Ap_Siapa Varchar2(1);
    lv_Auto_Cierre Varchar2(1);
    lv_Nov_Act Varchar2(1);
    lv_Id_Nov_Act varchar2(10);
    lv_Fecha_Nov_Act varchar2(10);
    lv_Nov_Inact Varchar2(1);
    lv_Id_Nov_Inact varchar2(10);
    lv_Fecha_Nov_Inact varchar2(10);  
    lv_Sap_Cc_Inferior Varchar2(1);
    lv_Sap_Vh_Excento Varchar2(1);
    lv_Sap_Vh_Nat_Pu Varchar2(1);
    lv_Sap_Vh_Otro_Dpto Varchar2(1);
    lv_Indet_Sap   varchar2(1);
    lv_Tarde_Bd Varchar2(1);
    lv_GeDoc Varchar2(1);
    lv_GeDoc_Nr Varchar2(3);
    lv_GeDoc_Fech Varchar2(10);
    lv_GeDoc_anu Varchar2(1);
    lv_GeDoc_Nr_anu Varchar2(3);
    lv_GeDoc_Fech_anu Varchar2(10);    
    lv_Qx_Cc_Inferior Varchar2(1);
    lv_Qx_Vh_Excento Varchar2(1);
    lv_Qx_Vh_Nat_Pu Varchar2(1);
    lv_Qx_Vh_Otro_Dpto Varchar2(1);
    lv_Nov_Qx      Varchar2(1);
    lv_Qx_Id_Nov varchar2(3);
    lv_Qx_Fecha_Nov varchar2(10);   
    lv_Indet_Qx    varchar2(1);    
    lv_Formato_Placa varchar2(1);
    lv_Cadena Varchar2(30);
    lv_Cierre_Anu varchar2(1);
    lv_OtroEstado_AP varchar2(3);
    lv_MI_Posterior varchar2(1);
    lv_MarcadoArchivo varchar2(1000);
    ln_Posicion1 number;
    ln_Posicion2 number;
 
 Cursor lcur_partidas is
 Select Nro_Placa, Referencia, Interlocutor, Identificacion
 from Gant_Universo_Pa
 Where Vigencia = GN_VIGENCIA;
   -- AND ROWNUM <1000
   -- And Nro_placa  in('LYA755', 'LYA916','LYA982');
 
 Type tyPartidas is table of lcur_partidas%ROWTYPE;
 ArrayPartidas tyPartidas;
 
  BEGIN
  
  SP_CARGARPARAMETROS(); --Cargo los parametros
  
  Open lcur_partidas;
      Loop Fetch lcur_partidas
         Bulk collect into ArrayPartidas Limit GN_BLOQUE_PROCESO;         
            For lnIndex in 1..ArrayPartidas.count() Loop
            Begin
             -- Limpio e inicializo las variables 
                iv_Resultado :='N';  
                lv_inactiva  := 'N'; 
                lv_Cadena := 'N';                                                                   
                iv_Resultado := 'N'; 
                lv_Fisca_Act := 'N'; 
                lv_Nr_Act := null; 
                lv_Fecha_Act := null; 
                lv_Fisca_Inact := 'N'; 
                lv_Nr_Inact := null; 
                lv_Fecha_Inact := null; 
                lv_Tcc := 'N'; 
                lv_Pago := 'N'; 
                lv_Ap_Sap := 'N'; 
                lv_OtroEstado_AP := 'N'; 
                lv_Ap_Siapa := 'N'; 
                lv_Auto_Cierre := 'N'; 
                lv_Cierre_Anu := 'N'; 
                lv_Nov_Act := 'N'; 
                lv_Id_Nov_Act := null; 
                lv_Fecha_Nov_Act := null; 
                lv_Nov_Inact := 'N'; 
                lv_Id_Nov_Inact := null; 
                lv_Fecha_Nov_Inact := null; 
                lv_Sap_Cc_Inferior := 'N'; 
                lv_Sap_Vh_Excento := 'N'; 
                lv_Sap_Vh_Nat_Pu := 'N'; 
                lv_Sap_Vh_Otro_Dpto := 'N'; 
                lv_MI_Posterior := 'N'; 
                lv_MarcadoArchivo := 'N'; 
                lv_Indet_Sap := 'N'; 
                lv_Tarde_Bd := 'N'; 
                lv_GeDoc := 'N'; 
                lv_GeDoc_Nr := null; 
                lv_GeDoc_Fech := null; 
                lv_GeDoc_anu := 'N'; 
                lv_GeDoc_Nr_anu := null; 
                lv_GeDoc_Fech_anu := null; 
                lv_Formato_Placa := 'N'; 
                lv_Qx_Cc_Inferior := 'N'; 
                lv_Qx_Vh_Excento := 'N'; 
                lv_Qx_Vh_Nat_Pu := 'N'; 
                lv_Qx_Vh_Otro_Dpto := 'N'; 
                lv_Nov_Qx := 'N'; 
                lv_Qx_Id_Nov := null; 
                lv_Qx_Fecha_Nov := null; 
                lv_Indet_Qx := 'N'; 
                lv_Cadena	 := null; 
                ln_Posicion1 := 0;
                ln_Posicion2 := 0;   
                in_existe :=0;
                             
/*======================================================================================================================*/   
/*                             I N I C I O  P R O C E S O  D E   V A L I D A C I O N                                    */
/*======================================================================================================================*/                  
                
                lv_Cadena := FT_EXISTE_FISCA (ArrayPartidas(lnIndex).Nro_Placa,
                                              ArrayPartidas(lnIndex).Referencia,0);-- Existe fiscalizaci�n activa
                If Length(lv_Cadena)>1 then
                    ln_Posicion1 := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2 := instr(lv_Cadena,'-',1,2);                    
                    lv_Fisca_Act := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Nr_Act    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Fecha_Act := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Fisca_Act := lv_Cadena; 
                End If;
                
                lv_Cadena := null;              
                lv_Cadena := FT_EXISTE_FISCA (ArrayPartidas(lnIndex).Nro_Placa,
                                              ArrayPartidas(lnIndex).Referencia,1);-- Existe fiscalizaci�n Inactiva
                If Length(lv_Cadena)>1 then
                    ln_Posicion1   := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2   := instr(lv_Cadena,'-',1,2);                     
                    lv_Fisca_inact := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Nr_inact    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Fecha_Inact := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Fisca_inact := lv_Cadena; 
                End If;            
            
                lv_Tcc           := FT_EXISTE_TCC          (ArrayPartidas(lnIndex).Nro_Placa,   
                                                            ArrayPartidas(lnIndex).Identificacion); -- Existe Traslado Coactivo
                lv_Pago          := FT_VALIDAR_PAGO        (ArrayPartidas(lnIndex).Nro_Placa);      -- Existe Pago
                lv_Ap_Sap        := FT_ACUERDO_PAGO        (ArrayPartidas(lnIndex).Nro_Placa,0);    -- Acuerdo Pago SAP
                lv_Ap_Siapa      := FT_ACUERDO_PAGO        (ArrayPartidas(lnIndex).Nro_Placa,1);    -- Acuerdo Pago SIAPA
                lv_OtroEstado_AP := FT_ACUERDO_PAGO        (ArrayPartidas(lnIndex).Nro_Placa,2);    -- Otro estado AP
                lv_Auto_Cierre   := FT_VALIDAR_AUTO_CIERRE (ArrayPartidas(lnIndex).Nro_Placa,1);    -- Veh�culo tiene auto cierre
                lv_Cierre_Anu    := FT_VALIDAR_AUTO_CIERRE (ArrayPartidas(lnIndex).Nro_Placa,2);    -- Veh�culo tiene auto cierre Anulado
                
                lv_Cadena := null;
                lv_Cadena := FT_NOVEDADES_SAP (ArrayPartidas(lnIndex).Nro_Placa,1); -- Novedades Activas
                
                If Length(lv_Cadena)>1 then
                    ln_Posicion1     := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2     := instr(lv_Cadena,'-',1,2);                     
                    lv_Nov_Act       := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Id_Nov_Act    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Fecha_Nov_Act := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Nov_Act := lv_Cadena; 
                End If;

                lv_Cadena := null;
                lv_Cadena := FT_NOVEDADES_SAP (ArrayPartidas(lnIndex).Nro_Placa,0); -- Novedades Inactivas
                
                If Length(lv_Cadena)>1 then
                    ln_Posicion1       := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2       := instr(lv_Cadena,'-',1,2);                     
                    lv_Nov_Inact       := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Id_Nov_inact    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Fecha_Nov_Inact := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Nov_Inact  := lv_Cadena; 
                End If;               
                
                lv_Sap_Cc_Inferior  := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,1); -- Cilindraje Inferior 126
                lv_Sap_Vh_Excento   := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,2); -- Vehiculo Excento
                lv_Sap_Vh_Nat_Pu    := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,3); -- Veh�culo Naturaleza P�blica
                lv_Sap_Vh_Otro_Dpto := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,4); -- Veh�culo Otro Departamento
                lv_MI_Posterior     := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,5); -- Matricula inicial Posterior
                lv_MarcadoArchivo   := FT_CARACTERISTICAS_VH_SAP (ArrayPartidas(lnIndex).Nro_Placa,6); -- Marcado para Archivo 
                lv_Qx_Cc_Inferior   := FT_CARACTERISTICAS_VH_QX  (ArrayPartidas(lnIndex).Nro_Placa,1); -- Cilindraje Inferior 126;
                lv_Qx_Vh_Excento    := FT_CARACTERISTICAS_VH_QX  (ArrayPartidas(lnIndex).Nro_Placa,2); -- Vehiculo Excento  
                lv_Qx_Vh_Nat_Pu     := FT_CARACTERISTICAS_VH_QX  (ArrayPartidas(lnIndex).Nro_Placa,3); -- Veh�culo Naturaleza P�blica
                lv_Qx_Vh_Otro_Dpto  := FT_CARACTERISTICAS_VH_QX  (ArrayPartidas(lnIndex).Nro_Placa,4); -- Veh�culo Otro Departamento
                lv_Tarde_Bd         := FT_ENTRA_TARDE_BD         (ArrayPartidas(lnIndex).Nro_Placa);   -- Entra Tarde a BD
                
                lv_Cadena := null;
                lv_Cadena := FT_EXISTE_GEDOC (ArrayPartidas(lnIndex).Nro_Placa,
                                              ArrayPartidas(lnIndex).Referencia,
                                              ArrayPartidas(lnIndex).Interlocutor,0);  -- Gesti�n Documental  
                                              
                If Length(lv_Cadena)>1 then
                    ln_Posicion1  := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2  := instr(lv_Cadena,'-',1,2);                     
                    lv_GeDoc      := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_GeDoc_Nr   := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_GeDoc_Fech := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_GeDoc := lv_Cadena; 
                End If;                                                                                          
                                                                  
                lv_Cadena := null;
                lv_Cadena := FT_EXISTE_GEDOC (ArrayPartidas(lnIndex).Nro_Placa,
                                              ArrayPartidas(lnIndex).Referencia,
                                              ArrayPartidas(lnIndex).Interlocutor,1);  -- Gesti�n Documental Anulada   
                If Length(lv_Cadena)>1 then
                    ln_Posicion1      := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2      := instr(lv_Cadena,'-',1,2);                     
                    lv_GeDoc_anu      := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_GeDoc_Nr_anu   := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_GeDoc_Fech_anu := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_GeDoc_anu := lv_Cadena; 
                End If;                                               
                
                lv_Cadena := null;
                lv_Cadena := FT_NOVEDADES_QX (ArrayPartidas(lnIndex).Nro_Placa);   -- Novedades QX
                
                If Length(lv_Cadena)>1 then
                    ln_Posicion1    := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2    := instr(lv_Cadena,'-',1,2);                     
                    lv_Nov_Qx       := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Qx_Id_Nov    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Qx_Fecha_Nov := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Nov_Qx := lv_Cadena; 
                End If;
                
                lv_Indet_Qx         := FT_INDETERMINADO_QX  (ArrayPartidas(lnIndex).Nro_Placa);   -- Indeterminado QX
                lv_Indet_Sap        := FT_INDETERMINADO_SAP (ArrayPartidas(lnIndex).Nro_Placa, ArrayPartidas(lnIndex).Interlocutor);   -- Indeterminado SAP
                lv_Formato_Placa    := FT_ESTRUCTURA_PLACA  (ArrayPartidas(lnIndex).Nro_Placa);   -- Formato pllaca ;

                --Resultado
                iv_Resultado := 'N';
                /*
                If(lv_Ap_Sap = 'S' or lv_Ap_Siapa = 'S' or lv_Nov_Act = 'S' or lv_Sap_Cc_Inferior = 'S' or lv_Pago = 'S' or 
                   lv_Sap_Vh_Excento = 'S' or lv_Indet_Sap = 'S' or lv_Tarde_Bd = 'S' or lv_Formato_Placa = 'S') Then
                    iv_Resultado := 'S';
                Elsif(To_Number(lv_Nr_Act)>=13 and lv_Tcc = 'S') Then -- Fiscalizacion >= 13 y traslado a coactivo
                    iv_Resultado := 'S';
                Elsif(To_Number(lv_Nr_Act)<13 and lv_Tcc = 'S') Then -- Fiscalizacion < 13 y traslado a coactivo
                    iv_Resultado := 'S!';                   
                Elsif(To_Number(lv_Nr_Act)>=13 and lv_Tcc = 'N') Then -- Fiscalizacion >= 13 y NO traslado a coactivo
                    iv_Resultado := 'S!';     
                End If;    */

                Insert into Gant_Resultado
                     Values(ArrayPartidas(lnIndex ).Nro_Placa,
                            GN_VIGENCIA,
                            ArrayPartidas(lnIndex ).Referencia,
                            iv_Resultado,
                            lv_Fisca_Act,
                            lv_Nr_Act,
                            lv_Fecha_Act,
                            lv_Fisca_Inact,
                            lv_Nr_Inact,
                            lv_Fecha_Inact,
                            lv_Tcc,
                            lv_Pago,
                            lv_Ap_Sap,
                            lv_OtroEstado_AP,
                            lv_Ap_Siapa,
                            lv_Auto_Cierre,
                            lv_Cierre_Anu,
                            lv_Nov_Act,
                            lv_Id_Nov_Act,
                            lv_Fecha_Nov_Act,
                            lv_Nov_Inact,
                            lv_Id_Nov_Inact,
                            lv_Fecha_Nov_Inact,
                            lv_Sap_Cc_Inferior,
                            lv_Sap_Vh_Excento,
                            lv_Sap_Vh_Nat_Pu,
                            lv_Sap_Vh_Otro_Dpto,
                            lv_MI_Posterior,
                            lv_MarcadoArchivo,
                            lv_Indet_Sap,
                            lv_Tarde_Bd,
                            lv_GeDoc,
                            lv_GeDoc_Nr,
                            lv_GeDoc_Fech,
                            lv_GeDoc_anu,
                            lv_GeDoc_Nr_anu,
                            lv_GeDoc_Fech_anu,
                            lv_Formato_Placa,
                            lv_Qx_Cc_Inferior,
                            lv_Qx_Vh_Excento,
                            lv_Qx_Vh_Nat_Pu,
                            lv_Qx_Vh_Otro_Dpto,
                            lv_Nov_Qx,
                            lv_Qx_Id_Nov,
                            lv_Qx_Fecha_Nov,
                            lv_Indet_Qx,
                            null,null,null,null,null,null,null,null,null,null,
                            ArrayPartidas(lnIndex ).Identificacion,null, null, null, null, null);                                                                                         

                SP_COMMIT;--Confirmo la transacci�n
               -- SP_RESULTADO;
                EXCEPTION WHEN OTHERS THEN
                 SP_ERROR_PA ('',sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_INICIAR');
                 sp_commit;
                 Continue;
                End; 
            End Loop;        
         Exit when ArrayPartidas.count()<=0;         
      End Loop;  
      Commit;
      Pkg_Fechas_validacion.Sp_iniciar; --Adiciono las fechas
  END SP_INICIAR;
  
  Procedure sp_prueba_regla_novedades2(iv_placa varchar2, in_parametro number) as
  lv_resultado varchar2(1000);
  Cursor lcur_Pa is
  Select nro_placa, vigencia
  from gant_universo_pa;
 -- wHERE NRO_PLACA ='MMH832';

Begin
 if in_parametro = 1 then
      for lnIndex IN 1999 .. 2018 loop
           GN_VIGENCIA := lnIndex;
           lv_resultado := FT_NOVEDADES_SAP (iv_placa,1);
           
           Insert into gant_debe values (iv_placa,GN_VIGENCIA,lv_resultado);
       End loop;
Else
      for ln_Index in lcur_pa loop
       Begin
           GN_VIGENCIA := ln_Index.vigencia;
           lv_resultado := FT_NOVEDADES_SAP (ln_Index.NRO_PLACA,1);           
           Insert into gant_debe values (ln_Index.NRO_PLACA,GN_VIGENCIA,lv_resultado);
           SP_COMMIT;
       Exception when others then
       Continue;
       End;
      end loop;
End if;
   
  
  End sp_prueba_regla_novedades2;
  
  Procedure sp_Resultado is
  ld_fechaLimite date;
  Begin
        SP_CARGARPARAMETROS;
        ld_fechaLimite := ADD_MONTHS(GN_VENCE_VIGENCIA,GN_NOTIFICAR);
        
        Update GANT_RESULTADO set resultado = '01-Pago'
        Where resultado = 'N' and pago ='S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '02-Novedad'
        Where resultado = 'N' and novedad ='S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '03-Fiscalizaci�n Activa > 10 y <= '||ADD_MONTHS(GN_VENCE_VIGENCIA,60)
        Where resultado = 'N' and FISCALIZACION ='S' and NR > 10 and to_date(fecha_nr) <= ADD_MONTHS(GN_VENCE_VIGENCIA,60) and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '04-Acuerdo Pago Sap'
        Where resultado = 'N' and AP_SAP ='S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '05-Acuerdo Pago Siapa'
        Where resultado = 'N' and AP_SIAPA ='S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '06-Traslado Cobro Coactivo'
        Where resultado = 'N' and TRASLADO_TCC ='S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '07-Indeterminado Sap. Traspaso menor a '||GN_INICIO_VIGENCIA
        Where resultado = 'N' and SAP_INDETERMINADO ='S' and to_date(FECHA_INDET_SAP) < GN_INICIO_VIGENCIA and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '08-Sap Cilindraje Inferior'
        Where resultado = 'N' and SAP_CC_INFERIOR = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '09-Sap Veh�culo Excento'
        Where resultado = 'N' and SAP_VH_EXCENTO = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '10-Sap Veh�culo naturaleza P�blica'
        Where resultado = 'N' and SAP_VH_NAT_PU = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '11-Sap Veh�culo otro Dpto'
        Where resultado = 'N' and SAP_VH_OTRO_DPTO = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '12-Sap Matricula Posterior'
        Where resultado = 'N' and FECHA_MI_POSTERIOR = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '13-Entra tarde a BD (4 a�os 4 meses). Mayor a '||add_Months(ld_fechaLimite,4)
        Where resultado = 'N' and TARDE_BD = 'S' and to_date(FECHA_CREACION) > add_Months(ld_fechaLimite,4) and vigencia = GN_VIGENCIA;
        Commit;
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado2 = '13-Entra tarde a BD (4 a�os). Mayor a '||ld_fechaLimite
        Where (resultado = 'N' or resultado Like '13%') and TARDE_BD = 'S' and to_date(FECHA_CREACION) > ld_fechaLimite and vigencia = GN_VIGENCIA;
        Commit;        
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado = '14-Fiscalizaci�n activa = 10 y Notificaci�n NR = 10 y <= a '||ADD_MONTHS(GN_VENCE_VIGENCIA,60)
        Where resultado = 'N' and FISCALIZACION = 'S' and NR = 10
          and GDOC = 'S' and GDOC_NR = 10 and to_date(fecha_nr) <= ADD_MONTHS(GN_VENCE_VIGENCIA,60) and vigencia = GN_VIGENCIA;
        Commit;
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado = '15-Gesti�n Documental Activa.'
        Where resultado = 'N' and GDOC ='S' and vigencia = GN_VIGENCIA;
        Commit;
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado = '16-Fiscalizaci�n anulada > 10  y <= a'||ADD_MONTHS(GN_VENCE_VIGENCIA,60)
        Where resultado = 'N' and FISCA_ANU = 'S' and NR_ANU > 10 and to_date(fecha_nr_anu) <= ADD_MONTHS(GN_VENCE_VIGENCIA,60) and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '17-Fiscalizaci�n anulada = 10 y Notificaci�n NR = 10 y <= a '||ADD_MONTHS(GN_VENCE_VIGENCIA,60)
        Where resultado = 'N' and FISCA_ANU = 'S' and NR_ANU     = 10
          and GDOC = 'S' and GDOC_NR = 10 and to_date(fecha_nr_anu) <= ADD_MONTHS(GN_VENCE_VIGENCIA,60) and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '18-Novedad anulada (4 a�os 4 meses). Posterior a '||add_Months(ld_fechaLimite,4) 
        Where resultado = 'N' and NOVEDAD_ANU = 'S'
        and TO_DATE(FECHA_ANU_NOV) > add_Months(ld_fechaLimite,4) and vigencia = GN_VIGENCIA;
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado2 = '18-Novedad anulada (4 A�os). Posterior a '||ld_fechaLimite
        Where (resultado = 'N' or resultado Like '18%') and NOVEDAD_ANU = 'S'
        and TO_DATE(FECHA_ANU_NOV) > ld_fechaLimite and vigencia = GN_VIGENCIA;
        /*=================================================================================================*/
        /*=================================================================================================*/
        Update GANT_RESULTADO set resultado = '19-Gesti�n Documental Anulada.'
        Where resultado = 'N' and GDOC_ANU ='S' and vigencia = GN_VIGENCIA;
        Commit;
        /*=================================================================================================*/
        Commit;
        Update GANT_RESULTADO set resultado = '20-Qx Novedad Activa'
        Where resultado = 'N' and QX_NOVEDAD = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '21-Qx Cilindraje Inferior'
        Where resultado = 'N' and QX_CC_INFERIOR = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '22-Qx Veh�culo excento'
        Where resultado = 'N' and QX_VH_EXCENTO = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '23-Qx Veh�culo naturaleza P�blica'
        Where resultado = 'N' and QX_VH_NAT_PU = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '24-Qx Veh�culo otro Dpto'
        Where resultado = 'N' and QX_VH_OTRO_DPTO = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '25-Qx Indeterminado. Traspaso menor a '||GN_INICIO_VIGENCIA
        Where resultado = 'N' and QX_INDETERMINADO = 'S' AND TO_DATE(FECHA_INDET_QX) < GN_INICIO_VIGENCIA and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '26-Formato Placa'
        Where resultado = 'N' and FORMATO_PLACA = 'S' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = '27-Marcado para archivo'
        Where resultado = 'N' and MARCADO_ARCHIVO LIKE 'X%' and vigencia = GN_VIGENCIA;
        Commit;
        Update GANT_RESULTADO set resultado = 'N'
        Where id_Nov = 17 and  Pago != 'S' and vigencia = GN_VIGENCIA;
        Update GANT_RESULTADO set resultado = 'N'
        Where id_Nov_Anu = 17 and Pago != 'S' and vigencia = GN_VIGENCIA;
        Commit;
        
  End Sp_Resultado;
  
  Procedure sp_entra_tarde is
  lv_resultado varchar2(1000);
  Cursor lcur1 is
  Select nro_placa, vigencia
  From gant_universo_pa
  Where vigencia = gn_vigencia;
  Begin
    sp_cargarparametros;
  For lnindex in lcur1 Loop

  lv_resultado:='N';
    lv_resultado := ft_entra_tarde_bd(lnindex.nro_placa);
    Update gant_resultado set Tarde_Bd = lv_resultado
    Where Nro_placa = lnindex.nro_placa
      and Vigencia = lnindex.vigencia;
      Sp_commit;
  End loop;
  Commit;
    --pkg_fechas_validacion.Sp_Fecha_Creacion;
  End sp_entra_tarde; 



/*========================================================================================
  --  I N I C I O  D E S A R R O L L O  T O M A R  F I S C A L I Z A C I O N  Q X       --
  ========================================================================================*/

    
FUNCTION FT_EXISTE_FISCA_QX(iv_placa varchar2, iv_IdUsuario varchar2) return varchar2 IS
  /*
 @SYNCRONIK - GANT
 @Nombre    : FT_EXISTE_FISCA_QX
 @Autor     : Elvis.Betancur
 @Fecha     : 04/04/2018
 @Parametro : Nro. Placa, iv_IdUsuario, parametro
 @Retorno   : S/N
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Existe fiscalizaci�n en Qx
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   04/04/2018  Se realiza la creaci�n del objeto de tipo privado.
 */ 
lv_fecha varchar2(10);
lv_Resultado varchar2(20);
ln_Nr number:=0;

Begin

 ln_Nr:=0;
 lv_Resultado := 'N';
 lv_fecha := null;
    
    Select Id_Oficio_Notifica, Fecha_Notifica  Into ln_Nr, lv_fecha
      From Gant_Fiscalizacion_Qx
     Where Nro_Placa = iv_placa
       And Id_Usuario_Notificado = iv_IdUsuario
       And Notificado = 'S'
       And Vigencia = GN_VIGENCIA
       And Rownum = 1;
      
    IF(ln_Nr > 0) Then
        lv_Resultado := 'S' || '-' || to_char(ln_Nr)|| '-' || lv_fecha;
        iv_Resultado := 'S';
    End If;
    
    Return lv_Resultado;
    
 EXCEPTION WHEN OTHERS THEN
  SP_ERROR_PA (iv_placa,sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'FT_EXISTE_FISCA_QX');
  Return 'N';
 END FT_EXISTE_FISCA_QX; 
 
 
 
 PROCEDURE SP_CORRER_FISCA_QX AS
   /*
 @SYNCRONIK - GANT
 @Nombre    : SP_INICIAR
 @Autor     : Elvis.Betancur
 @Fecha     : 04/04/2018
 @Parametro : N/A
 @Retorno   : N/A
 @Proyecto  : Validaci�n Partidas abiertas
 @Versi�n   : N/A
 Objetivo   : Permite iniciar el proceso de validaci�n
 ******************************************************************************************
 @control de cambios realizados por desarrolladores
 ******************************************************************************************
 @Autor           @Fecha      @Modificaci�n
 Elvis.Betancur   04/04/2018  Se realiza la creaci�n del objeto de tipo p�blico.
 */ 
 
 lv_inactiva           varchar2(1); 
 lv_Cadena             varchar2(30);                                                                   
 lv_Fisca_Qx           varchar2(1); 
 lv_Nr_Qx              varchar2(3); 
 lv_Fecha_Qx           varchar2(10);
 lv_Resultado_Fisca_Qx varchar2(1); 
 ln_Posicion1          number:=0;
 ln_Posicion2          number:=0;
 ld_fechaLimite        date;
 
 Cursor lcur_partidas is
 Select Nro_Placa, Vigencia, Referencia_Inicial, Identificacion
 from Gant_Resultado
 Where Resultado = 'N'
   And Vigencia = GN_VIGENCIA;
   -- AND ROWNUM <1000
   --And Nro_placa  in('HCA255');
 
 Type tyPartidas is table of lcur_partidas%ROWTYPE;
 ArrayPartidas tyPartidas;
 
 BEGIN
   --Cargo los parametros
   SP_CARGARPARAMETROS(); 
   --Determino la fecha l�mite para los procesos fiscales
   ld_fechaLimite := ADD_MONTHS(GN_VENCE_VIGENCIA,GN_NOTIFICAR);
   
   Open lcur_partidas;
      Loop Fetch lcur_partidas
         Bulk collect into ArrayPartidas Limit GN_BLOQUE_PROCESO;         
            For lnIndex in 1..ArrayPartidas.count() Loop
            Begin
             -- Limpio e inicializo las variables 
                iv_Resultado          := 'N';  
                lv_inactiva           := 'N'; 
                lv_Cadena             := 'N';                                                                   
                lv_Fisca_Qx           := 'N'; 
                lv_Resultado_Fisca_Qx := 'N';
                lv_Nr_Qx              := null; 
                lv_Fecha_Qx           := null; 
                
                lv_Cadena := FT_EXISTE_FISCA_QX (ArrayPartidas(lnIndex).Nro_Placa,
                              ArrayPartidas(lnIndex).Identificacion);-- Existe fiscalizaci�n Qx
                              
                If Length(lv_Cadena)>1 then
                    ln_Posicion1 := instr(lv_Cadena,'-',1,1);
                    ln_Posicion2 := instr(lv_Cadena,'-',1,2);                    
                    lv_Fisca_Qx := Substr(lv_Cadena,1,ln_Posicion1-1);
                    lv_Nr_Qx    := Substr(lv_Cadena,(ln_Posicion1 + 1),(ln_Posicion2-3));
                    lv_Fecha_Qx := Substr(lv_Cadena,(ln_Posicion2 + 1),length(lv_Cadena));
                Else    
                    lv_Fisca_Qx := lv_Cadena; 
                End If;
                
                If(Length(lv_Fecha_Qx)>1)Then
                  If(To_Date(lv_Fecha_Qx)<ld_fechaLimite)Then
                    lv_Resultado_Fisca_Qx := 'S';
                  End IF;
                End If;
                
                Update Gant_Resultado 
                   Set Fiscalizacion_Qx = lv_Fisca_Qx, 
                       Nr_Qx = lv_Nr_Qx, 
                       Fecha_Nr_Qx = lv_Fecha_Qx,
                       Resultado_Con_Fiscalizacion_Qx = lv_Resultado_Fisca_Qx
                Where Referencia_Inicial = ArrayPartidas(lnIndex).Referencia_Inicial
                  And Nro_Placa = ArrayPartidas(lnIndex).Nro_Placa
                  And Vigencia = ArrayPartidas(lnIndex).Vigencia
                  And Identificacion = ArrayPartidas(lnIndex).Identificacion;
 
                 SP_COMMIT;--Confirmo la transacci�n
                -- SP_RESULTADO;
                EXCEPTION WHEN OTHERS THEN
                 SP_ERROR_PA ('',sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,'SP_CORRER_FISCA_QX');
                 sp_commit;
                 Continue;
                End; 
            End Loop;        
         Exit when ArrayPartidas.count()<=0;         
      End Loop;  
      Commit; 
 
 END SP_CORRER_FISCA_QX;

END PKG_VALIDACION_PA;

/
