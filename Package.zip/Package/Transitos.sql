--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type TP_ERROR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_TRANSITOS"."TP_ERROR" is Object (
Id_Error VARCHAR2(255 BYTE), 
Nombre_Error VARCHAR2(255 BYTE), 
Constructor Function Tp_Error Return Self As Result
);
/
CREATE OR REPLACE TYPE BODY "BD_TRANSITOS"."TP_ERROR" Is 
Constructor Function Tp_Error Return Self As Result Is 
    tp_Error_1 Tp_Error := Tp_Error(null,null);
        Begin
            Self := tp_Error_1;
            Return;
            End Tp_Error;
        End;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_ERROR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_TRANSITOS"."TP_LISTA_ERROR" Is table of Tp_Error;

/
--------------------------------------------------------
--  DDL for Procedure QAS_CARACTERISTICAS2
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BD_TRANSITOS"."QAS_CARACTERISTICAS2" AS 
Lv_Placa Varchar2(10);
LV_NOMBRE_MARCA Varchar2(10);
LV_NOMBRE_LINEA Varchar2(10);
LV_MODELO Varchar2(10);
LV_NOMBRE_CLASE Varchar2(10);
LV_NOMBRE_SERVICIO Varchar2(10);
LV_NOMBRE_CARROCERIA Varchar2(10);
LV_NRO_PUERTAS Varchar2(10);
LV_CILINDRAJE Varchar2(10);
LV_CAP_PASAJEROS Varchar2(10);
LV_CAP_TONELADAS Varchar2(10);
LV_ID_RADICADO Varchar2(10);
LV_NOMBRE Varchar2(10);
Ln_Contador Number := 0;

Cursor  consulta_placas Is
Select NRO_PLACA From CORRECCION_DATOS.QAS_CARACTERISTICAS;

Begin

For Ln_Index In consulta_placas Loop

Begin

select St.NRO_PLACA,
St.NOMBRE_MARCA,
St.NOMBRE_LINEA,
St.MODELO,
St.NOMBRE_CLASE,
St.NOMBRE_SERVICIO,
St.NOMBRE_CARROCERIA,
St.NRO_PUERTAS,
St.CILINDRAJE,
St.CAP_PASAJEROS,
St.CAP_TONELADAS,
St.ID_RADICADO,
ot.NOMBRE
INTO
LV_NOMBRE_MARCA,
LV_NOMBRE_LINEA,
LV_MODELO,
LV_NOMBRE_CLASE,
LV_NOMBRE_SERVICIO,
LV_NOMBRE_CARROCERIA,
LV_NRO_PUERTAS,
LV_CILINDRAJE,
LV_CAP_PASAJEROS,
LV_CAP_TONELADAS,
LV_ID_RADICADO,
LV_NOMBRETTO
from BD_TRANSITOS.ST_VEHICULOS St
Inner join BD_TRANSITOS.ST_MAESTRO M on M.Id_Radicado = St.Id_Radicado
Inner join correccion_datos.runt_organismos_tto Ot on ot.divipo = M.Id_Secretaria
where St.NRO_PLACA = Ln_Index.Nro_Placa;


Update CORRECCION_DATOS.QAS_CARACTERISTICAS Lt Set 
LT.NOMBRE_MARCA=LV_NOMBRE_MARCA,
LT.NOMBRE_LINEA=LV_NOMBRE_LINEA,
LT.MODELO=LV_MODELO,
LT.NOMBRE_CLASE=LV_NOMBRE_CLASE,
LT.NOMBRE_SERVICIO=LV_NOMBRE_SERVICIO,
LT.NOMBRE_CARROCERIA=LV_NOMBRE_CARROCERIA,
LT.NRO_PUERTAS=LV_NRO_PUERTAS,
LT.CILINDRAJE=LV_CILINDRAJE,
LT.CAP_PASAJEROS=LV_CAP_PASAJEROS,
LT.CAP_TONELADAS=LV_CAP_TONELADAS,
LT.ID_RADICADO=LV_ID_RADICADO,
LT.NOMBRE=LV_NOMBRETTO
Where Lt.Nro_Placa = Lv_Placa;


Exception
When Others Then

Update CORRECCION_DATOS.QAS_CARACTERISTICAS Lt  Set LT.NOMBRE_MARCA = 'NO ESTA EN BD'
Where LT.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END QAS_CARACTERISTICAS2;

/
--------------------------------------------------------
--  DDL for Procedure SHOW_FILE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BD_TRANSITOS"."SHOW_FILE" 
  IS
 almacenar UTL_FILE.FILE_TYPE := UTL_FILE.FOPEN ('INCONSISTENCIA_TTO', 'Example.txt','R');
      line VARCHAR2(2000):='';
  BEGIN
      LOOP
        UTL_FILE.GET_LINE (almacenar, line);
        Select Replace(line,';',''',''') Into line From Dual;
        
    END LOOP;
    
   EXCEPTION
     WHEN OTHERS THEN UTL_FILE.FCLOSE (almacenar);
  END;

/
--------------------------------------------------------
--  DDL for Procedure SP_PRUEBA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BD_TRANSITOS"."SP_PRUEBA" AS 

lNro_placa Varchar2(6 byte);
Marca Varchar2(255 byte);

BEGIN
Select Distinct Nro_Placa, Nombre_Marca Into lNro_placa, Marca From Arunt_Vehiculos
  Where Nro_Placa = 'TOW29E';
  
  Insert Into Tmp_Vehiculos (Nro_Placa)
  Values (lNro_placa);
END SP_PRUEBA;

/
--------------------------------------------------------
--  DDL for Package PKG_CONSULTA_SITT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_CONSULTA_SITT" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

END PKG_CONSULTA_SITT;

/
--------------------------------------------------------
--  DDL for Package PKG_CORRECCION_INCONSISTENCIAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_CORRECCION_INCONSISTENCIAS" AS 

/*ISVA
Nombre     :PKG_INCONSISTENCIAS_TRANSITOS
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :VN_RADICADO
Retorno    :           
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :valida las correcciones reportada por
           :los transitos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer);

END PKG_CORRECCION_INCONSISTENCIAS;

/
--------------------------------------------------------
--  DDL for Package PKG_DEPURAR_BD_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_DEPURAR_BD_RUNT" AS 

/*ISVA
Nombre     :PKG_DEPURAR_BD_TTO
Autor      :Blados.Ospina
Fecha      :15/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos Runt
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
15/06/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */
Procedure Sp_Inciar(an_Id_Radicado Number) ;

END PKG_DEPURAR_BD_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_DEPURAR_BD_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_DEPURAR_BD_TTO" AS 

/*ISVA
Nombre     :PKG_DEPURAR_BD_TTO
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_GENERAR_RADICADO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */

Procedure Sp_Inciar(as_Radicado Simple_Integer);

END PKG_DEPURAR_BD_TTO;

/
--------------------------------------------------------
--  DDL for Package PKG_INCONSISTENCIAS_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_INCONSISTENCIAS_RUNT" AS 

/*ISVA
Nombre     :PKG_INCONSISTENCIAS_RUNT
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :as_id_radicado
Retorno    :           
Proyecto   :PKG_INCONSISTENCIAS_RUNT
Versi�n    :1.0
Objetivo   :valida las correcciones reportada por
           :los transitos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                    */

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer);

END PKG_INCONSISTENCIAS_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_INCONSISTENCIAS_TRANSITOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_INCONSISTENCIAS_TRANSITOS" AS 

/*ISVA
Nombre     :PKG_INCONSISTENCIAS_TRANSITOS
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :VN_RADICADO
Retorno    :           
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :valida las correcciones reportada por
           :los transitos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer);

END PKG_INCONSISTENCIAS_TRANSITOS;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_NOVEDADES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_VALIDACION_NOVEDADES" AS 

PROCEDURE sp_iniciar(an_vigencia NUMBER);

END PKG_VALIDACION_NOVEDADES;

/
--------------------------------------------------------
--  DDL for Package PKG_VEHICULOS_NO_EXISTEN_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_TRANSITOS"."PKG_VEHICULOS_NO_EXISTEN_SAP" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
Procedure Sp_Placas_Not_Exists_Sap;
Function Ft_Validar_Novedades(lfPlaca Varchar2)return boolean;
Function Ft_Validar_Cambio_Cilindraje(lfPlaca varchar2) return boolean;
Function Ft_Validar_Cambio_Servicio(lfPlaca varchar2) return boolean;
END PKG_VEHICULOS_NO_EXISTEN_SAP;

/
--------------------------------------------------------
--  DDL for Package Body PKG_CONSULTA_SITT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_CONSULTA_SITT" AS

PROCEDURE SP_LLENAR_PLANTILLA AS

v_Existe Number :=0;
lv_Clase Varchar2(100);
lv_Cilindraje Varchar2(100);
lv_Servicio Varchar2(100);
lv_Modelo Varchar2(100);
lv_Tipo_Ingreso Varchar2(100);
lv_Fecha_Ingreso Varchar2(100);
lv_Id_Propietario Varchar2(100);
lv_Tipo_Documento Varchar2(100);
lv_Nombres Varchar2(100);
lv_Apellidos Varchar2(100);
lv_Fecha_Compra Varchar2(100);
lv_Tipo_Novedad1 Varchar2(100);
lv_Fecha_Novedad1 Varchar2(100);
lv_Adicional_Novedad1 Varchar2(100);
lv_Tipo_Novedad2 Varchar2(100);
lv_Fecha_Novedad2 Varchar2(100);
lv_Adicional_Novedad2 Varchar2(100);
lv_Tipo_Novedad3 Varchar2(100);
lv_Fecha_Novedad3 Varchar2(100);
lv_Adicional_Novedad3 Varchar2(100);
lv_Observacion Varchar2(100);

Cursor C_Registros Is
Select Nro_Placa From Tmp_Consulta;
BEGIN

FOR lnIndex in C_Registros loop

Select count(1) into v_Existe 
from st_vehiculos 
where nro_placa = lnIndex.nro_placa
  and Id_radicado != '16';

--Si solo existe un registro
if (v_Existe = 1 ) then
   --Capturo las caracteristicas
   Select nombre_clase, cilindraje, nombre_servicio, modelo
     into lv_Clase, lv_Cilindraje, lv_Servicio, lv_Modelo
   from st_vehiculos 
   where nro_placa = lnIndex.nro_placa and Id_radicado != '16';


    --valido y capturo el modo de ingreso
     select * 
       into lv_Tipo_Ingreso, lv_Fecha_Ingreso
     from (select nombre_tramite, fecha_tramite   
            from st_tramites
            where nro_placa = lnIndex.nro_placa
              and id_tramite in (9,10) and Id_radicado != '16'    
            Order by to_date(fecha_tramite) ASC) new_t
      where rownum = 1;
      
    --Ingreso el propietario
    --validamos si tiene traspaso
    Select count(1) into v_existe
    from st_historiales_traspaso
    where nro_placa = lnIndex.nro_placa;
    
    if (v_Existe > 0) then
    --Si tiene traspaso traigo el �ltimo propietario
      select *
        into lv_Id_Propietario, lv_Tipo_Documento, lv_Fecha_Compra, lv_Nombres,lv_Apellidos 
        from( Select sh.id_comprador, sh.tipo_documento_comprador, sh.fecha,
                     sc.nombres, sc.apellidos          
              from st_historiales_traspaso sh
              left join st_contribuyentes sc
                 on sc.id_usuario = sh.id_comprador
                and sc.id_documento = sh.tipo_documento_comprador
              where sh.nro_placa = lnIndex.nro_placa and sh.Id_radicado != '16'
              Order by to_date(sh.fecha) asc) new_t    
        where rownum = 1;    
      end if;  

end if;

End Loop;


END SP_LLENAR_PLANTILLA;
END PKG_CONSULTA_SITT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_CORRECCION_INCONSISTENCIAS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_CORRECCION_INCONSISTENCIAS" AS

iv_Transito Varchar2(255 Byte);
GS_RADICADO Simple_Integer:=0;

Procedure Sp_Registrar_Transito As

/*ISVA
Nombre     :Sp_Registrar_Transito
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Recupera el nombre del transito
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
iv_Transito:='';

    Select Distinct Fm.Municipio Into iv_Transito From St_Maestro Sm
    Inner Join Bd_Fiscalizacion.Fc_Municipio_Departamento Fm On Fm.Divipo = Sm.Id_Secretaria
    Where Id_Radicado = GS_RADICADO;

Exception 
    When Others Then 
    iv_Transito:='';    
    
End Sp_Registrar_Transito;

Procedure Sp_Inconsistencia_Tramites As

/*ISVA
Nombre     :Sp_Inconsistencia_Tramites
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los tramites
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CORRECION TRAMITES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

-- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_tramites Is 
        SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NRO_PLACA) > 6 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_TRAMITE
        SELECT   iv_Transito ,'Longitud ID_TRAMITE mayor a la permitida(4)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_TRAMITE) > 4 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_TRAMITE
        SELECT   iv_Transito ,'Longitud NOMBRE_TRAMITE mayor a la permitida(40)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_TRAMITE) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   iv_Transito ,'Longitud FECHA_TRAMITE mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   iv_Transito ,'Longitud FECHA_TRAMITE menor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) < 8 and ST_T.id_radicado = GS_RADICADO
        
        /*union
        
        -- VALIDO LONGITUD DE TIPO_CANCELACION
        SELECT   iv_Transito,'Longitud TIPO_CANCELACION mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*
        FROM TMP_TRAMITES ST_T
        where length (ST_T.TIPO_CANCELACION) > 8 and ST_T.id_radicado = GS_RADICADO*/
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_DESTINO
        SELECT   iv_Transito ,'Longitud ID_SECRETARIA_DESTINO mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_DESTINO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_ORIGEN
        SELECT  iv_Transito ,'Longitud ID_SECRETARIA_ORIGEN mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_ORIGEN) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_ANTERIOR
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_NUEVA
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA_NUEVA mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_NUEVA) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_NUEVA
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA_NUEVA mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_NUEVA) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_SERVICIO_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_NUEVO
        SELECT   iv_Transito ,'Longitud ID_SERVICIO_NUEVO mayor a la permitida(8)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_NUEVO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_NUEVO
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO_NUEVO mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_NUEVO) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_USUARIO_ANTERIOR mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_ANTERIOR) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_NUEVO
        SELECT   iv_Transito ,'Longitud ID_USUARIO_NUEVO mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_NUEVO) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.PORCENTAJE_PROP) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CLASICO_ANTIGUO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.BLINDADO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NIVEL_BLINDADO
        SELECT   iv_Transito ,'Longitud NIVEL_BLINDADO mayor a la permitida(2)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NIVEL_BLINDADO) > 2 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DESBLINDAJE
        SELECT   iv_Transito ,'Longitud DESBLINDAJE mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.DESBLINDAJE) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CILINDRAJE) > 10 and ST_T.id_radicado = GS_RADICADO
                
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_PASAJEROS) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_TONELADAS) > 6 and ST_T.id_radicado = GS_RADICADO
        
        
        --Pendiente validacion
        /*
        UNION
        
        Select iv_Transito Secretaria, 
               'Tramites No Reportados En Propietarios' Inconsistencia, 'Tramites' ARCHIVO, sv.*, sv.rowid
        from TMP_TRAMITES sv
        left join TMP_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        
       
        UNION
        
        Select iv_Transito Secretaria, 
               'Tramites No Reportados En Vehiculos' Inconsistencia, 'Tramites' ARCHIVO, st.*
        from TMP_TRAMITES st
        left join TMP_VEHICULOS sv on sv.nro_placa = st.nro_placa and sv.id_radicado = st.Id_radicado
        where sv.nro_placa is null and st.id_radicado = GS_RADICADO */
        
        union
        --Validaciones tramites.
        
        --Radicaciones Sin Id_Origen.
        Select iv_Transito Secretaria, 
               'Radicaciones Sin Id_Origen' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen is null
        
        
        union
        
        --Radicaciones Sin Id_Destino.
        Select  iv_Transito Secretaria, 
               'Radicaciones Sin Id_Destino' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Traslados Sin Id_Origen.
        Select iv_Transito Secretaria, 
               'Traslados Sin Id_Origen' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen Is Null
        
        
        union
        
        --Traslados Sin Id_Destino.
        Select  iv_Transito Secretaria, 
               'Traslados Sin Id_Destino' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Blindajes Sin Nivel Blindado.
        Select  iv_Transito Secretaria, 
               'Blindajes Sin Nivel Blindado' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 1 and St.id_radicado = GS_RADICADO
          And St.Blindado Is Not Null And St.Nivel_Blindado is null
        
        
        union
        
        --Transformacion Carroceria Carga Con Capacidad Casajeros > 3.
        Select   iv_Transito Secretaria,  
               'Transformacion Carroceria Carga Con Capacidad Casajeros > 3' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 14 and St.id_radicado = GS_RADICADO
          And St.Id_Carroceria_Nueva in('7','8','9','10','12','13','15','17','18','20','21','31','32','42','43',
                                        '44','45','47','58','60','70','78','79','80','83','84','96','98','104',
                                        '115','116','119','125','133','136','142','150','172','174','187','189',
                                        '192','193','196','197','198','199')
          And to_number(St.Cap_Pasajeros) > 3        
        
        
        union
        
        --Id_carroceria nueva != carroceria OC
        Select  iv_Transito Secretaria, 
               'Id_Carroceria Nueva Diferente a Carroceria OC' Inconsistencia,'VEHICULOS' ARCHIVO, St.* , st.rowid
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 14  and St.id_radicado = GS_RADICADO
          And SV.ID_CARROCERIA is not null
          And SV.ID_CARROCERIA != ST.ID_CARROCERIA_NUEVA
          And sv.id_radicado = st.id_radicado
        
        
        union
        
        --Porcentaje Traspaso Mayor a 100.
        Select  iv_Transito Secretaria, 
               'Porcentaje Traspaso Mayor a 100' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And to_number(replace(St.Porcentaje_Prop,'.','')) > 100
        
        
        union
        
        
        --Id_Comprador igual a Id_Vendedor
        Select iv_Transito Secretaria, 
               'Id_Comprador Igual a Id_Vendedor' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And ST.ID_USUARIO_nuevo = ST.ID_USUARIO_anterior
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select iv_Transito Secretaria, 
               'Id_Servicio_Anterior Igual a Id_Servicio_Nuevo' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And ST.ID_SERVICIO_ANTERIOR = ST.ID_SERVICIO_NUEVO
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select  iv_Transito Secretaria, 
               'Id_Servicio_Nuevo Diferente a Id_Servicio_Oc' Inconsistencia,'VEHICULOS' ARCHIVO, St.*, st.rowid
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And sv.ID_SERVICIO != ST.ID_SERVICIO_NUEVO
          And sv.id_radicado = st.id_radicado
        
        union
        
        --Carrocerias x clase tramites transformacion
        select  iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Tramites)' Inconsistencia, 'VEHICULOS' ARCHIVO, st.*, st.rowid 
        from TMP_VEHICULOS sv
        inner join TMP_TRAMITES st on st.nro_placa = sv.nro_placa AND SV.ID_RADICADO = ST.ID_RADICADO
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','')  and rc.codigo_carroceria_ws =REPLACE (st.ID_CARROCERIA_nueva,'.','') 
        where  st.id_tramite = 14 And RC.CODIGO_CARROCERIA_WS is null and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Tramite Null' Inconsistencia, 'TRAMITES' ARCHIVO, sv.*, sv.rowid
        from TMP_TRAMITES sv
        where  SV.Id_Tramite is null  and sv.id_radicado = GS_RADICADO;
        
Begin   
    lutl_archivo := UTL_FILE.FOPEN('DIR_CORECCION',lv_Archivo,'W');  
        For Ln_Index In lcur_tramites Loop   
        Begin
            
                If lb_Existe = False Then
                    UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_TRAMITE;'||'NOMBRE_TRAMITE;'
                                                ||'FECHA_TRAMITE;'||'TIPO_CANCELACION;'||'ID_SECRETARIA_DESTINO;'||'ID_SECRETARIA_ORIGEN;'
                                                ||'ID_CARROCERIA_ANTERIOR;'||'NOMBRE_CARROCERIA_ANTERIOR;'||'ID_CARROCERIA_NUEVA;'
                                                ||'NOMBRE_CARROCERIA_NUEVA;'||'ID_SERVICIO_ANTERIOR;'||'NOMBRE_SERVICIO_ANTERIOR;'
                                                ||'ID_SERVICIO_NUEVO;'||'NOMBRE_SERVICIO_NUEVO;'||'ID_DOCUMENTO_ANTERIOR;'||'ID_USUARIO_ANTERIOR;'
                                                ||'ID_DOCUMENTO_NUEVO;'||'ID_USUARIO_NUEVO;'||'PORCENTAJE_PROP;'||'CLASICO_ANTIGUO;'||'BLINDADO;'
                                                ||'NIVEL_BLINDADO;'||'DESBLINDAJE;'||'CILINDRAJE;'||'CAP_PASAJEROS;'||'CAP_TONELADAS;'||'ID_RADICADO');
                        lb_Existe:=True;
                 End If;
                UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                    ||Ln_Index.INCONSISTENCIA||';'
                    ||Ln_Index.ARCHIVO||';'
                    ||Ln_Index.NRO_PLACA||';'
                    ||Ln_Index.ID_TRAMITE||';'
                    ||Ln_Index.NOMBRE_TRAMITE||';'
                    ||Ln_Index.FECHA_TRAMITE||';'
                    ||Ln_Index.TIPO_CANCELACION||';'
                    ||Ln_Index.ID_SECRETARIA_DESTINO||';'
                    ||Ln_Index.ID_SECRETARIA_ORIGEN	||';'
                    ||Ln_Index.ID_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.ID_CARROCERIA_NUEVA||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_NUEVA||';'
                    ||Ln_Index.ID_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.ID_SERVICIO_NUEVO||';'
                    ||Ln_Index.NOMBRE_SERVICIO_NUEVO||';'
                    ||Ln_Index.ID_DOCUMENTO_ANTERIOR||';'
                    ||Ln_Index.ID_USUARIO_ANTERIOR||';'
                    ||Ln_Index.ID_DOCUMENTO_NUEVO||';'
                    ||Ln_Index.ID_USUARIO_NUEVO||';'
                    ||Ln_Index.PORCENTAJE_PROP||';'
                    ||Ln_Index.CLASICO_ANTIGUO||';'
                    ||Ln_Index.BLINDADO||';'
                    ||Ln_Index.NIVEL_BLINDADO||';'
                    ||Ln_Index.DESBLINDAJE||';'
                    ||Ln_Index.CILINDRAJE||';'
                    ||Ln_Index.CAP_PASAJEROS||';'
                    ||Ln_Index.CAP_TONELADAS||';'
                    ||Ln_Index.ID_RADICADO);   
                    
                    Delete From Tmp_Tramites
                    Where Rowid = ln_index.rowid;
                    
                    Exception 
                        When Others Then 
                            Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Sp_Vehiculos'); 
            End;
            End Loop;
        UTL_FILE.FCLOSE(lutl_archivo);
    End Sp_Inconsistencia_Tramites;

Procedure SP_Inconsistencia_Vehiculos As

/*ISVA
Nombre     :SP_Inconsistencia_Vehiculos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los vehiculos   
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CORRECCION VEHICULOS ' ||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;
        
        Cursor lcur_vehiculos Is 
            -- VALIDO LONGITUD DE NRO_PLACA
        SELECT  iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PLACA) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_MARCA
        SELECT   iv_Transito ,'Longitud ID_MARCA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_MARCA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_MARCA
        SELECT   iv_Transito ,'Longitud NOMBRE_MARCA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_MARCA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_LINEA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_LINEA
        SELECT   iv_Transito ,'Longitud NOMBRE_LINEA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_LINEA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE MODELO
        SELECT   iv_Transito ,'Longitud MODELO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CLASE
        SELECT   iv_Transito ,'Longitud ID_CLASE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CLASE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_LINEA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CLASE
        SELECT   iv_Transito ,'Longitud NOMBRE_CLASE mayor a la permitida(40)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CLASE) > 40 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_SERVICIO
        SELECT   iv_Transito ,'Longitud ID_SERVICIO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SERVICIO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SERVICIO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE ID_CARROCERIA
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CARROCERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CARROCERIA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_COMBUSTIBLE
        SELECT   iv_Transito ,'Longitud ID_COMBUSTIBLE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_COMBUSTIBLE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_BATERIA
        SELECT   iv_Transito ,'Longitud ID_BATERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_BATERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_BATERIA
        SELECT   iv_Transito ,'Longitud NOMBRE_BATERIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_BATERIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE POTENCIA
        SELECT   iv_Transito ,'Longitud POTENCIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.POTENCIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA
        SELECT   iv_Transito ,'Longitud ID_SECRETARIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SECRETARIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SECRETARIA
        SELECT   iv_Transito ,'Longitud NOMBRE_SECRETARIA mayor a la permitida(80)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SECRETARIA) > 80 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CILINDRAJE) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_TONELADAS) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE VALOR_FACTURA
        SELECT   iv_Transito ,'Longitud VALOR_FACTURA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.VALOR_FACTURA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.BLINDADO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE IMPORTADO_NACIONAL
        SELECT   iv_Transito ,'Longitud IMPORTADO_NACIONAL mayor a la permitida(2)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.IMPORTADO_NACIONAL) > 2 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_ESTADO
        SELECT   iv_Transito ,'Longitud ID_ESTADO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_ESTADO) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_ESTADO
        SELECT   iv_Transito ,'Longitud NOMBRE_ESTADO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_ESTADO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CLASICO_ANTIGUO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PUERTAS
        SELECT   iv_Transito ,'Longitud NRO_PUERTAS mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PUERTAS) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   iv_Transito ,'Longitud FECHA_MATRICULO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   iv_Transito ,'Longitud FECHA_MATRICULO menos a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 and ST_V.id_radicado =GS_RADICADO
        
        --Pendiente validacion
        /*
        union
        
        Select iv_Transito Secretaria, 
               'Vehiculos No Reportados En Tramites' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join TMP_TRAMITES st on st.nro_placa = sv.nro_placa and sv.id_radicado = st.Id_radicado
        where st.nro_placa is null and sv.id_radicado =GS_RADICADO */
        
        union
        
       --Pendiente por validar
      /*  Select  iv_Transito Secretaria,    
               'Vehiculos No Reportados En Propietarios' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join TMP_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado =GS_RADICADO
        
        union */
        
        --Carrocerias x clase Vehiculos
        select  iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Vehiculos)' Inconsistencia,'VEHICULOS' ARCHIVO, sv.* , sv.rowid
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null And Sv.Id_Carroceria is Not null and sv.id_radicado =GS_RADICADO 
        
        
        union
        
        --Lineas sin relacion a la marca transformacion
        select  iv_Transito As Secretaria, 
               'Linea Sin Relacion a La Marca' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null And Id_Linea is not null and sv.id_radicado =GS_RADICADO 
        
        union
        
        --Id_Marca con punto
        select  iv_Transito Secretaria, 
               'Id_Marca con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.id_marca like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select  iv_Transito Secretaria, 
               'Id_Linea con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.id_linea like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select iv_Transito Secretaria, 
               'Modelo con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.modelo like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --VALIDACION DE CAMPOS NULL
        
        select  iv_Transito Secretaria, 
               'Id_Marca Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Marca is null  and sv.id_radicado =GS_RADICADO 
        
        union
        
        select  iv_Transito Secretaria, 
               'Nro_placa Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  Sv.nro_placa is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Linea Null' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.id_linea is null  and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Modelo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Modelo is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Clase Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.ID_CLASE is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Servicio Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Servicio is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Carroceria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Carroceria is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Combustible Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Combustible is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Secretaria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Secretaria is null  and sv.id_radicado =GS_RADICADO
        
        union 
        select  iv_Transito Secretaria,
        'Cilindraje Null o Cero' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  (SV.Cilindraje  is null or SV.Cilindraje = 0) And Id_Combustible Not In (5)
        And sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Valor_Factura Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Valor_Factura is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select   iv_Transito Secretaria, 
               'Fecha_Matriculo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Fecha_Matriculo is null  and sv.id_radicado =GS_RADICADO;

Begin 
    lutl_archivo := UTL_FILE.FOPEN('DIR_CORECCION',lv_Archivo,'W');
        For Ln_Index In lcur_vehiculos Loop
            
        Begin
            If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'
                                                ||'ID_LINEA;'||'NOMBRE_LINEA;'||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'
                                                ||'NOMBRE_SERVICIO;'||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'
                                                ||'ID_COMBUSTIBLE;'||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'
                                                ||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'||'ID_ESTADO;'
                                                ||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'||'ID_RADICADO;'||'ID_MARCA2;'
                                                ||'ID_LINEA2;'||'CAJA;'||'TRACCION;'||'COMBUSTION');
                     lb_Existe:=True;
            End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
            ||Ln_Index.INCONSISTENCIA||';'
            ||Ln_Index.ARCHIVO||';'
            ||Ln_Index.NRO_PLACA||';'
            ||Ln_Index.ID_MARCA||';'
            ||Ln_Index.NOMBRE_MARCA||';'
            ||Ln_Index.ID_LINEA||';'
            ||Ln_Index.NOMBRE_LINEA||';'
            ||Ln_Index.MODELO||';'
            ||Ln_Index.ID_CLASE||';'
            ||Ln_Index.NOMBRE_CLASE||';'
            ||Ln_Index.ID_SERVICIO||';'
            ||Ln_Index.NOMBRE_SERVICIO||';'
            ||Ln_Index.ID_CARROCERIA||';'
            ||Ln_Index.NOMBRE_CARROCERIA||';'
            ||Ln_Index.NRO_PUERTAS||';'
            ||Ln_Index.ID_COMBUSTIBLE||';'
            ||Ln_Index.NOMBRE_COMBUSTIBLE||';'
            ||Ln_Index.ID_BATERIA||';'
            ||Ln_Index.NOMBRE_BATERIA||';'
            ||Ln_Index.POTENCIA||';'
            ||Ln_Index.ID_SECRETARIA||';'
            ||Ln_Index.NOMBRE_SECRETARIA||';'
            ||Ln_Index.CILINDRAJE||';'
            ||Ln_Index.CAP_PASAJEROS||';'
            ||Ln_Index.CAP_TONELADAS||';'
            ||Ln_Index.VALOR_FACTURA||';'
            ||Ln_Index.BLINDADO||';'
            ||Ln_Index.IMPORTADO_NACIONAL||';'
            ||Ln_Index.ID_ESTADO||';'
            ||Ln_Index.NOMBRE_ESTADO||';'
            ||Ln_Index.CLASICO_ANTIGUO||';'
            ||Ln_Index.FECHA_MATRICULO||';'
            ||Ln_Index.ID_RADICADO||';'
            ||Ln_Index.ID_MARCA2||';'
            ||Ln_Index.ID_LINEA2||';'
            ||Ln_Index.CAJA||';'
            ||Ln_Index.TRACCION||';'
            ||Ln_Index.COMBUSTION);
                
                Delete From tmp_vehiculos
                Where Rowid = Ln_Index.rowid;
            
            Exception 
                When Others Then 
                    Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Sp_Vehiculos'); 
        End;   
        End Loop;
        Commit;
         UTL_FILE.FCLOSE(lutl_archivo); 
         
END Sp_Inconsistencia_Vehiculos;

Procedure Sp_Inconsistencia_Contribuyent As

/*ISVA
Nombre     :Sp_Inconsistencia_Contribuyent
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los contribuyentes
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CORRECCION CONTRIBUYENTES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

    -- VALIDO LONGITUD DE ID_USUARIO
        Cursor lcur_contribuyentes Is
        SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_USUARIO) > 15 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DOCUMENTO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD
        SELECT   iv_Transito ,'Longitud ID_CIUDAD mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD
        SELECT   iv_Transito ,'Longitud NOMBRE_CIUDAD mayor a la permitida(30)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD) > 30 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE APELLIDOS
        SELECT   iv_Transito ,'Longitud APELLIDOS mayor a la permitida(80)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.APELLIDOS) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRES
        SELECT   iv_Transito ,'Longitud NOMBRES mayor a la permitida(80)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRES) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DIRECCION
        SELECT   iv_Transito ,'Longitud DIRECCION mayor a la permitida(100)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.DIRECCION) > 100 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   iv_Transito ,'Longitud TELEFONO mayor a la permitida(14)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) > 14 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   iv_Transito ,'Longitud TELEFONO MENOR a la permitida(7)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) < 7 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   iv_Transito ,'Longitud CELULAR mayor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) > 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   iv_Transito ,'Longitud CELULAR menor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) < 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMP_O_PART
        SELECT   iv_Transito ,'Longitud EMP_O_PART mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMP_O_PART) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE SEXO
        SELECT   iv_Transito ,'Longitud SEXO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.SEXO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   iv_Transito ,'Longitud FECHA_NACIMIENTO mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   iv_Transito ,'Longitud FECHA_NACIMIENTO menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_PAIS
        SELECT   iv_Transito ,'Longitud ID_PAIS mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_PAIS) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE NOMBRE_PAIS
        SELECT   iv_Transito ,'Longitud NOMBRE_PAIS mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_PAIS) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   iv_Transito ,'Longitud FECHA_MODIFICACION mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   iv_Transito ,'Longitud FECHA_MODIFICACION menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FAX
        SELECT   iv_Transito ,'Longitud FAX mayor a la permitida(12)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FAX) > 12 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT   iv_Transito ,'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   iv_Transito ,'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   iv_Transito ,'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD_DIR
        SELECT   iv_Transito ,'Longitud ID_CIUDAD_DIR mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD_DIR) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD_DIR
        SELECT   iv_Transito ,'Longitud NOMBRE_CIUDAD_DIR mayor a la permitida(40)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD_DIR) > 40 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DIRECCION
        SELECT   iv_Transito ,'Longitud ID_DIRECCION mayor a la permitida(20)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DIRECCION) > 20 and ST_C.id_radicado = GS_RADICADO
        
        
        union 
        
        /*CONTRIBUYENTES*/
        select iv_Transito Secretaria, 
               'Id_Ciudad No Existe en Runt' Inconsistencia, 'Contribuyentes' ARCHIVO,sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        left join CORRECCION_DATOS.runt_ciudades rl
                on rl.divipo = sv.ID_CIUDAD_DIR 
        where rl.nombre = '' and sv.id_radicado = GS_RADICADO  
        
        union 
        
        select  iv_Transito Secretaria, 
               'Nombres Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Nombres is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Apellidos Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Apellidos is null And sv.Id_Documento != 'N' and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Direccion Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Direccion is null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
         validacion de telefono y celular pendiente por activar esta validacion
        
        select  iv_Transito Secretaria, 
               'Telefono Null y Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Telefono is null And SV.Celular is Null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
        select  sv.Id_Radicado, iv_Transito Secretaria, 
               'Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Celular is null  and sv.id_radicado = GS_RADICADO 
        
        union 
        
        select  sv.Id_Radicado, iv_Transito Secretaria, 
               'Email Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Email is null  and sv.id_radicado = GS_RADICADO */
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Ciudad_Dir Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Id_Ciudad_Dir is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO;

Begin
     lutl_archivo := UTL_FILE.FOPEN('DIR_CORECCION',lv_Archivo,'W');  
        For ln_index In lcur_contribuyentes Loop
        
          If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'ID_USUARIO;'||'ID_DOCUMENTO;'
                            ||'ID_CIUDAD;'||'NOMBRE_CIUDAD;'||'APELLIDOS;'||'NOMBRES;'||'DIRECCION;'||'TELEFONO;'||'MP_O_PART;'||'SEXO;'
                            ||'FECHA_NACIMIENTO;'||'ID_PAIS;'||'NOMBRE_PAIS;'||'FECHA_MODIFICACION;'||'FAX;'||'EMAIL;'||'FECHA_ACTUALIZACION;'
                            ||'ID_CIUDAD_DIR;'||'NOMBRE_CIUDAD_DIR;'||'ID_DIRECCION;'||'ID_RADICADO;'||'CELULAR');                     
                        lb_Existe:=True;
         End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||ln_index.Inconsistencia ||';'
                ||ln_index.archivo||';'
                ||ln_index.id_usuario||';'
                ||ln_index.id_documento||';'
                ||ln_index.id_ciudad||';'
                ||ln_index.nombre_ciudad||';'
                ||ln_index.apellidos||';'
                ||ln_index.nombres||';'
                ||ln_index.direccion||';'
                ||ln_index.telefono||';'
                ||ln_index.emp_o_part||';'
                ||ln_index.sexo||';'
                ||ln_index.fecha_nacimiento||';'
                ||ln_index.Id_Pais||';'
                ||ln_index.nombre_pais||';'
                ||ln_index.fecha_modificacion||';'
                ||ln_index.fax||';'
                ||ln_index.email||';'
                ||ln_index.fecha_actualizacion||';'
                ||ln_index.id_ciudad_dir||';'
                ||ln_index.nombre_ciudad_dir||';'
                ||ln_index.id_direccion||';'
                ||ln_index.id_radicado||';'
                ||ln_index.celular);
                
                Delete from tmp_contribuyentes
                where rowid = ln_index.rowid;
        End Loop;
            UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Contribuyent;

Procedure Sp_Inconsistencia_Propietarios As

/*ISVA
Nombre     :Sp_Inconsistencia_Propietarios
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los propietarios
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CORRECIONES PROPIETARIOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

      -- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_propietarios Is
        SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.NRO_PLACA) > 6 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_USUARIO) > 15 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_DOCUMENTO) > 1 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA, 'PROPIETARIOS' as ARCHIVO,ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        /*
        UNION
        
        Select  iv_Transito Secretaria, 
               'Propietarios No Reportados En Vehiculos' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_VEHICULOS sv on sp.nro_placa = sv.nro_placa and sp.id_radicado = sv.Id_radicado
        where sv.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select   iv_Transito Secretaria, 
               'Propietarios No Reportados En Tramites' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_TRAMITES st on sp.nro_placa = st.nro_placa and sp.id_radicado = st.Id_radicado
        where st.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select  iv_Transito Secretaria, 
               'Propietarios No Reportados En Contribuyentes' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_CONTRIBUYENTES sc on Sp.Id_Usuario = Sc.Id_Usuario And Sp.Id_Documento = Sc.Id_Documento and sp.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sp.id_radicado = GS_RADICADO
        */
        union
         
        
        select  iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia,'PROPIETARIOS' ARCHIVO, sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select   iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select  iv_Transito Secretaria, 
               'Porcentaje_Propiedad Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Porcentaje_Prop is null  and sv.id_radicado = GS_RADICADO;
Begin
     lutl_archivo := UTL_FILE.FOPEN('DIR_CORECCION',lv_Archivo,'W');  
      For ln_index In lcur_propietarios Loop
             If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                               ||'ID_DOCUMENTO;'||'PORCENTAJE_PROP;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.id_documento||';'
                ||Ln_Index.porcentaje_prop||';'
                ||Ln_Index.id_radicado);
                
                Delete From Tmp_Propietarios
                Where Rowid = ln_index.rowid;
    End Loop;
         UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Propietarios;

Procedure Sp_Validar_Histo_Traspasos As

/*ISVA
Nombre     :Sp_Validar_Histo_Traspasos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los historiales traspasos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CORRECCION HISTORIALES_TRASPASOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

  -- VALIDO LONGITUD DE NRO_PLACA
            Cursor lcur_histo_Tras Is
            -- VALIDO LONGITUD DE NRO_PLACA
            SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.NRO_PLACA) > 6 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE ID_USUARIO
            SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.ID_USUARIO) > 15 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE TIPO_DOCUMENTO_USUARIO
            SELECT   iv_Transito ,'Longitud TIPO_DOCUMENTO_USUARIO mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.TIPO_DOCUMENTO_USUARIO) > 1 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE ID_COMPRADOR
            SELECT   iv_Transito ,'Longitud ID_COMPRADOR mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.ID_COMPRADOR) > 15 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE TIPO_DOCUMENTO_COMPRADOR
            SELECT   iv_Transito ,'Longitud TIPO_DOCUMENTO_COMPRADOR mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.TIPO_DOCUMENTO_COMPRADOR) > 1 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE PORCENTAJE
            SELECT   iv_Transito ,'Longitud PORCENTAJE mayor a la permitida(3)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.PORCENTAJE) > 3 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE FECHA
            SELECT   iv_Transito ,'Longitud FECHA diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA) < 8);
            /*
            UNION
            
            Select Distinct iv_Transito Secretaria, 
                   'Vendedores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from TMP_HISTORIALES_TRASPASO sh
            left join tmp_contribuyentes sc on Sh.Id_Usuario = Sc.Id_Usuario And Sh.TIPO_DOCUMENTO_USUARIO = sc.ID_DOCUMENTO and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
            
            
            UNION
            
            Select Distinct iv_Transito Secretaria, 
                   'Compradores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from TMP_HISTORIALES_TRASPASO sh
            left join tmp_contribuyentes sc on Sc.Id_Usuario = Sh.ID_COMPRADOR And Sc.Id_Documento = Sh.TIPO_DOCUMENTO_COMPRADOR and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO;
            
                */
Begin 
         lutl_archivo := UTL_FILE.FOPEN('DIR_CORECCION',lv_Archivo,'W');  
        For ln_index In lcur_Histo_Tras Loop
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                                        ||'TIPO_DOCUMENTO_USUARIO;'||'ID_COMPRADOR;'||'TIPO_DOCUMENTO_COMPRADOR;'
                                                        ||'PORCENTAJE;'||'FECHA;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.tipo_documento_usuario||';'
                ||Ln_Index.id_comprador||';'
                ||Ln_Index.tipo_documento_comprador||';'
                ||Ln_Index.porcentaje||';'
                ||Ln_Index.fecha||';'
                ||Ln_Index.id_radicado);
                
                Delete from tmp_historiales_traspaso
                Where rowid = ln_index.rowid;
        End Loop;
    UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Validar_Histo_Traspasos;

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer) AS

/*ISVA
Nombre     :Sp_Iniciar_Inconsistencia
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Ejecuta todos los procesos del pl-sql
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

BEGIN

GS_RADICADO := as_id_radicado;

    Sp_Registrar_Transito;
    SP_Inconsistencia_Vehiculos;
    Sp_Inconsistencia_Tramites;
    Sp_Inconsistencia_Propietarios;
    Sp_Inconsistencia_Contribuyent;
    Sp_Validar_Histo_Traspasos;
    
END Sp_Iniciar_Inconsistencia;

END PKG_CORRECCION_INCONSISTENCIAS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DEPURAR_BD_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_DEPURAR_BD_RUNT" AS

Procedure Sp_Cargar_Vehiculos (an_Id_Radicado number) is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Blados.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la tabla arunt_vehiculos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.0                      */

lnExiste number :=0;

Cursor curVehiculos is
Select Distinct * from arunt_vehiculos_tmp Where Id_Radicado = an_Id_Radicado;

type tableCursor is Table of curVehiculos%RowType;
arrayVehiculo tableCursor;

Begin

Open curVehiculos;
  Loop fetch curVehiculos
    Bulk Collect Into arrayVehiculo Limit 500;
    
    For lnIndex in 1..arrayVehiculo.Count() Loop
      Select count(1) Into lnExiste
      From arunt_vehiculos
      Where Nro_Placa = arrayVehiculo(lnIndex).Nro_Placa And           
            (Id_Marca = arrayVehiculo(lnIndex).Id_Marca or (Id_Marca is null and arrayVehiculo(lnIndex).Id_Marca is null)) And
            (Nombre_Marca = arrayVehiculo(lnIndex).Nombre_Marca or (Nombre_Marca is null and arrayVehiculo(lnIndex).Nombre_Marca is null)) And
            (Id_Linea = arrayVehiculo(lnIndex).Id_Linea or (Id_Linea is null and arrayVehiculo(lnIndex).Id_Linea is null)) And
            (Nombre_Linea = arrayVehiculo(lnIndex).Nombre_Linea or (Nombre_Linea is null and arrayVehiculo(lnIndex).Nombre_Linea is null)) And
            (Modelo = arrayVehiculo(lnIndex).Modelo or (Modelo is null and arrayVehiculo(lnIndex).Modelo is null)) And
            (Id_Clase = arrayVehiculo(lnIndex).Id_Clase or (Id_Clase is null and arrayVehiculo(lnIndex).Id_Clase is null)) And
            (Nombre_Clase = arrayVehiculo(lnIndex).Nombre_Clase or (Nombre_Clase is null and arrayVehiculo(lnIndex).Nombre_Clase is null)) And
            (Id_Servicio = arrayVehiculo(lnIndex).Id_Servicio or (Id_Servicio is null and arrayVehiculo(lnIndex).Id_Servicio is null)) And
            (Nombre_Servicio = arrayVehiculo(lnIndex).Nombre_Servicio or (Nombre_Servicio is null and arrayVehiculo(lnIndex).Nombre_Servicio is null)) And
            (Id_Carroceria = arrayVehiculo(lnIndex).Id_Carroceria or (Id_Carroceria is null and arrayVehiculo(lnIndex).Id_Carroceria is null)) And
            (Nombre_Carroceria = arrayVehiculo(lnIndex).Nombre_Carroceria or (Nombre_Carroceria is null and arrayVehiculo(lnIndex).Nombre_Carroceria is null)) And
            (Nro_Puertas = arrayVehiculo(lnIndex).Nro_Puertas or (Nro_Puertas is null and arrayVehiculo(lnIndex).Nro_Puertas is null)) And
            (Id_Combustible = arrayVehiculo(lnIndex).Id_Combustible or (Id_Combustible is null and arrayVehiculo(lnIndex).Id_Combustible is null)) And
            (Nombre_Combustible = arrayVehiculo(lnIndex).Nombre_Combustible or (Nombre_Combustible is null and arrayVehiculo(lnIndex).Nombre_Combustible is null)) And
            (Id_Bateria = arrayVehiculo(lnIndex).Id_Bateria or (Id_Bateria is null and arrayVehiculo(lnIndex).Id_Bateria is null)) And
            (Nombre_Bateria = arrayVehiculo(lnIndex).Nombre_Bateria or (Nombre_Bateria is null and arrayVehiculo(lnIndex).Nombre_Bateria is null)) And
            (Potencia = arrayVehiculo(lnIndex).Potencia or (Potencia is null and arrayVehiculo(lnIndex).Potencia is null)) And
            (Id_Secretaria = arrayVehiculo(lnIndex).Id_Secretaria or (Id_Secretaria is null and arrayVehiculo(lnIndex).Id_Secretaria is null)) And
            (Nombre_Secretaria = arrayVehiculo(lnIndex).Nombre_Secretaria or (Nombre_Secretaria is null and arrayVehiculo(lnIndex).Nombre_Secretaria is null)) And
            (Cilindraje = arrayVehiculo(lnIndex).Cilindraje or (Cilindraje is null and arrayVehiculo(lnIndex).Cilindraje is null)) And
            (Cap_Pasajeros = arrayVehiculo(lnIndex).Cap_Pasajeros or (Cap_Pasajeros is null and arrayVehiculo(lnIndex).Cap_Pasajeros is null)) And
            (Cap_Toneladas = arrayVehiculo(lnIndex).Cap_Toneladas or (Cap_Toneladas is null and arrayVehiculo(lnIndex).Cap_Toneladas is null)) And
            (Valor_Factura = arrayVehiculo(lnIndex).Valor_Factura or (Valor_Factura is null and arrayVehiculo(lnIndex).Valor_Factura is null)) And
            (Blindado = arrayVehiculo(lnIndex).Blindado or (Blindado is null and arrayVehiculo(lnIndex).Blindado is null)) And
            (Importado_Nacional = arrayVehiculo(lnIndex).Importado_Nacional or (Importado_Nacional is null and arrayVehiculo(lnIndex).Importado_Nacional is null)) And
            (Id_Estado = arrayVehiculo(lnIndex).Id_Estado or (Id_Estado is null and arrayVehiculo(lnIndex).Id_Estado is null)) And
            (Nombre_Estado = arrayVehiculo(lnIndex).Nombre_Estado or (Nombre_Estado is null and arrayVehiculo(lnIndex).Nombre_Estado is null)) And
            (Clasico_Antiguo = arrayVehiculo(lnIndex).Clasico_Antiguo or (Clasico_Antiguo is null and arrayVehiculo(lnIndex).Clasico_Antiguo is null)) And
            (Fecha_Matriculo = arrayVehiculo(lnIndex).Fecha_Matriculo or (Fecha_Matriculo is null and arrayVehiculo(lnIndex).Fecha_Matriculo is null)) And
            (Caja = arrayVehiculo(lnIndex).Caja or (Caja is null and arrayVehiculo(lnIndex).Caja is null)) And
            (Traccion = arrayVehiculo(lnIndex).Traccion or (Traccion is null and arrayVehiculo(lnIndex).Traccion is null)) And
            (Combustion = arrayVehiculo(lnIndex).Combustion or (Combustion is null and arrayVehiculo(lnIndex).Combustion is null)) And 
            (Watt = arrayVehiculo(lnIndex).Watt or (Watt is null and arrayVehiculo(lnIndex).Watt is null));

            
       If (lnExiste <= 0) Then
        insert into arunt_vehiculos (Nro_Placa,
                                  Id_Marca,
                                  Nombre_Marca,
                                  Id_Linea, 
                                  Nombre_Linea, 
                                  Modelo, Id_Clase, 
                                  Nombre_Clase, 
                                  Id_Servicio, 
                                  Nombre_Servicio, 
                                  Id_Carroceria, 
                                  Nombre_Carroceria,
                                  Nro_Puertas, 
                                  Id_Combustible, 
                                  Nombre_Combustible, 
                                  Id_Bateria,
                                  Nombre_Bateria, 
                                  Potencia,
                                  Id_Secretaria, 
                                  Nombre_Secretaria, 
                                  Cilindraje,
                                  Cap_Pasajeros, 
                                  Cap_Toneladas, 
                                  Valor_Factura,
                                  Blindado, 
                                  Importado_Nacional,
                                  Id_Estado, Nombre_Estado, 
                                  Clasico_Antiguo, 
                                  Fecha_Matriculo, 
                                  Caja, Traccion,
                                  Combustion, 
                                  Watt,
                                  Id_Radicado) 
                           values(arrayVehiculo(lnIndex).Nro_Placa, 
                                  arrayVehiculo(lnIndex).Id_Marca, 
                                  arrayVehiculo(lnIndex).Nombre_Marca, 
                                  arrayVehiculo(lnIndex).Id_Linea, 
                                  arrayVehiculo(lnIndex).Nombre_Linea,
                                  arrayVehiculo(lnIndex).Modelo, 
                                  arrayVehiculo(lnIndex).Id_Clase,
                                  arrayVehiculo(lnIndex).Nombre_Clase,
                                  arrayVehiculo(lnIndex).Id_Servicio, 
                                  arrayVehiculo(lnIndex).Nombre_Servicio,
                                  arrayVehiculo(lnIndex).Id_Carroceria, 
                                  arrayVehiculo(lnIndex).Nombre_Carroceria, 
                                  arrayVehiculo(lnIndex).Nro_Puertas,
                                  arrayVehiculo(lnIndex).Id_Combustible,
                                  arrayVehiculo(lnIndex).Nombre_Combustible, 
                                  arrayVehiculo(lnIndex).Id_Bateria, 
                                  arrayVehiculo(lnIndex).Nombre_Bateria,
                                  arrayVehiculo(lnIndex).Potencia, 
                                  arrayVehiculo(lnIndex).Id_Secretaria, 
                                  arrayVehiculo(lnIndex).Nombre_Secretaria, 
                                  arrayVehiculo(lnIndex).Cilindraje, 
                                  arrayVehiculo(lnIndex).Cap_Pasajeros, 
                                  arrayVehiculo(lnIndex).Cap_Toneladas, 
                                  arrayVehiculo(lnIndex).Valor_Factura, 
                                  arrayVehiculo(lnIndex).Blindado, 
                                  arrayVehiculo(lnIndex).Importado_Nacional,
                                  arrayVehiculo(lnIndex).Id_Estado, 
                                  arrayVehiculo(lnIndex).Nombre_Estado,
                                  arrayVehiculo(lnIndex).Clasico_Antiguo, 
                                  arrayVehiculo(lnIndex).Fecha_Matriculo, 
                                  arrayVehiculo(lnIndex).Caja, 
                                  arrayVehiculo(lnIndex).Traccion, 
                                  arrayVehiculo(lnIndex).Combustion,
                                  arrayVehiculo(lnIndex).Watt,
                                  an_Id_Radicado);      
       End if;
    End Loop;
    Exit When arrayVehiculo.count()<=0;
    Commit;
  End Loop;  
  Commit;

End Sp_Cargar_Vehiculos;

Procedure Sp_Carga_Tramites (an_Id_Radicado number) is

/*ISVA
Nombre     :Sp_Cargar_Tramites
Autor      :Blados.Ospina
Fecha      :15/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la tabla arunt_tramites
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
15/06/2018  Blados.Ospina   1.0                  */
lnExiste number :=0;

Cursor curTramites is
Select Distinct * from arunt_tramites_tmp Where Id_Radicado = an_Id_Radicado;

type tableCur is table of curTramites%RowType;
arrayTramites tableCur;

Begin

Open curTramites;
  Loop fetch curTramites
    Bulk Collect into arrayTramites Limit 500;
      For lnIndex in 1..arrayTramites.Count() Loop
        
        Select Count(1) Into lnExiste
        From arunt_tramites
        Where Nro_Placa = arrayTramites(lnIndex).Nro_Placa And
              (Id_Tramite = arrayTramites(lnIndex).Id_Tramite or (Id_Tramite is null and arrayTramites(lnIndex).Id_Tramite is null)) And
              (Nombre_Tramite = arrayTramites(lnIndex).Nombre_Tramite or (Nombre_Tramite is null and arrayTramites(lnIndex).Nombre_Tramite is null)) And
              (Fecha_Tramite = arrayTramites(lnIndex).Fecha_Tramite or (Fecha_Tramite is null and arrayTramites(lnIndex).Fecha_Tramite is null)) And
              (Tipo_Cancelacion = arrayTramites(lnIndex).Tipo_Cancelacion or (Tipo_Cancelacion is null and arrayTramites(lnIndex).Tipo_Cancelacion is null)) And
              (Id_Secretaria_Destino = arrayTramites(lnIndex).Id_Secretaria_Destino or (Id_Secretaria_Destino is null and arrayTramites(lnIndex).Id_Secretaria_Destino is null)) And
              (Id_Secretaria_Origen = arrayTramites(lnIndex).Id_Secretaria_Origen or (Id_Secretaria_Origen is null and arrayTramites(lnIndex).Id_Secretaria_Origen is null)) And
              (Id_Carroceria_Anterior = arrayTramites(lnIndex).Id_Carroceria_Anterior or (Id_Carroceria_Anterior is null and arrayTramites(lnIndex).Id_Carroceria_Anterior is null)) And
              (Nombre_Carroceria_Anterior = arrayTramites(lnIndex).Nombre_Carroceria_Anterior or (Nombre_Carroceria_Anterior is null and arrayTramites(lnIndex).Nombre_Carroceria_Anterior is null)) And
              (Id_Carroceria_Nueva = arrayTramites(lnIndex).Id_Carroceria_Nueva or (Id_Carroceria_Nueva is null and arrayTramites(lnIndex).Id_Carroceria_Nueva is null)) And
              (Nombre_Carroceria_Nueva = arrayTramites(lnIndex).Nombre_Carroceria_Nueva or (Nombre_Carroceria_Nueva is null and arrayTramites(lnIndex).Nombre_Carroceria_Nueva is null)) And
              (Id_Servicio_Anterior = arrayTramites(lnIndex).Id_Servicio_Anterior or (Id_Servicio_Anterior is null and arrayTramites(lnIndex).Id_Servicio_Anterior is null)) And
              (Nombre_Servicio_Anterior = arrayTramites(lnIndex).Nombre_Servicio_Anterior or (Nombre_Servicio_Anterior is null and arrayTramites(lnIndex).Nombre_Servicio_Anterior is null)) And
              (Id_Servicio_Nuevo = arrayTramites(lnIndex).Id_Servicio_Nuevo or (Id_Servicio_Nuevo is null and arrayTramites(lnIndex).Id_Servicio_Nuevo is null)) And
              (Nombre_Servicio_Nuevo = arrayTramites(lnIndex).Nombre_Servicio_Nuevo or (Nombre_Servicio_Nuevo is null and arrayTramites(lnIndex).Nombre_Servicio_Nuevo is null)) And
              (Id_Documento_Anterior = arrayTramites(lnIndex).Id_Documento_Anterior or (Id_Documento_Anterior is null and arrayTramites(lnIndex).Id_Documento_Anterior is null)) And
              (Id_Usuario_Anterior = arrayTramites(lnIndex).Id_Usuario_Anterior or (Id_Usuario_Anterior is null and arrayTramites(lnIndex).Id_Usuario_Anterior is null)) And
              (Id_Documento_Nuevo = arrayTramites(lnIndex).Id_Documento_Nuevo or (Id_Documento_Nuevo is null and arrayTramites(lnIndex).Id_Documento_Nuevo is null)) And
              (Id_Usuario_Nuevo = arrayTramites(lnIndex).Id_Usuario_Nuevo or (Id_Usuario_Nuevo is null and arrayTramites(lnIndex).Id_Usuario_Nuevo is null)) And
              (Porcentaje_Prop = arrayTramites(lnIndex).Porcentaje_Prop or (Porcentaje_Prop is null and arrayTramites(lnIndex).Porcentaje_Prop is null)) And
              (Clasico_Antiguo = arrayTramites(lnIndex).Clasico_Antiguo or (Clasico_Antiguo is null and arrayTramites(lnIndex).Clasico_Antiguo is null)) And
              (Blindado = arrayTramites(lnIndex).Blindado or (Blindado is null and arrayTramites(lnIndex).Blindado is null)) And
              (Nivel_Blindado = arrayTramites(lnIndex).Nivel_Blindado or (Nivel_Blindado is null and arrayTramites(lnIndex).Nivel_Blindado is null)) And
              (Desblindaje = arrayTramites(lnIndex).Desblindaje or (Desblindaje is null and arrayTramites(lnIndex).Desblindaje is null)) And
              (Cilindraje = arrayTramites(lnIndex).Cilindraje or (Cilindraje is null and arrayTramites(lnIndex).Cilindraje is null)) And
              (Cap_Pasajeros = arrayTramites(lnIndex).Cap_Pasajeros or (Cap_Pasajeros is null and arrayTramites(lnIndex).Cap_Pasajeros is null)) And
              (Cap_Toneladas = arrayTramites(lnIndex).Cap_Toneladas or (Cap_Toneladas is null and arrayTramites(lnIndex).Cap_Toneladas is null)) And
              (cilindraje_anterior = arrayTramites(lnIndex).cilindraje_anterior or (cilindraje_anterior is null and arrayTramites(lnIndex).cilindraje_anterior is null)) And
              (Cap_pasajeros_anterior = arrayTramites(lnIndex).Cap_pasajeros_anterior or (Cap_pasajeros_anterior is null and arrayTramites(lnIndex).Cap_pasajeros_anterior is null)) And
              (Cap_toneladas_anterior = arrayTramites(lnIndex).Cap_toneladas_anterior or (Cap_toneladas_anterior is null and arrayTramites(lnIndex).Cap_toneladas_anterior is null));

      If(lnExiste <= 0) then
        Insert Into arunt_Tramites(Nro_Placa, 
                                Id_Tramite, 
                                Nombre_Tramite, 
                                Fecha_Tramite, 
                                Tipo_Cancelacion, 
                                Id_Secretaria_Destino, 
                                Id_Secretaria_Origen, 
                                Id_Carroceria_Anterior, 
                                Nombre_Carroceria_Anterior, 
                                Id_Carroceria_Nueva, 
                                Nombre_Carroceria_Nueva, 
                                Id_Servicio_Anterior, 
                                Nombre_Servicio_Anterior, 
                                Id_Servicio_Nuevo, 
                                Nombre_Servicio_Nuevo, 
                                Id_Documento_Anterior, 
                                Id_Usuario_Anterior, 
                                Id_Documento_Nuevo, 
                                Id_Usuario_Nuevo, 
                                Porcentaje_Prop, 
                                Clasico_Antiguo, 
                                Blindado, 
                                Nivel_Blindado, 
                                Desblindaje, 
                                Cilindraje, 
                                Cap_Pasajeros, 
                                Cap_Toneladas,
                                cilindraje_anterior,
                                Cap_pasajeros_anterior,
                                Cap_toneladas_anterior,
                                Id_Radicado) 
                         Values(arrayTramites(lnIndex).Nro_Placa,
                                arrayTramites(lnIndex).Id_Tramite,
                                arrayTramites(lnIndex).Nombre_Tramite, 
                                arrayTramites(lnIndex).Fecha_Tramite, 
                                arrayTramites(lnIndex).Tipo_Cancelacion, 
                                arrayTramites(lnIndex).Id_Secretaria_Destino, 
                                arrayTramites(lnIndex).Id_Secretaria_Origen, 
                                arrayTramites(lnIndex).Id_Carroceria_Anterior, 
                                arrayTramites(lnIndex).Nombre_Carroceria_Anterior, 
                                arrayTramites(lnIndex).Id_Carroceria_Nueva, 
                                arrayTramites(lnIndex).Nombre_Carroceria_Nueva, 
                                arrayTramites(lnIndex).Id_Servicio_Anterior, 
                                arrayTramites(lnIndex).Nombre_Servicio_Anterior, 
                                arrayTramites(lnIndex).Id_Servicio_Nuevo, 
                                arrayTramites(lnIndex).Nombre_Servicio_Nuevo, 
                                arrayTramites(lnIndex).Id_Documento_Anterior, 
                                arrayTramites(lnIndex).Id_Usuario_Anterior, 
                                arrayTramites(lnIndex).Id_Documento_Nuevo, 
                                arrayTramites(lnIndex).Id_Usuario_Nuevo, 
                                arrayTramites(lnIndex).Porcentaje_Prop, 
                                arrayTramites(lnIndex).Clasico_Antiguo, 
                                arrayTramites(lnIndex).Blindado, 
                                arrayTramites(lnIndex).Nivel_Blindado, 
                                arrayTramites(lnIndex).Desblindaje, 
                                arrayTramites(lnIndex).Cilindraje, 
                                arrayTramites(lnIndex).Cap_Pasajeros, 
                                arrayTramites(lnIndex).Cap_Toneladas,
                                arrayTramites(lnIndex).Cilindraje_anterior,
                                arrayTramites(lnIndex).Cap_pasajeros_anterior,
                                arrayTramites(lnIndex).Cap_toneladas_anterior,
                                an_Id_Radicado);
          End If;
      End Loop;
      Exit When arrayTramites.Count()<=0;
      Commit;
   End Loop;   
   Commit;

End Sp_Carga_Tramites;

Procedure Sp_Carga_Propietarios(an_Id_Radicado Number) is

/*ISVA
Nombre     :Sp_Cargar_Propietarios
Autor      :Blados.Ospina
Fecha      :15/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la tabla arunt_tramites
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
15/06/2018  Blados.Ospina   1.0                    */

LnExiste Number :=0;

Cursor curPropietario is
Select * from arunt_Propietarios_Tmp Where Id_Radicado = an_Id_Radicado;

Type tableCur is table of curPropietario%RowType;
arrayProp tableCur;
Begin

Open curPropietario;
  Loop Fetch curPropietario
    Bulk Collect Into arrayProp Limit 500;
      For lnIndex in 1..arrayProp.Count() Loop
        
        Select Count(1) Into lnExiste
        From Arunt_Propietarios
        Where Nro_Placa = arrayProp(lnIndex).Nro_Placa And 
              (Id_Usuario = arrayProp(lnIndex).Id_Usuario or (Id_Usuario is null and arrayProp(lnIndex).Id_Usuario is null)) And
              (Id_Documento = arrayProp(lnIndex).Id_Documento or (Id_Documento is null and arrayProp(lnIndex).Id_Documento is null)) And
              (Porcentaje_Prop = arrayProp(lnIndex).Porcentaje_Prop or (Porcentaje_Prop is null and arrayProp(lnIndex).Porcentaje_Prop is null)) And 
              (Fecha_Propiedad = arrayProp(lnIndex).Fecha_Propiedad or (Fecha_Propiedad is null and arrayProp(lnIndex).Fecha_Propiedad is null));

        If lnExiste <=0 then
          Insert Into Arunt_Propietarios(Nro_Placa, 
                                         Id_Usuario, 
                                         Id_Documento, 
                                         Porcentaje_Prop, 
                                         Fecha_Propiedad,
                                         Id_Radicado)
                                  Values(arrayProp(lnIndex).Nro_Placa, 
                                         arrayProp(lnIndex).Id_Usuario, 
                                         arrayProp(lnIndex).Id_Documento, 
                                         arrayProp(lnIndex).Porcentaje_Prop,
                                         arrayProp(lnIndex).Fecha_Propiedad,
                                         an_Id_Radicado);
        End If;        
      End Loop;
      Exit When arrayProp.Count()<=0;
      Commit;
  End Loop;  
  Commit;

End Sp_Carga_Propietarios;

Procedure Sp_Cargar_Historiales(an_Id_Radicado Number) is

/*ISVA
Nombre     :Sp_Cargar_Historiales
Autor      :Blados.Ospina
Fecha      :18/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la tabla Historiales Traspasos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
18/06/2018  Blados.Ospina   1.0                      */

lnExiste number:=0;

Cursor curHist is
Select Distinct * From Arunt_Historico_Traspaso_Tmp Where Id_Radicado = an_Id_Radicado;

type tableHist is table of curHist%RowType;
arrayHist tableHist;

Begin

Open curHist;
  Loop Fetch curHist
    Bulk Collect Into arrayHist Limit 500;
      For lnIndex in 1..arrayHist.Count() Loop
        
        Select Count(1) Into lnExiste
        From Arunt_Historico_Traspaso
        Where Nro_Placa = arrayHist(lnIndex).Nro_Placa And 
              (Id_Usuario = arrayHist(lnIndex).Id_Usuario or (Id_Usuario is null and arrayHist(lnIndex).Id_Usuario is null)) And
              (Tipo_Documento = arrayHist(lnIndex).Tipo_Documento or (Tipo_Documento is null and arrayHist(lnIndex).Tipo_Documento is null)) And
              (Porcentaje = arrayHist(lnIndex).Porcentaje or (Porcentaje is null and arrayHist(lnIndex).Porcentaje is null)) And
              (Fecha_Inicio_Propiedad = arrayHist(lnIndex).Fecha_Inicio_Propiedad or (Fecha_Inicio_Propiedad is null and arrayHist(lnIndex).Fecha_Inicio_Propiedad is null)) And
              (Fecha_Fin_Propiedad = arrayHist(lnIndex).Fecha_Fin_Propiedad or (Fecha_Fin_Propiedad is null and arrayHist(lnIndex).Fecha_Fin_Propiedad is null));
        
        If lnExiste <=0 then
          Insert Into Arunt_Historico_Traspaso(Nro_Placa, 
                                              Id_Usuario, 
                                              Tipo_Documento, 
                                              Porcentaje, 
                                              Fecha_Inicio_Propiedad, 
                                              Fecha_Fin_Propiedad, 
                                              Id_Radicado)
                                       Values(arrayHist(lnIndex).Nro_Placa, 
                                              arrayHist(lnIndex).Id_Usuario, 
                                              arrayHist(lnIndex).Tipo_Documento, 
                                              arrayHist(lnIndex).Porcentaje, 
                                              arrayHist(lnIndex).Fecha_Inicio_Propiedad, 
                                              arrayHist(lnIndex).Fecha_Fin_Propiedad, 
                                              an_Id_Radicado);
        End If;
      End Loop;
      Exit When arrayHist.Count()<=0;
      Commit;
  End Loop; 
  Commit;
    
End Sp_Cargar_Historiales;

Procedure Sp_Carga_Contribuyentes(an_Id_Radicado Number)is

/*ISVA
Nombre     :Sp_Carga_Contribuyentes
Autor      :Blados.Ospina
Fecha      :18/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_RUNT
Version    :1.0
Objetivo   :No insertar duplicidad en la tabla Contribueyentes
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
18/06/2018  Blados.Ospina   1.0                    */

lnExiste number := 0;

Cursor curContribuyentes is
Select Distinct * from Arunt_Contribuyentes_Tmp Where Id_Radicado = an_Id_Radicado;

Type tableCur is table of curContribuyentes%RowType;
arrayCont tableCur;

Begin

Open curContribuyentes;
  Loop fetch curContribuyentes
    Bulk Collect Into arrayCont Limit 500;
      For lnIndex in 1..arrayCont.Count() Loop
      
        Select Count(1) Into lnExiste
        From Arunt_Contribuyentes
        Where Id_Usuario = arrayCont(lnIndex).Id_Usuario And 
              (Id_Documento = arrayCont(lnIndex).Id_Documento or (Id_Documento is null and arrayCont(lnIndex).Id_Documento is null)) And
              (Id_Ciudad = arrayCont(lnIndex).Id_Ciudad or (Id_Ciudad is null and arrayCont(lnIndex).Id_Ciudad is null)) And
              (Nombre_Ciudad = arrayCont(lnIndex).Nombre_Ciudad or (Nombre_Ciudad is null and arrayCont(lnIndex).Nombre_Ciudad is null)) And
              (Apellidos = arrayCont(lnIndex).Apellidos or (Apellidos is null and arrayCont(lnIndex).Apellidos is null)) And
              (Nombres = arrayCont(lnIndex).Nombres or (Nombres is null and arrayCont(lnIndex).Nombres is null)) And
              (Direccion = arrayCont(lnIndex).Direccion or (Direccion is null and arrayCont(lnIndex).Direccion is null)) And
              (Telefono = arrayCont(lnIndex).Telefono or (Telefono is null and arrayCont(lnIndex).Telefono is null)) And
              (Emp_O_Part = arrayCont(lnIndex).Emp_O_Part or (Emp_O_Part is null and arrayCont(lnIndex).Emp_O_Part is null)) And
              (Sexo = arrayCont(lnIndex).Sexo or (Sexo is null and arrayCont(lnIndex).Sexo is null)) And
              (Fecha_Nacimiento = arrayCont(lnIndex).Fecha_Nacimiento or (Fecha_Nacimiento is null and arrayCont(lnIndex).Fecha_Nacimiento is null)) And
              (Id_Pais = arrayCont(lnIndex).Id_Pais or (Id_Pais is null and arrayCont(lnIndex).Id_Pais is null)) And
              (Nombre_Pais = arrayCont(lnIndex).Nombre_Pais or (Nombre_Pais is null and arrayCont(lnIndex).Nombre_Pais is null)) And
              (Fecha_Modificacion = arrayCont(lnIndex).Fecha_Modificacion or (Fecha_Modificacion is null and arrayCont(lnIndex).Fecha_Modificacion is null)) And
              (Fax = arrayCont(lnIndex).Fax or (Fax is null and arrayCont(lnIndex).Fax is null)) And
              (Email = arrayCont(lnIndex).Email or (Email is null and arrayCont(lnIndex).Email is null)) And
              (Fecha_Actualizacion = arrayCont(lnIndex).Fecha_Actualizacion or (Fecha_Actualizacion is null and arrayCont(lnIndex).Fecha_Actualizacion is null)) And
              (Id_Ciudad_Dir = arrayCont(lnIndex).Id_Ciudad_Dir or (Id_Ciudad_Dir is null and arrayCont(lnIndex).Id_Ciudad_Dir is null)) And
              (Nombre_Ciudad_Dir = arrayCont(lnIndex).Nombre_Ciudad_Dir or (Nombre_Ciudad_Dir is null and arrayCont(lnIndex).Nombre_Ciudad_Dir is null)) And
              (Id_Direccion = arrayCont(lnIndex).Id_Direccion or (Id_Direccion is null and arrayCont(lnIndex).Id_Direccion is null)) And
              (Celular = arrayCont(lnIndex).Celular or (Celular is null and arrayCont(lnIndex).Celular is null));
             
                   
        If lnExiste <=0 Then
           Insert Into Arunt_Contribuyentes (Id_Usuario, 
                                          Id_Documento, 
                                          Id_Ciudad, 
                                          Nombre_Ciudad, 
                                          Apellidos, 
                                          Nombres, 
                                          Direccion, 
                                          Telefono, 
                                          Emp_O_Part, 
                                          Sexo, 
                                          Fecha_Nacimiento, 
                                          Id_Pais, 
                                          Nombre_Pais, 
                                          Fecha_Modificacion, 
                                          Fax, 
                                          Email, 
                                          Fecha_Actualizacion, 
                                          Id_Ciudad_Dir, 
                                          Nombre_Ciudad_Dir, 
                                          Id_Direccion,                                          
                                          Celular,
                                          Id_Radicado) 
                                  Values (arrayCont(lnIndex).Id_Usuario, 
                                          arrayCont(lnIndex).Id_Documento, 
                                          arrayCont(lnIndex).Id_Ciudad, 
                                          arrayCont(lnIndex).Nombre_Ciudad, 
                                          arrayCont(lnIndex).Apellidos, 
                                          arrayCont(lnIndex).Nombres, 
                                          arrayCont(lnIndex).Direccion, 
                                          arrayCont(lnIndex).Telefono, 
                                          arrayCont(lnIndex).Emp_O_Part, 
                                          arrayCont(lnIndex).Sexo, 
                                          arrayCont(lnIndex).Fecha_Nacimiento, 
                                          arrayCont(lnIndex).Id_Pais, 
                                          arrayCont(lnIndex).Nombre_Pais, 
                                          arrayCont(lnIndex).Fecha_Modificacion, 
                                          arrayCont(lnIndex).Fax, 
                                          arrayCont(lnIndex).Email, 
                                          arrayCont(lnIndex).Fecha_Actualizacion, 
                                          arrayCont(lnIndex).Id_Ciudad_Dir, 
                                          arrayCont(lnIndex).Nombre_Ciudad_Dir, 
                                          arrayCont(lnIndex).Id_Direccion,                                         
                                          arrayCont(lnIndex).Celular,
                                          an_Id_Radicado);   
                                          --Commit;
        End If;      
      End Loop;
      Exit When arrayCont.Count()<=0;
      Commit;
    End Loop;
    Commit;

End Sp_Carga_Contribuyentes;

Procedure Sp_Inciar (an_Id_Radicado Number) AS

/*ISVA
Nombre     :Sp_Inciar
Autor      :Blados.Ospina
Fecha      :15/06/2018
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos runt
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
15/06/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */

Begin
        Sp_Carga_Contribuyentes(an_Id_Radicado);
        Sp_Cargar_Historiales(an_Id_Radicado);
        Sp_Carga_Propietarios(an_Id_Radicado);
        Sp_Carga_Tramites(an_Id_Radicado);
        Sp_Cargar_Vehiculos (an_Id_Radicado);
END Sp_Inciar;

END PKG_DEPURAR_BD_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DEPURAR_BD_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_DEPURAR_BD_TTO" AS


Procedure Sp_Cargar_Vehiculos (lnIdRadicado number) is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */


lnExiste number :=0;

Cursor curVehiculos is
Select Distinct * from Tmp_vehiculos where Id_Radicado = lnIdRadicado;

type tableCursor is Table of curVehiculos%RowType;
arrayVehiculo tableCursor;

Begin

Open curVehiculos;
  Loop fetch curVehiculos
    Bulk Collect Into arrayVehiculo Limit 500;
    
    For lnIndex in 1..arrayVehiculo.Count() Loop
      Select count(1) Into lnExiste
      From St_Vehiculos
      Where Nro_Placa = arrayVehiculo(lnIndex).Nro_Placa And           
            (Id_Marca = arrayVehiculo(lnIndex).Id_Marca or (Id_Marca is null and arrayVehiculo(lnIndex).Id_Marca is null)) And
            (Nombre_Marca = arrayVehiculo(lnIndex).Nombre_Marca or (Nombre_Marca is null and arrayVehiculo(lnIndex).Nombre_Marca is null)) And
            (Id_Linea = arrayVehiculo(lnIndex).Id_Linea or (Id_Linea is null and arrayVehiculo(lnIndex).Id_Linea is null)) And
            (Nombre_Linea = arrayVehiculo(lnIndex).Nombre_Linea or (Nombre_Linea is null and arrayVehiculo(lnIndex).Nombre_Linea is null)) And
            (Modelo = arrayVehiculo(lnIndex).Modelo or (Modelo is null and arrayVehiculo(lnIndex).Modelo is null)) And
            (Id_Clase = arrayVehiculo(lnIndex).Id_Clase or (Id_Clase is null and arrayVehiculo(lnIndex).Id_Clase is null)) And
            (Nombre_Clase = arrayVehiculo(lnIndex).Nombre_Clase or (Nombre_Clase is null and arrayVehiculo(lnIndex).Nombre_Clase is null)) And
            (Id_Servicio = arrayVehiculo(lnIndex).Id_Servicio or (Id_Servicio is null and arrayVehiculo(lnIndex).Id_Servicio is null)) And
            (Nombre_Servicio = arrayVehiculo(lnIndex).Nombre_Servicio or (Nombre_Servicio is null and arrayVehiculo(lnIndex).Nombre_Servicio is null)) And
            (Id_Carroceria = arrayVehiculo(lnIndex).Id_Carroceria or (Id_Carroceria is null and arrayVehiculo(lnIndex).Id_Carroceria is null)) And
            (Nombre_Carroceria = arrayVehiculo(lnIndex).Nombre_Carroceria or (Nombre_Carroceria is null and arrayVehiculo(lnIndex).Nombre_Carroceria is null)) And
            (Nro_Puertas = arrayVehiculo(lnIndex).Nro_Puertas or (Nro_Puertas is null and arrayVehiculo(lnIndex).Nro_Puertas is null)) And
            (Id_Combustible = arrayVehiculo(lnIndex).Id_Combustible or (Id_Combustible is null and arrayVehiculo(lnIndex).Id_Combustible is null)) And
            (Nombre_Combustible = arrayVehiculo(lnIndex).Nombre_Combustible or (Nombre_Combustible is null and arrayVehiculo(lnIndex).Nombre_Combustible is null)) And
            (Id_Bateria = arrayVehiculo(lnIndex).Id_Bateria or (Id_Bateria is null and arrayVehiculo(lnIndex).Id_Bateria is null)) And
            (Nombre_Bateria = arrayVehiculo(lnIndex).Nombre_Bateria or (Nombre_Bateria is null and arrayVehiculo(lnIndex).Nombre_Bateria is null)) And
            (Potencia = arrayVehiculo(lnIndex).Potencia or (Potencia is null and arrayVehiculo(lnIndex).Potencia is null)) And
            (Id_Secretaria = arrayVehiculo(lnIndex).Id_Secretaria or (Id_Secretaria is null and arrayVehiculo(lnIndex).Id_Secretaria is null)) And
            (Nombre_Secretaria = arrayVehiculo(lnIndex).Nombre_Secretaria or (Nombre_Secretaria is null and arrayVehiculo(lnIndex).Nombre_Secretaria is null)) And
            (Cilindraje = arrayVehiculo(lnIndex).Cilindraje or (Cilindraje is null and arrayVehiculo(lnIndex).Cilindraje is null)) And
            (Cap_Pasajeros = arrayVehiculo(lnIndex).Cap_Pasajeros or (Cap_Pasajeros is null and arrayVehiculo(lnIndex).Cap_Pasajeros is null)) And
            (Cap_Toneladas = arrayVehiculo(lnIndex).Cap_Toneladas or (Cap_Toneladas is null and arrayVehiculo(lnIndex).Cap_Toneladas is null)) And
            (Valor_Factura = arrayVehiculo(lnIndex).Valor_Factura or (Valor_Factura is null and arrayVehiculo(lnIndex).Valor_Factura is null)) And
            (Blindado = arrayVehiculo(lnIndex).Blindado or (Blindado is null and arrayVehiculo(lnIndex).Blindado is null)) And
            (Importado_Nacional = arrayVehiculo(lnIndex).Importado_Nacional or (Importado_Nacional is null and arrayVehiculo(lnIndex).Importado_Nacional is null)) And
            (Id_Estado = arrayVehiculo(lnIndex).Id_Estado or (Id_Estado is null and arrayVehiculo(lnIndex).Id_Estado is null)) And
            (Nombre_Estado = arrayVehiculo(lnIndex).Nombre_Estado or (Nombre_Estado is null and arrayVehiculo(lnIndex).Nombre_Estado is null)) And
            (Clasico_Antiguo = arrayVehiculo(lnIndex).Clasico_Antiguo or (Clasico_Antiguo is null and arrayVehiculo(lnIndex).Clasico_Antiguo is null)) And
            (Fecha_Matriculo = arrayVehiculo(lnIndex).Fecha_Matriculo or (Fecha_Matriculo is null and arrayVehiculo(lnIndex).Fecha_Matriculo is null)) And
            (Caja = arrayVehiculo(lnIndex).Caja or (Caja is null and arrayVehiculo(lnIndex).Caja is null)) And
            (Traccion = arrayVehiculo(lnIndex).Traccion or (Traccion is null and arrayVehiculo(lnIndex).Traccion is null)) And
            (Combustion = arrayVehiculo(lnIndex).Combustion or (Combustion is null and arrayVehiculo(lnIndex).Combustion is null));

            
       If (lnExiste <= 0) Then
        insert into st_vehiculos (Nro_Placa,
                                  Id_Marca,
                                  Nombre_Marca,
                                  Id_Linea, 
                                  Nombre_Linea, 
                                  Modelo, Id_Clase, 
                                  Nombre_Clase, 
                                  Id_Servicio, 
                                  Nombre_Servicio, 
                                  Id_Carroceria, 
                                  Nombre_Carroceria,
                                  Nro_Puertas, 
                                  Id_Combustible, 
                                  Nombre_Combustible, 
                                  Id_Bateria,
                                  Nombre_Bateria, 
                                  Potencia,
                                  Id_Secretaria, 
                                  Nombre_Secretaria, 
                                  Cilindraje,
                                  Cap_Pasajeros, 
                                  Cap_Toneladas, 
                                  Valor_Factura,
                                  Blindado, 
                                  Importado_Nacional,
                                  Id_Estado, Nombre_Estado, 
                                  Clasico_Antiguo, 
                                  Fecha_Matriculo, 
                                  Caja, Traccion,
                                  Combustion, 
                                  Id_Radicado) 
                           values(arrayVehiculo(lnIndex).Nro_Placa, 
                                  arrayVehiculo(lnIndex).Id_Marca, 
                                  arrayVehiculo(lnIndex).Nombre_Marca, 
                                  arrayVehiculo(lnIndex).Id_Linea, 
                                  arrayVehiculo(lnIndex).Nombre_Linea,
                                  arrayVehiculo(lnIndex).Modelo, 
                                  arrayVehiculo(lnIndex).Id_Clase,
                                  arrayVehiculo(lnIndex).Nombre_Clase,
                                  arrayVehiculo(lnIndex).Id_Servicio, 
                                  arrayVehiculo(lnIndex).Nombre_Servicio,
                                  arrayVehiculo(lnIndex).Id_Carroceria, 
                                  arrayVehiculo(lnIndex).Nombre_Carroceria, 
                                  arrayVehiculo(lnIndex).Nro_Puertas,
                                  arrayVehiculo(lnIndex).Id_Combustible,
                                  arrayVehiculo(lnIndex).Nombre_Combustible, 
                                  arrayVehiculo(lnIndex).Id_Bateria, 
                                  arrayVehiculo(lnIndex).Nombre_Bateria,
                                  arrayVehiculo(lnIndex).Potencia, 
                                  arrayVehiculo(lnIndex).Id_Secretaria, 
                                  arrayVehiculo(lnIndex).Nombre_Secretaria, 
                                  arrayVehiculo(lnIndex).Cilindraje, 
                                  arrayVehiculo(lnIndex).Cap_Pasajeros, 
                                  arrayVehiculo(lnIndex).Cap_Toneladas, 
                                  arrayVehiculo(lnIndex).Valor_Factura, 
                                  arrayVehiculo(lnIndex).Blindado, 
                                  arrayVehiculo(lnIndex).Importado_Nacional,
                                  arrayVehiculo(lnIndex).Id_Estado, 
                                  arrayVehiculo(lnIndex).Nombre_Estado,
                                  arrayVehiculo(lnIndex).Clasico_Antiguo, 
                                  arrayVehiculo(lnIndex).Fecha_Matriculo, 
                                  arrayVehiculo(lnIndex).Caja, 
                                  arrayVehiculo(lnIndex).Traccion, 
                                  arrayVehiculo(lnIndex).Combustion, 
                                  lnIdRadicado);      
       End if;
    End Loop;
    Exit When arrayVehiculo.count()<=0;
    Commit;
  End Loop;  
  Commit;

End Sp_Cargar_Vehiculos;

Procedure Sp_Carga_Tramites (lnRadicado number) is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */


lnExiste number :=0;

Cursor curTramites is
Select Distinct * from Tmp_Tramites where ID_RADICADO = lnRadicado;

type tableCur is table of curTramites%RowType;
arrayTramites tableCur;

Begin

Open curTramites;
  Loop fetch curTramites
    Bulk Collect into arrayTramites Limit 500;
      For lnIndex in 1..arrayTramites.Count() Loop
        
        Select Count(1) Into lnExiste
        From St_Tramites 
        Where Nro_Placa = arrayTramites(lnIndex).Nro_Placa And
              (Id_Tramite = arrayTramites(lnIndex).Id_Tramite or (Id_Tramite is null and arrayTramites(lnIndex).Id_Tramite is null)) And
              (Nombre_Tramite = arrayTramites(lnIndex).Nombre_Tramite or (Nombre_Tramite is null and arrayTramites(lnIndex).Nombre_Tramite is null)) And
              (Fecha_Tramite = arrayTramites(lnIndex).Fecha_Tramite or (Fecha_Tramite is null and arrayTramites(lnIndex).Fecha_Tramite is null)) And
              (Tipo_Cancelacion = arrayTramites(lnIndex).Tipo_Cancelacion or (Tipo_Cancelacion is null and arrayTramites(lnIndex).Tipo_Cancelacion is null)) And
              (Id_Secretaria_Destino = arrayTramites(lnIndex).Id_Secretaria_Destino or (Id_Secretaria_Destino is null and arrayTramites(lnIndex).Id_Secretaria_Destino is null)) And
              (Id_Secretaria_Origen = arrayTramites(lnIndex).Id_Secretaria_Origen or (Id_Secretaria_Origen is null and arrayTramites(lnIndex).Id_Secretaria_Origen is null)) And
              (Id_Carroceria_Anterior = arrayTramites(lnIndex).Id_Carroceria_Anterior or (Id_Carroceria_Anterior is null and arrayTramites(lnIndex).Id_Carroceria_Anterior is null)) And
              (Nombre_Carroceria_Anterior = arrayTramites(lnIndex).Nombre_Carroceria_Anterior or (Nombre_Carroceria_Anterior is null and arrayTramites(lnIndex).Nombre_Carroceria_Anterior is null)) And
              (Id_Carroceria_Nueva = arrayTramites(lnIndex).Id_Carroceria_Nueva or (Id_Carroceria_Nueva is null and arrayTramites(lnIndex).Id_Carroceria_Nueva is null)) And
              (Nombre_Carroceria_Nueva = arrayTramites(lnIndex).Nombre_Carroceria_Nueva or (Nombre_Carroceria_Nueva is null and arrayTramites(lnIndex).Nombre_Carroceria_Nueva is null)) And
              (Id_Servicio_Anterior = arrayTramites(lnIndex).Id_Servicio_Anterior or (Id_Servicio_Anterior is null and arrayTramites(lnIndex).Id_Servicio_Anterior is null)) And
              (Nombre_Servicio_Anterior = arrayTramites(lnIndex).Nombre_Servicio_Anterior or (Nombre_Servicio_Anterior is null and arrayTramites(lnIndex).Nombre_Servicio_Anterior is null)) And
              (Id_Servicio_Nuevo = arrayTramites(lnIndex).Id_Servicio_Nuevo or (Id_Servicio_Nuevo is null and arrayTramites(lnIndex).Id_Servicio_Nuevo is null)) And
              (Nombre_Servicio_Nuevo = arrayTramites(lnIndex).Nombre_Servicio_Nuevo or (Nombre_Servicio_Nuevo is null and arrayTramites(lnIndex).Nombre_Servicio_Nuevo is null)) And
              (Id_Documento_Anterior = arrayTramites(lnIndex).Id_Documento_Anterior or (Id_Documento_Anterior is null and arrayTramites(lnIndex).Id_Documento_Anterior is null)) And
              (Id_Usuario_Anterior = arrayTramites(lnIndex).Id_Usuario_Anterior or (Id_Usuario_Anterior is null and arrayTramites(lnIndex).Id_Usuario_Anterior is null)) And
              (Id_Documento_Nuevo = arrayTramites(lnIndex).Id_Documento_Nuevo or (Id_Documento_Nuevo is null and arrayTramites(lnIndex).Id_Documento_Nuevo is null)) And
              (Id_Usuario_Nuevo = arrayTramites(lnIndex).Id_Usuario_Nuevo or (Id_Usuario_Nuevo is null and arrayTramites(lnIndex).Id_Usuario_Nuevo is null)) And
              (Porcentaje_Prop = arrayTramites(lnIndex).Porcentaje_Prop or (Porcentaje_Prop is null and arrayTramites(lnIndex).Porcentaje_Prop is null)) And
              (Clasico_Antiguo = arrayTramites(lnIndex).Clasico_Antiguo or (Clasico_Antiguo is null and arrayTramites(lnIndex).Clasico_Antiguo is null)) And
              (Blindado = arrayTramites(lnIndex).Blindado or (Blindado is null and arrayTramites(lnIndex).Blindado is null)) And
              (Nivel_Blindado = arrayTramites(lnIndex).Nivel_Blindado or (Nivel_Blindado is null and arrayTramites(lnIndex).Nivel_Blindado is null)) And
              (Desblindaje = arrayTramites(lnIndex).Desblindaje or (Desblindaje is null and arrayTramites(lnIndex).Desblindaje is null)) And
              (Cilindraje = arrayTramites(lnIndex).Cilindraje or (Cilindraje is null and arrayTramites(lnIndex).Cilindraje is null)) And
              (Cap_Pasajeros = arrayTramites(lnIndex).Cap_Pasajeros or (Cap_Pasajeros is null and arrayTramites(lnIndex).Cap_Pasajeros is null)) And
              (Cap_Toneladas = arrayTramites(lnIndex).Cap_Toneladas or (Cap_Toneladas is null and arrayTramites(lnIndex).Cap_Toneladas is null));


      If(lnExiste <= 0) then
        Insert Into St_Tramites(Nro_Placa, 
                                Id_Tramite, 
                                Nombre_Tramite, 
                                Fecha_Tramite, 
                                Tipo_Cancelacion, 
                                Id_Secretaria_Destino, 
                                Id_Secretaria_Origen, 
                                Id_Carroceria_Anterior, 
                                Nombre_Carroceria_Anterior, 
                                Id_Carroceria_Nueva, 
                                Nombre_Carroceria_Nueva, 
                                Id_Servicio_Anterior, 
                                Nombre_Servicio_Anterior, 
                                Id_Servicio_Nuevo, 
                                Nombre_Servicio_Nuevo, 
                                Id_Documento_Anterior, 
                                Id_Usuario_Anterior, 
                                Id_Documento_Nuevo, 
                                Id_Usuario_Nuevo, 
                                Porcentaje_Prop, 
                                Clasico_Antiguo, 
                                Blindado, 
                                Nivel_Blindado, 
                                Desblindaje, 
                                Cilindraje, 
                                Cap_Pasajeros, 
                                Cap_Toneladas,
                                Id_Radicado) 
                         Values(arrayTramites(lnIndex).Nro_Placa,
                                arrayTramites(lnIndex).Id_Tramite,
                                arrayTramites(lnIndex).Nombre_Tramite, 
                                arrayTramites(lnIndex).Fecha_Tramite, 
                                arrayTramites(lnIndex).Tipo_Cancelacion, 
                                arrayTramites(lnIndex).Id_Secretaria_Destino, 
                                arrayTramites(lnIndex).Id_Secretaria_Origen, 
                                arrayTramites(lnIndex).Id_Carroceria_Anterior, 
                                arrayTramites(lnIndex).Nombre_Carroceria_Anterior, 
                                arrayTramites(lnIndex).Id_Carroceria_Nueva, 
                                arrayTramites(lnIndex).Nombre_Carroceria_Nueva, 
                                arrayTramites(lnIndex).Id_Servicio_Anterior, 
                                arrayTramites(lnIndex).Nombre_Servicio_Anterior, 
                                arrayTramites(lnIndex).Id_Servicio_Nuevo, 
                                arrayTramites(lnIndex).Nombre_Servicio_Nuevo, 
                                arrayTramites(lnIndex).Id_Documento_Anterior, 
                                arrayTramites(lnIndex).Id_Usuario_Anterior, 
                                arrayTramites(lnIndex).Id_Documento_Nuevo, 
                                arrayTramites(lnIndex).Id_Usuario_Nuevo, 
                                arrayTramites(lnIndex).Porcentaje_Prop, 
                                arrayTramites(lnIndex).Clasico_Antiguo, 
                                arrayTramites(lnIndex).Blindado, 
                                arrayTramites(lnIndex).Nivel_Blindado, 
                                arrayTramites(lnIndex).Desblindaje, 
                                arrayTramites(lnIndex).Cilindraje, 
                                arrayTramites(lnIndex).Cap_Pasajeros, 
                                arrayTramites(lnIndex).Cap_Toneladas,
                                lnRadicado);
          End If;
      End Loop;
      Exit When arrayTramites.Count()<=0;
      Commit;
   End Loop;   
   Commit;

End Sp_Carga_Tramites;

Procedure Sp_Carga_Contribuyentes(lnRadicado Number)is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */

lnExiste number := 0;

Cursor curContribuyentes is
Select Distinct * from Tmp_Contribuyentes where Id_Radicado = lnRadicado;

Type tableCur is table of curContribuyentes%RowType;
arrayCont tableCur;

Begin

Open curContribuyentes;
  Loop fetch curContribuyentes
    Bulk Collect Into arrayCont Limit 500;
      For lnIndex in 1..arrayCont.Count() Loop
      
        Select Count(1) Into lnExiste
        From st_Contribuyentes
        Where Id_Usuario = arrayCont(lnIndex).Id_Usuario And 
              (Id_Documento = arrayCont(lnIndex).Id_Documento or (Id_Documento is null and arrayCont(lnIndex).Id_Documento is null)) And
              (Id_Ciudad = arrayCont(lnIndex).Id_Ciudad or (Id_Ciudad is null and arrayCont(lnIndex).Id_Ciudad is null)) And
              (Nombre_Ciudad = arrayCont(lnIndex).Nombre_Ciudad or (Nombre_Ciudad is null and arrayCont(lnIndex).Nombre_Ciudad is null)) And
              (Apellidos = arrayCont(lnIndex).Apellidos or (Apellidos is null and arrayCont(lnIndex).Apellidos is null)) And
              (Nombres = arrayCont(lnIndex).Nombres or (Nombres is null and arrayCont(lnIndex).Nombres is null)) And
              (Direccion = arrayCont(lnIndex).Direccion or (Direccion is null and arrayCont(lnIndex).Direccion is null)) And
              (Telefono = arrayCont(lnIndex).Telefono or (Telefono is null and arrayCont(lnIndex).Telefono is null)) And
              (Emp_O_Part = arrayCont(lnIndex).Emp_O_Part or (Emp_O_Part is null and arrayCont(lnIndex).Emp_O_Part is null)) And
              (Sexo = arrayCont(lnIndex).Sexo or (Sexo is null and arrayCont(lnIndex).Sexo is null)) And
              (Fecha_Nacimiento = arrayCont(lnIndex).Fecha_Nacimiento or (Fecha_Nacimiento is null and arrayCont(lnIndex).Fecha_Nacimiento is null)) And
              (Id_Pais = arrayCont(lnIndex).Id_Pais or (Id_Pais is null and arrayCont(lnIndex).Id_Pais is null)) And
              (Nombre_Pais = arrayCont(lnIndex).Nombre_Pais or (Nombre_Pais is null and arrayCont(lnIndex).Nombre_Pais is null)) And
              (Fecha_Modificacion = arrayCont(lnIndex).Fecha_Modificacion or (Fecha_Modificacion is null and arrayCont(lnIndex).Fecha_Modificacion is null)) And
              (Fax = arrayCont(lnIndex).Fax or (Fax is null and arrayCont(lnIndex).Fax is null)) And
              (Email = arrayCont(lnIndex).Email or (Email is null and arrayCont(lnIndex).Email is null)) And
              (Fecha_Actualizacion = arrayCont(lnIndex).Fecha_Actualizacion or (Fecha_Actualizacion is null and arrayCont(lnIndex).Fecha_Actualizacion is null)) And
              (Id_Ciudad_Dir = arrayCont(lnIndex).Id_Ciudad_Dir or (Id_Ciudad_Dir is null and arrayCont(lnIndex).Id_Ciudad_Dir is null)) And
              (Nombre_Ciudad_Dir = arrayCont(lnIndex).Nombre_Ciudad_Dir or (Nombre_Ciudad_Dir is null and arrayCont(lnIndex).Nombre_Ciudad_Dir is null)) And
              (Id_Direccion = arrayCont(lnIndex).Id_Direccion or (Id_Direccion is null and arrayCont(lnIndex).Id_Direccion is null)) And
              (Celular = arrayCont(lnIndex).Celular or (Celular is null and arrayCont(lnIndex).Celular is null));
             
                   
        If lnExiste <=0 Then
           Insert Into St_Contribuyentes (Id_Usuario, 
                                          Id_Documento, 
                                          Id_Ciudad, 
                                          Nombre_Ciudad, 
                                          Apellidos, 
                                          Nombres, 
                                          Direccion, 
                                          Telefono, 
                                          Emp_O_Part, 
                                          Sexo, 
                                          Fecha_Nacimiento, 
                                          Id_Pais, 
                                          Nombre_Pais, 
                                          Fecha_Modificacion, 
                                          Fax, 
                                          Email, 
                                          Fecha_Actualizacion, 
                                          Id_Ciudad_Dir, 
                                          Nombre_Ciudad_Dir, 
                                          Id_Direccion,                                          
                                          Celular,
                                          Id_Radicado) 
                                  Values (arrayCont(lnIndex).Id_Usuario, 
                                          arrayCont(lnIndex).Id_Documento, 
                                          arrayCont(lnIndex).Id_Ciudad, 
                                          arrayCont(lnIndex).Nombre_Ciudad, 
                                          arrayCont(lnIndex).Apellidos, 
                                          arrayCont(lnIndex).Nombres, 
                                          arrayCont(lnIndex).Direccion, 
                                          arrayCont(lnIndex).Telefono, 
                                          arrayCont(lnIndex).Emp_O_Part, 
                                          arrayCont(lnIndex).Sexo, 
                                          arrayCont(lnIndex).Fecha_Nacimiento, 
                                          arrayCont(lnIndex).Id_Pais, 
                                          arrayCont(lnIndex).Nombre_Pais, 
                                          arrayCont(lnIndex).Fecha_Modificacion, 
                                          arrayCont(lnIndex).Fax, 
                                          arrayCont(lnIndex).Email, 
                                          arrayCont(lnIndex).Fecha_Actualizacion, 
                                          arrayCont(lnIndex).Id_Ciudad_Dir, 
                                          arrayCont(lnIndex).Nombre_Ciudad_Dir, 
                                          arrayCont(lnIndex).Id_Direccion,                                         
                                          arrayCont(lnIndex).Celular,
                                          lnRadicado);   
                                          --Commit;
        End If;      
      End Loop;
      Exit When arrayCont.Count()<=0;
      Commit;
    End Loop;
    Commit;

End Sp_Carga_Contribuyentes;

Procedure Sp_Carga_Propietarios(lnRadicado Number) is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */

LnExiste Number :=0;

Cursor curPropietario is
Select Distinct * from Tmp_Propietarios where Id_Radicado = lnRadicado;

Type tableCur is table of curPropietario%RowType;
arrayProp tableCur;
Begin

Open curPropietario;
  Loop Fetch curPropietario
    Bulk Collect Into arrayProp Limit 500;
      For lnIndex in 1..arrayProp.Count() Loop
        
        Select Count(1) Into lnExiste
        From St_Propietarios
        Where Nro_Placa = arrayProp(lnIndex).Nro_Placa And 
              (Id_Usuario = arrayProp(lnIndex).Id_Usuario or (Id_Usuario is null and arrayProp(lnIndex).Id_Usuario is null)) And
              (Id_Documento = arrayProp(lnIndex).Id_Documento or (Id_Documento is null and arrayProp(lnIndex).Id_Documento is null)) And
              (Porcentaje_Prop = arrayProp(lnIndex).Porcentaje_Prop or (Porcentaje_Prop is null and arrayProp(lnIndex).Porcentaje_Prop is null));

        If lnExiste <=0 then
          Insert Into St_Propietarios(Nro_Placa, 
                                      Id_Usuario, 
                                      Id_Documento, 
                                      Porcentaje_Prop, 
                                      Id_Radicado)
                               Values(arrayProp(lnIndex).Nro_Placa, 
                                      arrayProp(lnIndex).Id_Usuario, 
                                      arrayProp(lnIndex).Id_Documento, 
                                      arrayProp(lnIndex).Porcentaje_Prop, 
                                      lnRadicado);
        End If;        
      End Loop;
      Exit When arrayProp.Count()<=0;
      Commit;
  End Loop;  
  Commit;

End Sp_Carga_Propietarios;

Procedure Sp_Cargar_Historiales(lnRadicado Number) is

/*ISVA
Nombre     :Sp_Cargar_Vehiculos
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql */

lnExiste number:=0;

Cursor curHist is
Select Distinct * From Tmp_Historiales_Traspaso Where Id_Radicado = lnRadicado;

type tableHist is table of curHist%RowType;
arrayHist tableHist;

Begin

Open curHist;
  Loop Fetch curHist
    Bulk Collect Into arrayHist Limit 500;
      For lnIndex in 1..arrayHist.Count() Loop
        
        Select Count(1) Into lnExiste
        From St_Historiales_Traspaso
        Where Nro_Placa = arrayHist(lnIndex).Nro_Placa And 
              (Id_Usuario = arrayHist(lnIndex).Id_Usuario or (Id_Usuario is null and arrayHist(lnIndex).Id_Usuario is null)) And
              (Tipo_Documento_Usuario = arrayHist(lnIndex).Tipo_Documento_Usuario or (Tipo_Documento_Usuario is null and arrayHist(lnIndex).Tipo_Documento_Usuario is null)) And
              (Id_Comprador = arrayHist(lnIndex).Id_Comprador or (Id_Comprador is null and arrayHist(lnIndex).Id_Comprador is null)) And
              (Tipo_Documento_Comprador = arrayHist(lnIndex).Tipo_Documento_Comprador or (Tipo_Documento_Comprador is null and arrayHist(lnIndex).Tipo_Documento_Comprador is null)) And
              (Porcentaje = arrayHist(lnIndex).Porcentaje or (Porcentaje is null and arrayHist(lnIndex).Porcentaje is null)) And
              (Fecha = arrayHist(lnIndex).Fecha or (Fecha is null and arrayHist(lnIndex).Fecha is null));
        
        If lnExiste <=0 then
          Insert Into St_Historiales_Traspaso(Nro_Placa, 
                                              Id_Usuario, 
                                              Tipo_Documento_Usuario, 
                                              Id_Comprador, 
                                              Tipo_Documento_Comprador, 
                                              Porcentaje, 
                                              Fecha,
                                              Id_Radicado)
                                       Values(arrayHist(lnIndex).Nro_Placa, 
                                              arrayHist(lnIndex).Id_Usuario, 
                                              arrayHist(lnIndex).Tipo_Documento_Usuario, 
                                              arrayHist(lnIndex).Id_Comprador, 
                                              arrayHist(lnIndex).Tipo_Documento_Comprador, 
                                              arrayHist(lnIndex).Porcentaje, 
                                              arrayHist(lnIndex).Fecha, 
                                              lnRadicado);
        End If;
      End Loop;
      Exit When arrayHist.Count()<=0;
      Commit;
  End Loop; 
  Commit;
    
End Sp_Cargar_Historiales;

Procedure Sp_Inciar(as_Radicado Simple_Integer) is

/*ISVA
Nombre     :Sp_Inciar
Autor      :Elvis.Betancur
Fecha      :01/01/18
Parametros :as_Radicado
Retorno    :         
Proyecto   :PKG_DEPURAR_BD_TTO
Version    :1.0
Objetivo   :No insertar duplicidad en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
02/05/2018  Blados.Ospina   1.1       Se le aplica la estandarizacion para 
                                      pl-sql y para llamar todos los procedimientos */

Begin
      Sp_Cargar_Vehiculos (as_Radicado);
      Sp_Carga_Tramites (as_Radicado);
      Sp_Carga_Contribuyentes(as_Radicado);
      Sp_Carga_Propietarios(as_Radicado);
      Sp_Cargar_Historiales(as_Radicado);
end Sp_Inciar;

END PKG_DEPURAR_BD_TTO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_INCONSISTENCIAS_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_INCONSISTENCIAS_RUNT" AS

GS_RADICADO Simple_Integer:=0;

Procedure Sp_Detalle_Inconsistencia As

/*
Nombre     :Sp_Detalle_Inconsistencia
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Registra todas la incosistencias 
           :de forma mas detallada
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):= GS_RADICADO||' DETALLE_INCONSISTENCIA '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

            -- VALIDO LONGITUD DE NRO_PLACA 
        Cursor lcur_detalle_incons Is
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NRO_PLACA) > 6 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
            
        union
        
        -- VALIDO LONGITUD DE ID_MARCA
        SELECT DISTINCT ST_V.ID_RADICADO ,'Longitud ID_MARCA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.ID_MARCA,'.','')) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_MARCA
        SELECT DISTINCT ST_V.ID_RADICADO , 'Longitud NOMBRE_MARCA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_MARCA) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.ID_LINEA,'.','')) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_LINEA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_LINEA) > 50 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE MODELO
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud MODELO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE ID_CLASE
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_CLASE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_CLASE) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_LINEA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CLASE
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_CLASE mayor a la permitida(40)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_CLASE) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_SERVICIO
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_SERVICIO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_SERVICIO) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_SERVICIO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_SERVICIO) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_CARROCERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_CARROCERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_CARROCERIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_CARROCERIA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_CARROCERIA) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_COMBUSTIBLE
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_COMBUSTIBLE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_COMBUSTIBLE) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_BATERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_BATERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_BATERIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_BATERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_BATERIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_BATERIA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE POTENCIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud POTENCIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.POTENCIA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud ID_SECRETARIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_SECRETARIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SECRETARIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud NOMBRE_SECRETARIA mayor a la permitida(80)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_SECRETARIA) > 80 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT DISTINCT ST_V.ID_RADICADO ,  'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CILINDRAJE) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT DISTINCT ST_V.ID_RADICADO , 'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT DISTINCT  ST_V.ID_RADICADO ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CAP_TONELADAS) > 6 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE VALOR_FACTURA
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud VALOR_FACTURA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.VALOR_FACTURA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.BLINDADO) > 1 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE IMPORTADO_NACIONAL
        SELECT DISTINCT  ST_V.ID_RADICADO ,'Longitud IMPORTADO_NACIONAL mayor a la permitida(2)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.IMPORTADO_NACIONAL) > 2 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_ESTADO
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud ID_ESTADO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_ESTADO) > 4 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_ESTADO
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud NOMBRE_ESTADO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_ESTADO) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CLASICO_ANTIGUO) > 1 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PUERTAS
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud NRO_PUERTAS mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NRO_PUERTAS) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT DISTINCT ST_V.ID_RADICADO , 'Longitud FECHA_MATRICULO mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.FECHA_MATRICULO) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT DISTINCT  ST_V.ID_RADICADO , 'Longitud FECHA_MATRICULO menos a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_USUARIO) > 15 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_DOCUMENTO) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_CIUDAD mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_CIUDAD) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud NOMBRE_CIUDAD mayor a la permitida(30)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_CIUDAD) > 30 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE APELLIDOS
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud APELLIDOS mayor a la permitida(80)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.APELLIDOS) > 80 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRES
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud NOMBRES mayor a la permitida(80)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRES) > 80 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DIRECCION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud DIRECCION mayor a la permitida(100)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.DIRECCION) > 100 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud TELEFONO mayor a la permitida(14)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.TELEFONO) > 14 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud TELEFONO MENOR a la permitida(7)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.TELEFONO) < 7 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud CELULAR mayor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.CELULAR) > 10 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud CELULAR menor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.CELULAR) < 10 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMP_O_PART
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud EMP_O_PART mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.EMP_O_PART) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE SEXO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud SEXO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.SEXO) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_NACIMIENTO mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_NACIMIENTO) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_NACIMIENTO menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_NACIMIENTO) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_PAIS
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_PAIS mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_PAIS) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO  
        --ORDER BY ST_C.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_PAIS
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud NOMBRE_PAIS mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_PAIS) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_MODIFICACION mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_MODIFICACION) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_MODIFICACION menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_MODIFICACION) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FAX
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FAX mayor a la permitida(12)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FAX) > 12 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_ACTUALIZACION) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO  
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_ACTUALIZACION) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD_DIR
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_CIUDAD_DIR mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_CIUDAD_DIR) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD_DIR
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud NOMBRE_CIUDAD_DIR mayor a la permitida(40)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_CIUDAD_DIR) > 40 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DIRECCION
        SELECT DISTINCT ST_C.ID_RADICADO, 'Longitud ID_DIRECCION mayor a la permitida(20)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_DIRECCION) > 20 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_P.ID_RADICADO, 'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.NRO_PLACA) > 6 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_P.ID_RADICADO, 'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.ID_USUARIO) > 15 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT DISTINCT ST_P.ID_RADICADO, 'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.ID_DOCUMENTO) > 1 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_P.ID_RADICADO, 'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_P.ID_RADICADO, 'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA, 'PROPIETARIOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_PROPIETARIOS_TMP ST_T
        where length (ST_T.NRO_PLACA) > 6 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_TRAMITE mayor a la permitida(4)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_TRAMITE) > 4 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NOMBRE_TRAMITE mayor a la permitida(40)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_TRAMITE) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud FECHA_TRAMITE mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.FECHA_TRAMITE) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud FECHA_TRAMITE menor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.FECHA_TRAMITE) < 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_DESTINO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_SECRETARIA_DESTINO mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SECRETARIA_DESTINO) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_ORIGEN
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_SECRETARIA_ORIGEN mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SECRETARIA_ORIGEN) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_CARROCERIA_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_CARROCERIA_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NOMBRE_CARROCERIA_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_CARROCERIA_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_NUEVA
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_CARROCERIA_NUEVA mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_CARROCERIA_NUEVA) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_NUEVA
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NOMBRE_CARROCERIA_NUEVA mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_CARROCERIA_NUEVA) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_SERVICIO_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SERVICIO_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NOMBRE_SERVICIO_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_SERVICIO_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_SERVICIO_NUEVO mayor a la permitida(8)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SERVICIO_NUEVO) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NOMBRE_SERVICIO_NUEVO mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_SERVICIO_NUEVO) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_USUARIO_ANTERIOR mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_USUARIO_ANTERIOR) > 15 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud ID_USUARIO_NUEVO mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_USUARIO_NUEVO) > 15 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.PORCENTAJE_PROP) > 3 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CLASICO_ANTIGUO) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.BLINDADO) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NIVEL_BLINDADO
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud NIVEL_BLINDADO mayor a la permitida(2)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NIVEL_BLINDADO) > 2 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE DESBLINDAJE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud DESBLINDAJE mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.DESBLINDAJE) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CILINDRAJE) > 10 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CAP_PASAJEROS) > 3 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT DISTINCT ST_T.ID_RADICADO, 'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CAP_TONELADAS) > 6 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where length (ST_H.NRO_PLACA) > 6 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where length (ST_H.ID_USUARIO) > 15 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TIPO_DOCUMENTO_USUARIO
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud TIPO_DOCUMENTO_USUARIO mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where length (ST_H.TIPO_DOCUMENTO) > 1 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
    
        
        -- VALIDO LONGITUD DE PORCENTAJE
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud PORCENTAJE mayor a la permitida(3)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where length (ST_H.PORCENTAJE) > 3 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ------ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_INICIO_PROPIEDAD
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud FECHA diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA_INICIO_PROPIEDAD) < 8) 
        GROUP BY ST_H.ID_RADICADO 
        --ORDER BY ID_RADICADO,ARCHIVO;
        
        union
        
        -- VALIDO LONGITUD DE FECHA_INICIO_PROPIEDAD
        SELECT DISTINCT ST_H.ID_RADICADO, 'Longitud FECHA_FIN_PROPIEDAD diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
        where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA_FIN_PROPIEDAD) < 8) 
        GROUP BY ST_H.ID_RADICADO 
        Union
        
        --Validaciones tramites.
        
        --Radicaciones Sin Id_Origen.
        Select Distinct St.Id_Radicado, 
               'Radicaciones Sin Id_Origen' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen is null
        Group By St.Id_Radicado
        
        union
        
        --Radicaciones Sin Id_Destino.
        Select Distinct St.Id_Radicado, 
               'Radicaciones Sin Id_Destino' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        Group By St.Id_Radicado
        
        union
        
        --Traslados Sin Id_Origen.
        Select Distinct St.Id_Radicado, 
               'Traslados Sin Id_Origen' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen Is Null
        Group By St.Id_Radicado
        
        union
        
        --Traslados Sin Id_Destino.
        Select Distinct St.Id_Radicado, 
               'Traslados Sin Id_Destino' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        Group By St.Id_Radicado
        
        union
        
        --Blindajes Sin Nivel Blindado.
        Select Distinct St.Id_Radicado, 
               'Blindajes Sin Nivel Blindado' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 1 and St.id_radicado = GS_RADICADO
          And St.Blindado Is Not Null And St.Nivel_Blindado is null
        Group By St.Id_Radicado
        
        union
        
        --Transformacion Carroceria Carga Con Capacidad Pasajeros > 3.
        Select Distinct St.Id_Radicado,  
               'Transformacion Carroceria Carga Con Capacidad Casajeros > 3' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 14 and St.id_radicado = GS_RADICADO
          And St.Id_Carroceria_Nueva in('7','8','9','10','12','13','15','17','18','20','21','31','32','42','43',
                                        '44','45','47','58','60','70','78','79','80','83','84','96','98','104',
                                        '115','116','119','125','133','136','142','150','172','174','187','189',
                                        '192','193','196','197','198','199')
          And to_number(St.Cap_Pasajeros) > 3        
        Group By St.Id_Radicado
        
        union
        
        --Id_carroceria nueva != carroceria OC
        Select Distinct St.Id_Radicado, 
               'Id_Carroceria Nueva Diferente a Carroceria OC' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        From ARUNT_VEHICULOS_TMP sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 14  and St.id_radicado = GS_RADICADO
          And SV.ID_CARROCERIA is not null
          And SV.ID_CARROCERIA != ST.ID_CARROCERIA_NUEVA
          And sv.id_radicado = st.id_radicado
        Group By St.Id_Radicado
        
        union
        
        --Porcentaje Traspaso Mayor a 100.
        Select Distinct St.Id_Radicado, 
               'Porcentaje Traspaso Mayor a 100' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And to_number(replace(St.Porcentaje_Prop,'.','')) > 100
        Group By St.Id_Radicado
        
        union
        
        
        --Id_Comprador igual a Id_Vendedor
        Select Distinct St.Id_Radicado, 
               'Id_Comprador Igual a Id_Vendedor' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And ST.ID_USUARIO_nuevo = ST.ID_USUARIO_anterior
        Group By St.Id_Radicado
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select Distinct St.Id_Radicado, 
               'Id_Servicio_Anterior Igual a Id_Servicio_Nuevo' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And ST.ID_SERVICIO_ANTERIOR = ST.ID_SERVICIO_NUEVO
        Group By St.Id_Radicado
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select Distinct St.Id_Radicado, 
               'Id_Servicio_Nuevo Diferente a Id_Servicio_Oc' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        From ARUNT_VEHICULOS_TMP sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And sv.ID_SERVICIO != ST.ID_SERVICIO_NUEVO
          And sv.id_radicado = st.id_radicado
        Group By St.Id_Radicado
        
        /*VALIDAMOS PARAMETRICAS RUNT*/
        UNION 
        --Carrocerias x clase Vehiculos
        select Distinct sv.Id_Radicado, 
               'Carroceria Sin Relacion a La Clase (Vehiculos)' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null  And Sv.Id_Carroceria is Not null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
         
        union
        
        --Carrocerias x clase tramites transformacion
        select Distinct sv.Id_Radicado, 
               'Carroceria Sin Relacion a La Clase (Tramites)' Inconsistencia, 'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        inner join ARUNT_TRAMITES_TMP st on st.nro_placa = sv.nro_placa AND SV.ID_RADICADO = ST.ID_RADICADO
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','')  and rc.codigo_carroceria_ws =REPLACE (st.ID_CARROCERIA_nueva,'.','') 
        where  st.id_tramite = 14 And RC.CODIGO_CARROCERIA_WS is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        

        
        union
        
        
        --Lineas sin relacion a la marca transformacion
        select Distinct sv.Id_Radicado, 
               'Linea Sin Relacion a La Marca' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        left join CORRECCION_DATOS.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        
        union
        
        --Id_Marca con punto
        select Distinct sv.Id_Radicado, 
               'Id_Marca con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where sv.id_marca like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        --Id_Linea con punto
        select Distinct sv.Id_Radicado, 
               'Id_Linea con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where sv.id_linea like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        --Id_Linea con punto
        select Distinct sv.Id_Radicado, 
               'Modelo con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where sv.modelo like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        /*VALIDACION DE CAMPOS NULL*/
        
        select Distinct sv.Id_Radicado, 
               'Id_Marca Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Marca is null  and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union
        
        select Distinct sv.Id_Radicado, 
               'Nro_placa Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  Sv.nro_placa is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Linea Null' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.id_linea is null  and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Modelo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Modelo is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Clase Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.ID_CLASE is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Servicio Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Servicio is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Carroceria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Carroceria is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Combustible Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Combustible is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Secretaria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Secretaria is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Cilindraje Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Cilindraje is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Valor_Factura Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Valor_Factura is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Fecha_Matriculo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Fecha_Matriculo is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Usuario Null' Inconsistencia,'PROPIETARIOS' ARCHIVO, Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Documento Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Porcentaje_Propiedad Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Porcentaje_Prop is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        /*CONTRIBUYENTES*/
        select Distinct sv.Id_Radicado, 
               'Id_Ciudad No Existe en Runt' Inconsistencia, 'Contribuyentes' ARCHIVO,Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        left join CORRECCION_DATOS.runt_ciudades rl
                on rl.divipo = sv.ID_CIUDAD_DIR 
        where rl.nombre = '' and sv.id_radicado = GS_RADICADO  
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Nombres Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Nombres is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Apellidos Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Apellidos is null And sv.Id_Documento != 'N' and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Direccion Null' Inconsistencia,'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Direccion is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        /*
        union 
        
        select Distinct sv.Id_Radicado, 
               'Telefono Null y Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Telefono is null  and SV.Celular is null And sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado */
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Ciudad_Dir Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Ciudad_Dir is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Documento Null' Inconsistencia,'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Usuario Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, 
               'Id_Tramite Null' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        from ARUNT_TRAMITES_TMP sv
        where  SV.Id_Tramite is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        Union
        
        Select Distinct Sv.Id_Radicado, 
               'Vehiculos No Reportados En Tramites' Inconsistencia, 'Vehiculos' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        left join ARUNT_TRAMITES_TMP st on st.nro_placa = sv.nro_placa and sv.id_radicado = st.Id_radicado
        where st.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        UNION
        
        Select Distinct Sv.Id_Radicado, 
               'Vehiculos No Reportados En Propietarios' Inconsistencia, 'Vehiculos' ARCHIVO, Count(1) Cantidad 
        from ARUNT_VEHICULOS_TMP sv
        left join ARUNT_PROPIETARIOS_TMP sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        UNION
        
        Select Distinct Sv.Id_Radicado, 
               'Tramites No Reportados En Propietarios' Inconsistencia, 'Tramites' ARCHIVO, Count(1) Cantidad 
        from ARUNT_TRAMITES_TMP sv
        left join ARUNT_PROPIETARIOS_TMP sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado 
        
        UNION
        
        Select Distinct st.Id_Radicado, 
               'Tramites No Reportados En Vehiculos' Inconsistencia, 'Tramites' ARCHIVO, Count(1) Cantidad 
        from ARUNT_TRAMITES_TMP st
        left join ARUNT_VEHICULOS_TMP sv on sv.nro_placa = st.nro_placa and sv.id_radicado = st.Id_radicado
        where sv.nro_placa is null and st.id_radicado = GS_RADICADO
        Group By st.Id_Radicado 
        
        UNION
        
        Select Distinct sp.Id_Radicado, 
               'Propietarios No Reportados En Vehiculos' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_VEHICULOS_TMP sv on sp.nro_placa = sv.nro_placa and sp.id_radicado = sv.Id_radicado
        where sv.nro_placa is null and sp.id_radicado = GS_RADICADO
        Group By sp.Id_Radicado 
        
        UNION
        
        Select Distinct sp.Id_Radicado, 
               'Propietarios No Reportados En Tramites' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_TRAMITES_TMP st on sp.nro_placa = st.nro_placa and sp.id_radicado = st.Id_radicado
        where st.nro_placa is null and sp.id_radicado = GS_RADICADO
        Group By sp.Id_Radicado 
        
        UNION
        
        Select Distinct Sp.Id_Radicado, 
               'Propietarios No Reportados En Contribuyentes' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_CONTRIBUYENTES_TMP sc on Sp.Id_Usuario = Sc.Id_Usuario And Sp.Id_Documento = Sc.Id_Documento and sp.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sp.id_radicado = GS_RADICADO
        Group By Sp.Id_Radicado 
        
        UNION
        
        Select Distinct Sh.Id_Radicado, 
               'Vendedores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, Count(1) Cantidad 
        from ARUNT_HISTORICO_TRASPASO_TMP sh
        left join ARUNT_CONTRIBUYENTES_TMP sc on Sh.Id_Usuario = Sc.Id_Usuario And Sh.TIPO_DOCUMENTO = sc.ID_DOCUMENTO and sh.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
        Group By Sh.Id_Radicado 
        
        UNION
        
        Select Distinct Sh.Id_Radicado, 
               'Compradores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, Count(1) Cantidad 
        from ARUNT_HISTORICO_TRASPASO_TMP sh
        left join ARUNT_CONTRIBUYENTES_TMP sc on Sc.Id_Usuario = Sh.ID_USUARIO And Sc.Id_Documento = Sh.TIPO_DOCUMENTO and sh.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
        Group By Sh.Id_Radicado ;

Begin
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_RUNT',lv_Archivo,'W');  
        For ln_index In lcur_Detalle_Incons Loop
                    If lb_Existe = False Then
                            UTL_FILE.PUT_LINE(lutl_archivo,'ID_RADICADO;'||'INCONSISTENCIA;'||'ARCHIVO;'||'CANTIDAD');
                        lb_Existe:=True;
                    End If;
                UTL_FILE.PUT_LINE(lutl_archivo,ln_index.id_radicado||';'
                    ||ln_index.inconsistencia||';'
                    ||ln_index.archivo||';'
                    ||ln_index.cantidad);
        End Loop;
     UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Detalle_Inconsistencia;

Procedure SP_Inconsistencia_Vehiculos As

/*ISVA
Nombre     :SP_Inconsistencia_Vehiculos
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_RUNT
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por runt 
           :para los vehiculos   
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' VEHICULOS ' ||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;
        
        Cursor lcur_vehiculos Is 
            -- VALIDO LONGITUD DE NRO_PLACA
        SELECT  'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NRO_PLACA) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_MARCA
        SELECT   'Longitud ID_MARCA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.ID_MARCA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_MARCA
        SELECT   'Longitud NOMBRE_MARCA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_MARCA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.ID_LINEA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_LINEA
        SELECT   'Longitud NOMBRE_LINEA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_LINEA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE MODELO
        SELECT   'Longitud MODELO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CLASE
        SELECT   'Longitud ID_CLASE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_CLASE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_LINEA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CLASE
        SELECT   'Longitud NOMBRE_CLASE mayor a la permitida(40)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_CLASE) > 40 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_SERVICIO
        SELECT   'Longitud ID_SERVICIO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_SERVICIO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO
        SELECT   'Longitud NOMBRE_SERVICIO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_SERVICIO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE ID_CARROCERIA
        SELECT   'Longitud ID_CARROCERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_CARROCERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA
        SELECT   'Longitud NOMBRE_CARROCERIA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_CARROCERIA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_COMBUSTIBLE
        SELECT   'Longitud ID_COMBUSTIBLE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_COMBUSTIBLE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_BATERIA
        SELECT   'Longitud ID_BATERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_BATERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_BATERIA
        SELECT   'Longitud NOMBRE_BATERIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_BATERIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE POTENCIA
        SELECT   'Longitud POTENCIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.POTENCIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA
        SELECT   'Longitud ID_SECRETARIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_SECRETARIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SECRETARIA
        SELECT   'Longitud NOMBRE_SECRETARIA mayor a la permitida(80)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_SECRETARIA) > 80 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CILINDRAJE) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CAP_TONELADAS) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE VALOR_FACTURA
        SELECT   'Longitud VALOR_FACTURA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.VALOR_FACTURA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.BLINDADO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE IMPORTADO_NACIONAL
        SELECT   'Longitud IMPORTADO_NACIONAL mayor a la permitida(2)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.IMPORTADO_NACIONAL) > 2 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_ESTADO
        SELECT   'Longitud ID_ESTADO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.ID_ESTADO) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_ESTADO
        SELECT   'Longitud NOMBRE_ESTADO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NOMBRE_ESTADO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.CLASICO_ANTIGUO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PUERTAS
        SELECT   'Longitud NRO_PUERTAS mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.NRO_PUERTAS) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   'Longitud FECHA_MATRICULO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.FECHA_MATRICULO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   'Longitud FECHA_MATRICULO menos a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM ARUNT_VEHICULOS_TMP ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        Select 'Vehiculos No Reportados En Tramites' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        left join ARUNT_TRAMITES_TMP st on st.nro_placa = sv.nro_placa and sv.id_radicado = st.Id_radicado
        where st.nro_placa is null and sv.id_radicado =GS_RADICADO 
        
        union
        

        Select 'Vehiculos No Reportados En Propietarios' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        left join ARUNT_PROPIETARIOS_TMP sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado =GS_RADICADO
        
        union
        
        --Carrocerias x clase Vehiculos
        select 'Carroceria Sin Relacion a La Clase (Vehiculos)' Inconsistencia,'VEHICULOS' ARCHIVO, sv.* , sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null And Sv.Id_Carroceria is Not null and sv.id_radicado =GS_RADICADO 
        
        
        union
        
        --Lineas sin relacion a la marca transformacion
        select 'Linea Sin Relacion a La Marca' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        left join CORRECCION_DATOS.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null And Id_Linea is not null and sv.id_radicado =GS_RADICADO 
        
        union
        
        --Id_Marca con punto
        select 'Id_Marca con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where sv.id_marca like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select 'Id_Linea con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where sv.id_linea like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select 
               'Modelo con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where sv.modelo like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --VALIDACION DE CAMPOS NULL
        
        select  
               'Id_Marca Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Marca is null  and sv.id_radicado =GS_RADICADO 
        
        union
        
        select  
               'Nro_placa Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  Sv.nro_placa is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  
               'Id_Linea Null' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.id_linea is null  and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  
               'Modelo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Modelo is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  
               'Id_Clase Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.ID_CLASE is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  
               'Id_Servicio Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Servicio is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  
               'Id_Carroceria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Carroceria is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  
               'Id_Combustible Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Combustible is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  
               'Id_Secretaria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Id_Secretaria is null  and sv.id_radicado =GS_RADICADO
        
        union 
        select 'Cilindraje Null o Cero' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  (SV.Cilindraje  is null or SV.Cilindraje = 0) And Id_Combustible Not In (5)
        And sv.id_radicado =GS_RADICADO
        
        union 
        
        select  
               'Valor_Factura Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Valor_Factura is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select   
               'Fecha_Matriculo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from ARUNT_VEHICULOS_TMP sv
        where  SV.Fecha_Matriculo is null  and sv.id_radicado =GS_RADICADO;

Begin 
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_RUNT',lv_Archivo,'W');
        For Ln_Index In lcur_vehiculos Loop
            
        Begin
            If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'
                                                ||'ID_LINEA;'||'NOMBRE_LINEA;'||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'
                                                ||'NOMBRE_SERVICIO;'||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'
                                                ||'ID_COMBUSTIBLE;'||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'
                                                ||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'||'ID_ESTADO;'
                                                ||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'||'ID_RADICADO;'
                                                ||'CAJA;'||'TRACCION;'||'COMBUSTION');
                     lb_Existe:=True;
            End If;
            UTL_FILE.PUT_LINE(lutl_archivo,Ln_Index.INCONSISTENCIA||';'
            ||Ln_Index.ARCHIVO||';'
            ||Ln_Index.NRO_PLACA||';'
            ||Ln_Index.ID_MARCA||';'
            ||Ln_Index.NOMBRE_MARCA||';'
            ||Ln_Index.ID_LINEA||';'
            ||Ln_Index.NOMBRE_LINEA||';'
            ||Ln_Index.MODELO||';'
            ||Ln_Index.ID_CLASE||';'
            ||Ln_Index.NOMBRE_CLASE||';'
            ||Ln_Index.ID_SERVICIO||';'
            ||Ln_Index.NOMBRE_SERVICIO||';'
            ||Ln_Index.ID_CARROCERIA||';'
            ||Ln_Index.NOMBRE_CARROCERIA||';'
            ||Ln_Index.NRO_PUERTAS||';'
            ||Ln_Index.ID_COMBUSTIBLE||';'
            ||Ln_Index.NOMBRE_COMBUSTIBLE||';'
            ||Ln_Index.ID_BATERIA||';'
            ||Ln_Index.NOMBRE_BATERIA||';'
            ||Ln_Index.POTENCIA||';'
            ||Ln_Index.ID_SECRETARIA||';'
            ||Ln_Index.NOMBRE_SECRETARIA||';'
            ||Ln_Index.CILINDRAJE||';'
            ||Ln_Index.CAP_PASAJEROS||';'
            ||Ln_Index.CAP_TONELADAS||';'
            ||Ln_Index.VALOR_FACTURA||';'
            ||Ln_Index.BLINDADO||';'
            ||Ln_Index.IMPORTADO_NACIONAL||';'
            ||Ln_Index.ID_ESTADO||';'
            ||Ln_Index.NOMBRE_ESTADO||';'
            ||Ln_Index.CLASICO_ANTIGUO||';'
            ||Ln_Index.FECHA_MATRICULO||';'
            ||Ln_Index.ID_RADICADO||';'
            ||Ln_Index.CAJA||';'
            ||Ln_Index.TRACCION||';'
            ||Ln_Index.COMBUSTION);
                
                --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                --Values (ln_index.rowid, 'tmp_vehiculos');
            
            Exception 
                When Others Then 
                    Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'arunt_Vehiculos'); 
        End;   
        End Loop;
        Commit;
         UTL_FILE.FCLOSE(lutl_archivo); 
         
END Sp_Inconsistencia_Vehiculos;

Procedure Sp_Inconsistencia_Tramites As

/*ISVA
Nombre     :PKG_INCONSISTENCIAS_TRANSITOS
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los tramites
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                 */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' TRAMITES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

-- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_tramites Is 
        SELECT   'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NRO_PLACA) > 6 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_TRAMITE
        SELECT   'Longitud ID_TRAMITE mayor a la permitida(4)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_TRAMITE) > 4 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_TRAMITE
        SELECT   'Longitud NOMBRE_TRAMITE mayor a la permitida(40)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_TRAMITE) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   'Longitud FECHA_TRAMITE mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.FECHA_TRAMITE) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   'Longitud FECHA_TRAMITE menor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.FECHA_TRAMITE) < 8 and ST_T.id_radicado = GS_RADICADO

        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_DESTINO
        SELECT   'Longitud ID_SECRETARIA_DESTINO mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SECRETARIA_DESTINO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_ORIGEN
        SELECT  'Longitud ID_SECRETARIA_ORIGEN mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SECRETARIA_ORIGEN) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_ANTERIOR
        SELECT   'Longitud ID_CARROCERIA_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_CARROCERIA_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_ANTERIOR
        SELECT   'Longitud NOMBRE_CARROCERIA_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_CARROCERIA_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_NUEVA
        SELECT   'Longitud ID_CARROCERIA_NUEVA mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_CARROCERIA_NUEVA) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_NUEVA
        SELECT   'Longitud NOMBRE_CARROCERIA_NUEVA mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_CARROCERIA_NUEVA) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_ANTERIOR
        SELECT   'Longitud ID_SERVICIO_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SERVICIO_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_ANTERIOR
        SELECT   'Longitud NOMBRE_SERVICIO_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_SERVICIO_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_NUEVO
        SELECT   'Longitud ID_SERVICIO_NUEVO mayor a la permitida(8)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_SERVICIO_NUEVO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_NUEVO
        SELECT   'Longitud NOMBRE_SERVICIO_NUEVO mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NOMBRE_SERVICIO_NUEVO) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_ANTERIOR
        SELECT   'Longitud ID_USUARIO_ANTERIOR mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_USUARIO_ANTERIOR) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_NUEVO
        SELECT   'Longitud ID_USUARIO_NUEVO mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.ID_USUARIO_NUEVO) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.PORCENTAJE_PROP) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CLASICO_ANTIGUO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.BLINDADO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NIVEL_BLINDADO
        SELECT   'Longitud NIVEL_BLINDADO mayor a la permitida(2)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.NIVEL_BLINDADO) > 2 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DESBLINDAJE
        SELECT   'Longitud DESBLINDAJE mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.DESBLINDAJE) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CILINDRAJE) > 10 and ST_T.id_radicado = GS_RADICADO
                
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CAP_PASAJEROS) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM ARUNT_TRAMITES_TMP ST_T
        where length (ST_T.CAP_TONELADAS) > 6 and ST_T.id_radicado = GS_RADICADO
        
        UNION
        
        Select 
               'Tramites No Reportados En Propietarios' Inconsistencia, 'Tramites' ARCHIVO, sv.*, sv.rowid
        from ARUNT_TRAMITES_TMP sv
        left join ARUNT_PROPIETARIOS_TMP sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        
       
        UNION
        
        Select 
               'Tramites No Reportados En Vehiculos' Inconsistencia, 'Tramites' ARCHIVO, st.*, st.rowid
        from ARUNT_TRAMITES_TMP st
        left join ARUNT_VEHICULOS_TMP sv on sv.nro_placa = st.nro_placa and sv.id_radicado = st.Id_radicado
        where sv.nro_placa is null and st.id_radicado = GS_RADICADO
        
        union
        --Validaciones tramites.
        
        --Radicaciones Sin Id_Origen.
        Select 
               'Radicaciones Sin Id_Origen' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen is null
        
        
        union
        
        --Radicaciones Sin Id_Destino.
        Select  
               'Radicaciones Sin Id_Destino' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Traslados Sin Id_Origen.
        Select 
               'Traslados Sin Id_Origen' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen Is Null
        
        
        union
        
        --Traslados Sin Id_Destino.
        Select  
               'Traslados Sin Id_Destino' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Blindajes Sin Nivel Blindado.
        Select  
               'Blindajes Sin Nivel Blindado' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 1 and St.id_radicado = GS_RADICADO
          And St.Blindado Is Not Null And St.Nivel_Blindado is null
        
        
        union
        
        --Transformacion Carroceria Carga Con Capacidad Casajeros > 3.
        Select    
               'Transformacion Carroceria Carga Con Capacidad Casajeros > 3' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 14 and St.id_radicado = GS_RADICADO
          And St.Id_Carroceria_Nueva in('7','8','9','10','12','13','15','17','18','20','21','31','32','42','43',
                                        '44','45','47','58','60','70','78','79','80','83','84','96','98','104',
                                        '115','116','119','125','133','136','142','150','172','174','187','189',
                                        '192','193','196','197','198','199')
          And to_number(St.Cap_Pasajeros) > 3        
        
        
        union
        
        --Id_carroceria nueva != carroceria OC
        Select  'Id_Carroceria Nueva Diferente a Carroceria OC' Inconsistencia,'VEHICULOS' ARCHIVO, St.* , st.rowid
        From ARUNT_VEHICULOS_TMP sv
        inner join ARUNT_TRAMITES_TMP St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 14  and St.id_radicado = GS_RADICADO
          And SV.ID_CARROCERIA is not null
          And SV.ID_CARROCERIA != ST.ID_CARROCERIA_NUEVA
          And sv.id_radicado = st.id_radicado
        
        
        union
        
        --Porcentaje Traspaso Mayor a 100.
        Select  
               'Porcentaje Traspaso Mayor a 100' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And to_number(replace(St.Porcentaje_Prop,'.','')) > 100
        
        
        union
        
        
        --Id_Comprador igual a Id_Vendedor
        Select 
               'Id_Comprador Igual a Id_Vendedor' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And ST.ID_USUARIO_nuevo = ST.ID_USUARIO_anterior
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select 
               'Id_Servicio_Anterior Igual a Id_Servicio_Nuevo' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid 
        From ARUNT_TRAMITES_TMP St
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And ST.ID_SERVICIO_ANTERIOR = ST.ID_SERVICIO_NUEVO
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select  
               'Id_Servicio_Nuevo Diferente a Id_Servicio_Oc' Inconsistencia,'VEHICULOS' ARCHIVO, St.*, st.rowid
        From ARUNT_VEHICULOS_TMP sv
        inner join ARUNT_TRAMITES_TMP St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And sv.ID_SERVICIO != ST.ID_SERVICIO_NUEVO
          And sv.id_radicado = st.id_radicado
        
        union
        
        --Carrocerias x clase tramites transformacion
        select  
               'Carroceria Sin Relacion a La Clase (Tramites)' Inconsistencia, 'VEHICULOS' ARCHIVO, st.*, st.rowid 
        from ARUNT_VEHICULOS_TMP sv
        inner join ARUNT_TRAMITES_TMP st on st.nro_placa = sv.nro_placa AND SV.ID_RADICADO = ST.ID_RADICADO
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','')  and rc.codigo_carroceria_ws =REPLACE (st.ID_CARROCERIA_nueva,'.','') 
        where  st.id_tramite = 14 And RC.CODIGO_CARROCERIA_WS is null and sv.id_radicado = GS_RADICADO
        And st.ID_CARROCERIA_nueva is not null
        
        union 
        
        select  
               'Id_Tramite Null' Inconsistencia, 'TRAMITES' ARCHIVO, sv.*, sv.rowid
        from ARUNT_TRAMITES_TMP sv
        where  SV.Id_Tramite is null  and sv.id_radicado = GS_RADICADO;
        
Begin   
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_RUNT',lv_Archivo,'W');  
        For Ln_Index In lcur_tramites Loop   
        Begin
            
                If lb_Existe = False Then
                    UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_TRAMITE;'||'NOMBRE_TRAMITE;'
                                                ||'FECHA_TRAMITE;'||'TIPO_CANCELACION;'||'ID_SECRETARIA_DESTINO;'||'ID_SECRETARIA_ORIGEN;'
                                                ||'ID_CARROCERIA_ANTERIOR;'||'NOMBRE_CARROCERIA_ANTERIOR;'||'ID_CARROCERIA_NUEVA;'
                                                ||'NOMBRE_CARROCERIA_NUEVA;'||'ID_SERVICIO_ANTERIOR;'||'NOMBRE_SERVICIO_ANTERIOR;'
                                                ||'ID_SERVICIO_NUEVO;'||'NOMBRE_SERVICIO_NUEVO;'||'ID_DOCUMENTO_ANTERIOR;'||'ID_USUARIO_ANTERIOR;'
                                                ||'ID_DOCUMENTO_NUEVO;'||'ID_USUARIO_NUEVO;'||'PORCENTAJE_PROP;'||'CLASICO_ANTIGUO;'||'BLINDADO;'
                                                ||'NIVEL_BLINDADO;'||'DESBLINDAJE;'||'CILINDRAJE;'||'CAP_PASAJEROS;'||'CAP_TONELADAS;'||'ID_RADICADO');
                        lb_Existe:=True;
                 End If;
                UTL_FILE.PUT_LINE(lutl_archivo,Ln_Index.INCONSISTENCIA||';'
                    ||Ln_Index.ARCHIVO||';'
                    ||Ln_Index.NRO_PLACA||';'
                    ||Ln_Index.ID_TRAMITE||';'
                    ||Ln_Index.NOMBRE_TRAMITE||';'
                    ||Ln_Index.FECHA_TRAMITE||';'
                    ||Ln_Index.TIPO_CANCELACION||';'
                    ||Ln_Index.ID_SECRETARIA_DESTINO||';'
                    ||Ln_Index.ID_SECRETARIA_ORIGEN	||';'
                    ||Ln_Index.ID_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.ID_CARROCERIA_NUEVA||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_NUEVA||';'
                    ||Ln_Index.ID_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.ID_SERVICIO_NUEVO||';'
                    ||Ln_Index.NOMBRE_SERVICIO_NUEVO||';'
                    ||Ln_Index.ID_DOCUMENTO_ANTERIOR||';'
                    ||Ln_Index.ID_USUARIO_ANTERIOR||';'
                    ||Ln_Index.ID_DOCUMENTO_NUEVO||';'
                    ||Ln_Index.ID_USUARIO_NUEVO||';'
                    ||Ln_Index.PORCENTAJE_PROP||';'
                    ||Ln_Index.CLASICO_ANTIGUO||';'
                    ||Ln_Index.BLINDADO||';'
                    ||Ln_Index.NIVEL_BLINDADO||';'
                    ||Ln_Index.DESBLINDAJE||';'
                    ||Ln_Index.CILINDRAJE||';'
                    ||Ln_Index.CAP_PASAJEROS||';'
                    ||Ln_Index.CAP_TONELADAS||';'
                    ||Ln_Index.ID_RADICADO);   
                    
                    Exception 
                        When Others Then 
                            Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Arunt_Vehiculos'); 
            End;
            End Loop;
        UTL_FILE.FCLOSE(lutl_archivo);
    End Sp_Inconsistencia_Tramites;

Procedure Sp_Inconsistencia_Contribuyent As

/*ISVA
Nombre     :PKG_INCONSISTENCIAS_TRANSITOS
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por runt
           :para los contribuyentes
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                    */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' CONTRIBUYENTES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

    -- VALIDO LONGITUD DE ID_USUARIO
        Cursor lcur_contribuyentes Is
        SELECT   'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_USUARIO) > 15 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_DOCUMENTO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD
        SELECT   'Longitud ID_CIUDAD mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_CIUDAD) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD
        SELECT   'Longitud NOMBRE_CIUDAD mayor a la permitida(30)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_CIUDAD) > 30 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE APELLIDOS
        SELECT   'Longitud APELLIDOS mayor a la permitida(80)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.APELLIDOS) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRES
        SELECT   'Longitud NOMBRES mayor a la permitida(80)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRES) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DIRECCION
        SELECT   'Longitud DIRECCION mayor a la permitida(100)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.DIRECCION) > 100 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   'Longitud TELEFONO mayor a la permitida(14)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.TELEFONO) > 14 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   'Longitud TELEFONO MENOR a la permitida(7)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.TELEFONO) < 7 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   'Longitud CELULAR mayor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.CELULAR) > 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   'Longitud CELULAR menor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.CELULAR) < 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMP_O_PART
        SELECT   'Longitud EMP_O_PART mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.EMP_O_PART) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE SEXO
        SELECT   'Longitud SEXO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.SEXO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   'Longitud FECHA_NACIMIENTO mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_NACIMIENTO) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   'Longitud FECHA_NACIMIENTO menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_NACIMIENTO) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_PAIS
        SELECT   'Longitud ID_PAIS mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_PAIS) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE NOMBRE_PAIS
        SELECT   'Longitud NOMBRE_PAIS mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_PAIS) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   'Longitud FECHA_MODIFICACION mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_MODIFICACION) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   'Longitud FECHA_MODIFICACION menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_MODIFICACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FAX
        SELECT   'Longitud FAX mayor a la permitida(12)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FAX) > 12 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT   'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   'Longitud FECHA_ACTUALIZACION mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_ACTUALIZACION) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.FECHA_ACTUALIZACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD_DIR
        SELECT   'Longitud ID_CIUDAD_DIR mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_CIUDAD_DIR) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD_DIR
        SELECT   'Longitud NOMBRE_CIUDAD_DIR mayor a la permitida(40)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.NOMBRE_CIUDAD_DIR) > 40 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DIRECCION
        SELECT   'Longitud ID_DIRECCION mayor a la permitida(20)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM ARUNT_CONTRIBUYENTES_TMP ST_C
        where length (ST_C.ID_DIRECCION) > 20 and ST_C.id_radicado = GS_RADICADO
        
        
        union 
        
        /*CONTRIBUYENTES*/
        select 
               'Id_Ciudad No Existe en Runt' Inconsistencia, 'Contribuyentes' ARCHIVO,sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        left join CORRECCION_DATOS.runt_ciudades rl
                on rl.divipo = sv.ID_CIUDAD_DIR 
        where rl.nombre = '' and sv.id_radicado = GS_RADICADO  
        
        union 
        
        select  
               'Nombres Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Nombres is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  
               'Apellidos Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Apellidos is null And sv.Id_Documento != 'N' and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  
               'Direccion Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Direccion is null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
         validacion de telefono y celular pendiente por activar esta validacion
        
        select  
               'Telefono Null y Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Telefono is null And SV.Celular is Null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
        select  sv.Id_Radicado, 
               'Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Celular is null  and sv.id_radicado = GS_RADICADO 
        
        union 
        
        select  sv.Id_Radicado, 
               'Email Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Email is null  and sv.id_radicado = GS_RADICADO */
        
        union 
        
        select  
               'Id_Ciudad_Dir Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Ciudad_Dir is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  
               'Id_Documento Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select 
               'Id_Usuario Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from ARUNT_CONTRIBUYENTES_TMP sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO;

Begin
     lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_RUNT',lv_Archivo,'W');  
        For ln_index In lcur_contribuyentes Loop
        
          If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'ID_USUARIO;'||'ID_DOCUMENTO;'
                            ||'ID_CIUDAD;'||'NOMBRE_CIUDAD;'||'APELLIDOS;'||'NOMBRES;'||'DIRECCION;'||'TELEFONO;'||'MP_O_PART;'||'SEXO;'
                            ||'FECHA_NACIMIENTO;'||'ID_PAIS;'||'NOMBRE_PAIS;'||'FECHA_MODIFICACION;'||'FAX;'||'EMAIL;'||'FECHA_ACTUALIZACION;'
                            ||'ID_CIUDAD_DIR;'||'NOMBRE_CIUDAD_DIR;'||'ID_DIRECCION;'||'ID_RADICADO;'||'CELULAR');                     
                        lb_Existe:=True;
         End If;
            UTL_FILE.PUT_LINE(lutl_archivo,ln_index.Inconsistencia ||';'
                ||ln_index.archivo||';'
                ||ln_index.id_usuario||';'
                ||ln_index.id_documento||';'
                ||ln_index.id_ciudad||';'
                ||ln_index.nombre_ciudad||';'
                ||ln_index.apellidos||';'
                ||ln_index.nombres||';'
                ||ln_index.direccion||';'
                ||ln_index.telefono||';'
                ||ln_index.emp_o_part||';'
                ||ln_index.sexo||';'
                ||ln_index.fecha_nacimiento||';'
                ||ln_index.Id_Pais||';'
                ||ln_index.nombre_pais||';'
                ||ln_index.fecha_modificacion||';'
                ||ln_index.fax||';'
                ||ln_index.email||';'
                ||ln_index.fecha_actualizacion||';'
                ||ln_index.id_ciudad_dir||';'
                ||ln_index.nombre_ciudad_dir||';'
                ||ln_index.id_direccion||';'
                ||ln_index.id_radicado||';'
                ||ln_index.celular);
                               
        End Loop;
            UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Contribuyent;

Procedure Sp_Inconsistencia_Propietarios As

/*ISVA
Nombre     :Sp_Inconsistencia_Propietarios
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por runt
           :para los propietarios
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                        */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' PROPIETARIOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

      -- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_propietarios Is
        SELECT   'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.NRO_PLACA) > 6 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT   'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.ID_USUARIO) > 15 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.ID_DOCUMENTO) > 1 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA, 'PROPIETARIOS' as ARCHIVO,ST_P.*, St_p.Rowid
        FROM ARUNT_PROPIETARIOS_TMP ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select 'Propietarios No Reportados En Vehiculos' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_VEHICULOS_TMP sv on sp.nro_placa = sv.nro_placa and sp.id_radicado = sv.Id_radicado
        where sv.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select   
               'Propietarios No Reportados En Tramites' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_TRAMITES_TMP st on sp.nro_placa = st.nro_placa and sp.id_radicado = st.Id_radicado
        where st.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select  
               'Propietarios No Reportados En Contribuyentes' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from ARUNT_PROPIETARIOS_TMP sp
        left join ARUNT_CONTRIBUYENTES_TMP sc on Sp.Id_Usuario = Sc.Id_Usuario And Sp.Id_Documento = Sc.Id_Documento and sp.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sp.id_radicado = GS_RADICADO
        
        union
         
        
        select  
               'Id_Usuario Null' Inconsistencia,'PROPIETARIOS' ARCHIVO, sv.*, Sv.Rowid
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select   
               'Id_Documento Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select  
               'Porcentaje_Propiedad Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from ARUNT_PROPIETARIOS_TMP sv
        where  SV.Porcentaje_Prop is null  and sv.id_radicado = GS_RADICADO;
Begin
     lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
      For ln_index In lcur_propietarios Loop
             If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                               ||'ID_DOCUMENTO;'||'PORCENTAJE_PROP;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.id_documento||';'
                ||Ln_Index.porcentaje_prop||';'
                ||Ln_Index.id_radicado);
            
    End Loop;
         UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Propietarios;

Procedure Sp_Validar_Histo_Traspasos As

/*ISVA
Nombre     :Sp_Validar_Histo_Traspasos
Autor      :Blados.Ospina
Fecha      :30/10/2018
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_RUNT
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los historiales traspasos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' HISTORIALES_TRASPASOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

  -- VALIDO LONGITUD DE NRO_PLACA
            Cursor lcur_histo_Tras Is
            -- VALIDO LONGITUD DE NRO_PLACA
            SELECT  'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where length (ST_H.NRO_PLACA) > 6 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE ID_USUARIO
            SELECT   'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where length (ST_H.ID_USUARIO) > 15 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE TIPO_DOCUMENTO_USUARIO
            SELECT   'Longitud TIPO_DOCUMENTO_USUARIO mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where length(ST_H.TIPO_DOCUMENTO) > 1
            
            union
            
            -- VALIDO LONGITUD DE PORCENTAJE
            SELECT   'Longitud PORCENTAJE mayor a la permitida(3)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where length (ST_H.PORCENTAJE) > 3 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE FECHA
            SELECT   'Longitud FECHA INICIO PROPIEDAD diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA_INICIO_PROPIEDAD) < 8) 
            
            UNION
            
                -- VALIDO LONGITUD DE FECHA
            SELECT   'Longitud FECHA FIN PROPIEDAD diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM ARUNT_HISTORICO_TRASPASO_TMP ST_H
            where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA_FIN_PROPIEDAD) < 8) 
            
           /* UNION
            
            Select Distinct 'Vendedores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from ARUNT_HISTORICO_TRASPASO_TMP sh
            left join ARUNT_CONTRIBUYENTES_TMP sc on Sh.Id_Usuario = Sc.Id_Usuario And Sh.TIPO_DOCUMENTO = sc.ID_DOCUMENTO and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO*/
            
            
            UNION
            
            Select Distinct 
                   'Compradores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from ARUNT_HISTORICO_TRASPASO_TMP sh
            left join ARUNT_CONTRIBUYENTES_TMP sc on Sc.Id_Usuario = Sh.ID_USUARIO And Sc.Id_Documento = Sh.TIPO_DOCUMENTO and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO;

Begin 
         lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_RUNT',lv_Archivo,'W');  
        For ln_index In lcur_Histo_Tras Loop
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                                        ||'TIPO_DOCUMENTO;'||'PORCENTAJE;'||'FECHA_INICIO_PROPIEDAD;'
                                                        ||'FECHA_FIN_PROPIEDAD;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.tipo_documento||';'
                ||Ln_Index.porcentaje||';'
                ||Ln_Index.fecha_inicio_propiedad||';'
                ||Ln_Index.fecha_fin_propiedad||';'
                ||Ln_Index.id_radicado);
                
                
        End Loop;
        
    UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Validar_Histo_Traspasos;

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer) AS

/*ISVA
Nombre     :Sp_Iniciar_Inconsistencia
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Ejecuta todos los procesos del pl-sql
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

BEGIN

GS_RADICADO := as_id_radicado;

    Sp_Detalle_Inconsistencia;
    SP_Inconsistencia_Vehiculos;
    Sp_Inconsistencia_Tramites;
    Sp_Inconsistencia_Propietarios;
    Sp_Inconsistencia_Contribuyent;
    Sp_Validar_Histo_Traspasos;
      
END Sp_Iniciar_Inconsistencia;

END PKG_INCONSISTENCIAS_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_INCONSISTENCIAS_TRANSITOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_INCONSISTENCIAS_TRANSITOS" AS

iv_Transito Varchar2(255 Byte);
GS_RADICADO Simple_Integer:=0;

Procedure Sp_Registrar_Transito As

/*ISVA
Nombre     :Sp_Registrar_Transito
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Recupera el nombre del transito
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

Begin
iv_Transito:='';

    Select Distinct Fm.Municipio Into iv_Transito From St_Maestro Sm
    Inner Join Bd_Fiscalizacion.Fc_Municipio_Departamento Fm On Fm.Divipo = Sm.Id_Secretaria
    Where Id_Radicado = GS_RADICADO;

Exception 
    When Others Then 
    iv_Transito:='';    
    
End Sp_Registrar_Transito;

Procedure Sp_Detalle_Inconsistencia As

/*
Nombre     :Sp_Detalle_Inconsistencia
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Registra todas la incosistencias 
           :de forma mas detallada
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):= GS_RADICADO||' '||iv_Transito||' DETALLE_INCONSISTENCIA '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

            -- VALIDO LONGITUD DE NRO_PLACA 
        Cursor lcur_detalle_incons Is
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PLACA) > 6 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
            
        union
        
        -- VALIDO LONGITUD DE ID_MARCA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_MARCA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_MARCA,'.','')) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_MARCA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_MARCA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_MARCA) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_LINEA,'.','')) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_LINEA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_LINEA) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE MODELO
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud MODELO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE ID_CLASE
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_CLASE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CLASE) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_LINEA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CLASE
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_CLASE mayor a la permitida(40)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CLASE) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_SERVICIO
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_SERVICIO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SERVICIO) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_SERVICIO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SERVICIO) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union 
        
        -- VALIDO LONGITUD DE ID_CARROCERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_CARROCERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CARROCERIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_CARROCERIA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CARROCERIA) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_COMBUSTIBLE
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_COMBUSTIBLE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_COMBUSTIBLE) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE ID_BATERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_BATERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_BATERIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO 
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_BATERIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_BATERIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_BATERIA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE POTENCIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud POTENCIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.POTENCIA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud ID_SECRETARIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SECRETARIA) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SECRETARIA
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud NOMBRE_SECRETARIA mayor a la permitida(80)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SECRETARIA) > 80 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CILINDRAJE) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT DISTINCT ST_V.ID_RADICADO ,  iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_TONELADAS) > 6 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE VALOR_FACTURA
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud VALOR_FACTURA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.VALOR_FACTURA) > 10 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.BLINDADO) > 1 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE IMPORTADO_NACIONAL
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud IMPORTADO_NACIONAL mayor a la permitida(2)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.IMPORTADO_NACIONAL) > 2 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_ESTADO
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud ID_ESTADO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_ESTADO) > 4 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_ESTADO
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud NOMBRE_ESTADO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_ESTADO) > 40 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CLASICO_ANTIGUO) > 1 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PUERTAS
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud NRO_PUERTAS mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PUERTAS) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT DISTINCT ST_V.ID_RADICADO , iv_Transito ,'Longitud FECHA_MATRICULO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) > 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT DISTINCT  ST_V.ID_RADICADO , iv_Transito ,'Longitud FECHA_MATRICULO menos a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 and ST_V.id_radicado = GS_RADICADO
        GROUP BY ST_V.ID_RADICADO 
        --ORDER BY ST_V.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_USUARIO) > 15 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DOCUMENTO) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_CIUDAD mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_CIUDAD mayor a la permitida(30)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD) > 30 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE APELLIDOS
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud APELLIDOS mayor a la permitida(80)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.APELLIDOS) > 80 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRES
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud NOMBRES mayor a la permitida(80)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRES) > 80 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DIRECCION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud DIRECCION mayor a la permitida(100)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.DIRECCION) > 100 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud TELEFONO mayor a la permitida(14)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) > 14 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud TELEFONO MENOR a la permitida(7)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) < 7 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud CELULAR mayor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) > 10 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud CELULAR menor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) < 10 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMP_O_PART
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud EMP_O_PART mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMP_O_PART) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE SEXO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud SEXO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.SEXO) > 1 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_NACIMIENTO mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_NACIMIENTO menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_PAIS
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_PAIS mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_PAIS) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO  
        --ORDER BY ST_C.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_PAIS
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_PAIS mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_PAIS) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_MODIFICACION mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_MODIFICACION menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FAX
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FAX mayor a la permitida(12)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FAX) > 12 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO  
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) < 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD_DIR
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_CIUDAD_DIR mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD_DIR) > 8 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD_DIR
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_CIUDAD_DIR mayor a la permitida(40)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD_DIR) > 40 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DIRECCION
        SELECT DISTINCT ST_C.ID_RADICADO, iv_Transito ,'Longitud ID_DIRECCION mayor a la permitida(20)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DIRECCION) > 20 and ST_C.id_radicado = GS_RADICADO
        GROUP BY ST_C.ID_RADICADO 
        --ORDER BY ST_C.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_P.ID_RADICADO, iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_propietarios ST_P
        where length (ST_P.NRO_PLACA) > 6 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_P.ID_RADICADO, iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_USUARIO) > 15 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT DISTINCT ST_P.ID_RADICADO, iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_DOCUMENTO) > 1 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_P.ID_RADICADO, iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_P.ID_RADICADO, iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA, 'PROPIETARIOS' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        GROUP BY ST_P.ID_RADICADO 
        --ORDER BY ST_P.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NRO_PLACA) > 6 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_TRAMITE mayor a la permitida(4)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_TRAMITE) > 4 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_TRAMITE mayor a la permitida(40)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_TRAMITE) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud FECHA_TRAMITE mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud FECHA_TRAMITE menor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) < 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        /*union
        
        -- VALIDO LONGITUD DE TIPO_CANCELACION
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud TIPO_CANCELACION mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        INNER JOIN ST_MAESTRO ST_M ON ST_T.ID_RADICADO = ST_M.ID_RADICADO
        INNER JOIN CORRECCION_DATOS.RUNT_CIUDADES RC ON RC.DIVIPO = ST_M.ID_SECRETARIA
        where length (ST_T.TIPO_CANCELACION) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO*/
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_DESTINO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_SECRETARIA_DESTINO mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_DESTINO) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_ORIGEN
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_SECRETARIA_ORIGEN mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_ORIGEN) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_CARROCERIA_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_CARROCERIA_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_NUEVA
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_CARROCERIA_NUEVA mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_NUEVA) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_NUEVA
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_CARROCERIA_NUEVA mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_NUEVA) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_SERVICIO_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_SERVICIO_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_SERVICIO_NUEVO mayor a la permitida(8)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_NUEVO) > 8 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NOMBRE_SERVICIO_NUEVO mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_NUEVO) > 40 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_ANTERIOR
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_USUARIO_ANTERIOR mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_ANTERIOR) > 15 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_NUEVO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud ID_USUARIO_NUEVO mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_NUEVO) > 15 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.PORCENTAJE_PROP) > 3 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CLASICO_ANTIGUO) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.BLINDADO) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NIVEL_BLINDADO
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud NIVEL_BLINDADO mayor a la permitida(2)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NIVEL_BLINDADO) > 2 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE DESBLINDAJE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud DESBLINDAJE mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.DESBLINDAJE) > 1 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CILINDRAJE) > 10 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_PASAJEROS) > 3 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT DISTINCT ST_T.ID_RADICADO, iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_TONELADAS) > 6 and ST_T.id_radicado = GS_RADICADO
        GROUP BY ST_T.ID_RADICADO 
        --ORDER BY ST_T.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PLACA
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.NRO_PLACA) > 6 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.ID_USUARIO) > 15 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TIPO_DOCUMENTO_USUARIO
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud TIPO_DOCUMENTO_USUARIO mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.TIPO_DOCUMENTO_USUARIO) > 1 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_COMPRADOR
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud ID_COMPRADOR mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.ID_COMPRADOR) > 15 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ----ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TIPO_DOCUMENTO_COMPRADOR
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud TIPO_DOCUMENTO_COMPRADOR mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.TIPO_DOCUMENTO_COMPRADOR) > 1 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ------ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud PORCENTAJE mayor a la permitida(3)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where length (ST_H.PORCENTAJE) > 3 and ST_H.id_radicado = GS_RADICADO
        GROUP BY ST_H.ID_RADICADO 
        ------ORDER BY ST_H.ID_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA
        SELECT DISTINCT ST_H.ID_RADICADO, iv_Transito ,'Longitud FECHA diferente a la permitida(16)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, COUNT(1) CANTIDAD
        FROM TMP_HISTORIALES_TRASPASO ST_H
        where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA) < 16) 
        GROUP BY ST_H.ID_RADICADO 
        --ORDER BY ID_RADICADO,ARCHIVO;
        
        Union
        
        --Validaciones tramites.
        
        --Radicaciones Sin Id_Origen.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Radicaciones Sin Id_Origen' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen is null
        Group By St.Id_Radicado
        
        union
        
        --Radicaciones Sin Id_Destino.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Radicaciones Sin Id_Destino' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        Group By St.Id_Radicado
        
        union
        
        --Traslados Sin Id_Origen.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Traslados Sin Id_Origen' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen Is Null
        Group By St.Id_Radicado
        
        union
        
        --Traslados Sin Id_Destino.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Traslados Sin Id_Destino' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        Group By St.Id_Radicado
        
        union
        
        --Blindajes Sin Nivel Blindado.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Blindajes Sin Nivel Blindado' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 1 and St.id_radicado = GS_RADICADO
          And St.Blindado Is Not Null And St.Nivel_Blindado is null
        Group By St.Id_Radicado
        
        union
        
        --Transformacion Carroceria Carga Con Capacidad Pasajeros > 3.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria,  
               'Transformacion Carroceria Carga Con Capacidad Casajeros > 3' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 14 and St.id_radicado = GS_RADICADO
          And St.Id_Carroceria_Nueva in('7','8','9','10','12','13','15','17','18','20','21','31','32','42','43',
                                        '44','45','47','58','60','70','78','79','80','83','84','96','98','104',
                                        '115','116','119','125','133','136','142','150','172','174','187','189',
                                        '192','193','196','197','198','199')
          And to_number(St.Cap_Pasajeros) > 3        
        Group By St.Id_Radicado
        
        union
        
        --Id_carroceria nueva != carroceria OC
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Id_Carroceria Nueva Diferente a Carroceria OC' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 14  and St.id_radicado = GS_RADICADO
          And SV.ID_CARROCERIA is not null
          And SV.ID_CARROCERIA != ST.ID_CARROCERIA_NUEVA
          And sv.id_radicado = st.id_radicado
        Group By St.Id_Radicado
        
        union
        
        --Porcentaje Traspaso Mayor a 100.
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Porcentaje Traspaso Mayor a 100' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And to_number(replace(St.Porcentaje_Prop,'.','')) > 100
        Group By St.Id_Radicado
        
        union
        
        
        --Id_Comprador igual a Id_Vendedor
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Id_Comprador Igual a Id_Vendedor' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And ST.ID_USUARIO_nuevo = ST.ID_USUARIO_anterior
        Group By St.Id_Radicado
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Id_Servicio_Anterior Igual a Id_Servicio_Nuevo' Inconsistencia,'TRAMITES' ARCHIVO, Count(1) Cantidad 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And ST.ID_SERVICIO_ANTERIOR = ST.ID_SERVICIO_NUEVO
        Group By St.Id_Radicado
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select Distinct St.Id_Radicado, iv_Transito Secretaria, 
               'Id_Servicio_Nuevo Diferente a Id_Servicio_Oc' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And sv.ID_SERVICIO != ST.ID_SERVICIO_NUEVO
          And sv.id_radicado = st.id_radicado
        Group By St.Id_Radicado
        
        /*VALIDAMOS PARAMETRICAS RUNT*/
        UNION 
        --Carrocerias x clase Vehiculos
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Vehiculos)' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null  And Sv.Id_Carroceria is Not null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
         
        union
        
        --Carrocerias x clase tramites transformacion
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Tramites)' Inconsistencia, 'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from TMP_VEHICULOS sv
        inner join TMP_TRAMITES st on st.nro_placa = sv.nro_placa AND SV.ID_RADICADO = ST.ID_RADICADO
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','')  and rc.codigo_carroceria_ws =REPLACE (st.ID_CARROCERIA_nueva,'.','') 
        where  st.id_tramite = 14 And RC.CODIGO_CARROCERIA_WS is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        

        
        union
        
        
        --Lineas sin relacion a la marca transformacion
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Linea Sin Relacion a La Marca' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        
        union
        
        --Id_Marca con punto
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Marca con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where sv.id_marca like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        --Id_Linea con punto
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Linea con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where sv.id_linea like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        --Id_Linea con punto
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Modelo con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where sv.modelo like '%.%' and sv.id_radicado = GS_RADICADO
        Group By sv.Id_Radicado
        
        union
        
        /*VALIDACION DE CAMPOS NULL*/
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Marca Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Id_Marca is null  and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Nro_placa Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  Sv.nro_placa is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Linea Null' Inconsistencia,'VEHICULOS' ARCHIVO, Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.id_linea is null  and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Modelo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Modelo is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Clase Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.ID_CLASE is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Servicio Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Id_Servicio is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Carroceria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Id_Carroceria is null and sv.id_radicado = GS_RADICADO 
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Combustible Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Id_Combustible is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Secretaria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Id_Secretaria is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Cilindraje Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Cilindraje is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Valor_Factura Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Valor_Factura is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Fecha_Matriculo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,Count(1) Cantidad 
        from TMP_VEHICULOS sv
        where  SV.Fecha_Matriculo is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia,'PROPIETARIOS' ARCHIVO, Count(1) Cantidad 
        from TMP_propietarios sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,Count(1) Cantidad 
        from TMP_propietarios sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Porcentaje_Propiedad Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,Count(1) Cantidad 
        from TMP_propietarios sv
        where  SV.Porcentaje_Prop is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        /*CONTRIBUYENTES*/
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Ciudad No Existe en Runt' Inconsistencia, 'Contribuyentes' ARCHIVO,Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        left join CORRECCION_DATOS.runt_ciudades rl
                on rl.divipo = sv.ID_CIUDAD_DIR 
        where rl.nombre = '' and sv.id_radicado = GS_RADICADO  
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Nombres Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Nombres is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Apellidos Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Apellidos is null And sv.Id_Documento != 'N' and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Direccion Null' Inconsistencia,'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Direccion is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        /*
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Telefono Null y Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Telefono is null  and SV.Celular is null And sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado */
        
        union 
        
        /*
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Email Null' Inconsistencia,'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Email is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado 
        
        union  */
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Ciudad_Dir Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Ciudad_Dir is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia,'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia, 'Contribuyentes' ARCHIVO, Count(1) Cantidad 
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        union 
        
        select Distinct sv.Id_Radicado, iv_Transito Secretaria, 
               'Id_Tramite Null' Inconsistencia, 'TRAMITES' ARCHIVO, Count(1) Cantidad 
        from TMP_TRAMITES sv
        where  SV.Id_Tramite is null  and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        Union
        
        Select Distinct Sv.Id_Radicado, iv_Transito Secretaria, 
               'Vehiculos No Reportados En Tramites' Inconsistencia, 'Vehiculos' ARCHIVO, Count(1) Cantidad 
        from tmp_vehiculos sv
        left join tmp_tramites st on st.nro_placa = sv.nro_placa and sv.id_radicado = st.Id_radicado
        where st.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        UNION
        
        Select Distinct Sv.Id_Radicado, iv_Transito Secretaria, 
               'Vehiculos No Reportados En Propietarios' Inconsistencia, 'Vehiculos' ARCHIVO, Count(1) Cantidad 
        from tmp_vehiculos sv
        left join tmp_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado
        
        UNION
        
        Select Distinct Sv.Id_Radicado, iv_Transito Secretaria, 
               'Tramites No Reportados En Propietarios' Inconsistencia, 'Tramites' ARCHIVO, Count(1) Cantidad 
        from tmp_tramites sv
        left join tmp_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        Group By Sv.Id_Radicado 
        
        UNION
        
        Select Distinct st.Id_Radicado, iv_Transito Secretaria, 
               'Tramites No Reportados En Vehiculos' Inconsistencia, 'Tramites' ARCHIVO, Count(1) Cantidad 
        from tmp_tramites st
        left join tmp_vehiculos sv on sv.nro_placa = st.nro_placa and sv.id_radicado = st.Id_radicado
        where sv.nro_placa is null and st.id_radicado = GS_RADICADO
        Group By st.Id_Radicado 
        
        UNION
        
        Select Distinct sp.Id_Radicado, iv_Transito Secretaria, 
               'Propietarios No Reportados En Vehiculos' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from tmp_Propietarios sp
        left join tmp_vehiculos sv on sp.nro_placa = sv.nro_placa and sp.id_radicado = sv.Id_radicado
        where sv.nro_placa is null and sp.id_radicado = GS_RADICADO
        Group By sp.Id_Radicado 
        
        UNION
        
        Select Distinct sp.Id_Radicado, iv_Transito Secretaria, 
               'Propietarios No Reportados En Tramites' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from tmp_Propietarios sp
        left join tmp_tramites st on sp.nro_placa = st.nro_placa and sp.id_radicado = st.Id_radicado
        where st.nro_placa is null and sp.id_radicado = GS_RADICADO
        Group By sp.Id_Radicado 
        
        UNION
        
        Select Distinct Sp.Id_Radicado, iv_Transito Secretaria, 
               'Propietarios No Reportados En Contribuyentes' Inconsistencia, 'Propietarios' ARCHIVO, Count(1) Cantidad 
        from tmp_Propietarios sp
        left join tmp_contribuyentes sc on Sp.Id_Usuario = Sc.Id_Usuario And Sp.Id_Documento = Sc.Id_Documento and sp.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sp.id_radicado = GS_RADICADO
        Group By Sp.Id_Radicado 
        
        UNION
        
        Select Distinct Sh.Id_Radicado, iv_Transito Secretaria, 
               'Vendedores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, Count(1) Cantidad 
        from tmp_historiales_traspaso sh
        left join tmp_contribuyentes sc on Sh.Id_Usuario = Sc.Id_Usuario And Sh.TIPO_DOCUMENTO_USUARIO = sc.ID_DOCUMENTO and sh.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
        Group By Sh.Id_Radicado 
        
        UNION
        
        Select Distinct Sh.Id_Radicado, iv_Transito Secretaria, 
               'Compradores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, Count(1) Cantidad 
        from tmp_historiales_traspaso sh
        left join tmp_contribuyentes sc on Sc.Id_Usuario = Sh.ID_COMPRADOR And Sc.Id_Documento = Sh.TIPO_DOCUMENTO_COMPRADOR and sh.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
        Group By Sh.Id_Radicado ;

Begin
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
        For ln_index In lcur_Detalle_Incons Loop
                    If lb_Existe = False Then
                            UTL_FILE.PUT_LINE(lutl_archivo,'ID_RADICADO;'||'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'CANTIDAD');
                        lb_Existe:=True;
                    End If;
                UTL_FILE.PUT_LINE(lutl_archivo,ln_index.id_radicado||';'
                    ||iv_Transito||';'
                    ||ln_index.inconsistencia||';'
                    ||ln_index.archivo||';'
                    ||ln_index.cantidad);
        End Loop;
     UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Detalle_Inconsistencia;

Procedure SP_Inconsistencia_Vehiculos As

/*ISVA
Nombre     :SP_Inconsistencia_Vehiculos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los vehiculos   
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' VEHICULOS ' ||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;
        
        Cursor lcur_vehiculos Is 
            -- VALIDO LONGITUD DE NRO_PLACA
        SELECT  iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PLACA) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_MARCA
        SELECT   iv_Transito ,'Longitud ID_MARCA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_MARCA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_MARCA
        SELECT   iv_Transito ,'Longitud NOMBRE_MARCA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_MARCA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.ID_LINEA,'.','')) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_LINEA
        SELECT   iv_Transito ,'Longitud NOMBRE_LINEA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_LINEA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE MODELO
        SELECT   iv_Transito ,'Longitud MODELO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CLASE
        SELECT   iv_Transito ,'Longitud ID_CLASE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CLASE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_LINEA
        SELECT   iv_Transito ,'Longitud ID_LINEA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_LINEA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CLASE
        SELECT   iv_Transito ,'Longitud NOMBRE_CLASE mayor a la permitida(40)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CLASE) > 40 and ST_V.id_radicado =GS_RADICADO
        
        
        
        union 
        
        -- VALIDO LONGITUD DE ID_SERVICIO
        SELECT   iv_Transito ,'Longitud ID_SERVICIO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SERVICIO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SERVICIO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union 
        
        -- VALIDO LONGITUD DE ID_CARROCERIA
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_CARROCERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_CARROCERIA) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_COMBUSTIBLE
        SELECT   iv_Transito ,'Longitud ID_COMBUSTIBLE mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_COMBUSTIBLE) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_BATERIA
        SELECT   iv_Transito ,'Longitud ID_BATERIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_BATERIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_BATERIA
        SELECT   iv_Transito ,'Longitud NOMBRE_BATERIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_BATERIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE POTENCIA
        SELECT   iv_Transito ,'Longitud POTENCIA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.POTENCIA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA
        SELECT   iv_Transito ,'Longitud ID_SECRETARIA mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_SECRETARIA) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SECRETARIA
        SELECT   iv_Transito ,'Longitud NOMBRE_SECRETARIA mayor a la permitida(80)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_SECRETARIA) > 80 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CILINDRAJE) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CAP_TONELADAS) > 6 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE VALOR_FACTURA
        SELECT   iv_Transito ,'Longitud VALOR_FACTURA mayor a la permitida(10)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.VALOR_FACTURA) > 10 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.BLINDADO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE IMPORTADO_NACIONAL
        SELECT   iv_Transito ,'Longitud IMPORTADO_NACIONAL mayor a la permitida(2)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.IMPORTADO_NACIONAL) > 2 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_ESTADO
        SELECT   iv_Transito ,'Longitud ID_ESTADO mayor a la permitida(4)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.ID_ESTADO) > 4 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_ESTADO
        SELECT   iv_Transito ,'Longitud NOMBRE_ESTADO mayor a la permitida(40)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NOMBRE_ESTADO) > 40 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.CLASICO_ANTIGUO) > 1 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NRO_PUERTAS
        SELECT   iv_Transito ,'Longitud NRO_PUERTAS mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.NRO_PUERTAS) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   iv_Transito ,'Longitud FECHA_MATRICULO mayor a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) > 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT   iv_Transito ,'Longitud FECHA_MATRICULO menos a la permitida(8)' as INCONSISTENCIA, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM TMP_VEHICULOS ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 and ST_V.id_radicado =GS_RADICADO
        
        union
        
        Select iv_Transito Secretaria, 
               'Vehiculos No Reportados En Tramites' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join TMP_TRAMITES st on st.nro_placa = sv.nro_placa and sv.id_radicado = st.Id_radicado
        where st.nro_placa is null and sv.id_radicado =GS_RADICADO 
        
        union
        

        Select  iv_Transito Secretaria,    
               'Vehiculos No Reportados En Propietarios' Inconsistencia, 'Vehiculos' ARCHIVO, sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join TMP_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado =GS_RADICADO
        
        union
        
        --Carrocerias x clase Vehiculos
        select  iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Vehiculos)' Inconsistencia,'VEHICULOS' ARCHIVO, sv.* , sv.rowid
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null And Sv.Id_Carroceria is Not null and sv.id_radicado =GS_RADICADO 
        
        
        union
        
        --Lineas sin relacion a la marca transformacion
        select  iv_Transito As Secretaria, 
               'Linea Sin Relacion a La Marca' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        left join CORRECCION_DATOS.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null And Id_Linea is not null and sv.id_radicado =GS_RADICADO 
        
        union
        
        --Id_Marca con punto
        select  iv_Transito Secretaria, 
               'Id_Marca con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.id_marca like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select  iv_Transito Secretaria, 
               'Id_Linea con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.id_linea like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --Id_Linea con punto
        select iv_Transito Secretaria, 
               'Modelo con punto' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where sv.modelo like '%.%' and sv.id_radicado =GS_RADICADO
        
        union
        
        --VALIDACION DE CAMPOS NULL
        
        select  iv_Transito Secretaria, 
               'Id_Marca Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Marca is null  and sv.id_radicado =GS_RADICADO 
        
        union
        
        select  iv_Transito Secretaria, 
               'Nro_placa Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  Sv.nro_placa is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Linea Null' Inconsistencia,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.id_linea is null  and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Modelo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Modelo is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Clase Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.ID_CLASE is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Servicio Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Servicio is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Carroceria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Carroceria is null and sv.id_radicado =GS_RADICADO 
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Combustible Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Combustible is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Secretaria Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Id_Secretaria is null  and sv.id_radicado =GS_RADICADO
        
        union 
        select  iv_Transito Secretaria,
        'Cilindraje Null o Cero' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  (SV.Cilindraje  is null or SV.Cilindraje = 0) And Id_Combustible Not In (5)
        And sv.id_radicado =GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Valor_Factura Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Valor_Factura is null  and sv.id_radicado =GS_RADICADO
        
        union 
        
        select   iv_Transito Secretaria, 
               'Fecha_Matriculo Null' Inconsistencia, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from TMP_VEHICULOS sv
        where  SV.Fecha_Matriculo is null  and sv.id_radicado =GS_RADICADO;

Begin 
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');
        For Ln_Index In lcur_vehiculos Loop
            
        Begin
            If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'
                                                ||'ID_LINEA;'||'NOMBRE_LINEA;'||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'
                                                ||'NOMBRE_SERVICIO;'||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'
                                                ||'ID_COMBUSTIBLE;'||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'
                                                ||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'||'ID_ESTADO;'
                                                ||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'||'ID_RADICADO;'||'ID_MARCA2;'
                                                ||'ID_LINEA2;'||'CAJA;'||'TRACCION;'||'COMBUSTION');
                     lb_Existe:=True;
            End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
            ||Ln_Index.INCONSISTENCIA||';'
            ||Ln_Index.ARCHIVO||';'
            ||Ln_Index.NRO_PLACA||';'
            ||Ln_Index.ID_MARCA||';'
            ||Ln_Index.NOMBRE_MARCA||';'
            ||Ln_Index.ID_LINEA||';'
            ||Ln_Index.NOMBRE_LINEA||';'
            ||Ln_Index.MODELO||';'
            ||Ln_Index.ID_CLASE||';'
            ||Ln_Index.NOMBRE_CLASE||';'
            ||Ln_Index.ID_SERVICIO||';'
            ||Ln_Index.NOMBRE_SERVICIO||';'
            ||Ln_Index.ID_CARROCERIA||';'
            ||Ln_Index.NOMBRE_CARROCERIA||';'
            ||Ln_Index.NRO_PUERTAS||';'
            ||Ln_Index.ID_COMBUSTIBLE||';'
            ||Ln_Index.NOMBRE_COMBUSTIBLE||';'
            ||Ln_Index.ID_BATERIA||';'
            ||Ln_Index.NOMBRE_BATERIA||';'
            ||Ln_Index.POTENCIA||';'
            ||Ln_Index.ID_SECRETARIA||';'
            ||Ln_Index.NOMBRE_SECRETARIA||';'
            ||Ln_Index.CILINDRAJE||';'
            ||Ln_Index.CAP_PASAJEROS||';'
            ||Ln_Index.CAP_TONELADAS||';'
            ||Ln_Index.VALOR_FACTURA||';'
            ||Ln_Index.BLINDADO||';'
            ||Ln_Index.IMPORTADO_NACIONAL||';'
            ||Ln_Index.ID_ESTADO||';'
            ||Ln_Index.NOMBRE_ESTADO||';'
            ||Ln_Index.CLASICO_ANTIGUO||';'
            ||Ln_Index.FECHA_MATRICULO||';'
            ||Ln_Index.ID_RADICADO||';'
            ||Ln_Index.ID_MARCA2||';'
            ||Ln_Index.ID_LINEA2||';'
            ||Ln_Index.CAJA||';'
            ||Ln_Index.TRACCION||';'
            ||Ln_Index.COMBUSTION);
                
                --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                --Values (ln_index.rowid, 'tmp_vehiculos');
            
            Exception 
                When Others Then 
                    Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Sp_Vehiculos'); 
        End;   
        End Loop;
        Commit;
         UTL_FILE.FCLOSE(lutl_archivo); 
         
END Sp_Inconsistencia_Vehiculos;

Procedure Sp_Inconsistencia_Tramites As

/*ISVA
Nombre     :Sp_Inconsistencia_Tramites
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los tramites
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' TRAMITES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

-- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_tramites Is 
        SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NRO_PLACA) > 6 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_TRAMITE
        SELECT   iv_Transito ,'Longitud ID_TRAMITE mayor a la permitida(4)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_TRAMITE) > 4 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_TRAMITE
        SELECT   iv_Transito ,'Longitud NOMBRE_TRAMITE mayor a la permitida(40)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_TRAMITE) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   iv_Transito ,'Longitud FECHA_TRAMITE mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        -- VALIDO LONGITUD DE FECHA_TRAMITE
        SELECT   iv_Transito ,'Longitud FECHA_TRAMITE menor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.FECHA_TRAMITE) < 8 and ST_T.id_radicado = GS_RADICADO
        
        /*union
        
        -- VALIDO LONGITUD DE TIPO_CANCELACION
        SELECT   iv_Transito,'Longitud TIPO_CANCELACION mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*
        FROM TMP_TRAMITES ST_T
        where length (ST_T.TIPO_CANCELACION) > 8 and ST_T.id_radicado = GS_RADICADO*/
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_DESTINO
        SELECT   iv_Transito ,'Longitud ID_SECRETARIA_DESTINO mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_DESTINO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SECRETARIA_ORIGEN
        SELECT  iv_Transito ,'Longitud ID_SECRETARIA_ORIGEN mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SECRETARIA_ORIGEN) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_ANTERIOR
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CARROCERIA_NUEVA
        SELECT   iv_Transito ,'Longitud ID_CARROCERIA_NUEVA mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_CARROCERIA_NUEVA) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CARROCERIA_NUEVA
        SELECT   iv_Transito ,'Longitud NOMBRE_CARROCERIA_NUEVA mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_CARROCERIA_NUEVA) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_SERVICIO_ANTERIOR mayor a la permitida(8)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_ANTERIOR) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO_ANTERIOR mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_ANTERIOR) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_SERVICIO_NUEVO
        SELECT   iv_Transito ,'Longitud ID_SERVICIO_NUEVO mayor a la permitida(8)' as INCONSISTENCIA, 'TRAMITES' as ARCHIVO,ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_SERVICIO_NUEVO) > 8 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_SERVICIO_NUEVO
        SELECT   iv_Transito ,'Longitud NOMBRE_SERVICIO_NUEVO mayor a la permitida(40)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NOMBRE_SERVICIO_NUEVO) > 40 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_ANTERIOR
        SELECT   iv_Transito ,'Longitud ID_USUARIO_ANTERIOR mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_ANTERIOR) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO_NUEVO
        SELECT   iv_Transito ,'Longitud ID_USUARIO_NUEVO mayor a la permitida(15)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.ID_USUARIO_NUEVO) > 15 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.PORCENTAJE_PROP) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CLASICO_ANTIGUO
        SELECT   iv_Transito ,'Longitud CLASICO_ANTIGUO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CLASICO_ANTIGUO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE BLINDADO
        SELECT   iv_Transito ,'Longitud BLINDADO mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.BLINDADO) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NIVEL_BLINDADO
        SELECT   iv_Transito ,'Longitud NIVEL_BLINDADO mayor a la permitida(2)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.NIVEL_BLINDADO) > 2 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DESBLINDAJE
        SELECT   iv_Transito ,'Longitud DESBLINDAJE mayor a la permitida(1)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.DESBLINDAJE) > 1 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CILINDRAJE
        SELECT   iv_Transito ,'Longitud CILINDRAJE mayor a la permitida(10)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CILINDRAJE) > 10 and ST_T.id_radicado = GS_RADICADO
                
        union
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT   iv_Transito ,'Longitud CAP_PASAJEROS mayor a la permitida(3)' as INCONSISTENCIA,'TRAMITES' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_PASAJEROS) > 3 and ST_T.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT   iv_Transito ,'Longitud CAP_TONELADAS mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_T.*, ST_T.Rowid
        FROM TMP_TRAMITES ST_T
        where length (ST_T.CAP_TONELADAS) > 6 and ST_T.id_radicado = GS_RADICADO
        
        UNION
        
        Select iv_Transito Secretaria, 
               'Tramites No Reportados En Propietarios' Inconsistencia, 'Tramites' ARCHIVO, sv.*, sv.rowid
        from TMP_TRAMITES sv
        left join TMP_propietarios sp on sp.nro_placa = sv.nro_placa and sv.id_radicado = sp.Id_radicado
        where sp.nro_placa is null and sv.id_radicado = GS_RADICADO
        
       
        UNION
        
        Select iv_Transito Secretaria, 
               'Tramites No Reportados En Vehiculos' Inconsistencia, 'Tramites' ARCHIVO, st.*, st.rowid
        from TMP_TRAMITES st
        left join TMP_VEHICULOS sv on sv.nro_placa = st.nro_placa and sv.id_radicado = st.Id_radicado
        where sv.nro_placa is null and st.id_radicado = GS_RADICADO
        
        union
        --Validaciones tramites.
        
        --Radicaciones Sin Id_Origen.
        Select iv_Transito Secretaria, 
               'Radicaciones Sin Id_Origen' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen is null
        
        
        union
        
        --Radicaciones Sin Id_Destino.
        Select  iv_Transito Secretaria, 
               'Radicaciones Sin Id_Destino' Inconsistencia, 'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 10 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Traslados Sin Id_Origen.
        Select iv_Transito Secretaria, 
               'Traslados Sin Id_Origen' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Origen Is Null
        
        
        union
        
        --Traslados Sin Id_Destino.
        Select  iv_Transito Secretaria, 
               'Traslados Sin Id_Destino' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 15 and St.id_radicado = GS_RADICADO
          And St.Id_Secretaria_Destino Is Null
        
        
        union
        
        --Blindajes Sin Nivel Blindado.
        Select  iv_Transito Secretaria, 
               'Blindajes Sin Nivel Blindado' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 1 and St.id_radicado = GS_RADICADO
          And St.Blindado Is Not Null And St.Nivel_Blindado is null
        
        
        union
        
        --Transformacion Carroceria Carga Con Capacidad Casajeros > 3.
        Select   iv_Transito Secretaria,  
               'Transformacion Carroceria Carga Con Capacidad Casajeros > 3' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite = 14 and St.id_radicado = GS_RADICADO
          And St.Id_Carroceria_Nueva in('7','8','9','10','12','13','15','17','18','20','21','31','32','42','43',
                                        '44','45','47','58','60','70','78','79','80','83','84','96','98','104',
                                        '115','116','119','125','133','136','142','150','172','174','187','189',
                                        '192','193','196','197','198','199')
          And to_number(St.Cap_Pasajeros) > 3        
        
        
        union
        
        --Id_carroceria nueva != carroceria OC
        Select  iv_Transito Secretaria, 
               'Id_Carroceria Nueva Diferente a Carroceria OC' Inconsistencia,'VEHICULOS' ARCHIVO, St.* , st.rowid
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 14  and St.id_radicado = GS_RADICADO
          And SV.ID_CARROCERIA is not null
          And SV.ID_CARROCERIA != ST.ID_CARROCERIA_NUEVA
          And sv.id_radicado = st.id_radicado
        
        
        union
        
        --Porcentaje Traspaso Mayor a 100.
        Select  iv_Transito Secretaria, 
               'Porcentaje Traspaso Mayor a 100' Inconsistencia,'TRAMITES' ARCHIVO, St.* , st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And to_number(replace(St.Porcentaje_Prop,'.','')) > 100
        
        
        union
        
        
        --Id_Comprador igual a Id_Vendedor
        Select iv_Transito Secretaria, 
               'Id_Comprador Igual a Id_Vendedor' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid
        From TMP_TRAMITES St
        Where St.Id_Tramite in (16,65) and St.id_radicado = GS_RADICADO
          And ST.ID_USUARIO_nuevo = ST.ID_USUARIO_anterior
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select iv_Transito Secretaria, 
               'Id_Servicio_Anterior Igual a Id_Servicio_Nuevo' Inconsistencia,'TRAMITES' ARCHIVO, St.*, st.rowid 
        From TMP_TRAMITES St
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And ST.ID_SERVICIO_ANTERIOR = ST.ID_SERVICIO_NUEVO
        
        
        union
        
        --ID_SERVICIO_ANTERIOR = ID_SERVICIO_NUEVO
        Select  iv_Transito Secretaria, 
               'Id_Servicio_Nuevo Diferente a Id_Servicio_Oc' Inconsistencia,'VEHICULOS' ARCHIVO, St.*, st.rowid
        From TMP_VEHICULOS sv
        inner join TMP_TRAMITES St on st.nro_placa = sv.nro_placa
        Where St.Id_Tramite = 6 and St.id_radicado = GS_RADICADO
          And sv.ID_SERVICIO != ST.ID_SERVICIO_NUEVO
          And sv.id_radicado = st.id_radicado
        
        union
        
        --Carrocerias x clase tramites transformacion
        select  iv_Transito Secretaria, 
               'Carroceria Sin Relacion a La Clase (Tramites)' Inconsistencia, 'VEHICULOS' ARCHIVO, st.*, st.rowid 
        from TMP_VEHICULOS sv
        inner join TMP_TRAMITES st on st.nro_placa = sv.nro_placa AND SV.ID_RADICADO = ST.ID_RADICADO
        left join CORRECCION_DATOS.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','')  and rc.codigo_carroceria_ws =REPLACE (st.ID_CARROCERIA_nueva,'.','') 
        where  st.id_tramite = 14 And RC.CODIGO_CARROCERIA_WS is null and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Tramite Null' Inconsistencia, 'TRAMITES' ARCHIVO, sv.*, sv.rowid
        from TMP_TRAMITES sv
        where  SV.Id_Tramite is null  and sv.id_radicado = GS_RADICADO;
        
Begin   
    lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
        For Ln_Index In lcur_tramites Loop   
        Begin
            
                If lb_Existe = False Then
                    UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_TRAMITE;'||'NOMBRE_TRAMITE;'
                                                ||'FECHA_TRAMITE;'||'TIPO_CANCELACION;'||'ID_SECRETARIA_DESTINO;'||'ID_SECRETARIA_ORIGEN;'
                                                ||'ID_CARROCERIA_ANTERIOR;'||'NOMBRE_CARROCERIA_ANTERIOR;'||'ID_CARROCERIA_NUEVA;'
                                                ||'NOMBRE_CARROCERIA_NUEVA;'||'ID_SERVICIO_ANTERIOR;'||'NOMBRE_SERVICIO_ANTERIOR;'
                                                ||'ID_SERVICIO_NUEVO;'||'NOMBRE_SERVICIO_NUEVO;'||'ID_DOCUMENTO_ANTERIOR;'||'ID_USUARIO_ANTERIOR;'
                                                ||'ID_DOCUMENTO_NUEVO;'||'ID_USUARIO_NUEVO;'||'PORCENTAJE_PROP;'||'CLASICO_ANTIGUO;'||'BLINDADO;'
                                                ||'NIVEL_BLINDADO;'||'DESBLINDAJE;'||'CILINDRAJE;'||'CAP_PASAJEROS;'||'CAP_TONELADAS;'||'ID_RADICADO');
                        lb_Existe:=True;
                 End If;
                UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                    ||Ln_Index.INCONSISTENCIA||';'
                    ||Ln_Index.ARCHIVO||';'
                    ||Ln_Index.NRO_PLACA||';'
                    ||Ln_Index.ID_TRAMITE||';'
                    ||Ln_Index.NOMBRE_TRAMITE||';'
                    ||Ln_Index.FECHA_TRAMITE||';'
                    ||Ln_Index.TIPO_CANCELACION||';'
                    ||Ln_Index.ID_SECRETARIA_DESTINO||';'
                    ||Ln_Index.ID_SECRETARIA_ORIGEN	||';'
                    ||Ln_Index.ID_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.ID_CARROCERIA_NUEVA||';'
                    ||Ln_Index.NOMBRE_CARROCERIA_NUEVA||';'
                    ||Ln_Index.ID_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.ID_SERVICIO_NUEVO||';'
                    ||Ln_Index.NOMBRE_SERVICIO_NUEVO||';'
                    ||Ln_Index.ID_DOCUMENTO_ANTERIOR||';'
                    ||Ln_Index.ID_USUARIO_ANTERIOR||';'
                    ||Ln_Index.ID_DOCUMENTO_NUEVO||';'
                    ||Ln_Index.ID_USUARIO_NUEVO||';'
                    ||Ln_Index.PORCENTAJE_PROP||';'
                    ||Ln_Index.CLASICO_ANTIGUO||';'
                    ||Ln_Index.BLINDADO||';'
                    ||Ln_Index.NIVEL_BLINDADO||';'
                    ||Ln_Index.DESBLINDAJE||';'
                    ||Ln_Index.CILINDRAJE||';'
                    ||Ln_Index.CAP_PASAJEROS||';'
                    ||Ln_Index.CAP_TONELADAS||';'
                    ||Ln_Index.ID_RADICADO);   
                    
                    --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                    --Values (ln_index.rowid, 'Tmp_Tramites');
                    
                    Exception 
                        When Others Then 
                            Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Sp_Vehiculos'); 
            End;
            End Loop;
        UTL_FILE.FCLOSE(lutl_archivo);
    End Sp_Inconsistencia_Tramites;

Procedure Sp_Inconsistencia_Contribuyent As

/*ISVA
Nombre     :Sp_Inconsistencia_Contribuyent
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los contribuyentes
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' CONTRIBUYENTES '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

    -- VALIDO LONGITUD DE ID_USUARIO
        Cursor lcur_contribuyentes Is
        SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_USUARIO) > 15 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DOCUMENTO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD
        SELECT   iv_Transito ,'Longitud ID_CIUDAD mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD
        SELECT   iv_Transito ,'Longitud NOMBRE_CIUDAD mayor a la permitida(30)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD) > 30 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE APELLIDOS
        SELECT   iv_Transito ,'Longitud APELLIDOS mayor a la permitida(80)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.APELLIDOS) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRES
        SELECT   iv_Transito ,'Longitud NOMBRES mayor a la permitida(80)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRES) > 80 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE DIRECCION
        SELECT   iv_Transito ,'Longitud DIRECCION mayor a la permitida(100)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.DIRECCION) > 100 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   iv_Transito ,'Longitud TELEFONO mayor a la permitida(14)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) > 14 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE TELEFONO
        SELECT   iv_Transito ,'Longitud TELEFONO MENOR a la permitida(7)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.TELEFONO) < 7 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   iv_Transito ,'Longitud CELULAR mayor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) > 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE CELULAR
        SELECT   iv_Transito ,'Longitud CELULAR menor a la permitida(10)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.CELULAR) < 10 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMP_O_PART
        SELECT   iv_Transito ,'Longitud EMP_O_PART mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMP_O_PART) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE SEXO
        SELECT   iv_Transito ,'Longitud SEXO mayor a la permitida(1)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.SEXO) > 1 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   iv_Transito ,'Longitud FECHA_NACIMIENTO mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_NACIMIENTO
        SELECT   iv_Transito ,'Longitud FECHA_NACIMIENTO menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_NACIMIENTO) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_PAIS
        SELECT   iv_Transito ,'Longitud ID_PAIS mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_PAIS) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE NOMBRE_PAIS
        SELECT   iv_Transito ,'Longitud NOMBRE_PAIS mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_PAIS) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   iv_Transito ,'Longitud FECHA_MODIFICACION mayor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MODIFICACION
        SELECT   iv_Transito ,'Longitud FECHA_MODIFICACION menor a la permitida(8)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_MODIFICACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FAX
        SELECT   iv_Transito ,'Longitud FAX mayor a la permitida(12)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FAX) > 12 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE EMAIL
        SELECT   iv_Transito ,'Longitud EMAIL mayor a la permitida(50)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.EMAIL) > 50 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   iv_Transito ,'Longitud FECHA_ACTUALIZACION mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) > 8 and ST_C.id_radicado = GS_RADICADO
         
        union
        
        -- VALIDO LONGITUD DE FECHA_ACTUALIZACION
        SELECT   iv_Transito ,'Longitud FECHA_ACTUALIZACION menor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.FECHA_ACTUALIZACION) < 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_CIUDAD_DIR
        SELECT   iv_Transito ,'Longitud ID_CIUDAD_DIR mayor a la permitida(8)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_CIUDAD_DIR) > 8 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE NOMBRE_CIUDAD_DIR
        SELECT   iv_Transito ,'Longitud NOMBRE_CIUDAD_DIR mayor a la permitida(40)' as INCONSISTENCIA, 'CONTRIBUYENTES' as ARCHIVO,ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.NOMBRE_CIUDAD_DIR) > 40 and ST_C.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DIRECCION
        SELECT   iv_Transito ,'Longitud ID_DIRECCION mayor a la permitida(20)' as INCONSISTENCIA,'CONTRIBUYENTES' as ARCHIVO, ST_C.*, ST_C.rowid
        FROM TMP_CONTRIBUYENTES ST_C
        where length (ST_C.ID_DIRECCION) > 20 and ST_C.id_radicado = GS_RADICADO
        
        
        union 
        
        /*CONTRIBUYENTES*/
        select iv_Transito Secretaria, 
               'Id_Ciudad No Existe en Runt' Inconsistencia, 'Contribuyentes' ARCHIVO,sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        left join CORRECCION_DATOS.runt_ciudades rl
                on rl.divipo = sv.ID_CIUDAD_DIR 
        where rl.nombre = '' and sv.id_radicado = GS_RADICADO  
        
        union 
        
        select  iv_Transito Secretaria, 
               'Nombres Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Nombres is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Apellidos Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Apellidos is null And sv.Id_Documento != 'N' and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Direccion Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Direccion is null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
         validacion de telefono y celular pendiente por activar esta validacion
        
        select  iv_Transito Secretaria, 
               'Telefono Null y Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Telefono is null And SV.Celular is Null  and sv.id_radicado = GS_RADICADO
        
        /*union 
        
        select  sv.Id_Radicado, iv_Transito Secretaria, 
               'Celular Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Celular is null  and sv.id_radicado = GS_RADICADO 
        
        union 
        
        select  sv.Id_Radicado, iv_Transito Secretaria, 
               'Email Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Email is null  and sv.id_radicado = GS_RADICADO */
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Ciudad_Dir Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        Inner Join St_Maestro Sm On sv.Id_Radicado = Sm.Id_Radicado
        Inner Join Correccion_datos.Runt_ciudades Sq On Sq.Divipo = Sm.Id_Secretaria
        where  SV.Id_Ciudad_Dir is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select  iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia,'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        union 
        
        select iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia, 'Contribuyentes' ARCHIVO, sv.*, Sv.rowid
        from TMP_CONTRIBUYENTES sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO;

Begin
     lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
        For ln_index In lcur_contribuyentes Loop
        
          If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'ID_USUARIO;'||'ID_DOCUMENTO;'
                            ||'ID_CIUDAD;'||'NOMBRE_CIUDAD;'||'APELLIDOS;'||'NOMBRES;'||'DIRECCION;'||'TELEFONO;'||'MP_O_PART;'||'SEXO;'
                            ||'FECHA_NACIMIENTO;'||'ID_PAIS;'||'NOMBRE_PAIS;'||'FECHA_MODIFICACION;'||'FAX;'||'EMAIL;'||'FECHA_ACTUALIZACION;'
                            ||'ID_CIUDAD_DIR;'||'NOMBRE_CIUDAD_DIR;'||'ID_DIRECCION;'||'ID_RADICADO;'||'CELULAR');                     
                        lb_Existe:=True;
         End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||ln_index.Inconsistencia ||';'
                ||ln_index.archivo||';'
                ||ln_index.id_usuario||';'
                ||ln_index.id_documento||';'
                ||ln_index.id_ciudad||';'
                ||ln_index.nombre_ciudad||';'
                ||ln_index.apellidos||';'
                ||ln_index.nombres||';'
                ||ln_index.direccion||';'
                ||ln_index.telefono||';'
                ||ln_index.emp_o_part||';'
                ||ln_index.sexo||';'
                ||ln_index.fecha_nacimiento||';'
                ||ln_index.Id_Pais||';'
                ||ln_index.nombre_pais||';'
                ||ln_index.fecha_modificacion||';'
                ||ln_index.fax||';'
                ||ln_index.email||';'
                ||ln_index.fecha_actualizacion||';'
                ||ln_index.id_ciudad_dir||';'
                ||ln_index.nombre_ciudad_dir||';'
                ||ln_index.id_direccion||';'
                ||ln_index.id_radicado||';'
                ||ln_index.celular);
                
                --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                --Values (ln_index.rowid, 'tmp_contribuyentes');
                
        End Loop;
            UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Contribuyent;

Procedure Sp_Inconsistencia_Propietarios As

/*ISVA
Nombre     :Sp_Inconsistencia_Propietarios
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los propietarios
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' PROPIETARIOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;

      -- VALIDO LONGITUD DE NRO_PLACA
        Cursor lcur_propietarios Is
        SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.NRO_PLACA) > 6 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_USUARIO
        SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_USUARIO) > 15 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE ID_DOCUMENTO
        SELECT   iv_Transito ,'Longitud ID_DOCUMENTO mayor a la permitida(1)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.ID_DOCUMENTO) > 1 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA,'PROPIETARIOS' as ARCHIVO, ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        union
        
        -- VALIDO LONGITUD DE PORCENTAJE_PROP
        SELECT   iv_Transito ,'Longitud PORCENTAJE_PROP mayor a la permitida(3)' as INCONSISTENCIA, 'PROPIETARIOS' as ARCHIVO,ST_P.*, St_p.Rowid
        FROM TMP_propietarios ST_P
        where length (ST_P.PORCENTAJE_PROP) > 3 and ST_P.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select  iv_Transito Secretaria, 
               'Propietarios No Reportados En Vehiculos' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_VEHICULOS sv on sp.nro_placa = sv.nro_placa and sp.id_radicado = sv.Id_radicado
        where sv.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select   iv_Transito Secretaria, 
               'Propietarios No Reportados En Tramites' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_TRAMITES st on sp.nro_placa = st.nro_placa and sp.id_radicado = st.Id_radicado
        where st.nro_placa is null and sp.id_radicado = GS_RADICADO
        
        
        UNION
        
        Select  iv_Transito Secretaria, 
               'Propietarios No Reportados En Contribuyentes' Inconsistencia, 'Propietarios' ARCHIVO, sp.*, Sp.Rowid
        from TMP_propietarios sp
        left join TMP_CONTRIBUYENTES sc on Sp.Id_Usuario = Sc.Id_Usuario And Sp.Id_Documento = Sc.Id_Documento and sp.id_radicado = sc.Id_radicado
        where sc.Id_Usuario is null and sp.id_radicado = GS_RADICADO
        
        union
         
        
        select  iv_Transito Secretaria, 
               'Id_Usuario Null' Inconsistencia,'PROPIETARIOS' ARCHIVO, sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Id_Usuario is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select   iv_Transito Secretaria, 
               'Id_Documento Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Id_Documento is null  and sv.id_radicado = GS_RADICADO
        
        
        union 
        
        select  iv_Transito Secretaria, 
               'Porcentaje_Propiedad Null' Inconsistencia, 'PROPIETARIOS' ARCHIVO,sv.*, Sv.Rowid
        from TMP_propietarios sv
        where  SV.Porcentaje_Prop is null  and sv.id_radicado = GS_RADICADO;
Begin
     lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
      For ln_index In lcur_propietarios Loop
             If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                               ||'ID_DOCUMENTO;'||'PORCENTAJE_PROP;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.id_documento||';'
                ||Ln_Index.porcentaje_prop||';'
                ||Ln_Index.id_radicado);
                
                --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                --Values (ln_index.rowid, 'Tmp_Propietarios');
    End Loop;
         UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Inconsistencia_Propietarios;

Procedure Sp_Validar_Histo_Traspasos As

/*ISVA
Nombre     :Sp_Validar_Histo_Traspasos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los historiales traspasos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):=GS_RADICADO||' '||iv_Transito||' HISTORIALES_TRASPASOS '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

  -- VALIDO LONGITUD DE NRO_PLACA
            Cursor lcur_histo_Tras Is
            -- VALIDO LONGITUD DE NRO_PLACA
            SELECT   iv_Transito ,'Longitud NRO_PLACA mayor a la permitida(6)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.NRO_PLACA) > 6 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE ID_USUARIO
            SELECT   iv_Transito ,'Longitud ID_USUARIO mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.ID_USUARIO) > 15 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE TIPO_DOCUMENTO_USUARIO
            SELECT   iv_Transito ,'Longitud TIPO_DOCUMENTO_USUARIO mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.TIPO_DOCUMENTO_USUARIO) > 1 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE ID_COMPRADOR
            SELECT   iv_Transito ,'Longitud ID_COMPRADOR mayor a la permitida(15)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.ID_COMPRADOR) > 15 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE TIPO_DOCUMENTO_COMPRADOR
            SELECT   iv_Transito ,'Longitud TIPO_DOCUMENTO_COMPRADOR mayor a la permitida(1)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.TIPO_DOCUMENTO_COMPRADOR) > 1 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE PORCENTAJE
            SELECT   iv_Transito ,'Longitud PORCENTAJE mayor a la permitida(3)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where length (ST_H.PORCENTAJE) > 3 and ST_H.id_radicado = GS_RADICADO
            
            union
            
            -- VALIDO LONGITUD DE FECHA
            SELECT   iv_Transito ,'Longitud FECHA diferente a la permitida(8)' as INCONSISTENCIA,'HISTORIALES_TRASPASO' as ARCHIVO, ST_H.*, ST_H.rowid
            FROM TMP_HISTORIALES_TRASPASO ST_H
            where  ST_H.id_radicado = GS_RADICADO and (length (ST_H.FECHA) < 8) 
            
            UNION
            
            Select Distinct iv_Transito Secretaria, 
                   'Vendedores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from TMP_HISTORIALES_TRASPASO sh
            left join tmp_contribuyentes sc on Sh.Id_Usuario = Sc.Id_Usuario And Sh.TIPO_DOCUMENTO_USUARIO = sc.ID_DOCUMENTO and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO
            
            
            UNION
            
            Select Distinct iv_Transito Secretaria, 
                   'Compradores No Reportados En Contribuyentes' Inconsistencia, 'Historial Traspaso' ARCHIVO, sh.*, SH.rowid
            from TMP_HISTORIALES_TRASPASO sh
            left join tmp_contribuyentes sc on Sc.Id_Usuario = Sh.ID_COMPRADOR And Sc.Id_Documento = Sh.TIPO_DOCUMENTO_COMPRADOR and sh.id_radicado = sc.Id_radicado
            where sc.Id_Usuario is null and sh.id_radicado = GS_RADICADO;

Begin 
         lutl_archivo := UTL_FILE.FOPEN('INCONSISTENCIA_TTO',lv_Archivo,'W');  
        For ln_index In lcur_Histo_Tras Loop
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'SECRETARIA;'||'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_USUARIO;'
                                                        ||'TIPO_DOCUMENTO_USUARIO;'||'ID_COMPRADOR;'||'TIPO_DOCUMENTO_COMPRADOR;'
                                                        ||'PORCENTAJE;'||'FECHA;'||'ID_RADICADO');

                    lb_Existe:=True;
             End If;
            UTL_FILE.PUT_LINE(lutl_archivo,iv_Transito||';'
                ||Ln_Index.inconsistencia||';'
                ||Ln_Index.archivo||';'
                ||Ln_Index.nro_placa||';'
                ||Ln_Index.id_usuario||';'
                ||Ln_Index.tipo_documento_usuario||';'
                ||Ln_Index.id_comprador||';'
                ||Ln_Index.tipo_documento_comprador||';'
                ||Ln_Index.porcentaje||';'
                ||Ln_Index.fecha||';'
                ||Ln_Index.id_radicado);
                
                --Insert Into Count_row_id (Rowid_column, Nombre_tabla)  
                --Values (ln_index.rowid, 'tmp_historiales_traspaso');
                
        End Loop;
        
    UTL_FILE.FCLOSE(lutl_archivo);
End Sp_Validar_Histo_Traspasos;

Procedure Sp_Eliminar_Inconsistencia As

/*ISVA
Nombre     :Sp_Eliminar_Inconsistencia
Autor      :Blados.Ospina
Fecha      :06/09/2018
Parametros :
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Version    :1.0
Objetivo   :Eliminar las inconsistencias
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
06/09/2018  Blados.Ospina   1.0                     */

SQLTEXT varchar2(255);

cursor lcur_prueba Is Select Distinct Rowid_column, nombre_tabla From count_row_id;
Begin
    For ln_index IN lcur_prueba Loop
       SQLTEXT := 'Delete from '||ln_index.nombre_tabla||' where rowid = '||'''' || ln_index.rowid_column||'''';
       EXECUTE IMMEDIATE SQLTEXT;
    End Loop;
        Delete From Count_Row_Id;
        Commit;
End;

Procedure Sp_Iniciar_Inconsistencia (as_id_radicado Simple_Integer) AS

/*ISVA
Nombre     :Sp_Iniciar_Inconsistencia
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Ejecuta todos los procesos del pl-sql
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

BEGIN

GS_RADICADO := as_id_radicado;

    Sp_Registrar_Transito;
    Sp_Detalle_Inconsistencia;
    SP_Inconsistencia_Vehiculos;
    Sp_Inconsistencia_Tramites;
    Sp_Inconsistencia_Propietarios;
    Sp_Inconsistencia_Contribuyent;
    Sp_Validar_Histo_Traspasos;
    --Sp_Eliminar_Inconsistencia;
      
END Sp_Iniciar_Inconsistencia;


END PKG_INCONSISTENCIAS_TRANSITOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_NOVEDADES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_VALIDACION_NOVEDADES" AS

itp_placa consultas.tp_propietarios := consultas.tp_propietarios();
itp_lista_placa consultas.tp_lista_propietarios :=  consultas.tp_lista_propietarios();
in_vigencia NUMBER:=0;


PROCEDURE sp_recuperar_placa AS

/*ISVA
Nombre     :sp_recuperar_placa
Autor      :Blados.Ospina
Fecha      :20/12/2018
Argumento  :
Variables  :lv_placas, ltul_read
Retorno    :             
Proyecto   :PKG_VALIDACION_NOVEDADES
Version    :1.0
Objetivo   :recupera la totalida de las placas a 
           :procesar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_placas VARCHAR2(255 BYTE);
ltul_read UTL_FILE.FILE_TYPE; 

BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
        LOOP
            BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_placas);
                lv_placas:='';   
                itp_placa.nro_placa :=''; 
                itp_lista_placa.Extend;
                itp_lista_placa(itp_lista_placa.Count()):=itp_placa;
                
            EXCEPTION 
            WHEN No_Data_Found THEN EXIT;
            END;
        END LOOP;
END sp_recuperar_placa;

PROCEDURE sp_validacion_novedades AS


lv_cancelacion VARCHAR2(2);
lv_radicacion VARCHAR2(2);
lv_traslado_interno VARCHAR2(2);
lv_traslado VARCHAR2(2);
lv_matricula VARCHAR2(2);
lv_cbio_pu_pa VARCHAR2(2);
lv_cbio_pa_pu VARCHAR2(2);
lv_indeterminado VARCHAR2(2); 

CURSOR lcur_novedades(av_placa VARCHAR) IS SELECT nro_placa, id_tramite,nombre_tramite, fecha_tramite,
                                                  id_secretaria_destino,id_secretaria_origen,id_servicio_anterior,
                                                  nombre_servicio_anterior,id_servicio_nuevo,nombre_servicio_nuevo,
                                                  estado_novedad
                                            FROM arunt_tramites
                                            WHERE nro_placa = av_placa AND id_tramite IN (6,9,10,13,15,20,65)
                                            ORDER BY fecha_tramite ASC;
                         
BEGIN
    FOR ln_index IN 1..itp_lista_placa.count() LOOP
          FOR ln_novedad IN lcur_novedades(itp_lista_placa(ln_index).nro_placa) LOOP
            CASE ln_novedad.id_tramite
                WHEN 6  THEN
                    IF  ln_novedad.fecha_tramite > TO_DATE('01/01/'|| in_vigencia) THEN
                        NULL;    
                    END IF;
                WHEN 9  THEN
                    NULL;
                WHEN 10 THEN
                    NULL;
                WHEN 13 THEN
                    NULL;
                WHEN 15 THEN
                    NULL;
                WHEN 20 THEN
                    NULL;
                WHEN 65 THEN
                    NULL;
        ELSE
            NULL;
        END CASE;
          END LOOP;
    END LOOP;
   
END sp_validacion_novedades;

PROCEDURE sp_iniciar(an_vigencia NUMBER) AS

/*ISVA
Nombre     :sp_iniciar
Autor      :Blados.Ospina
Fecha      :20/12/2018
Argumento  :
Variables  :
Retorno    :             
Proyecto   :PKG_VALIDACION_NOVEDADES
Version    :1.0
Objetivo   :Inicar las validaciones de novedades RUNT
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion                                                    */

BEGIN
    in_vigencia:=an_vigencia;
    sp_recuperar_placa;
END sp_iniciar;

END PKG_VALIDACION_NOVEDADES;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VEHICULOS_NO_EXISTEN_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_TRANSITOS"."PKG_VEHICULOS_NO_EXISTEN_SAP" As



Procedure Sp_Placas_Not_Exists_Sap as

esCrearVehiculo boolean := true;
esServicioValido boolean := true;
esCilindrajeValido boolean := true;
esHabilitaNovedad boolean := true;
esExisteArchivo boolean := false;
lnCilindraje number := 0;
lnServicio number := 0;
lvCadenaTexto varchar2(32767);
lFile UTL_FILE.FILE_TYPE;

Cursor curPlaca is
Select Distinct Sv.Nro_Placa, Sv.Id_Servicio,Sv.Cilindraje
from St_Vehiculos sv
left join BD_FISCALIZACION.Fc_Vehiculos Fv
  on Fv.nro_placa = sv.Nro_Placa
where Fv.nro_placa is null;
--and rownum <1000;

Type tyPlaca is table of curPlaca%ROWTYPE;
ArrayPlaca tyPlaca;

Begin

Open curPlaca;
 Loop fetch curPlaca
   Bulk Collect into ArrayPlaca limit 500;
    For lnIndex in 1..ArrayPlaca.count() Loop
     
     --Convierto el cilidraje
     begin
      lnCilindraje := to_number(ArrayPlaca(lnIndex).Cilindraje);
      lnServicio := to_number(ArrayPlaca(lnIndex).Id_Servicio);
     exception when others then     
      lnCilindraje := 0;
      lnServicio := 0;
     end;
     
     --Valido el servicio del veh�culo
     if(lnServicio not in(1,4)) then
        esServicioValido := Ft_Validar_Cambio_Servicio(ArrayPlaca(lnIndex).Nro_Placa);        
     end if;   
     
      --Valido que no tenga novedades que inhabiliten la creaci�n del veh�culo
      esHabilitaNovedad := Ft_Validar_Novedades(ArrayPlaca(lnIndex).Nro_Placa);
      
     --Valido el Cilindraje del veh�culo
     if(lnCilindraje < 126) then
        esCilindrajeValido := Ft_Validar_Cambio_Cilindraje(ArrayPlaca(lnIndex).Nro_Placa);
     end if;    
     
    --Si todas las validaciones son verdaderas creo el vehiculo
    if(esServicioValido = true and esHabilitaNovedad = true and esCilindrajeValido = true) then
      esCrearVehiculo := true;
    else
      esCrearVehiculo := false;
    end if; 
     
          
    If (esCrearVehiculo = true)then
      --Creo la cadena a insertar.
      lvCadenaTexto := ArrayPlaca(lnIndex).Nro_Placa;
      if(esExisteArchivo = false) then
       -- Abro fichero para escritura (Write)
        lFile := UTL_FILE.FOPEN('PLANOS_TI_PLSQL','Crear_Vehiculos.txt','W',256); 
        -- Escribo en el fichero
        UTL_FILE.PUT(lFile,'Veh�culos en BD OTS no existen en SAP. Generado: '||sysdate);
        esExisteArchivo := true;
        else
        -- Abro y escribo en el fichero para escritura (Actualizar)
        lFile := UTL_FILE.FOPEN('PLANOS_TI_PLSQL','Crear_Vehiculos.txt','A',256);
      End If;
      -- Escribo en el fichero
      UTL_FILE.PUT(lFile,lvCadenaTexto);
      --Cierro el Fichero
      Utl_File.Fclose(lFile);
    End If;
    
    End Loop;
     Exit when ArrayPlaca.count()<=0;
 End Loop; 

End Sp_Placas_Not_Exists_Sap;

Function Ft_Validar_Cambio_Cilindraje(lfPlaca varchar2) return boolean as

esPagaImpuesto boolean := false;
lnCilindraje number := 0;

Cursor curCbioServicio is
Select Nro_Placa, Id_Tramite, 
       To_Date(Decode(length(St.Fecha_Tramite),7,
                                              '0'||St.Fecha_Tramite,                                     
                                              St.Fecha_Tramite)) Fecha_Tramite,
                                              Decode(St.Cilindraje,'',
                                                                    0,
                                                        St.Cilindraje) Cilindraje                                                                                          
From st_tramites St
Inner Join St_Maestro sm on Sm.Id_Radicado = St.Id_Radicado 
Where St.Nro_Placa = lfPlaca and Sm.Produccion = 'S'
  And St.Id_Tramite In(4)--Tramite cambio Motor
order by 3 asc;

begin

For lnIndex in curCbioServicio loop

   --Convierto el cilidraje
   begin
    lnCilindraje := lnIndex.Cilindraje;
     -- Si cilindraje mayor a 125 paga
     if(lnCilindraje > 125) then      
        esPagaImpuesto := true;
     else
        esPagaImpuesto := false;
     End if; 
     
   exception when others
   then 
    esPagaImpuesto := false;
   end;  

End Loop;
return esPagaImpuesto;

End Ft_Validar_Cambio_Cilindraje;



Function Ft_Validar_Cambio_Servicio(lfPlaca varchar2) return boolean as

esPagaImpuesto boolean := false;

Cursor curCbioServicio is
Select Nro_Placa, Id_Tramite, To_Date(Decode(length(St.Fecha_Tramite),7,
                                    '0'||St.Fecha_Tramite,                                     
                                    St.Fecha_Tramite)) Fecha_Tramite, 
       St.Id_Secretaria_Destino, St.Id_Secretaria_Origen, Id_Servicio_Anterior, Id_Servicio_Nuevo
From st_tramites St
Inner Join St_Maestro sm on Sm.Id_Radicado = St.Id_Radicado 
Where St.Nro_Placa = lfPlaca and Sm.Produccion = 'S'
  And St.Id_Tramite In(6)--Tramite servicio
order by 3 asc;

begin

For lnIndex in curCbioServicio loop

   -- Cambio de Servicio a Particular.
   if(lnIndex.Id_Servicio_Anterior != 1 and 
       lnIndex.Id_Servicio_Nuevo in(1,4)) then
      esPagaImpuesto := true;
    End if;   
    
   -- Cambio de Particular a P�blico.
   if(lnIndex.Id_Servicio_Anterior = 1 and 
      lnIndex.Id_Servicio_Nuevo != 1) then
        if (lnIndex.Fecha_Tramite > '31/12/98') then
          esPagaImpuesto := true;
        else
          esPagaImpuesto := false;
        end if;
    End if; 

End Loop;
return esPagaImpuesto;

End Ft_Validar_Cambio_Servicio;


Function Ft_Validar_Novedades (lfPlaca Varchar2)return boolean as

lnPagaImpuesto Boolean := true;

Cursor curNovedades is
Select Nro_Placa, Id_Tramite, To_Date(Decode(length(St.Fecha_Tramite),7,
                                    '0'||St.Fecha_Tramite,                                     
                                    St.Fecha_Tramite)) Fecha_Tramite, 
       St.Id_Secretaria_Destino, St.Id_Secretaria_Origen, Id_Servicio_Anterior, Id_Servicio_Nuevo
From st_tramites St
Inner Join St_Maestro sm on Sm.Id_Radicado = St.Id_Radicado 
Where St.Nro_Placa = lfPlaca and Sm.Produccion = 'S'
  And St.Id_Tramite In(10,13,15,20)
order by 3 asc;

Begin

For lnIndex in curNovedades Loop
  Case lnIndex.Id_Tramite
    /*When 6 Then -- Cambio Servicio
       -- Cambio de Servicio a Particular.
       if(lnIndex.Id_Servicio_Anterior != 1 and 
           lnIndex.Id_Servicio_Nuevo in(1,4)) then
          lnPagaImpuesto := true;
        End if;   
        
       -- Cambio de Particular a P�blico.
       if(lnIndex.Id_Servicio_Anterior = 1 and 
          lnIndex.Id_Servicio_Nuevo != 1) then
            if (lnIndex.Fecha_Tramite > '31/12/98') then
              lnPagaImpuesto := true;
            else
              lnPagaImpuesto := false;
            end if;
        End if; */
        
    When 10 Then -- Radicaci�n
        lnPagaImpuesto := true; 
        
    When 13 Then -- Rematricula     
        lnPagaImpuesto := true;
        
    When 15 Then -- Traslado
      if (lnIndex.Fecha_Tramite > '31/12/98') then
        lnPagaImpuesto := true;
      else
        lnPagaImpuesto := false;
      end if; 
       
    When 20 Then -- Cancelacion
      if (lnIndex.Fecha_Tramite > '31/12/98') then
        lnPagaImpuesto := true;
      else
        lnPagaImpuesto := false;
      end if;
              
    End Case; 
   
End loop;

Return lnPagaImpuesto;

End Ft_Validar_Novedades;

End Pkg_Vehiculos_No_Existen_Sap;

/
