--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type TP_LISTA_PERSONA
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_VALIDACION_RUNT"."TP_LISTA_PERSONA" Is table of Tp_Persona;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_PROP_RUNT
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_VALIDACION_RUNT"."TP_LISTA_PROP_RUNT" Is table of Tp_prop_runt;

/
--------------------------------------------------------
--  DDL for Type TP_PERSONA
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_VALIDACION_RUNT"."TP_PERSONA" is Object (
ID_PERSONA VARCHAR2(255 BYTE), 
ID_DOCUMENTO NUMBER, 
NOMBRE VARCHAR2(150 BYTE), 
FECHA_NACIMIENTO DATE, 
VALOR_HORA NUMBER(10,0), 
HORAS_TRABAJADA NUMBER(5,0), 
SEXO VARCHAR2(1 BYTE),
Constructor Function Tp_Persona Return Self As Result
);
/
CREATE OR REPLACE TYPE BODY "BD_VALIDACION_RUNT"."TP_PERSONA" Is 
Constructor Function Tp_Persona Return Self As Result Is 
    tp_Persona_1 Tp_Persona := Tp_Persona(null,null,null,null,null,null,null);
        Begin
            Self := tp_Persona_1;
            Return;
            End Tp_Persona;
        End;

/
--------------------------------------------------------
--  DDL for Type TP_PROP_RUNT
--------------------------------------------------------

  CREATE OR REPLACE TYPE "BD_VALIDACION_RUNT"."TP_PROP_RUNT" is Object (
id_usuario VARCHAR2(255 BYTE), 
id_documento VARCHAR2(255 BYTE), 
nombres VARCHAR2(255 BYTE), 
apellidos VARCHAR2(255 BYTE), 
direccion VARCHAR2(255 BYTE),
telefono VARCHAR2(255 BYTE), 
email VARCHAR2(255 BYTE), 
celular VARCHAR2(255 BYTE),
id_ciudad_dir VARCHAR2(255 BYTE),
municipio VARCHAR2(255 BYTE),
departamento VARCHAR2(255 BYTE),
Constructor Function Tp_prop_runt Return Self As Result
);
/
CREATE OR REPLACE TYPE BODY "BD_VALIDACION_RUNT"."TP_PROP_RUNT" Is 
Constructor Function Tp_prop_runt Return Self As Result Is 
    Tp_prop_runt_1 Tp_prop_runt := Tp_prop_runt(null,null,null,null,null,null,null,null,null,null,null);
        Begin
            Self := Tp_prop_runt_1;
            Return;
            End Tp_prop_runt;
        End;

/
--------------------------------------------------------
--  DDL for Trigger TGR_VALIDAR_DOC_PRO_SAP
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "BD_VALIDACION_RUNT"."TGR_VALIDAR_DOC_PRO_SAP" 
    BEFORE  INSERT OR UPDATE ON PROPIETARIOS_SAP

    REFERENCING OLD AS VIEJO NEW AS NUEVO
    FOR EACH ROW
    BEGIN
      IF (INSERTING) THEN
            :Nuevo.Id_Documento:=Ft_validar_documento (UPPER(:Nuevo.Id_Documento));
      ELSIF (UPDATING) THEN
            :Nuevo.Id_Documento:=Ft_validar_documento (UPPER(:Nuevo.Id_Documento));
      END IF;
   END;
/
ALTER TRIGGER "BD_VALIDACION_RUNT"."TGR_VALIDAR_DOC_PRO_SAP" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TGR_VALIDAR_DOCUMENTO
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "BD_VALIDACION_RUNT"."TGR_VALIDAR_DOCUMENTO" 
    BEFORE  INSERT OR UPDATE ON SAP_INTERLOCUTORES

    REFERENCING OLD AS VIEJO NEW AS NUEVO
    FOR EACH ROW
    BEGIN
      IF (INSERTING) THEN
            :Nuevo.Id_Documento:=Ft_validar_documento (UPPER(:Nuevo.Id_Documento));
      ELSIF (UPDATING) THEN
            :Nuevo.Id_Documento:=Ft_validar_documento (UPPER(:Nuevo.Id_Documento));
      END IF;
   END;
/
ALTER TRIGGER "BD_VALIDACION_RUNT"."TGR_VALIDAR_DOCUMENTO" ENABLE;
--------------------------------------------------------
--  DDL for Procedure SP_ULTIMO_PROPIETARIO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "BD_VALIDACION_RUNT"."SP_ULTIMO_PROPIETARIO" AS 

CURSOR lcur_ultimo IS SELECT nro_placa FROM vr_tmp_propietarios_runt;

BEGIN
  FOR ln_index IN lcur_ultimo LOOP
    DELETE vr_tmp_propietarios_runt 
    WHERE NRO_PLACA = ln_index.nro_placa AND fecha_runt NOT IN (SELECT   MAX(fecha_runt) FROM vr_tmp_propietarios_runt
                                                                WHERE NRO_PLACA = ln_index.nro_placa);
  END LOOP;
END SP_ULTIMO_PROPIETARIO;

/
--------------------------------------------------------
--  DDL for Package PKG_HOMOLOGACION_OC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_HOMOLOGACION_OC" AS 

--Insertar caracteristicas los vehiculos RUNT
PROCEDURE sp_insertar_vehiculos_runt;

--Proceso plantilla OC
PROCEDURE sp_iniciar;

END PKG_HOMOLOGACION_OC;

/
--------------------------------------------------------
--  DDL for Package PKG_PLANTILLA_MOD_IC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_PLANTILLA_MOD_IC" AS 

PROCEDURE sp_crear_plantilla_ic;
PROCEDURE sp_insertar_interlocutores;


END PKG_PLANTILLA_MOD_IC;

/
--------------------------------------------------------
--  DDL for Package PKG_PLANTILLAS_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_PLANTILLAS_SAP" AS 

/*ISVA
Nombre     :PKG_PLANTILLAS_SAP
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :Array_Novedades, tp_Novedades
Retorno    :
Proyecto   :PKG_PLANTILLAS_SAP
Versi�n    :1.0
Objetivo   :envia el codigo de cada una de las novedades
           :para generar las plantillas en sap
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

PROCEDURE SP_GENERAR_PLANTILLAS;

END PKG_PLANTILLAS_SAP;

/
--------------------------------------------------------
--  DDL for Package PKG_REPORTE_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_REPORTE_VEHICULOS" AS 

--Actualiza las caracteristicas de los vehiculos de SAP
PROCEDURE sp_actualizar_caracteristicas;

--Actualiza los nombres y otros datos de los pagos
PROCEDURE sp_actualizar_interlocutor_sap;

-- Actualiza los nombres y caracteristicas de RUNT
PROCEDURE sp_actualizar_interlo_runt;

END PKG_REPORTE_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDACION_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_VALIDACION_PROPIETARIOS" AS 

PROCEDURE sp_iniciar;

END PKG_VALIDACION_PROPIETARIOS;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_TRAMITE_RUNT_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_VALIDAR_TRAMITE_RUNT_SAP" AS 

/*ISVA
Nombre     :Sp_Iniciar_Validacion
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :Inicia las validaciones para tramites runt
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

Procedure Sp_Iniciar_Validacion;

END PKG_VALIDAR_TRAMITE_RUNT_SAP;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_VALIDAR_VEHICULOS" AS 

procedure sp_iniciar;

END PKG_VALIDAR_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package PKG_VAL_PROP_RUNT_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "BD_VALIDACION_RUNT"."PKG_VAL_PROP_RUNT_SAP" AS 

/*ISVA
Nombre     :PKG_VAL_PROP_RUNT_SAP
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Para inicar comparacion de que posse el interlocutor
           :mas actualizado.
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Procedure Sp_Iniciar_Validacion;

END PKG_VAL_PROP_RUNT_SAP;

/
--------------------------------------------------------
--  DDL for Package Body PKG_HOMOLOGACION_OC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_HOMOLOGACION_OC" AS

iv_id_marca VARCHAR2(20 BYTE); iv_marca VARCHAR2(255 BYTE); iv_id_clase VARCHAR2(10 BYTE); iv_tipo_carga VARCHAR2(10 BYTE);
iv_id_carroceria  VARCHAR2(10 BYTE); iv_id_servicio VARCHAR(2 BYTE); iv_id_linea VARCHAR(10 BYTE); id_capacidad VARCHAR2(20);
in_id_secreataria NUMBER; iv_id_depto VARCHAR(2 BYTE); iv_inconsistencia VARCHAR2(4000 BYTE);

ib_error_marca BOOLEAN; ib_error_modelo BOOLEAN; ib_error_carroceria BOOLEAN; ib_error_clase BOOLEAN; ib_error_servicio BOOLEAN;
ib_error_linea BOOLEAN; ib_error_cilindraje BOOLEAN; ib_error_secreataria BOOLEAN; ib_error_tipo BOOLEAN;

it_error SYSTEM.Tp_Error := SYSTEM.Tp_Error();
it_list_error SYSTEM.Tp_Lista_Error := SYSTEM.Tp_Lista_Error();

PROCEDURE sp_error AS
BEGIN
    FOR ln_index IN 1..it_list_error.COUNT() LOOP
          DELETE tmp_placas;
          COMMIT;
          INSERT INTO tmp_placas (nro_placa,estado)
          VALUES (it_list_error(ln_index).nombre_error,it_list_error(ln_index).id_error);
          COMMIT;
    END LOOP;
END sp_error;

FUNCTION estadarizar_linea (av_linea VARCHAR) RETURN VARCHAR AS 

lv_linea_runt VARCHAR(255); 
lv_linea_runt_temp VARCHAR(255):='';
lv_validador_temp VARCHAR2(255);
ln_ultimo_caracter NUMBER:=0;
lv_ultimo_caracter VARCHAR2(2);

CURSOR lcur_caracteristicas IS SELECT caracteristica FROM correccion_datos.dq_caracteristicas;

Begin
    lv_linea_runt := TRANSLATE(av_linea,'-/����������������������()','  AEIOUAEIOUAEIOUAEIOUNN'); 

    FOR ln_index IN lcur_caracteristicas LOOP
              FOR I IN 1..LENGTH(lv_linea_runt) LOOP  
                lv_validador_temp:='';
                  FOR M IN I..I+LENGTH(ln_index.caracteristica) LOOP
                     lv_validador_temp := lv_validador_temp || SUBSTR(lv_linea_runt,M,1);
                     ln_ultimo_caracter := I+LENGTH(ln_index.caracteristica)+1;
                     lv_ultimo_caracter := SUBSTR(lv_linea_runt,ln_ultimo_caracter,1);
                  END LOOP;
                   IF lv_ultimo_caracter IS NOT NULL AND lv_ultimo_caracter NOT IN ('') THEN
                        NULL;    
                   ELSIF lv_ultimo_caracter IN ('',' ') OR lv_ultimo_caracter IS NULL THEN
                        IF lv_validador_temp = ln_index.caracteristica||' ' THEN
                                 lv_linea_runt_temp:= REPLACE(lv_linea_runt,ln_index.caracteristica||' ','');
                                 lv_linea_runt := lv_linea_runt_temp;
                        ELSIF lv_validador_temp = ' '||ln_index.caracteristica THEN
                                 lv_linea_runt_temp := REPLACE(lv_linea_runt,' '||ln_index.caracteristica,'');
                                 lv_linea_runt := lv_linea_runt_temp;
                        END IF; 
                  END IF;
                END LOOP;     
     END LOOP;

    RETURN lv_linea_runt;
    
END estadarizar_linea;

FUNCTION ft_validar_novedades (av_nro_placa VARCHAR) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_validar_novedades
Autor      :Blados.Ospina
Fecha      :23/11/2018
Parametros :
Retorno    :lb_existe          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :valida si tiene tramite de radicacion, cambio servicio 
           :o rematricula  
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                      */

ln_existe NUMBER:=0;
lb_existe BOOLEAN:=FALSE;

BEGIN
    SELECT COUNT(1) INTO ln_existe FROM vr_reporte_novedades_sap
    WHERE nro_placa = av_nro_placa and id_novedad IN (4,6,8);
    
        IF ln_existe > 0 THEN
            lb_existe := TRUE; 
        END IF;
        
        RETURN lb_existe;
        
EXCEPTION
WHEN OTHERS THEN
RETURN TRUE;
END ft_validar_novedades;

PROCEDURE sp_inconsistencias_Vehiculos AS

/*ISVA
Nombre     :SP_Inconsistencia_Vehiculos
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :lv_Archivo, lb_Existe, lutl_archivo, lcur_vehiculos
Retorno    :          
Proyecto   :PKG_INCONSISTENCIAS_TRANSITOS
Versi�n    :1.0
Objetivo   :Genera las inconsistencias por transito 
           :para los vehiculos   
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */

lv_Archivo Varchar2(255 byte):='CORRECCION VEHICULOS RUNT ' ||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

lutl_archivo UTL_FILE.FILE_TYPE;
        
        Cursor lcur_vehiculos Is 
            -- VALIDO LONGITUD DE NRO_PLACA
        SELECT 'Longitud NRO_PLACA mayor a la permitida(6)' as inconsistencia_runt, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (ST_V.NRO_PLACA) > 6 
        
        union
     
        -- VALIDO LONGITUD DE MODELO
        SELECT  'Longitud MODELO mayor a la permitida(4)' as inconsistencia_runt, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (REPLACE (ST_V.MODELO,'.','')) > 4 
        
        unioN
        
        -- VALIDO LONGITUD DE CAP_PASAJEROS
        SELECT  'Longitud CAP_PASAJEROS mayor a la permitida(3)' as inconsistencia_runt, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (ST_V.CAP_PASAJEROS) > 3 
        
        union
        
        -- VALIDO LONGITUD DE CAP_TONELADAS
        SELECT  'Longitud CAP_TONELADAS mayor a la permitida(6)' as inconsistencia_runt,'VEHICULOS' as ARCHIVO, ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (ST_V.CAP_TONELADAS) > 6 
        

        UNION
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT  'Longitud FECHA_MATRICULO mayor a la permitida(8)' as inconsistencia_runt, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (ST_V.FECHA_MATRICULO) > 8 
        
        union
        
        -- VALIDO LONGITUD DE FECHA_MATRICULO
        SELECT  'Longitud FECHA_MATRICULO menor a la permitida(8)' as inconsistencia_runt, 'VEHICULOS' as ARCHIVO,ST_V.*, st_v.rowid
        FROM oc_runt ST_V
        where length (ST_V.FECHA_MATRICULO) < 8 
        

        UNION
        
        --Carrocerias x clase Vehiculos
        select  'Carroceria Sin Relacion a La Clase (Vehiculos)' inconsistencia_runt,'VEHICULOS' ARCHIVO, sv.* , sv.rowid
        from oc_runt sv
        left join correccion_datos.RUNT_CARROCERIAS_X_CLASE rc
                on rc.codigo_clase = REPLACE (sv.id_clase,'.','') and rc.codigo_carroceria_ws = REPLACE (SV.ID_CARROCERIA,'.','')
        where RC.CODIGO_CARROCERIA_WS is null And Sv.Id_Carroceria is Not null 
        
        
        union
        
        --Lineas sin relacion a la marca transformacion
        select 'Linea Sin Relacion a La Marca' inconsistencia_runt,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        left join correccion_datos.runt_linea rl
                on rl.codigo_marca = REPLACE (sv.id_marca,'.','') and rl.codigo_linea_ws = REPLACE (sv.ID_LINEA,'.','')
        where  rl.codigo_linea_ws is null And Id_Linea is not null 
        
        union
        
        --Id_Marca con punto
        select 'Id_Marca con punto' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where sv.id_marca like '%.%' 
        
        union
        
        --Id_Linea con punto
        select 'Id_Linea con punto' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where sv.id_linea like '%.%' 
        
        union
        
        --Id_Linea con punto
        select 'Modelo con punto' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where sv.modelo like '%.%' 
        
        union
        
        --VALIDACION DE CAMPOS NULL
        
        select  'Id_Marca Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Id_Marca is null  
        
        union
        
        select 'Nro_placa Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  Sv.nro_placa is null 
        
        union 
        
        select 'Id_Linea Null' inconsistencia_runt,'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.id_linea is null  
        
        union 
        
        select 'Modelo Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Modelo is null  
        
        union 
        
        select 'Id_Clase Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.ID_CLASE is null  
        
        union 
        
        select 'Id_Servicio Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Id_Servicio is null 
        
        union 
        
        select 'Id_Carroceria Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Id_Carroceria is null 
        
        union 
        
        select 'Id_Secretaria Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Id_Secretaria is null  
        
        union 
        
        select 'Cilindraje Null o Cero' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  (SV.Cilindraje  is null or SV.Cilindraje = 0) And Id_Combustible Not In (5)
        
        
        union 
        
        select 'Fecha_Matriculo Null' inconsistencia_runt, 'VEHICULOS' ARCHIVO,sv.*, sv.rowid
        from oc_runt sv
        where  SV.Fecha_Matriculo is null;

Begin 
    lutl_archivo := UTL_FILE.FOPEN('ERRORES_RUNT',lv_Archivo,'W');
        For Ln_Index In lcur_vehiculos Loop
            
        Begin
            If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_archivo,'INCONSISTENCIA;'||'ARCHIVO;'||'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'
                                                ||'ID_LINEA;'||'NOMBRE_LINEA;'||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'
                                                ||'NOMBRE_SERVICIO;'||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'
                                                ||'ID_COMBUSTIBLE;'||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'
                                                ||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'||'ID_ESTADO;'
                                                ||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'||'ID_RADICADO;'||'ID_MARCA2;'
                                                ||'ID_LINEA2;'||'CAJA;'||'TRACCION;'||'COMBUSTION');
                     lb_Existe:=True;
            End If;
            UTL_FILE.PUT_LINE(lutl_archivo,Ln_Index.INCONSISTENCIA_RUNT||';'
            ||Ln_Index.ARCHIVO||';'
            ||Ln_Index.NRO_PLACA||';'
            ||Ln_Index.ID_MARCA||';'
            ||Ln_Index.NOMBRE_MARCA||';'
            ||Ln_Index.ID_LINEA||';'
            ||Ln_Index.NOMBRE_LINEA||';'
            ||Ln_Index.MODELO||';'
            ||Ln_Index.ID_CLASE||';'
            ||Ln_Index.NOMBRE_CLASE||';'
            ||Ln_Index.ID_SERVICIO||';'
            ||Ln_Index.NOMBRE_SERVICIO||';'
            ||Ln_Index.ID_CARROCERIA||';'
            ||Ln_Index.NOMBRE_CARROCERIA||';'
            ||Ln_Index.NRO_PUERTAS||';'
            ||Ln_Index.ID_COMBUSTIBLE||';'
            ||Ln_Index.NOMBRE_COMBUSTIBLE||';'
            ||Ln_Index.ID_BATERIA||';'
            ||Ln_Index.NOMBRE_BATERIA||';'
            ||Ln_Index.POTENCIA||';'
            ||Ln_Index.ID_SECRETARIA||';'
            ||Ln_Index.NOMBRE_SECRETARIA||';'
            ||Ln_Index.CILINDRAJE||';'
            ||Ln_Index.CAP_PASAJEROS||';'
            ||Ln_Index.CAP_TONELADAS||';'
            ||Ln_Index.VALOR_FACTURA||';'
            ||Ln_Index.BLINDADO||';'
            ||Ln_Index.IMPORTADO_NACIONAL||';'
            ||Ln_Index.ID_ESTADO||';'
            ||Ln_Index.NOMBRE_ESTADO||';'
            ||Ln_Index.CLASICO_ANTIGUO||';'
            ||Ln_Index.FECHA_MATRICULO);
                
                Delete From oc_runt
                Where Rowid = Ln_Index.rowid;
            
            Exception 
                When Others Then 
                    Dbms_Output.Put_Line(sqlerrm||Dbms_Utility.Format_Error_Backtrace||' '||'Sp_Vehiculos'); 
        End;   
        End Loop;
         UTL_FILE.FCLOSE(lutl_archivo); 
END sp_inconsistencias_Vehiculos;

FUNCTION ft_validacion_datos (an_modelo NUMBER DEFAULT NULL, av_cilindraje VARCHAR DEFAULT NULL,
                              av_linea VARCHAR DEFAULT NULL) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_validacion_datos
Autor      :Blados.Ospina
Fecha      :13/09/2018
Parametros :an_modelo, av_cilindraje
Retorno    :
Variables  :lv_error
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Validad el modelo y el cilindraje
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   */

lb_error BOOLEAN:=FALSE;
ln_existe NUMBER:=0;

BEGIN
    CASE
        WHEN an_modelo IS NOT NULL THEN
            IF LENGTH(an_modelo) = 4 THEN
               lb_error:=TRUE; 
            END IF;
            
        WHEN av_cilindraje IS NOT NULL THEN
            IF LENGTH(an_modelo) = 4 THEN
               lb_error:=TRUE; 
            END IF;
            
        WHEN av_linea IS NOT NULL THEN
           SELECT COUNT(1) INTO ln_existe  FROM depuracion.sap_lineas
           WHERE id_linea_sap = av_linea AND (UPPER(desc_linea_sap) 
           LIKE ('%SIN L%') OR UPPER(desc_linea_sap) LIKE ('%SIN-L%') OR UPPER(desc_linea_sap) LIKE ('%SIN LINEA%'));
                IF ln_existe > 0 THEN
                   lb_error:=TRUE; 
                END IF;   
    ELSE
        lb_error:= FALSE;
    END CASE;
    
    RETURN lb_error;

EXCEPTION
WHEN OTHERS THEN
RETURN lb_error;
 
RETURN lb_error;
    
END ft_validacion_datos;

PROCEDURE sp_validar_sap AS

/*ISVA
Nombre     :sp_validar_sap
Autor      :Blados.Ospina
Fecha      :13/09/2018
Parametros :
Retorno    :
Variables  :lv_error, ln_contador
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Valida las diferencias entre runt y sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion                        */

lv_error VARCHAR2(500);
ln_contador NUMBER := 0;
lv_sin_linea BOOLEAN;
lb_matricula BOOLEAN;
  
CURSOR lcur_oc_runt IS
       SELECT * FROM plantilla_oc_runt;
       
CURSOR lcur_oc_sap (av_placa VARCHAR2) IS
       SELECT * FROM oc_sap 
       WHERE placa = av_placa;   
  
BEGIN

FOR ln_runt IN lcur_oc_runt LOOP
    
    FOR ln_sap IN lcur_oc_sap (ln_runt.objeto_contrato) LOOP
    
    lb_matricula:=FALSE;
    lv_sin_linea:=FALSE;
    
    ln_contador := ln_contador + 1;
    
    lv_error:= NULL;
    
    IF ln_runt.modelo != ln_sap.modelo THEN
      lv_error := 'MODELO <>, ';
    END IF;  
    
    IF ln_runt.marca != ln_sap.id_marca THEN
      lv_error :=  lv_error || 'MARCA <>, ';
    END IF;  
        
    lv_sin_linea:=ft_validacion_datos(av_linea => ln_runt.linea);
        IF lv_sin_linea = TRUE THEN
            UPDATE plantilla_oc_runt SET linea = ln_sap.linea, marca = ln_sap.id_marca
            WHERE objeto_contrato = ln_runt.objeto_contrato;   
        ELSE
            IF ln_runt.linea != ln_sap.linea THEN 
              lv_error := lv_error || 'LINEA <>, ';
            END IF; 
        END IF;
    
    IF ln_runt.clase != ln_sap.clase THEN
      lv_error := lv_error || 'CLASE <>, ';
    END IF;  
    
    IF ln_runt.servicio != ln_sap.servicio THEN
      lv_error := lv_error || 'SERVICIO <>, ';
    END IF;  
    
    IF ln_runt.carroceria != ln_sap.carroceria THEN
      lv_error := lv_error || 'CARROCERIA <>, ';
    END IF; 
    
    IF  ln_sap.tipo_carga IS NULL THEN
        IF ln_runt.tipo_carga != ln_sap.tipo_carga THEN
          lv_error := lv_error || 'TIPO_CARGA <>, ';
        END IF; 
    ELSE
         UPDATE plantilla_oc_runt SET tipo_carga = ln_sap.tipo_carga
         WHERE objeto_contrato = ln_runt.objeto_contrato; 
    END IF;
    
    
    IF ln_runt.cilindraje IN (0,NULL,1) THEN
         UPDATE plantilla_oc_runt SET cilindraje = ln_sap.cilindraje
         WHERE objeto_contrato = ln_runt.objeto_contrato;  
    ELSE
        IF To_number(ln_runt.cilindraje) != To_Number(ln_sap.cilindraje) THEN
          lv_error := lv_error || 'CILINDRAJE <>, ';
        END IF;
    END IF;
    IF ln_sap.capacidad IS NOT NULL THEN
         UPDATE plantilla_oc_runt SET capacidad = ln_sap.capacidad
         WHERE objeto_contrato = ln_runt.objeto_contrato;     
    ELSE
          UPDATE plantilla_oc_runt SET capacidad = ln_runt.capacidad
          WHERE objeto_contrato = ln_runt.objeto_contrato;  
            IF ln_runt.capacidad != ln_sap.capacidad THEN
              lv_error := lv_error || 'CAPACIDAD <>, ';
            END IF;
    END IF;
    
    IF ln_runt.unidad_transito IS NULL AND ln_sap.unidad_transito IS NOT NULL THEN
          UPDATE plantilla_oc_runt SET unidad_transito = ln_sap.unidad_transito, depto_matricula = ln_sap.unidad_transito
          WHERE objeto_contrato = ln_runt.objeto_contrato;  
    ELSE
        IF ln_runt.unidad_transito != ln_sap.unidad_transito THEN
            lv_error := lv_error || 'TRANSITO <>, ';
        END IF;
        
        IF ln_runt.depto_matricula != ln_sap.depto_matricula THEN
            lv_error := lv_error || 'DEPARTAMENTO <>, ';
        END IF;
        
    END IF;
    
  
    IF ln_runt.tipo_caja IS NULL AND ln_sap.tipo_caja IS NOT NULL THEN
        UPDATE plantilla_oc_runt SET tipo_caja = ln_sap.tipo_caja
        WHERE objeto_contrato = ln_runt.objeto_contrato;
    ELSE
        IF ln_runt.tipo_caja != ln_sap.tipo_caja THEN
          lv_error := lv_error || 'CAJA <>, ';
        END IF;
    END IF;
    
    IF ln_runt.n_puertas IS NULL AND ln_sap.n_puertas IS NOT NULL THEN
        UPDATE plantilla_oc_runt SET n_puertas = ln_sap.n_puertas
        WHERE objeto_contrato = ln_runt.objeto_contrato;
    ELSE
        IF ln_runt.n_puertas != ln_sap.n_puertas THEN
          lv_error := lv_error || 'PUERTAS <>, ';
        END IF;
    END IF;
    
    IF ln_runt.combustion_traccion IS NULL AND ln_sap.combustion_traccion IS NOT NULL THEN
        UPDATE plantilla_oc_runt SET combustion_traccion = ln_sap.combustion_traccion
        WHERE objeto_contrato = ln_runt.objeto_contrato;
    ELSE
        IF ln_runt.combustion_traccion != ln_sap.combustion_traccion THEN
          lv_error := lv_error || 'COMBUSTION <>, ';
        END IF;
    END IF;
    
    lb_matricula :=ft_validar_novedades(ln_runt.objeto_contrato);
    IF lb_matricula = FALSE THEN
        IF TO_DATE(REPLACE(ln_runt.fecha_matricula,'.'),'DDMMYYYY') != TO_DATE(REPLACE(ln_sap.fecha_matricula,'.'),'DDMMYYYY') THEN
          lv_error := lv_error || 'MATRICULA <>, ';
        END IF;
    ELSE
        UPDATE plantilla_oc_runt SET fecha_matricula = ln_sap.fecha_matricula
        WHERE objeto_contrato = ln_runt.objeto_contrato;
    END IF;
    
    UPDATE plantilla_oc_runt SET liq_activa = ln_sap.liq_activa
    WHERE objeto_contrato = ln_runt.objeto_contrato;
    
    IF lv_error IS NULL THEN
      lv_error := 'RUNT = SAP';
    END IF;
    
    
    
    UPDATE plantilla_oc_runt
       SET inconsistencia = lv_error
    WHERE objeto_contrato = ln_runt.objeto_contrato;  
    
    IF ln_contador = 100 THEN
      COMMIT;
      ln_contador :=0;
    END IF;  
  
  END LOOP;

END LOOP;
COMMIT;


END sp_validar_sap;

PROCEDURE sp_generar_inconsistencia AS

lv_name  VARCHAR2(255 byte):='INCONSISTENCIAS '||To_char(sysdate,'dd-mm-yyyy hh-mi-ss')||'.txt';


lutl_write   UTL_FILE.FILE_TYPE;
CURSOR lcur_incosistencias IS SELECT nro_placa, inconsistencia FROM oc_runt;

BEGIN
    lutl_write:= UTL_FILE.FOPEN('GENERAR_ERROR',lv_name ,'W'); 
        DELETE FROM oc_runt
        WHERE nro_placa IN (SELECT objeto_contrato FROM plantilla_oc_runt);
        COMMIT;
       
        FOR ln_index IN lcur_incosistencias LOOP
               UTL_FILE.PUT_LINE(lutl_write, ln_index.nro_placa||' '||ln_index.inconsistencia); 
        END LOOP;
    UTL_FILE.FCLOSE( lutl_write);  
    
        
END;

FUNCTION ft_recuperar_caracte_oc_sap (av_id_marca VARCHAR DEFAULT NULL, av_id_carroceria VARCHAR DEFAULT NULL,
                                      av_id_clase VARCHAR DEFAULT NULL, an_id_servicio NUMBER DEFAULT NULL,
                                      an_id_secretaria NUMBER DEFAULT NULL,an_id_linea NUMBER DEFAULT NULL) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_recuperar_caracte_oc_sap
Autor      :Blados.Ospina
Fecha      :31/08/18
Parametros :av_id_marca, av_id_carroceria
Parametros :av_id_clase
Retorno    :lb_existe         
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Homologa deiferentes caracteristicas
           :runt a codigo sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
31/08/2018  Blados.Ospina   1.0                     */

lb_existe BOOLEAN:=FALSE;

BEGIN
    CASE
        WHEN av_id_marca IS NOT NULL THEN
            SELECT DISTINCT sm.id_marca_sap, sm.desc_marca_sap INTO iv_id_marca, iv_marca  FROM quipux.qx_tipo_marca qm
            INNER JOIN quipux.Marca_Vehiculos mv On mv.id_marca_qx = qm.id_marca_qx
            INNER JOIN depuracion.Sap_Marcas sm ON sm.id_marca_qx = mv.id_marca_qx
            WHERE qm.runt_marca = av_id_marca AND rownum = 1;
                IF iv_id_marca IS NOT NULL AND iv_marca IS NOT NULL THEN
                    lb_existe:=TRUE;
                END IF;
         WHEN av_id_carroceria IS NOT NULL AND av_id_clase IS NOT NULL THEN
            SELECT DISTINCT tipo_carga INTO iv_tipo_carga FROM depuracion.tmp_homologacion_caract_veh
            WHERE Trim(id_clase||id_carroceria) = Trim(av_id_clase||av_id_carroceria);
                 IF iv_tipo_carga IS NOT NULL THEN
                            lb_existe:=TRUE;
                 END IF;
        WHEN av_id_clase IS NOT NULL  THEN
            SELECT DISTINCT sc.id_clase_sap INTO iv_id_clase FROM quipux.qx_tipo_clase qc
            INNER JOIN quipux.clase_vehiculos cv ON cv.id_clase_qx = qc.id_clase_qx
            INNER JOIN depuracion.sap_clase sc ON sc.id_clase_qx = cv.id_clase_qx
            WHERE qc.runt_clase = av_id_clase AND rownum = 1;
                IF iv_id_clase IS NOT NULL THEN
                    lb_existe:=TRUE;   
                END IF; 
        WHEN av_id_carroceria IS NOT NULL THEN
            SELECT DISTINCT sc.id_carroceria_sap Into iv_id_carroceria From quipux.qx_tipo_carroceria qc
            INNER JOIN quipux.Tipo_Carroceria tc ON tc.id_carroceria_qx = qc.id_carroceria_qx
            INNER JOIN depuracion.Sap_Carroceria sc ON sc.id_carroceria_qx = tc.id_carroceria_qx
            WHERE qc.runt_carroceria = av_id_carroceria AND rownum = 1;
                IF iv_id_carroceria IS NOT NULL THEN
                    lb_existe:=TRUE;
                END IF; 
        WHEN an_id_servicio IS NOT NULL THEN
            SELECT DISTINCT sv.id_servicio_sap INTO iv_id_servicio FROM quipux.tipo_servicio tp
            INNER JOIN depuracion.sap_servicio sv ON sv.id_servicio_qx = tp.id_servicio 
            WHERE tp.runt_servicio = an_id_servicio;
                IF iv_id_servicio IS NOT NULL  THEN
                    lb_existe:=TRUE;
                END IF;
        WHEN an_id_secretaria IS NOT NULL THEN  
            SELECT DISTINCT  sc.id_ciudad_sap, sc.id_depto_sap INTO  in_id_secreataria, iv_id_depto FROM quipux.qx_ciudad qc 
            INNER JOIN quipux.ciudades qci ON qci.id_ciudad_qx = qc.id_ciudad_Qx
            INNER JOIN depuracion.sap_ciudades sc ON sc.id_ciudad_qx = qci.id_ciudad_qx
            WHERE qc.min_ciudad_qx = an_id_secretaria;
                IF in_id_secreataria IS NOT NULL  THEN
                    lb_existe:=TRUE;
                END IF;
         WHEN an_id_linea IS NOT NULL THEN 
            SELECT DISTINCT sl.id_linea_sap INTO iv_id_linea FROM quipux.qx_tipo_linea ql
            INNER JOIN quipux.tipo_linea tl ON tl.id_linea_qx = ql.id_linea_qx
            INNER JOIN depuracion.sap_lineas sl ON sl.id_linea_qx = tl.id_linea_qx 
            WHERE ql.runt_linea = an_id_linea AND ROWNUM = 1;
                IF iv_id_linea IS NOT NULL  THEN
                    lb_existe:=TRUE;
                END IF;
        ELSE
            lb_existe:=FALSE;
    END CASE;
        RETURN lb_existe;
    EXCEPTION 
     WHEN OTHERS THEN
       RETURN lb_existe;
       
END ft_recuperar_caracte_oc_sap;

PROCEDURE sp_reset_variables AS

/*ISVA
Nombre     :sp_reset_variables
Autor      :Blados.Ospina
Fecha      :13/09/2018
Parametros :
Retorno    :
Variables  :
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Resetea las variables
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   */

BEGIN

    ib_error_marca:=FALSE;
    ib_error_modelo:=FALSE;
    ib_error_carroceria:=FALSE;
    ib_error_clase:=FALSE;
    ib_error_servicio:=FALSE;
    ib_error_linea:=FALSE;
    ib_error_cilindraje:=FALSE;
    ib_error_secreataria:=FALSE;
    ib_error_tipo:=FALSE;
    iv_id_marca:='';
    iv_marca:='';
    iv_id_clase:='';
    iv_tipo_carga:='';
    iv_id_carroceria:='';
    iv_id_servicio:='';
    iv_id_linea:='';
    id_capacidad:='';
    in_id_secreataria:=0;
    iv_id_depto:='';
    iv_inconsistencia:='';
    
END sp_reset_variables;

PROCEDURE sp_inconsistencia (an_tipo_inconsistencia NUMBER) AS

/*ISVA
Nombre     :sp_inconsistencia
Autor      :Blados.Ospina
Fecha      :13/09/2018
Parametros :
Retorno    :
Variables  :
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Captura el error
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   */

BEGIN
    CASE an_tipo_inconsistencia
        WHEN 1 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion en la marca. ';
        WHEN 2 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia modelo. ';
        WHEN 3 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion en la carroceria. ';
        WHEN 4 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion en la clase. ';
        WHEN 5 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion servicio. ';
        WHEN 6 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion linea. ';
        WHEN 7 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de homologacion en la secreataria. ';
        WHEN 8 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia de Tipo_carga/pasajeros. ';
        WHEN 9 THEN
            iv_inconsistencia:= iv_inconsistencia||'Inconsistencia Lineas SAP no contenida en RUNT. ';
        ELSE
            NULL;
    END CASE;
        
        
        
END sp_inconsistencia; 

FUNCTION ft_validacion_linea (av_id_linea VARCHAR, av_linea_runt VARCHAR) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_validacion_linea
Autor      :Blados.Ospina
Fecha      :03/09/18
Parametros :av_id_linea, av_descripcion
Retorno    :lb_existe         
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :homologa la linea codgio sap
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
03/08/2018  Blados.Ospina   1.0                     */

lb_existe BOOLEAN:=FALSE;
ls_count SIMPLE_INTEGER:=0;
ls_caracteres SIMPLE_INTEGER:=0;
lv_carac_linea VARCHAR(10 BYTE):='';
lv_linea_sap_temp VARCHAR2(255 BYTE);
lv_linea_runt_temp VARCHAR2(255 BYTE);
ln_bandera NUMBER:=0;

CURSOR lcur_linea IS SELECT DISTINCT sl.id_linea_sap AS id_linea_sap, sl.desc_linea_Sap AS desc_linea_Sap, 
                                     sl.desc_linea_qx AS desc_linea_qx, sl.cilindraje_sap AS cilindraje_sap
                     FROM quipux.qx_tipo_linea ql
                     INNER JOIN quipux.tipo_linea tl ON tl.id_linea_qx = ql.id_linea_qx
                     INNER JOIN depuracion.sap_lineas sl ON sl.id_linea_qx = tl.id_linea_qx 
                     WHERE ql.runt_linea = av_id_linea;

BEGIN
    
    FOR ln_index IN lcur_linea LOOP
        ls_count:=INSTR(UPPER(av_linea_runt),UPPER(ln_index.desc_linea_Sap),1);
        ls_caracteres := LENGTH(iv_id_marca);
        lv_carac_linea := SUBSTR(ln_index.id_linea_sap,1,ls_caracteres);
            IF ls_count > 0 AND ln_index.cilindraje_sap = 0 THEN
                    IF lv_carac_linea = iv_id_marca THEN
                        iv_id_linea := ln_index.id_linea_sap;   
                        lb_existe:=True;
                        ln_bandera:=1;
                        EXIT;
                    END IF;
            ELSIF ls_count > 0 AND ln_index.cilindraje_sap > 0 THEN
                    IF lv_carac_linea = iv_id_marca THEN
                        iv_id_linea := ln_index.id_linea_sap;   
                        lb_existe:=True;
                        ln_bandera:=1;
                        EXIT;
                    END IF;
            END IF;
    END LOOP;
    
    IF ln_bandera = 0 THEN
        FOR ln_index_1 IN lcur_linea LOOP
            lv_linea_runt_temp := UPPER(REPLACE(estadarizar_linea(av_linea_runt),' ',''));
            lv_linea_sap_temp := UPPER(REPLACE(estadarizar_linea(ln_index_1.desc_linea_Sap),' ',''));
            ls_count:=INSTR(lv_linea_runt_temp, lv_linea_sap_temp,1);
                         IF ls_count > 0 AND ln_index_1.cilindraje_sap = 0  THEN
                                IF lv_carac_linea = iv_id_marca THEN
                                    iv_id_linea := ln_index_1.id_linea_sap;   
                                    lb_existe:=True;
                                    ln_bandera:=1;
                                    EXIT;  
                                END IF;
                         END IF;
        END LOOP;
    END IF;
    
    IF ln_bandera = 0 THEN
        FOR ln_index_2 IN lcur_linea LOOP
                lv_linea_sap_temp:= estadarizar_linea(ln_index_2.desc_linea_Sap); --desc_linea_qx
                ls_count:=INSTR(lv_linea_runt_temp, lv_linea_sap_temp,1);
                    IF ls_count > 0 THEN
                            IF lv_carac_linea = iv_id_marca THEN
                                iv_id_linea := ln_index_2.id_linea_sap;   
                                lb_existe:=True;
                                EXIT;  
                            END IF;
                    END IF;
        END LOOP;
    END IF;
        Return lb_existe;
END ft_validacion_linea; 

PROCEDURE sp_generar_plantilla_sap AS

/*ISVA
Nombre     :sp_generar_plantilla_sap
Autor      :Blados.Ospina
Fecha      :31/08/18
Parametros :av_id_marca, av_id_carroceria
Parametros :av_id_clase
Retorno    :lb_existe         
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Construye la plantilla para realizar
           :las cargas masivas en sap de los vehiculos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
31/08/2018  Blados.Ospina   1.0                     */

CURSOR lcur_oc_runt IS SELECT nro_placa,id_marca,modelo,id_clase,id_servicio, id_linea, nombre_linea, id_carroceria, cilindraje,
                              cap_pasajeros, cap_toneladas, id_secretaria,id_combustible, fecha_matriculo FROM OC_RUNT;

ln_commit NUMBER:=0;

BEGIN
    FOR ln_index IN lcur_oc_runt LOOP
        BEGIN
            ln_commit := ln_commit + 1;
         sp_reset_variables;
        
            ib_error_marca:=  ft_recuperar_caracte_oc_sap(av_id_marca=> ln_index.id_marca);
               IF ib_error_marca = FALSE THEN
                    sp_inconsistencia(1);
               END IF;
            ib_error_modelo:= ft_validacion_datos(TRIM(ln_index.modelo));
               IF ib_error_modelo = FALSE THEN
                    sp_inconsistencia(2);
               END IF;
            ib_error_carroceria:=  ft_recuperar_caracte_oc_sap(av_id_carroceria=> ln_index.id_carroceria);
               IF ib_error_carroceria = FALSE THEN
                    sp_inconsistencia(3);
               END IF;
            ib_error_clase:=  ft_recuperar_caracte_oc_sap(av_id_clase=> ln_index.id_clase);
               IF ib_error_clase = FALSE THEN
                    sp_inconsistencia(4);
               END IF;
                   IF ib_error_carroceria IS NOT NULL AND ib_error_clase IS NOT NULL THEN
                       ib_error_tipo :=ft_recuperar_caracte_oc_sap(av_id_clase=> iv_id_clase,av_id_carroceria=>iv_id_carroceria);
                           IF ib_error_tipo = FALSE THEN
                                sp_inconsistencia(8);
                           END IF;
                   ELSE
                        sp_inconsistencia(8);
                   END IF;
            IF ln_index.id_combustible = 5 THEN
                ib_error_servicio:= ft_recuperar_caracte_oc_sap(an_id_servicio=>ln_index.id_combustible);  
               IF ib_error_servicio = FALSE THEN
                    sp_inconsistencia(5);
               END IF;
            ELSE
                ib_error_servicio:= ft_recuperar_caracte_oc_sap(an_id_servicio=>ln_index.id_servicio);
               IF ib_error_servicio = FALSE THEN
                    sp_inconsistencia(5);
               END IF;
            END IF;  
               ib_error_linea:= ft_recuperar_caracte_oc_sap(an_id_linea=>ln_index.id_linea);
                    IF ib_error_linea = TRUE THEN
                        ib_error_linea:= ft_validacion_linea(ln_index.id_linea, ln_index.nombre_linea);
                           IF ib_error_linea = FALSE THEN
                                sp_inconsistencia(9);
                           END IF;
                    ELSE
                        sp_inconsistencia(6);
                    END IF;
            ib_error_secreataria := ft_recuperar_caracte_oc_sap(an_id_secretaria => ln_index.id_secretaria);  
               IF ib_error_secreataria = FALSE THEN
                    sp_inconsistencia(7);
               END IF;
            
              
                IF iv_tipo_carga = 'P' THEN
                    id_capacidad := ln_index.cap_pasajeros||',00';
                ELSIF iv_tipo_carga = 'C' THEN
                    id_capacidad := (TO_NUMBER(ln_index.cap_toneladas) / 1000)||',00';
                END IF;
               
            IF iv_inconsistencia IS NULL THEN
                INSERT INTO plantilla_oc_runt (objeto_contrato, denominacion_objeto,modelo,marca,clase,tipo_carga,
                                               servicio,linea,carroceria, cilindraje, capacidad, unidad_transito,
                                               depto_matricula, fecha_matricula)
                VALUES (ln_index.nro_placa, iv_marca,ln_index.modelo,iv_id_marca,iv_id_clase, iv_tipo_carga, iv_id_servicio,
                        iv_id_linea, iv_id_carroceria, ln_index.cilindraje,id_capacidad,in_id_secreataria, iv_id_depto, 
                        REPLACE(ln_index.fecha_matriculo,'/','.'));
                            
                       
            ELSE
                    UPDATE oc_runt SET inconsistencia = iv_inconsistencia
                    WHERE nro_placa = ln_index.nro_placa;
            END IF;
            
            IF ln_commit = 500 THEN
             ln_commit :=0; 
              COMMIT;
            END IF;
            EXCEPTION 
            WHEN OTHERS THEN
                iv_inconsistencia := (ln_index.nro_placa||', '||sqlerrm||Dbms_Utility.Format_Error_Backtrace);
        END;  
    END LOOP;
   
END sp_generar_plantilla_sap;

PROCEDURE sp_insertar_vehiculos_runt AS

lv_placas VARCHAR2(10); 
ltul_read UTL_FILE.FILE_TYPE; 

BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
        LOOP
            BEGIN
                UTL_FILE.GET_LINE(ltul_read,lv_placas); 
                
                INSERT INTO oc_runt (nro_placa, id_marca, nombre_marca, id_linea, nombre_linea, modelo, id_clase, nombre_clase, id_servicio, 
                                     nombre_servicio, id_carroceria, nombre_carroceria, nro_puertas, id_combustible, nombre_combustible, 
                                     id_bateria, nombre_bateria, potencia, id_secretaria, nombre_secretaria, cilindraje, cap_pasajeros, 
                                     cap_toneladas, valor_factura, blindado, importado_nacional, id_estado, nombre_estado, clasico_antiguo, 
                                     fecha_matriculo)
                SELECT distinct nro_placa, id_marca, nombre_marca, id_linea, nombre_linea, modelo, id_clase, nombre_clase, id_servicio, 
                       nombre_servicio, id_carroceria, nombre_carroceria, nro_puertas, id_combustible, nombre_combustible, id_bateria, 
                       nombre_bateria, potencia, id_secretaria, nombre_secretaria, cilindraje, cap_pasajeros, cap_toneladas, 
                       valor_factura, blindado, importado_nacional, id_estado, nombre_estado, clasico_antiguo, Replace(fecha_matriculo,'/','.')
                FROM bd_transitos.arunt_vehiculos
                WHERE nro_placa = lv_placas AND id_radicado = (SELECT MAX(id_radicado) FROM bd_transitos.arunt_vehiculos
                                                               WHERE nro_placa = lv_placas);
                    
        
                EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN
                it_error.nombre_error := lv_placas;
                it_error.id_error := sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
                
                it_list_error.Extend;
                it_list_error(it_list_error.Count) := it_error;
                
            END;   
        End LOOP;
    sp_error;
    
END sp_insertar_vehiculos_runt;

PROCEDURE sp_iniciar AS

/*ISVA
Nombre     :sp_generar_plantilla_sap
Autor      :Blados.Ospina
Fecha      :31/08/18
Parametros :av_id_marca, av_id_carroceria
Parametros :av_id_clase
Retorno    :lb_existe         
Proyecto   :PKG_GENERAR_PLANTILLA_OC
Versi�n    :1.0
Objetivo   :Inicia todos los procesos para generar
           :la plantilla
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
31/08/2018  Blados.Ospina   1.0                     */

  BEGIN
                --sp_insertar_vehiculos_runt;
                --sp_inconsistencias_Vehiculos;  
    
    sp_generar_plantilla_sap;
    sp_generar_inconsistencia;
    Sp_validar_sap;
  
END sp_iniciar;

END PKG_HOMOLOGACION_OC;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PLANTILLA_MOD_IC
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_PLANTILLA_MOD_IC" AS

iv_id_municipio VARCHAR2(10 BYTE);
iv_id_departamento VARCHAR2(2 BYTE);
iv_tipo_interlocutor VARCHAR2(1 BYTE);
iv_clase_interlocutor VARCHAR2(5 BYTE);
iv_nombre_organizacion VARCHAR2(255 BYTE);
in_nombre_persona VARCHAR2(255 BYTE);
in_nombre_apellidos VARCHAR2(255 BYTE);
in_per_fisica VARCHAR2(255 BYTE);
iv_interlocutor VARCHAR2(255 BYTE);
iv_tipo_doc VARCHAR2(10 BYTE);
iv_documento VARCHAR2(255 BYTE);
iv_concepto_busqueda VARCHAR2(255 BYTE);

ib_validar BOOLEAN;
ib_interlocutor BOOLEAN;

PROCEDURE sp_resetar(av_rowid VARCHAR) AS
BEGIN

    iv_tipo_interlocutor:='';
    iv_clase_interlocutor:='';
    iv_nombre_organizacion:='';
    in_nombre_persona:='';
    in_nombre_apellidos:='';
    in_per_fisica:='';
    ib_validar:=FALSE;
    ib_interlocutor:=FALSE;
    iv_id_municipio:='';
    iv_id_departamento:='';
    iv_interlocutor:='';
    iv_tipo_doc:='';
    iv_documento:='';
    iv_concepto_busqueda:='';
        DELETE vr_direcion_masivas_sap 
        WHERE ROWID = av_rowid;
END sp_resetar;

FUNCTION ft_buscar_interlocutor ( av_documento VARCHAR, av_tipo_documento VARCHAR) RETURN BOOLEAN AS
BEGIN
       SELECT DISTINCT id_interlocutor INTO iv_interlocutor
       FROM sap_interlocutores
       WHERE id_usuario = av_documento AND id_documento = av_tipo_documento ;
       
       IF iv_interlocutor IS NOT NULL THEN
            RETURN TRUE; 
       END IF;
EXCEPTION
WHEN OTHERS THEN 
RETURN FALSE;
END ft_buscar_interlocutor;

FUNCTION ft_tipo_doc (av_tipo_doc VARCHAR) RETURN VARCHAR AS

lv_tipo_doc VARCHAR2(10 BYTE);

BEGIN

            CASE av_tipo_doc
                WHEN 'C' THEN
                   lv_tipo_doc  := 'CC'; 
                WHEN 'N' THEN
                   lv_tipo_doc  := 'NIT'; 
                WHEN 'E' THEN
                   lv_tipo_doc  := 'CE'; 
                WHEN 'T' THEN
                   lv_tipo_doc  := 'TI';
                WHEN 'U' THEN
                   lv_tipo_doc  := 'RC'; 
                WHEN 'D' THEN
                   lv_tipo_doc  := 'CD'; 
                WHEN 'P' THEN
                   lv_tipo_doc  := 'PASAP'; 
                ELSE
                   lv_tipo_doc:= av_tipo_doc;
            END CASE;  
            
        RETURN lv_tipo_doc;
        
END ft_tipo_doc;

FUNCTION ft_codigo_dir (av_departamento VARCHAR, av_municipio VARCHAR) RETURN BOOLEAN AS

lv_clave VARCHAR(255 BYTE):='';

BEGIN

    lv_clave:= TRANSLATE(av_departamento||av_municipio,'������','AEIOUU');
        
        SELECT DISTINCT codigo_departamento_sap,codigo_municipio_sap INTO iv_id_departamento, iv_id_municipio  
        FROM bd_fiscalizacion.fc_municipio_departamento
        WHERE TRANSLATE(departamento||municipio,'������','AEIOUU') = lv_clave;
        
        RETURN TRUE;
        
EXCEPTION 
WHEN OTHERS THEN
RETURN FALSE;
        
END ft_codigo_dir;

PROCEDURE sp_generar_plantilla AS

lv_Name_File Varchar2(255 byte):='Modificar Ic '||To_Char(SYSDATE,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lutl_write UTL_FILE.FILE_TYPE;  

CURSOR lcur_dir IS SELECT identificacion,documento,digito_verificacion,nombres,apellidos,direccion,municipio,
                          departamento,telefono, celular, email,rowid 
                   FROM vr_direcion_masivas_sap;


BEGIN
    lutl_write := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
    FOR ln_index IN lcur_dir LOOP
    BEGIN    
      ib_validar:=ft_codigo_dir(ln_index.departamento,ln_index.municipio);
      IF TRIM(ln_index.documento) IN ('NIT','N') THEN
            ib_interlocutor:= ft_buscar_interlocutor((ln_index.identificacion||ln_index.digito_verificacion),ln_index.documento);
      ELSE
            ib_interlocutor:= ft_buscar_interlocutor((ln_index.identificacion),ln_index.documento); 
      END IF;
      
      IF ib_validar = TRUE AND ib_interlocutor = TRUE THEN
            
            IF TRIM(ln_index.documento) IN ('NIT','N') THEN
                iv_concepto_busqueda:=ln_index.nombres;
                iv_tipo_interlocutor:=2; 
                iv_clase_interlocutor:='PJPR';
                iv_nombre_organizacion:=ln_index.nombres;
                iv_tipo_doc:= ft_tipo_doc(ln_index.documento);
                iv_documento:=ln_index.identificacion||ln_index.digito_verificacion;
            ELSE
                iv_tipo_interlocutor:=1;
                iv_clase_interlocutor:='PNAT';
                iv_concepto_busqueda:=ln_index.apellidos;
                in_nombre_persona:=ln_index.nombres;
                in_nombre_apellidos:=ln_index.apellidos;
                in_per_fisica:='X';
                iv_tipo_doc:= ft_tipo_doc(ln_index.documento);
                iv_documento:=ln_index.identificacion;
            END IF;
                UTL_FILE.PUT_LINE(lutl_write,iv_interlocutor||';'||iv_tipo_interlocutor||';'||iv_clase_interlocutor
                                  ||';'||'1'||';'||''||';'||iv_concepto_busqueda||';'||'VEHICULOS'||';'||'7'||';'||''||';'
                                  ||''||';'||iv_nombre_organizacion||';'||''||';'||''||';'||''||';'||''||';'||''||';'||''
                                  ||';'||''||';'||''||';'||in_nombre_persona||';'||in_nombre_apellidos||';'||''||';'||''
                                  ||';'||'S'||';'||''||';'||''||';'||''||';'||'CO'||';'||''||';'||'S'||';'||''||';'||''
                                  ||';'||''||';'||in_per_fisica||';'||iv_tipo_doc||';'||iv_documento
                                  ||';'||'XXDEFAULT'||';'||ln_index.direccion||';'||''||';'||''||';'||''||';'||''
                                  ||';'||'ZNOTIFIVEH'||';'||ln_index.direccion||';'||'ZRESIDVEHI'||';'||ln_index.direccion
                                  ||';'||''||';'||'CO'||';'||iv_id_departamento||';'||iv_id_municipio||';'||ln_index.telefono
                                  ||';'||ln_index.celular||';'||''||';'||ln_index.email);
    END IF;
            IF ib_validar = TRUE AND ib_interlocutor = TRUE THEN
                sp_resetar(ln_index.rowid);
            END IF;
        EXCEPTION
        WHEN OTHERS THEN
        UPDATE vr_direcion_masivas_sap SET estado = 'Error'
        WHERE ROWID = ln_index.rowid;
    END;
    END LOOP;
    
    UTL_FILE.FCLOSE(lutl_write);
END sp_generar_plantilla;

PROCEDURE sp_ejecutar_insercion AS

BEGIN
    DELETE SAP_INTERLOCUTORES
    WHERE ID_INTERLOCUTOR IN (SELECT INTERLOCUTOR FROM TMP_SUBIR_REGISTROS);
    COMMIT;
    
    INSERT INTO SAP_INTERLOCUTORES
    SELECT INTERLOCUTOR,DOCUMENTO,TIPO_DOCUMENTO FROM TMP_SUBIR_REGISTROS;
    COMMIT;

END sp_ejecutar_insercion;


PROCEDURE sp_crear_plantilla_ic AS
BEGIN
    -- TAREA: Se necesita implantaci�n para PROCEDURE PKG_PLANTILLA_MOD_OC.sp_iniciar
    sp_generar_plantilla;
END sp_crear_plantilla_ic;

PROCEDURE sp_insertar_interlocutores AS
BEGIN
     -- TAREA: Se necesita implantaci�n para PROCEDURE PKG_PLANTILLA_MOD_OC.sp_iniciar
    sp_ejecutar_insercion;
END;


END PKG_PLANTILLA_MOD_IC;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PLANTILLAS_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_PLANTILLAS_SAP" AS

PROCEDURE sp_novedades (av_id_novedad Varchar Default null, av_nombre_novedad Varchar Default null) As

/*ISVA
Nombre     :sp_novedades
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :lv_Name_File, v_MyFileHandle
           :lcur_novedades
Retorno    :      
Proyecto   :PKG_PLANTILLAS_SAP
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

lv_Name_File Varchar2(255 byte):=av_id_novedad||'_'||av_nombre_novedad||' '||To_char(sysdate,'dd-mm-yyyy hh-mi-ss')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Cursor lcur_novedades Is Select Distinct Vs.* From Vr_Tmp_Vehiculos_Runt Vr
                         Inner Join Vr_Novedades_Sap Vs On Vs.Nro_Placa = Vr.Nro_Placa
                         Where Vs.Id_Novedad =av_id_novedad;
Begin   
     v_MyFileHandle := UTL_FILE.FOPEN('DIR_ESTRUCTURA_SAP',lv_Name_File,'W');  
       For Ln_Index In lcur_novedades Loop
         UTL_FILE.PUT_LINE(v_MyFileHandle,ln_index.NRO_PLACA||';'||ln_index.NRO_ACTO_ADMIN||';'||ln_index.INTERLOCUTOR||';'||ln_index.ID_USUARIO||';'
         ||ln_index.NOMBRES||';'||ln_index.APELLIDOS||';'||ln_index.ID_NOVEDAD||';'||ln_index.DESCRIPCION_NOV||';'||ln_index.FECHA_ACTO||';'
         ||ln_index.MOTIVO_NOVEDAD||';'||ln_index.MONEDA||';'||Trim(ln_index.VAL_A_O_L)||';'||ln_index.VALIDO_DESDE||';'||ln_index.VALIDO_HASTA||';'
         ||ln_index.ID_DEPARTAMENTO||';'||ln_index.ID_MUNICIPIO||';'||ln_index.ID_CARROCERIA||';'||ln_index.ID_CAPACIDAD||';'||ln_index.ID_CILINDRAJE||';'
         ||ln_index.FECHA_MODIFICACION||';'||ln_index.USARIO_POR||';'||ln_index.MODIFICADO||';'||ln_index.MODIFICADO_POR||';'||ln_index.BORRADO||';'
         ||ln_index.USUARIO_BORRO||';'||ln_index.FECHA_BORRO||';'||ln_index.HORA);
       End Loop;
    UTL_FILE.FCLOSE(v_MyFileHandle);  
End sp_novedades;

PROCEDURE SP_GENERAR_PLANTILLAS AS

/*ISVA
Nombre     :SP_GENERAR_PLANTILLAS
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :Array_Novedades,tp_Novedades
Retorno    :
Proyecto   :PKG_PLANTILLAS_SAP
Versi�n    :1.0
Objetivo   :envia el codigo de cada una de las novedades
           :para generar las plantillas en sap
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/


Type Array_Novedades is varray(9) of Varchar2(2 byte);

tp_Novedades Array_Novedades:=Array_Novedades('02','03','04','06','07','08','14','16','18');

BEGIN

    For Ln_Index In 1..tp_Novedades.Count() Loop
            Case tp_Novedades(Ln_Index)
                When '02' Then
                    sp_novedades(tp_Novedades(Ln_Index),'BLINDAJE');
                When '03' Then
                    sp_novedades(tp_Novedades(Ln_Index),'CANCELACION');
                When '04' Then
                    sp_novedades(tp_Novedades(Ln_Index),'REMATRICULA');
                When '06' Then
                    sp_novedades(tp_Novedades(Ln_Index),'RADICACI�N');
                When '07' Then
                    sp_novedades(tp_Novedades(Ln_Index),'TRASLADO');
                When '08' Then
                    sp_novedades(tp_Novedades(Ln_Index),'CAMBIO_SERVICIO PU_PA');
                When '14' Then
                    sp_novedades(tp_Novedades(Ln_Index),'CAMBIO_SERVICIO PA_PU');
                When '16' Then
                    sp_novedades(tp_Novedades(Ln_Index),'CLASICO_ANTIGUO');
                When '18' Then
                    sp_novedades(tp_Novedades(Ln_Index),'DESBLINDAJE');
            End Case;
    End Loop;
END SP_GENERAR_PLANTILLAS;

END PKG_PLANTILLAS_SAP;

/
--------------------------------------------------------
--  DDL for Package Body PKG_REPORTE_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_REPORTE_VEHICULOS" AS

in_commit NUMBER:=0;

FUNCTION ft_validar_numero (av_numero VARCHAR) RETURN NUMBER AS

/*ISVA
Nombre     :ft_validar_numero
Autor      :Blados.Ospina
Fecha      :17/01/2018
Argumento  :av_numero
Variables  :ln_numero
Retorno    :ln_numero              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :valida si el numero o celular es valido
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */


ln_numero NUMBER:=0;
lv_numero VARCHAR(10):='';

BEGIN
        ln_numero :=TO_NUMBER(depuracion.pkg_ds_estandariza_registros.ft_estandarizar_telefono(av_numero));
        
            IF LENGTH(ln_numero) IN (10,7) THEN
                RETURN ln_numero;
            END IF;
        
        RETURN lv_numero;
           
EXCEPTION 
WHEN OTHERS THEN
RETURN lv_numero;
END ft_validar_numero;

PROCEDURE sp_actualizar_interlo_runt AS

CURSOR lcur IS SELECT DISTINCT id_interlocutor FROM zvh_validacion_ots WHERE estado = 'Pagos' AND documento IS NULL;

lv_id_usuario VARCHAR2(255);
lv_id_documento VARCHAR2(255);
lv_nombres VARCHAR2(255);
lv_apellidos VARCHAR2(255);

BEGIN
    FOR ln_index IN lcur LOOP
    lv_id_usuario:='';                         
    lv_id_documento:='';                         
    lv_nombres:='';                         
    lv_apellidos:='';                         
    BEGIN
        
        SELECT DISTINCT ac.id_usuario, ac.id_documento, ac.nombres, ac.apellidos
        INTO lv_id_usuario,lv_id_documento, lv_nombres, lv_apellidos 
        FROM sap_interlocutores si
        INNER JOIN bd_transitos.arunt_contribuyentes ac ON ac.id_usuario = si.id_usuario 
                                                        AND ac.id_documento = si.id_documento
        WHERE si.id_interlocutor = ln_index.id_interlocutor AND ROWNUM = 1;
    
            UPDATE zvh_validacion_ots SET
                documento = lv_id_usuario,
                tipo_documento = lv_id_documento,   
                nombre = lv_nombres,   
                apellidos = lv_apellidos
            WHERE id_interlocutor = ln_index.id_interlocutor;
    
            IF in_commit = 500 THEN
               in_commit:=0;
               COMMIT;
            END IF;  
    EXCEPTION 
    WHEN OTHERS THEN
    CONTINUE;
    END;
    
    END LOOP;
END;


PROCEDURE sp_actualizar_interlocutor_sap AS

CURSOR lcur IS SELECT DISTINCT id_interlocutor FROM zvh_validacion_ots WHERE estado = 'Pagos' AND documento IS NULL;

lv_id_usuario VARCHAR2(255);
lv_id_documento VARCHAR2(255);
lv_nombres VARCHAR2(255);
lv_apellidos VARCHAR2(255);
lv_razon_social VARCHAR2(255); 
lv_telefono VARCHAR2(255);
lv_tel_validado VARCHAR2(10);



BEGIN
    FOR ln_index IN lcur LOOP
        BEGIN
            in_commit:= in_commit + 1;
            lv_id_usuario:='';
            lv_id_documento:=''; 
            lv_nombres:=''; 
            lv_apellidos:=''; 
            lv_razon_social:='';
            lv_telefono:='';
        
            SELECT DISTINCT id_usuario, id_documento,nombres,apellidos, razon_social,telefono INTO 
            lv_id_usuario, lv_id_documento, lv_nombres, lv_apellidos, lv_razon_social,lv_telefono
            FROM zvh_con_ic_oc
            WHERE interlocutor = ln_index.id_interlocutor AND ROWNUM = 1;
            
            lv_tel_validado:= ft_validar_numero(lv_telefono);
            
            UPDATE zvh_validacion_ots SET
                documento = lv_id_usuario,
                tipo_documento = lv_id_documento,   
                nombre = lv_nombres,   
                apellidos = lv_apellidos,   
                razon_social = lv_razon_social,
                telefono = lv_tel_validado
            WHERE id_interlocutor = ln_index.id_interlocutor;
            
            IF in_commit = 500 THEN
               in_commit:=0;
               COMMIT;
            END IF;
            
            
        EXCEPTION 
        WHEN OTHERS THEN
        CONTINUE;
        END;
    END LOOP;
END sp_actualizar_interlocutor_sap;

PROCEDURE sp_actualizar_caracteristicas AS

CURSOR lcur IS SELECT DISTINCT nro_placa FROM zvh_validacion_ots WHERE marca IS NULL;

lv_nombre_servicio VARCHAR2(255);
lv_nombre_marca VARCHAR2(255);
lv_nombre_linea VARCHAR2(255);
lv_nombre_clase VARCHAR2(255);
lv_fecha_matricula VARCHAR2(255);
ln_modelo NUMBER;
ln_id_municipio NUMBER; 

BEGIN
    FOR ln_index IN lcur LOOP
    in_commit:= in_commit +1;
    lv_nombre_servicio:='';lv_nombre_marca:='';lv_nombre_linea:='';lv_nombre_clase:='';
    lv_fecha_matricula:='';ln_id_municipio:=0;ln_modelo:=0;
        BEGIN
        SELECT nombre_servicio, nombre_marca,nombre_linea,nombre_clase, modelo, fecha_matricula, id_municipio 
        INTO lv_nombre_servicio, lv_nombre_marca,lv_nombre_linea, lv_nombre_clase, ln_modelo, lv_fecha_matricula,ln_id_municipio 
        FROM bd_fiscalizacion.fc_vehiculos
        WHERE nro_placa IN ln_index.nro_placa;
        
        UPDATE zvh_validacion_ots SET
        uso = lv_nombre_servicio,
        marca = lv_nombre_marca,   
        linea = lv_nombre_linea,   
        clase = lv_nombre_clase, 
        modelo = ln_modelo,
        fecha_matricula = lv_fecha_matricula,   
        transito = ln_id_municipio
        WHERE nro_placa = ln_index.nro_placa;
            IF in_commit = 500 THEN
               in_commit:=0;
               COMMIT;
            END IF;
        
        EXCEPTION
        WHEN OTHERS THEN
        CONTINUE;      
        END;    
    END LOOP;
END sp_actualizar_caracteristicas;

FUNCTION ft_existe_avaluo (av_clase VARCHAR , av_marca VARCHAR, av_linea VARCHAR,an_modelo NUMBER) RETURN BOOLEAN AS

ln_existe NUMBER:=0;
lb_existe BOOLEAN:= FALSE;

BEGIN
    SELECT  COUNT(1) INTO ln_existe FROM zvh_validacion_ots where estado IN ('Activas','Pagos') AND
    (clase = av_clase AND marca = av_marca AND linea = av_linea AND modelo = an_modelo);
    
        IF ln_existe > 0 THEN
            lb_existe := TRUE;  
        END IF;
    RETURN lb_existe;

EXCEPTION 
WHEN OTHERS THEN 
RETURN lb_existe;
END ft_existe_avaluo;

FUNCTION ft_recuperar_avaluo (av_clase VARCHAR , av_marca VARCHAR, av_linea VARCHAR,an_modelo NUMBER) RETURN NUMBER AS

ln_avaluo NUMBER:=0;

BEGIN
    SELECT  MIN(avaluo) INTO ln_avaluo FROM zvh_validacion_ots WHERE estado IN ('Activas','Pagos') AND
    (clase = av_clase AND marca = av_marca AND linea = av_linea AND modelo = an_modelo);
    
        IF ln_avaluo > 0 THEN
            ln_avaluo := ln_avaluo;  
        END IF;
    RETURN ln_avaluo;

EXCEPTION 
WHEN OTHERS THEN 
RETURN ln_avaluo;
END ft_recuperar_avaluo;

PROCEDURE sp_no_liquida AS

CURSOR lcur_avaluo IS SELECT nro_placa,clase, marca,linea,modelo,estado FROM zvh_validacion_ots where estado = 'No liquida';

lb_existe BOOLEAN;
ln_avaluo NUMBER;

BEGIN
    FOR ln_index IN lcur_avaluo LOOP
    in_commit:= in_commit + 1;
    ln_avaluo:=0;
    lb_existe:=FALSE;
        lb_existe:=ft_existe_avaluo(ln_index.clase,ln_index.marca, ln_index.linea, ln_index.modelo);
            IF lb_existe = TRUE THEN
                ln_avaluo:=ft_recuperar_avaluo(ln_index.clase,ln_index.marca, ln_index.linea, ln_index.modelo); 
                    IF ln_avaluo > 0 THEN
                        UPDATE zvh_validacion_ots SET estado_2 = 'Avaluo Simulado', avaluo = ln_avaluo
                        WHERE nro_placa = ln_index.nro_placa;
                    ELSE
                        UPDATE zvh_validacion_ots SET estado_2 = 'avaluo igual a 0'
                        WHERE nro_placa = ln_index.nro_placa;
                    END IF;
            ELSE
                UPDATE zvh_validacion_ots SET estado_2 = 'No registra avaluo'
                WHERE nro_placa = ln_index.nro_placa;
            END IF;
        IF in_commit = 500 THEN 
            in_commit:=0;
            COMMIT;
        END IF;
    END LOOP;
    
END sp_no_liquida;

PROCEDURE sp_iniciar AS
BEGIN
    --sp_actualizar_caracteristicas;
    sp_actualizar_interlocutor_sap;
    --sp_actualizar_interlo_runt;
    --sp_no_liquida;
    
END sp_iniciar; 

END PKG_REPORTE_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDACION_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_VALIDACION_PROPIETARIOS" AS


iv_estado_1 VARCHAR2(255 BYTE):= 'Ya se encuentra asociado';
iv_estado_2 VARCHAR2(255 BYTE):= 'Interlocutor ya creado, asociar';
iv_estado_3 VARCHAR2(255 BYTE):= 'Crear interlocutor, asociar';

FUNCTION ft_exite_interlocutor (av_propietario VARCHAR, av_documento VARCHAR) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_validar_novedades
Autor      :Blados.Ospina
Fecha      :23/11/2018
Parametros :av_propietario, av_documento
Retorno    :lv_interlocutor          
Proyecto   :PKG_VALIDACION_PROPIETARIOS
Versi�n    :1.0
Objetivo   :Valida si exite el interlocutor en sap 
           :
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
                                                      */

lv_interlocutor VARCHAR2(255 BYTE):='';

BEGIN
        SELECT DISTINCT id_interlocutor INTO lv_interlocutor  FROM sap_interlocutores
        WHERE id_usuario = av_propietario AND id_documento = av_documento;
            
         RETURN lv_interlocutor;   

EXCEPTION
WHEN OTHERS THEN

RETURN lv_interlocutor; 

END ft_exite_interlocutor;

FUNCTION ft_exite_usuario (av_placa VARCHAR, av_documento VARCHAR, av_propietario VARCHAR) RETURN BOOLEAN AS

lv_existe NUMBER:=0;
lb_existe BOOLEAN:=FALSE;

BEGIN
        SELECT COUNT(1) INTO lv_existe FROM propietarios_sap
        WHERE nro_placa = av_placa  AND id_usuario = av_propietario  
                                    AND id_documento = av_documento
                                    AND obsoleto IS NULL;
    
    IF lv_existe > 0 THEN
        lb_existe := TRUE;
    END IF;
        RETURN lb_existe;
        
EXCEPTION
WHEN OTHERS THEN
RETURN lb_existe;
    
END ft_exite_usuario;

PROCEDURE sp_validacion_propietarios AS

CURSOR lcur_runt IS SELECT nro_placa, propietario, tipo_documento 
                    FROM  propietarios_runt;
lb_existe BOOLEAN;
lv_interlocutor VARCHAR2(255 BYTE);
ln_commit NUMBER:=0;

iv_digito VARCHAR2(255 BYTE);

BEGIN
    FOR ln_index IN lcur_runt LOOP
     BEGIN
        lb_existe:=FALSE;
        lv_interlocutor:='';
        ln_commit:= ln_commit + 1;
                       
                IF ln_index.tipo_documento = 'N' THEN
                   CASE LENGTH(ln_index.propietario)
                        WHEN  9 THEN
                            lb_existe:= ft_exite_usuario(ln_index.nro_placa, ln_index.tipo_documento,consultas.ft_digito_verificacion(ln_index.propietario));
                        WHEN 10 THEN
                            lb_existe:=ft_exite_usuario(ln_index.nro_placa, ln_index.tipo_documento, ln_index.propietario); 
                        ELSE
                            NULL;
                   END CASE;
                ELSE
                   lb_existe:=ft_exite_usuario(ln_index.nro_placa, ln_index.tipo_documento, ln_index.propietario); 
                END IF;
                
                IF lb_existe = TRUE THEN
                    UPDATE propietarios_runt SET estado = iv_estado_1
                    WHERE nro_placa = ln_index.nro_placa;
                ELSE
                    IF ln_index.tipo_documento = 'N' THEN
                       CASE LENGTH(ln_index.propietario)
                           WHEN 9 THEN
                                lv_interlocutor:=ft_exite_interlocutor(consultas.ft_digito_verificacion(ln_index.propietario),ln_index.tipo_documento);
                          WHEN 10 THEN
                                lv_interlocutor:=ft_exite_interlocutor(ln_index.propietario, ln_index.tipo_documento);
                          ELSE
                               NULL;
                      END CASE;
                    ELSE
                        lv_interlocutor:=ft_exite_interlocutor(ln_index.propietario, ln_index.tipo_documento);
                    END IF;
                    
                    IF lv_interlocutor IS NOT NULL THEN
                        UPDATE propietarios_runt SET estado = iv_estado_2, interlocutor = lv_interlocutor 
                        WHERE nro_placa = ln_index.nro_placa;
                    ELSE
                        UPDATE propietarios_runt SET estado = iv_estado_3
                        WHERE nro_placa = ln_index.nro_placa;
                    END IF;
                END IF;  
                
                IF ln_commit = 500 THEN
                    ln_commit:=0;
                    COMMIT;
                END IF;
                
         EXCEPTION
         WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(Dbms_Utility.Format_Error_Backtrace);
      END;
    END LOOP;

END sp_validacion_propietarios;

PROCEDURE sp_iniciar AS
BEGIN

    sp_validacion_propietarios;
    
END sp_iniciar;

END PKG_VALIDACION_PROPIETARIOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_TRAMITE_RUNT_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_VALIDAR_TRAMITE_RUNT_SAP" AS

in_Diferencia_Dias NUMBER;
inBlindaje NUMBER;
inDesblindaje NUMBER;


FUNCTION Ft_Validar_Tras_Radic_Interno (anCodigo_Runt NUMBER) RETURN NUMBER AS

/*ISVA
Nombre     :Ft_Validar_Tras_Radic_Interno
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :anCodigo_Runt
Retorno    :ln_Existe         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :Valida si el traslado o radicacion son internas o externas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

ln_Existe Simple_Integer:=0;

BEGIN
      SELECT COUNT(1) INTO ln_Existe FROM Bd_Fiscalizacion.Fc_Municipio_Departamento
            WHERE Divipo = anCodigo_Runt;
        IF ln_Existe > 0 THEN
            SELECT COUNT(1) INTO ln_Existe FROM Bd_Fiscalizacion.Fc_Municipio_Departamento
                WHERE Divipo = anCodigo_Runt AND Codigo_Departamento_Sap NOT IN ('05');
        ELSE
             ln_Existe := -2;
        END IF;  
                RETURN ln_Existe;
EXCEPTION
WHEN OTHERS THEN 
RETURN 0;

END Ft_Validar_Tras_Radic_Interno;

FUNCTION Ft_Fecha_Novedad (avPlaca VARCHAR, anId_Novedad_R NUMBER) RETURN DATE AS

/*ISVA
Nombre     :Ft_Fecha_Novedad
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :avPlaca, anId_Novedad_R
Retorno    :ld_Fecha_Sap         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :recupera la ultima fecha de novedad
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

ld_Fecha_Sap DATE;

BEGIN 
       SELECT MAX(Fecha_Novedad) INTO ld_Fecha_Sap FROM Vr_reporte_novedades_Sap
                            WHERE Nro_Placa = avPlaca AND Id_Novedad = anId_Novedad_R;
                
            IF ld_Fecha_Sap IS NULL THEN 
                 RETURN NULL;  
            ELSE
                 RETURN  ld_Fecha_Sap;  
            END IF;
EXCEPTION 
WHEN OTHERS THEN
RETURN NULL;
                           
END Ft_Fecha_Novedad;

FUNCTION Ft_Validar_Nov_Sap (avPlaca VARCHAR, anId_Novedad_R NUMBER, adFecha_Tramite_R DATE) RETURN NUMBER AS

/*ISVA
Nombre     :Ft_Validar_Nov_Sap
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :avPlaca, anId_Novedad_R, adFecha_Tramite_R
Retorno    :ld_Fecha_Sap         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :genera los dias de diferencia en sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

ln_Existe Simple_Integer:=0;
ld_Fecha_Sap Date;
ln_Anno_TrRunt NUMBER (4,0):=0;
ln_Anno_TrSap NUMBER (4,0):=0;


BEGIN       --Valido que si esxista la novedad en sap
            SELECT COUNT(1) INTO ln_Existe FROM Vr_reporte_novedades_Sap
            WHERE Nro_Placa = avPlaca AND Id_Novedad = anId_Novedad_R AND Fecha_Novedad = TO_CHAR(adFecha_Tramite_R,'DD/MM/YY');
                    
                    IF ln_Existe > 0 THEN 
                        RETURN 1;
                    ELSE --valido si la novedad es igual al mismo a�o para modificar
                           ld_Fecha_Sap:= Ft_Fecha_Novedad(avPlaca,anId_Novedad_R);
                              
                             If ld_Fecha_Sap IS NULL THEN
                                        RETURN 0;
                             ELSE
                                    ln_Anno_TrSap:= TO_CHAR(ld_Fecha_Sap,'YYYY');
                                    ln_Anno_TrRunt:= TO_CHAR(adFecha_Tramite_R,'YYYY');
                                        IF ln_Anno_TrSap = ln_Anno_TrRunt THEN
                                            in_Diferencia_Dias := adFecha_Tramite_R - ld_Fecha_Sap;
                                            IF in_Diferencia_Dias < 0 THEN
                                                in_Diferencia_Dias:=in_Diferencia_Dias *(-1);
                                            END IF;
                                                RETURN 2; --guardo la diferencia en dias    
                                        ELSE
                                                RETURN 0; --son diferente en el a�o
                                        END IF;
                            END IF;  
                  END IF;
END Ft_Validar_Nov_Sap;

PROCEDURE Sp_Existe_Novedad_Sap (aNro_Placa VARCHAR2,aId_Tramite NUMBER, aFecha_Tramite DATE,aId_Secretaria_Destino NUMBER,
                                 aId_Secretaria_Origen NUMBER, aDesblindaje VARCHAR2, aRowId VARCHAR2) As

/*ISVA
Nombre     :Sp_Existe_Novedad_Sap
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :aNro_Placa, aId_Tramite, aFecha_Tramite, aId_Secretaria_Destino
Parametros :aId_Secretaria_Origen, aDesblindaje, aRowId
Retorno    :ld_Fecha_Sap         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :Convierte los codigos de novedad runt a sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

ln_Codigo_Sap NUMBER(2):=0;
ln_Tras_Rad_Interno Simple_Integer:=0;
Ln_Existe Simple_Integer:=0;

BEGIN
            CASE aId_Tramite
                         WHEN 1 THEN 
                                IF adesblindaje = 'S' THEN --Desblindado
                                    ln_Codigo_Sap := 18;
                                ELSE  --Blindado
                                    ln_Codigo_Sap := 2;
                                END IF;
                          WHEN 20 THEN --Cancelacion 
                            ln_Codigo_Sap := 3;
                          WHEN 13 THEN --rematricula
                            ln_Codigo_Sap := 4;
                          WHEN 10 THEN --Radicacion 
                            ln_Tras_Rad_Interno:=Ft_Validar_Tras_Radic_Interno(aId_Secretaria_Origen);
                                  IF ln_Tras_Rad_Interno > 0 THEN
                                    ln_Codigo_Sap := 6;
                                  ELSIF ln_Tras_Rad_Interno =-2 THEN
                                      ln_Codigo_Sap:= -2;
                                  ELSE
                                    ln_Codigo_Sap:=-1;
                                  END IF;
                          WHEN 15 THEN --Traslado
                            ln_Tras_Rad_Interno:=Ft_Validar_Tras_Radic_Interno(aId_Secretaria_Destino);
                                  IF ln_Tras_Rad_Interno > 0 THEN
                                     ln_Codigo_Sap := 7;
                                  ELSIF ln_Tras_Rad_Interno =-2 THEN
                                      ln_Codigo_Sap:= -2;
                                  ELSE
                                     ln_Codigo_Sap:= -1;
                                  End If;  
                          WHEN 6  THEN --Cambio Servicio 
                            ln_Codigo_Sap := 8;
                          WHEN 14 THEN --Transformacion
                            ln_Codigo_Sap := 11;
                          ELSE
                            NULL;
             END CASE; 
                         
            IF  ln_Codigo_Sap NOT IN (-1,-2,11) THEN                         
                 Ln_Existe:=Ft_Validar_Nov_Sap(aNro_Placa,ln_Codigo_Sap,aFecha_Tramite); 
            ELSIF  ln_Codigo_Sap = 11 THEN 
                Ln_Existe:=5;
            ELSIF ln_Codigo_Sap = -2 THEN
                Ln_Existe:=5;
            ELSE
            
                Ln_Existe:=3;
            END IF;
                Case Ln_Existe
                   WHEN  1 THEN 
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Novedad ya ingresada en sap'
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId; 
                   WHEN  2 THEN
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Diferencia en dias'||'  /  '||in_Diferencia_Dias
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId; 
                   WHEN 0 THEN
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Ingresar novedad en sap'
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId; 
                  WHEN 3 THEN
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Traslado o Radicacion interna no afecta el impuesto'
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId; 
                  WHEN 4 THEN
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Validar Transformacion'
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId;  
                  ELSE
                        UPDATE Vr_Tmp_Tramites_Runt SET Estado = 'Validadar novedad'
                        WHERE Nro_Placa = aNro_Placa  
                        AND ROWID = aRowId;  
                  END CASE;
                                            

END Sp_Existe_Novedad_Sap;

PROCEDURE Sp_Iniciar_Validacion AS

/*ISVA
Nombre     :Sp_Iniciar_Validacion
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VALIDAR_TRAMITE_RS
Version    :1.0
Objetivo   :Inicia las validaciones y caprturas las novedades validas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

CURSOR curTramite IS SELECT DISTINCT Nro_Placa,Id_Tramite,Fecha_Tramite,Id_Secretaria_Destino,
                                Id_Secretaria_Origen, Desblindaje, ROWID
                     FROM Vr_Tmp_Tramites_Runt 
                     WHERE Id_Tramite IN (1,6,10,13,14,15,20);
                                        
TYPE tblTramite IS TABLE OF curTramite%RowType;
ArrayTramite tblTramite;

BEGIN
    OPEN curTramite;
        LOOP FETCH curTramite
            BULK COLLECT INTO ArrayTramite LIMIT 500;
                FOR Ln_Index IN 1..ArrayTramite.COUNT() LOOP
                               
                    Sp_Existe_Novedad_Sap (ArrayTramite(Ln_Index).Nro_placa, ArrayTramite(Ln_Index).Id_Tramite,
                                           ArrayTramite(Ln_Index).Fecha_Tramite,ArrayTramite(Ln_Index).Id_Secretaria_Destino,
                                           ArrayTramite(Ln_Index).Id_Secretaria_Origen,ArrayTramite(Ln_Index).Desblindaje,
                                           ArrayTramite(Ln_Index).ROWID);                                          
                END LOOP;
            EXIT WHEN ArrayTramite.COUNT()<=0;
          COMMIT;
        END LOOP;
    CLOSE curTramite;
END Sp_Iniciar_Validacion;

END PKG_VALIDAR_TRAMITE_RUNT_SAP;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_VALIDAR_VEHICULOS" AS

procedure sp_depurar_placas As

/*ISVA
Nombre     :sp_depurar_placas
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_VALIDAR_VEHICULOS
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

Begin
        Delete tmp_placas; 
        Commit;

        Insert Into tmp_placas (Nro_placa)
        Select Nro_placa from vr_tmp_vehiculos_runt
            Where id_servicio in (1)
        And Nro_PLaca Not In (Select Nro_Placa From vr_tmp_vehiculos_runt
            Where Id_Clase In (10,14,17,19,163,165) And Id_Servicio IN (1,3,4) And id_combustible not in (5) And To_Number(Cilindraje) Between 48 and 125)
        And Nro_PLaca Not In (Select Nro_Placa From vr_tmp_vehiculos_runt
                              Where Id_Clase In (10,14,17,19,163,165) And id_combustible IN (5))
        Union
        Select Nro_placa From vr_tmp_vehiculos_runt
                Where Id_Clase In (10,14,17,19,163,165) And Id_Servicio IN (3,4) And To_Number(Cilindraje) > 125 
        union
        Select Vr.Nro_placa From Vr_tmp_vehiculos_runt Vr
                Inner join vr_tmp_tramites_runt at On At.Nro_placa = Vr.nro_placa
                    Where id_tramite = 6
        Union
            Select Nro_placa from vr_tmp_vehiculos_runt
                Where id_servicio is null;
                

End sp_depurar_placas;

procedure sp_vehiculos_no_sujetas_cobro As

/*ISVA
Nombre     :sp_vehiculos_no_sujetas_cobro
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :lcur_novedades
Retorno    :      
Proyecto   :PKG_VALIDAR_VEHICULOS
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

lv_Archivo Varchar2(255 byte):='Vehiculos no sujetas del cobro '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

cursor lcur_no_pagan Is Select * From vr_tmp_vehiculos_runt
                                    Where Nro_Placa Not in (Select nro_placa From tmp_placas); 

Begin
    Begin
    lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo,'W');
        For ln_index in lcur_no_pagan Loop 
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'||'ID_LINEA;'||'NOMBRE_LINEA;'
                                                     ||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'||'NOMBRE_SERVICIO;'
                                                     ||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'||'ID_COMBUSTIBLE;'
                                                     ||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'||'POTENCIA;'
                                                     ||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                     ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'
                                                     ||'ID_ESTADO;'||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'
                                                     ||'CAJA;'||'TRACCION;'||'COMBUSTION;'||'WATT');
                             lb_Existe:=True;
                End If;
             UTL_FILE.PUT_LINE(lutl_archivo,ln_index.NRO_PLACA||';'||ln_index.ID_MARCA||';'||ln_index.NOMBRE_MARCA||';'||ln_index.ID_LINEA
             ||';'||ln_index.NOMBRE_LINEA||';'||ln_index.MODELO||';'||ln_index.ID_CLASE||';'||ln_index.NOMBRE_CLASE||';'||ln_index.ID_SERVICIO||';'
             ||ln_index.NOMBRE_SERVICIO||';'||ln_index.ID_CARROCERIA||';'||ln_index.NOMBRE_CARROCERIA||';'||ln_index.NRO_PUERTAS||';'
             ||ln_index.ID_COMBUSTIBLE||';'||ln_index.NOMBRE_COMBUSTIBLE||';'||ln_index.ID_BATERIA||';'||ln_index.NOMBRE_BATERIA||';'
             ||ln_index.POTENCIA||';'||ln_index.ID_SECRETARIA||';'||ln_index.NOMBRE_SECRETARIA||';'||ln_index.CILINDRAJE||';'
             ||ln_index.CAP_PASAJEROS||';'||ln_index.CAP_TONELADAS||';'||ln_index.VALOR_FACTURA||';'||ln_index.BLINDADO||';'
             ||ln_index.IMPORTADO_NACIONAL||';'||ln_index.ID_ESTADO||';'||ln_index.NOMBRE_ESTADO||';'||ln_index.CLASICO_ANTIGUO||';'
             ||ln_index.FECHA_MATRICULO||';'||ln_index.CAJA||';'||ln_index.TRACCION||';'||ln_index.COMBUSTION||';'||ln_index.WATT);
        End loop; 
    UTL_FILE.FCLOSE(lutl_archivo); 
End;


End sp_vehiculos_no_sujetas_cobro;

procedure sp_eleminar_no_paga_impuesto As

/*ISVA
Nombre     :sp_generar_placas_para_cobro
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :
Retorno    :      
Proyecto   :PKG_VALIDAR_VEHICULOS
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

Begin
    Delete From vr_tmp_vehiculos_runt
        Where Nro_Placa Not in (Select nro_placa From tmp_placas); 
        
    Delete From vr_tmp_tramites_runt
        Where Nro_Placa Not in (Select nro_placa From tmp_placas); 
        
    Delete From vr_tmp_historico_traspaso_runt
        Where Nro_Placa Not in (Select nro_placa From tmp_placas);
        
    Delete From vr_tmp_Propietarios_runt
        Where Nro_Placa Not in (Select nro_placa From tmp_placas); 
        
End sp_eleminar_no_paga_impuesto;

Procedure sp_crear_vehiculos_sap As

/*ISVA
Nombre     :sp_crear_vehiculos_sap
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :lv_Archivo,lv_Name_File, v_MyFileHandle
Parametros :lb_Existe,lcur_novedades
           :
Retorno    :      
Proyecto   :PKG_VALIDAR_VEHICULOS
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

lv_Archivo Varchar2(255 byte):='Crear vehiculos en sap '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;
lutl_archivo UTL_FILE.FILE_TYPE;

Cursor lcur_vehiculos is Select Distinct vr.* From vr_tmp_vehiculos_runt vr
                         Left Join bd_fiscalizacion.fc_vehiculos vs On vs.nro_placa = vr.nro_placa
                         Where vs.nro_placa is null;

 Begin
    lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo,'W');
        For ln_index in lcur_vehiculos Loop 
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'||'ID_LINEA;'||'NOMBRE_LINEA;'
                                                     ||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'||'NOMBRE_SERVICIO;'
                                                     ||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'||'ID_COMBUSTIBLE;'
                                                     ||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'||'POTENCIA;'
                                                     ||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                     ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'
                                                     ||'ID_ESTADO;'||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'
                                                     ||'CAJA;'||'TRACCION;'||'COMBUSTION;'||'WATT');
                             lb_Existe:=True;
                End If;
             UTL_FILE.PUT_LINE(lutl_archivo,ln_index.NRO_PLACA||';'||ln_index.ID_MARCA||';'||ln_index.NOMBRE_MARCA||';'||ln_index.ID_LINEA
             ||';'||ln_index.NOMBRE_LINEA||';'||ln_index.MODELO||';'||ln_index.ID_CLASE||';'||ln_index.NOMBRE_CLASE||';'||ln_index.ID_SERVICIO||';'
             ||ln_index.NOMBRE_SERVICIO||';'||ln_index.ID_CARROCERIA||';'||ln_index.NOMBRE_CARROCERIA||';'||ln_index.NRO_PUERTAS||';'
             ||ln_index.ID_COMBUSTIBLE||';'||ln_index.NOMBRE_COMBUSTIBLE||';'||ln_index.ID_BATERIA||';'||ln_index.NOMBRE_BATERIA||';'
             ||ln_index.POTENCIA||';'||ln_index.ID_SECRETARIA||';'||ln_index.NOMBRE_SECRETARIA||';'||ln_index.CILINDRAJE||';'
             ||ln_index.CAP_PASAJEROS||';'||ln_index.CAP_TONELADAS||';'||ln_index.VALOR_FACTURA||';'||ln_index.BLINDADO||';'
             ||ln_index.IMPORTADO_NACIONAL||';'||ln_index.ID_ESTADO||';'||ln_index.NOMBRE_ESTADO||';'||ln_index.CLASICO_ANTIGUO||';'
             ||ln_index.FECHA_MATRICULO||';'||ln_index.CAJA||';'||ln_index.TRACCION||';'||ln_index.COMBUSTION||';'||ln_index.WATT);
        End loop; 
    UTL_FILE.FCLOSE(lutl_archivo); 
    
                        Delete from vr_tmp_vehiculos_runt
                        where nro_placa in (Select Distinct vr.nro_placa From vr_tmp_vehiculos_runt vr
                                            Left Join bd_fiscalizacion.fc_vehiculos vs On vs.nro_placa = vr.nro_placa
                                            Where vs.nro_placa is null); 
End sp_crear_vehiculos_sap;

procedure sp_generar_plantillas As

lv_Archivo_v Varchar2(255 byte):='Vehiculos '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lv_Archivo_t Varchar2(255 byte):='tramites '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lv_Archivo_p Varchar2(255 byte):='Propietarios '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lv_Archivo_h Varchar2(255 byte):='Historico Traspasos '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe Boolean:=False;

cursor lur_vehiculos is select * from vr_tmp_vehiculos_runt;
cursor lur_tramites is select * from vr_tmp_tramites_runt;
cursor lur_propietarios is select * from vr_tmp_propietarios_runt;
cursor lur_historico_traspaso is select * from vr_tmp_historico_traspaso_runt;

lutl_archivo UTL_FILE.FILE_TYPE;

 Begin
    lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo_v,'W');
        For ln_index in lur_vehiculos Loop 
            If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_MARCA;'||'NOMBRE_MARCA;'||'ID_LINEA;'||'NOMBRE_LINEA;'
                                                     ||'MODELO;'||'ID_CLASE;'||'NOMBRE_CLASE;'||'ID_SERVICIO;'||'NOMBRE_SERVICIO;'
                                                     ||'ID_CARROCERIA;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'||'ID_COMBUSTIBLE;'
                                                     ||'NOMBRE_COMBUSTIBLE;'||'ID_BATERIA;'||'NOMBRE_BATERIA;'||'POTENCIA;'
                                                     ||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CILINDRAJE;'||'CAP_PASAJEROS;'
                                                     ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'IMPORTADO_NACIONAL;'
                                                     ||'ID_ESTADO;'||'NOMBRE_ESTADO;'||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'
                                                     ||'CAJA;'||'TRACCION;'||'COMBUSTION;'||'WATT');
                             lb_Existe:=True;
                End If;
             UTL_FILE.PUT_LINE(lutl_archivo,ln_index.NRO_PLACA||';'||ln_index.ID_MARCA||';'||ln_index.NOMBRE_MARCA||';'||ln_index.ID_LINEA
             ||';'||ln_index.NOMBRE_LINEA||';'||ln_index.MODELO||';'||ln_index.ID_CLASE||';'||ln_index.NOMBRE_CLASE||';'||ln_index.ID_SERVICIO||';'
             ||ln_index.NOMBRE_SERVICIO||';'||ln_index.ID_CARROCERIA||';'||ln_index.NOMBRE_CARROCERIA||';'||ln_index.NRO_PUERTAS||';'
             ||ln_index.ID_COMBUSTIBLE||';'||ln_index.NOMBRE_COMBUSTIBLE||';'||ln_index.ID_BATERIA||';'||ln_index.NOMBRE_BATERIA||';'
             ||ln_index.POTENCIA||';'||ln_index.ID_SECRETARIA||';'||ln_index.NOMBRE_SECRETARIA||';'||ln_index.CILINDRAJE||';'
             ||ln_index.CAP_PASAJEROS||';'||ln_index.CAP_TONELADAS||';'||ln_index.VALOR_FACTURA||';'||ln_index.BLINDADO||';'
             ||ln_index.IMPORTADO_NACIONAL||';'||ln_index.ID_ESTADO||';'||ln_index.NOMBRE_ESTADO||';'||ln_index.CLASICO_ANTIGUO||';'
             ||ln_index.FECHA_MATRICULO||';'||ln_index.CAJA||';'||ln_index.TRACCION||';'||ln_index.COMBUSTION||';'||ln_index.WATT);
        End loop; 
    lb_Existe:=False;
    UTL_FILE.FCLOSE(lutl_archivo); 
    
    lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo_t,'W');
        For ln_index in lur_tramites Loop 
          If lb_Existe = False Then
            UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_TRAMITE;'||'NOMBRE_TRAMITE;'||'FECHA_TRAMITE;'||'TIPO_CANCELACION;'
                                         ||'ID_SECRETARIA_DESTINO;'||'ID_SECRETARIA_ORIGEN;'||'ID_CARROCERIA_ANTERIOR;'
                                         ||'NOMBRE_CARROCERIA_ANTERIOR;'||'ID_CARROCERIA_NUEVA;'||'NOMBRE_CARROCERIA_NUEVA;'
                                         ||'ID_SERVICIO_ANTERIOR;'||'NOMBRE_SERVICIO_ANTERIOR;'||'ID_SERVICIO_NUEVO;'||'NOMBRE_SERVICIO_NUEVO;'
                                         ||'ID_DOCUMENTO_ANTERIOR;'||'ID_USUARIO_ANTERIOR;'||'ID_DOCUMENTO_NUEVO;'||'ID_USUARIO_NUEVO;'
                                         ||'PORCENTAJE_PROP;'||'CLASICO_ANTIGUO;'||'BLINDADO'||'NIVEL_BLINDADO;'||'DESBLINDAJE;'||'CILINDRAJE;'
                                         ||'CAP_PASAJEROS;'||'CAP_TONELADAS;'||'CILINDRAJE_ANTERIOR'||'CAP_PASAJEROS_ANTERIOR;'
                                         ||'CAP_TONELADAS_ANTERIOR;'||'ESTADO');
                        lb_Existe:=True;
          End If;
            UTL_FILE.PUT_LINE(lutl_archivo, Ln_Index.NRO_PLACA||';'||Ln_Index.ID_TRAMITE||';'||Ln_Index.NOMBRE_TRAMITE||';'
                    ||Ln_Index.FECHA_TRAMITE||';'||Ln_Index.TIPO_CANCELACION||';'||Ln_Index.ID_SECRETARIA_DESTINO||';'
                    ||Ln_Index.ID_SECRETARIA_ORIGEN	||';'||Ln_Index.ID_CARROCERIA_ANTERIOR||';'||Ln_Index.NOMBRE_CARROCERIA_ANTERIOR||';'
                    ||Ln_Index.ID_CARROCERIA_NUEVA||';'||Ln_Index.NOMBRE_CARROCERIA_NUEVA||';'||Ln_Index.ID_SERVICIO_ANTERIOR||';'
                    ||Ln_Index.NOMBRE_SERVICIO_ANTERIOR||';'||Ln_Index.ID_SERVICIO_NUEVO||';'||Ln_Index.NOMBRE_SERVICIO_NUEVO||';'
                    ||Ln_Index.ID_DOCUMENTO_ANTERIOR||';'||Ln_Index.ID_USUARIO_ANTERIOR||';'||Ln_Index.ID_DOCUMENTO_NUEVO||';'
                    ||Ln_Index.ID_USUARIO_NUEVO||';'||Ln_Index.PORCENTAJE_PROP||';'||Ln_Index.CLASICO_ANTIGUO||';'
                    ||Ln_Index.BLINDADO||';'||Ln_Index.NIVEL_BLINDADO||';'||Ln_Index.DESBLINDAJE||';'||Ln_Index.CILINDRAJE||';'
                    ||Ln_Index.CAP_PASAJEROS||';'||Ln_Index.CAP_TONELADAS||';'||Ln_Index.CILINDRAJE_ANTERIOR||';'
                    ||Ln_Index.CAP_PASAJEROS_ANTERIOR||';'||Ln_Index.CAP_TONELADAS_ANTERIOR||';'||Ln_Index.ESTADO);   
                End loop; 
    UTL_FILE.FCLOSE(lutl_archivo); 
    lb_Existe:=False;
     
    lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo_p,'W');
        For ln_index in lur_propietarios Loop 
          If lb_Existe = False Then
            UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_USUARIO;'||'ID_DOCUMENTO;'||'PORCENTAJE_PROP;'||'FECHA_RUNT;'
                                         ||'FECHA_SAP;'||'INTERLOCUTOR;'||'ESTADO;');
                        lb_Existe:=True;
          End If;
            UTL_FILE.PUT_LINE(lutl_archivo, Ln_Index.nro_placa||';'||Ln_Index.id_usuario||';'||Ln_Index.id_documento||';'
                    ||Ln_Index.porcentaje_prop||';'||Ln_Index.fecha_runt||';'||Ln_Index.fecha_sap||';'
                    ||Ln_Index.interlocutor	||';'||Ln_Index.estado);   
                End loop; 
    UTL_FILE.FCLOSE(lutl_archivo); 
     lb_Existe:=False;
     
     lutl_archivo := UTL_FILE.FOPEN('BACKUP_NO_IMPUESTO',lv_Archivo_h,'W');
        For ln_index in lur_historico_traspaso Loop 
          If lb_Existe = False Then
            UTL_FILE.PUT_LINE(lutl_archivo,'NRO_PLACA;'||'ID_USUARIO;'||'ID_DOCUMENTO;'||'PORCENTAJE;'||'FECHA_INICIO_PROPIEDAD;'
                                         ||'FECHA_FIN_PROPIEDAD');
                        lb_Existe:=True;
          End If;
            UTL_FILE.PUT_LINE(lutl_archivo, Ln_Index.nro_placa||';'||Ln_Index.id_usuario||';'||Ln_Index.tipo_documento||';'
                    ||Ln_Index.porcentaje||';'||Ln_Index.fecha_inicio_propiedad||';'||Ln_Index.fecha_fin_propiedad);   
                End loop; 
    UTL_FILE.FCLOSE(lutl_archivo); 
                    
end sp_generar_plantillas;

procedure sp_iniciar AS

/*ISVA
Nombre     :sp_novedades
Autor      :Blados.Ospina
Fecha      :15/05/18
Parametros :lv_Name_File, v_MyFileHandle
           :lcur_novedades
Retorno    :      
Proyecto   :PKG_PLANTILLAS_SAP
Versi�n    :1.0
Objetivo   :Crea los archivos planos en una ruta 
           :especifica
correspondiente
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha           Autor           Modificacion
15/05/2018      Blados.Ospina
*/

Begin
    sp_depurar_placas;
    sp_vehiculos_no_sujetas_cobro;
    sp_eleminar_no_paga_impuesto;
    sp_crear_vehiculos_sap;
    sp_generar_plantillas;
END sp_iniciar;

END PKG_VALIDAR_VEHICULOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VAL_PROP_RUNT_SAP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "BD_VALIDACION_RUNT"."PKG_VAL_PROP_RUNT_SAP" AS

In_Contador Simple_Integer:=0;
iv_interlocutor Varchar(255);
iv_id_inderterminada varchar2(15 byte) := '1001061777';

iv_mesaje_1 Varchar2(255):='Asociar propietario runt, Interlocutor creado en sap';
iv_mesaje_2 Varchar2(255):='El propietario de sap reporta un fecha mas actualizada';
iv_mesaje_3 Varchar2(255):='Asociar propietario runt, validar tipo de documento';
iv_mesaje_4 Varchar2(255):='Asociar propietario runt, crear interlocutor';
iv_mesaje_5 Varchar2(255):='No tiene fecha de asociacion en sap';
iv_mesaje_6 Varchar2(255):='Fecha Runt y sap igual, se deja por defecto el interlocutor de sap';
iv_mesaje_7 Varchar2(255):='No reporta usuario o es null el campo';
iv_mesaje_8 Varchar2(255):='Se le asigna interlocutor, persona indeterminada';



    
Procedure Sp_Commit As

/*ISVA
Nombre     :Sp_Commit
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Realizar commit cierta cantidad de registros
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Begin
    If In_Contador = 0 Then
        In_Contador:=0;
        Commit;
    Else
        In_Contador:=In_Contador + 1;
    End If;
  
End Sp_Commit;

Function Ft_Fecha_Mayor_Prop_Runt (vPlaca Varchar) Return Date As

/*ISVA
Nombre     :Ft_Fecha_Mayor_Prop_Runt
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :vPlaca
Retorno    :Ld_Fecha_Sap       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Retorna la maxima de propietarios runt
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Ld_Fecha_Runt Date;
Begin
        --Retorno la ultmima fecha de sap de asignar interlocutor
        Select Max(Fecha_Runt) Into Ld_Fecha_Runt  From Vr_Tmp_Propietarios_Runt
         Where Nro_Placa = vPlaca;
            Return Ld_Fecha_Runt;
        Exception 
            When Others Then
                Return Null;
END Ft_Fecha_Mayor_Prop_Runt;

Procedure Sp_Ultimo_Propietario As

/*ISVA
Nombre     :Sp_Ultimo_Propietario
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Deja el ultimo traspaso
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Cursor Lcur Is Select Distinct Nro_Placa From Vr_Tmp_Propietarios_Runt;
ln_fecha Date;

Begin
    For Ln_Index In Lcur Loop
            ln_fecha := Ft_Fecha_Mayor_Prop_Runt(ln_index.nro_placa);

        Delete From Vr_Tmp_Propietarios_Runt 
        Where Nro_Placa = ln_index.nro_placa And fecha_runt <> ln_fecha;
            Sp_Commit;
    End Loop;
End Sp_Ultimo_Propietario;

Function Ft_Fecha_Mayor_Sap (vPlaca Varchar) Return Date As

/*ISVA
Nombre     :Ft_Fecha_Mayor_Sap
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :vPlaca
Retorno    :Ld_Fecha_Sap       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Retorna la maxima fecha de asociasion en sap
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Ld_Fecha_Sap Date;
Begin
        --Retorno la ultmima fecha de sap de asignar interlocutor
        Select Max(Fecha_Asociar_Ic) Into Ld_Fecha_Sap  From Vr_Interlocutores_Sap
         Where Nro_Placa = vPlaca;
            Return Ld_Fecha_Sap;
        Exception 
            When Others Then
                Return Null;
END Ft_Fecha_Mayor_Sap;

Procedure Sp_Actualizar_Fecha_Prop_Runt As

/*ISVA
Nombre     :Sp_Actualizar_Fecha
Autor      :Blados.Ospina
Fecha      :20/06/2018
Parametros :
Retorno    :         
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Actualiza la fecha en propietarios run
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
20/06/2018  Blados.Ospina   1.0                      */

Cursor curPlacas Is Select Distinct Nro_placa From Vr_Tmp_Propietarios_Runt;
ld_Fecha_Mayor Date;

Begin
    For Ln_Index In curPlacas Loop
        Begin
        ld_Fecha_Mayor:=Ft_Fecha_Mayor_Sap (Ln_Index.Nro_placa);
         If ld_Fecha_Mayor Is not Null Then
            Update Vr_Tmp_Propietarios_Runt Set Fecha_Sap = ld_Fecha_Mayor
                Where Nro_Placa = Ln_Index.Nro_Placa;
                    Sp_Commit;
        Else
            Update Vr_Tmp_Propietarios_Runt Set Estado = 'No esta incluida en las placas'
                Where Nro_Placa = Ln_Index.Nro_Placa;
                    Sp_Commit;
        End If;
        Exception
        When Others Then
            Continue;
        End;
    End Loop;

END Sp_Actualizar_Fecha_Prop_Runt;

Function Ft_Buscar_Interlocutor (av_nit Varchar) Return Number As

/*ISVA
Nombre     :Ft_Buscar_Interlocutor
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :av_nit
Retorno    :ln_existe       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Veirifica si exite el nit en sap 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

ln_existe Number:=0;

Begin
    Select Count(1),Id_Interlocutor Into ln_existe,iv_interlocutor From sap_interlocutores
    Where Id_Usuario = av_nit And Id_Documento = 'N' And RowNum = 1
    Group By Id_Interlocutor;
            Return ln_existe;
        Exception 
        When Others Then 
            Return 0;
End Ft_Buscar_Interlocutor;

Function Ft_Validar_Nit (av_nit Varchar) Return Number As 

/*ISVA
Nombre     :Ft_Validar_Nit
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :av_nit
Retorno    :ln_existe       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Valida nit y genera el digito de verificacion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

indice Number:=0;
ln_existe Number:=0;
ln_digito_verificacion Number:=0;
lb_validacion boolean:=False;

Begin   
        If Length(av_nit) = 9 Then 
                For ln_index In 0..9 Loop 
                    ln_digito_verificacion:= Ft_Buscar_Interlocutor(av_nit||ln_index);
                        If ln_digito_verificacion > 0 Then
                               ln_existe := 1;
                               lb_validacion := True;
                               Exit;
                        End If;
                End Loop;
            If lb_validacion  = False Then
                ln_existe:= Ft_Buscar_Interlocutor(av_nit);
            End If;
        ElsIf Length(av_nit) = 10 Then 
            ln_existe:= Ft_Buscar_Interlocutor(av_nit);
                If ln_existe = 0 Then
                    ln_existe:= Ft_Buscar_Interlocutor(SubStr(av_nit,1,9));
                End If;
        Elsif Length(av_nit) = 8 Then
                ln_existe:= Ft_Buscar_Interlocutor(av_nit); 
        End If;
    Return ln_existe;
End Ft_Validar_Nit;

Function Ft_Validar_Propietario (av_id_usuario Varchar, av_id_Documento Varchar) return Number As

/*ISVA
Nombre     :Ft_Validar_Propietario
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :av_id_usuario, av_id_Documento
Retorno    :Ln_existe       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Valida nit y genera el digito de verificacion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

Ln_existe Number:=0;
lb_existe Boolean;
Cursor curInterlocutor Is Select Distinct Id_Usuario, Id_Documento,Id_Interlocutor From sap_interlocutores
                                    Where Id_Usuario = av_id_usuario; --And To_Date(Fecha_Asociar_Ic) = ''
                                                --And Obsoleto is Null;
Begin
lb_existe := False;
iv_interlocutor :='';
        
        If av_id_Documento = 'N' Then
            Ln_existe:= Ft_Validar_Nit(av_id_usuario);
        Else
            For Ln_Index In curInterlocutor Loop 
                lb_existe := True;
                        If Ln_Index.Id_Usuario = av_id_usuario And Ln_Index.Id_Documento =  av_id_Documento Then 
                                Ln_existe := 1;   
                                iv_interlocutor:= ln_index.id_interlocutor; 
                        Elsif (Ln_Index.Id_Usuario = av_id_usuario And Ln_Index.Id_Documento !=  av_id_Documento)
                                And Ln_existe Not In (1) Then
                                Ln_existe := 2;
                        End If; 
            End Loop;   
        End If;
       /*    If lb_existe = False Then 
                If av_id_Documento = 'N' Then
                    Ln_existe:= Ft_Validar_Nit(av_id_usuario);
                End If;
            End If; */
                Return Ln_existe;      
End Ft_Validar_Propietario;

Procedure Sp_Registrar_Estado (av_rowid Varchar, av_mensaje Varchar) As

/*ISVA
Nombre     :Sp_Registrar_Estado
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :av_rowid, av_mensaje
Retorno    :       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Actualiza el estado con predeterminado mensaje
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

Begin
        Update Vr_Tmp_Propietarios_Runt Set Estado = av_mensaje, Interlocutor = iv_interlocutor
        Where RowId = av_rowid;
            Sp_Commit;
End Sp_Registrar_Estado;

Procedure Sp_Validacion_Final As

/*ISVA
Nombre     :Sp_Validacion_Final
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :lcur_registro_runt, ln_codigo
Retorno    :       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Actualiza el estado con predeterminado mensaje
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

Cursor lcur_registro_runt Is Select Distinct nro_placa,
                                             id_usuario,
                                             id_documento,
                                             fecha_runt,
                                             fecha_sap,
                                             RowId
                             From Vr_Tmp_Propietarios_Runt; --Where Nro_Placa = 'KFB068' And Id_Usuario = '235126';
	
Type tblProp is table Of lcur_registro_runt%rowType;
ArrayProp tblProp;

ln_codigo Simple_Integer:=0;

Begin
    Open lcur_registro_runt;
        Loop Fetch lcur_registro_runt
            Bulk Collect Into ArrayProp Limit 500;
                For Ln_Index In 1..ArrayProp.Count() Loop
                  iv_interlocutor:= '';
                    If ArrayProp(ln_index).id_usuario is null Then
                        Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_7);
                    Elsif Upper(ArrayProp(ln_index).id_documento) = 'S' Then
                        iv_interlocutor:= iv_id_inderterminada;
                        Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_8);
                        
                    Else
                           If ArrayProp(ln_index).fecha_sap is null Then
                                Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_5);
                           Elsif ArrayProp(ln_index).fecha_runt = ArrayProp(ln_index).fecha_sap Then
                                    Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_6);
                           Elsif ArrayProp(ln_index).fecha_runt > ArrayProp(ln_index).fecha_sap Then
                                ln_codigo:=Ft_Validar_Propietario(ArrayProp(ln_index).id_usuario,ArrayProp(ln_index).id_documento);
                                        Case ln_codigo
                                            When 1 Then
                                                Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_1);
                                            When 2 then
                                                Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_3);
                                        Else
                                                Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_4);
                                        End Case;
                           Else
                                Sp_Registrar_Estado(ArrayProp(ln_index).RowId,iv_mesaje_2);
                           End If;
                    End If;
                 End Loop; 
                 
             Exit When ArrayProp.Count()<=0;
          Commit;
        End Loop;
    Close lcur_registro_runt;
End Sp_Validacion_Final;

Procedure Sp_Iniciar_Validacion AS

/*ISVA
Nombre     :Sp_Iniciar_Validacion
Autor      :Blados.Ospina
Fecha      :22/06/2018
Parametros :lcur_registro_runt, ln_codigo
Retorno    :       
Proyecto   :PKG_VAL_PROP_RUNT_SAP
Version    :1.0
Objetivo   :Encargado  de dirigir la orquesta
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
22/06/2018  Blados.Ospina   1.0                      */

Begin
    --Sp_Ultimo_Propietario;
    --Sp_Actualizar_Fecha_Prop_Runt;
    Sp_Validacion_Final;
    
END Sp_Iniciar_Validacion;

END PKG_VAL_PROP_RUNT_SAP;

/
--------------------------------------------------------
--  DDL for Function FT_VALIDAR_DOCUMENTO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "BD_VALIDACION_RUNT"."FT_VALIDAR_DOCUMENTO" (av_documento Varchar) RETURN VARCHAR2 AS 

/*ISVA
Nombre     :FT_VALIDAR_DOCUMENTO
Autor      :Blados.Ospina
Fecha      :25/06/2018
Parametros :
Retorno    :         
Proyecto   :FT_VALIDAR_DOCUMENTO
Version    :1Converte los tipo de documentos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version   Modificacion   
25/06/2018  Blados.Ospina   1.0                      */

lv_id_documento Varchar2(10 byte);

BEGIN
    CASE Replace(av_documento,' ','')
         WHEN 'CC' THEN
            lv_id_documento := 'C';  
         WHEN 'NIT' THEN
            lv_id_documento := 'N';
         WHEN 'CE' THEN
            lv_id_documento := 'E'; 
         WHEN 'TI' THEN
            lv_id_documento := 'T';  
         WHEN 'PASAP' THEN
            lv_id_documento := 'P'; 
         WHEN 'T12' THEN
            lv_id_documento := 'O'; 
         WHEN 'CD' THEN
            lv_id_documento := 'D'; 
         WHEN 'RC' THEN
            lv_id_documento := 'U'; 
         WHEN 'NN'  THEN
            lv_id_documento := 'X'; 
         WHEN 'S' THEN
            lv_id_documento := 'S';  
         WHEN 'SIND' THEN
            lv_id_documento := 'X'; 
        ELSE
            lv_id_documento := av_documento;  
    END CASE;
                RETURN lv_id_documento;
END FT_VALIDAR_DOCUMENTO;

/
