--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type TP_ERRORES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_ERRORES" AS OBJECT 
(
Id_Error VARCHAR2(255 BYTE), 
Nombre_Error VARCHAR2(255 BYTE),
Constructor Function Tp_Errores Return Self As Result
)
/
CREATE OR REPLACE TYPE BODY "CONSULTAS"."TP_ERRORES" Is 
Constructor Function Tp_Errores Return Self As Result Is 
    tp_Error_1 Tp_Errores := Tp_Errores(null,null);
        Begin
            Self := tp_Error_1;
            Return;
            End Tp_Errores;
        End;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_ERRORES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_LISTA_ERRORES" Is table of Tp_Errores;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_LISTA_PROPIETARIOS" Is table of Tp_Propietarios;

/
--------------------------------------------------------
--  DDL for Type TP_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_PROPIETARIOS" AS OBJECT 
( 
Nro_Placa VARCHAR2(10 BYTE), 
Tipo_Documento_Vendedor VARCHAR2(255 BYTE),
Id_Vendedor VARCHAR2(255 BYTE),
Tipo_Documento_Comprador VARCHAR2(255 BYTE),
Id_Comprador VARCHAR2(255 BYTE),
Porcentaje VARCHAR2(255 BYTE),
Fecha VARCHAR2(255 BYTE),
Transito VARCHAR2(255 BYTE),
Id_Documento_Propietario VARCHAR2(255 BYTE),
Id_Propieario VARCHAR2(255 BYTE),
estado VARCHAR2(255 BYTE),
Constructor Function TP_PROPIETARIOS Return Self As Result
)
/
CREATE OR REPLACE TYPE BODY "CONSULTAS"."TP_PROPIETARIOS" AS

  Constructor Function TP_PROPIETARIOS Return Self As Result AS
  
  TP_PROPIETARIO_1 TP_PROPIETARIOS := TP_PROPIETARIOS(null,null,null,null,null,null,null,null,null,null,null);
  BEGIN
     Self := TP_PROPIETARIO_1;
      Return;
            End TP_PROPIETARIOS;
END;

/
--------------------------------------------------------
--  DDL for Type TP_RUNT_CONTRIBUYENTES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_RUNT_CONTRIBUYENTES" AS OBJECT 
(
nro_placa VARCHAR2(10 BYTE),
id_usuario VARCHAR2(255 BYTE), 
digito_verificacion VARCHAR2(1 BYTE),
id_documento VARCHAR2(255 BYTE),
nombres VARCHAR2(255 BYTE),
apellidos VARCHAR2(255 BYTE),
direccion VARCHAR2(255 BYTE),
telefono VARCHAR2(255 BYTE),
fax VARCHAR2(255 BYTE),
email VARCHAR2(255 BYTE),
celular VARCHAR2(255 BYTE),
municipio VARCHAR2(255 BYTE),
departamento VARCHAR2(255 BYTE),
id_ciudad_dir VARCHAR2(255 BYTE),
radicado VARCHAR2(255 BYTE),
estado VARCHAR2(255 BYTE),
Constructor Function TP_RUNT_CONTRIBUYENTES Return Self As Result
)
/
CREATE OR REPLACE TYPE BODY "CONSULTAS"."TP_RUNT_CONTRIBUYENTES" AS

  Constructor Function TP_RUNT_CONTRIBUYENTES Return Self As Result AS
  
  TP_RUNT_CONTRIBUYENTES_1 TP_RUNT_CONTRIBUYENTES := TP_RUNT_CONTRIBUYENTES(null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null);
  
  BEGIN
         Self := TP_RUNT_CONTRIBUYENTES_1;
             Return;
  END TP_RUNT_CONTRIBUYENTES;

END;

/
--------------------------------------------------------
--  DDL for Type TP_RUNT_LISTA_CONTRIBUYENTES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "CONSULTAS"."TP_RUNT_LISTA_CONTRIBUYENTES" Is table of Tp_Runt_Contribuyentes;

/
--------------------------------------------------------
--  DDL for Package PGK_CONSULTAS_MASIVAS_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PGK_CONSULTAS_MASIVAS_TTO" AS 


Procedure Sp_Iniciar (as_Propietarios Simple_Integer,
                      as_Vehiculos Simple_Integer,
                      as_Novedades Simple_Integer,
                      as_Historico_Traspaso Simple_Integer);


END PGK_CONSULTAS_MASIVAS_TTO;

/
--------------------------------------------------------
--  DDL for Package PGK_REPORTE_VEHICULOS_ACTIVOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PGK_REPORTE_VEHICULOS_ACTIVOS" AS 

PROCEDURE sp_iniciar;

END PGK_REPORTE_VEHICULOS_ACTIVOS;

/
--------------------------------------------------------
--  DDL for Package PKG_CONSULTAS_MASIVAS_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_CONSULTAS_MASIVAS_RUNT" AS 

/*ISVA
Nombre     :PKG_CONSULTAS_MASIVAS_RUNT
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

Procedure Sp_Iniciar_Proceso (as_Propietarios Simple_Integer,
                              as_Vehiculos Simple_Integer,
                              as_Novedades Simple_Integer,
                              as_Historico_Traspaso Simple_Integer);

END PKG_CONSULTAS_MASIVAS_RUNT;

/
--------------------------------------------------------
--  DDL for Package PKG_DIRECCIONES_INTERLOCUTORES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_DIRECCIONES_INTERLOCUTORES" AS 

--Consulta el historico traspaso
PROCEDURE sp_consultar_traspaso_runt ; 

--Consulta el Digito de verificacion
PROCEDURE sp_consultar_digito_veri;

--Consulta el propietario
PROCEDURE sp_solo_propietario;

--Buscar Direccion solo con la cedula 
PROCEDURE sp_buscar_dir_documento;

--Buscar Direccion solo con cedula, tipo de documento y placa
PROCEDURE sp_buscar_direcciones;

END PKG_DIRECCIONES_INTERLOCUTORES;

/
--------------------------------------------------------
--  DDL for Package PKG_PROPIETARIOS_AUTOMOTOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_PROPIETARIOS_AUTOMOTOR" AS 

PROCEDURE sp_iniciar;

END PKG_PROPIETARIOS_AUTOMOTOR;

/
--------------------------------------------------------
--  DDL for Package PKG_REPORTE_LUISA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_REPORTE_LUISA" AS 

PROCEDURE sp_iniciar_reporte_pagos (an_vigencia number);

END PKG_REPORTE_LUISA;

/
--------------------------------------------------------
--  DDL for Package PKG_REPORTE_OMISOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_REPORTE_OMISOS" AS 

PROCEDURE sp_iniciar (an_vigencia_Anno NUMBER);

END PKG_REPORTE_OMISOS;

/
--------------------------------------------------------
--  DDL for Package PKG_REPORTE_PAGOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "CONSULTAS"."PKG_REPORTE_PAGOS" AS 

PROCEDURE SP_INICAR;

END PKG_REPORTE_PAGOS;

/
--------------------------------------------------------
--  DDL for Package Body PGK_CONSULTAS_MASIVAS_TTO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PGK_CONSULTAS_MASIVAS_TTO" AS

is_commit Simple_Integer:=0;
is_parametro Simple_Integer:=0;
Tp_Propietario Tp_Propietarios :=Tp_Propietarios();
Tp_Lista_Propietario Tp_Lista_Propietarios :=Tp_Lista_Propietarios();
is_Novedad_Matricula Simple_Integer:=9;
is_Novedad_Radicacion Simple_Integer:=10;
Tp_Lista_Error Tp_Lista_Errores:=Tp_Lista_Errores();
Tp_Error Tp_Errores:=Tp_Errores();
Tp_Vehiculo SYSTEM.Tp_Vehiculos:=system.Tp_Vehiculos();
Tp_lista_vehiculo system.Tp_lista_vehiculos:=system.Tp_lista_vehiculos();
iv_placa VARCHAR2(20); 
ltul_read UTL_FILE.FILE_TYPE; 
TYPE tp_placa IS VARRAY(1500000) OF VARCHAR(10);
Array_Placa tp_placa:=tp_placa();
iexception NUMBER;

PROCEDURE Sp_Cargar_Parametro AS

/*ISVA
Nombre     :Sp_Cargar_Parametro
Autor      :Blados.Ospina
Fecha      :11/05/18
Variables  :is_commit
Retorno    :              
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :Recupera placas para procesar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/05/2018  Blados.Ospina   1.0                     */

lv_placa Varchar2 (10 Byte):='';
ln_contador Number:=1;


Begin
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
        Loop
            Begin
                UTL_FILE.GET_LINE(ltul_read,lv_placa); 
                    Array_Placa.Extend;
                    Array_Placa(Array_Placa.Count) := lv_placa;
                EXCEPTION
                WHEN No_Data_Found THEN EXIT; 
            End;
        End Loop;    
        
End Sp_Cargar_Parametro;

Procedure Sp_Exception (av_Estado Varchar) As

/*ISVA
Nombre     :Sp_Exception
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :lv_Name_File_Error, v_Error 
Retorno    :              
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :2.1
Objetivo   :Capturar los errores y almacenarlos en archivo plano
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

lv_Name_File_Error Varchar2(255 byte):='Error_'||av_Estado||' '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_Error UTL_FILE.FILE_TYPE;

Begin
    If Tp_Lista_Error.Count()>0 Then
      v_Error:= UTL_FILE.FOPEN('DATA_TTO',lv_Name_File_Error,'W');
            For Ln_Index In 1..Tp_Lista_Error.Count() Loop
                UTL_FILE.PUT_LINE(v_Error,Tp_Lista_Error(Ln_Index).Nombre_Error||';'||Tp_Lista_Error(Ln_Index).Id_Error);
            End Loop;
       UTL_FILE.FCLOSE(v_Error);  
    End If;
End Sp_Exception;

Procedure sp_historico_traspaso As

/*ISVA
Nombre     :sp_historico_traspaso
Autor      :Blados.Ospina
Fecha      :17/09/2018
Variables  :lv_placas, lutl_read, lb_Existe
Variables  :lb_Existe_encabezado, lutl_write
Retorno    :              
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :Consulta el historico de traspasos Transito
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
17/09/2018 Blados.Ospina   1.0                     */

lv_Name_File VARCHAR2(255 byte):='Historico_Traspasos Transito '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
CURSOR lcur_historico_traspaso(av_placa VARCHAR)  IS SELECT DISTINCT Nro_Placa, id_usuario,tipo_documento_usuario,
                                                                     id_comprador,tipo_documento_comprador,porcentaje,
                                                                     REGEXP_REPLACE(fecha,'"','') As Fecha 
                                                     FROM bd_transitos.st_historiales_traspaso
                                                     WHERE nro_placa = av_placa;

lb_Existe_encabezado Boolean:=FALSE;
lb_Existe Boolean;
lutl_write UTL_FILE.FILE_TYPE;  

BEGIN
    lutl_write := UTL_FILE.FOPEN('DATA_TTO',lv_Name_File,'W'); 
    FOR ln_index_0 IN 1..Array_Placa.COUNT LOOP
        BEGIN 

         lb_Existe:=FALSE;
            IF lb_Existe_encabezado = FALSE THEN
                  UTL_FILE.PUT_LINE(lutl_write,'NRO_PLACA;'||'ID_VENDEDOR;'||'TIPO_DOCUMENTO_VENDEDOR;'||'ID_COMPRADOR;'
                                                           ||'TIPO_DOCUMENTO_COMPRADOR;'||'PORCENTAJE;'||'FECHA_TRAMITE');
                        lb_Existe_encabezado:=TRUE;
            END IF;
            FOR ln_index IN lcur_historico_traspaso(Array_Placa(ln_index_0)) LOOP
                    UTL_FILE.PUT_LINE(lutl_write,
                            Ln_Index.Nro_Placa||';'
                            ||Ln_Index.id_usuario||';'
                            ||Ln_Index.tipo_documento_usuario||';'
                            ||Ln_Index.id_comprador||';'
                            ||Ln_Index.tipo_documento_comprador||';'
                            ||Ln_Index.porcentaje||';'
                            ||Ln_Index.Fecha);
                        lb_Existe:= TRUE;  
            END LOOP;
            IF lb_Existe = FALSE THEN
                UTL_FILE.PUT_LINE(lutl_write,Array_Placa(ln_index_0)||';'||'No registra propietario');
            END IF;
            
            EXCEPTION 
            WHEN No_Data_Found THEN EXIT;
            WHEN OTHERS THEN
             Tp_Error.Id_Error:=sqlerrm;
             Tp_Error.Nombre_Error:=iv_placa||';'||Dbms_Utility.Format_Error_Backtrace;
             Tp_Lista_Error.EXTEND;
             Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
             CONTINUE;
        END;
    END LOOP;
      UTL_FILE.FCLOSE(lutl_write);
    
    Sp_Exception('Historiales_Traspasos Tto');
END sp_historico_traspaso;

PROCEDURE Sp_Consultar_Novedades_Tto AS

/*ISVA
Nombre     :Sp_Consultar_Novedades
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :lcur_placa, Lcur_Novedad, v_MyFileHandle
Retorno    :              
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :2.1
Objetivo   :Capturar los errrore y alamcenarlos en archivo plano
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0             */

lb_Existe BOOLEAN:=FALSE;
lv_Name_File VARCHAR2(255 BYTE):='Novedades Tto '||To_Char(SYSDATE,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Cursor Lcur_Novedad(av_nro_placa VARCHAR) IS SELECT DISTINCT 
                                                    St.Nro_Placa AS Placa,
                                                    St.Nombre_Tramite AS Tramite,
                                                    TO_dATE(Decode(Length(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) As Fecha,
                                                    Fm.Municipio AS Destino, 
                                                    Fr.Municipio AS Origen,
                                                    St.Nombre_Servicio_Anterior AS Servicio_Anterior,
                                                    St.Nombre_Servicio_Nuevo AS Servicion_nuevo,
                                                    Sr.Municipio AS Transito
                                                FROM Bd_Transitos.St_Tramites St
                                                LEFT JOIN Bd_Fiscalizacion.Fc_Municipio_Departamento fm ON Fm.Divipo = Id_Secretaria_Destino
                                                LEFT JOIN Bd_Fiscalizacion.Fc_Municipio_Departamento fr ON Fr.Divipo = Id_Secretaria_Origen
                                                INNER JOIN Bd_Transitos.St_Maestro Sm On Sm.Id_Radicado = St.Id_Radicado
                                                INNER JOIN Bd_Fiscalizacion.Fc_Municipio_Departamento Sr On Sr.Divipo = Sm.Id_Secretaria
                                                WHERE St.Id_tramite IN (1,5,6,9,10,13,15,20,65)
                                                    AND St.Nro_Placa = av_nro_placa
                                                ORDER BY 3 DESC;


  BEGIN
     v_MyFileHandle := UTL_FILE.FOPEN('DATA_TTO',lv_Name_File,'W');  
       FOR ln_index_0 IN 1..Array_Placa.COUNT() Loop
        BEGIN
            FOR Ln_Index_2 IN Lcur_Novedad(Array_Placa(ln_index_0)) LOOP
                BEGIN
                    IF lb_Existe = FALSE Then
                        UTL_FILE.PUT_LINE(v_MyFileHandle,'PLACA'||';'||'TRAMITE'||';'||'FECHA_TRAMITE'||';'||
                                                         'SECRETARIA_DESTINO'||';'||'SECRETARIA_ORIGEN'||';'||
                                                         'SERVICIO_ANTERIOR'||';'||'SERVICIO_NUEVO'||';'||'TRANSITO');
                        lb_Existe:=True;
                    END IF;
                        UTL_FILE.PUT_LINE(v_MyFileHandle,
                        Ln_Index_2.Placa||';'
                        ||Ln_Index_2.Tramite||';'
                        ||Ln_Index_2.Fecha||';'
                        ||Ln_Index_2.Destino||';'
                        ||Ln_Index_2.Origen||';'
                        ||Ln_Index_2.Servicio_Anterior||';'    
                        ||Ln_Index_2.Servicion_nuevo||';'    
                        ||Ln_Index_2.Transito);
                            
                     EXCEPTION
                        WHEN OTHERS THEN         
                            tp_Error.Id_Error:=sqlerrm;
                            tp_Error.Nombre_Error:=ln_index_2.Placa||';'||Dbms_Utility.Format_Error_Backtrace;
                            Tp_Lista_Error.EXTEND;
                            Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                            CONTINUE;
                END;
            END LOOP;
                   EXCEPTION
                       WHEN No_Data_Found THEN EXIT; 
                       WHEN OTHERS THEN
                           Tp_Error.Id_Error:=sqlerrm;
                           Tp_Error.Nombre_Error:=Array_Placa(ln_index_0)||';'||Dbms_Utility.Format_Error_Backtrace;
                           Tp_Lista_Error.EXTEND;
                           Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                           CONTINUE;
              END;
       END LOOP;
        UTL_FILE.FCLOSE(v_MyFileHandle);  
        
        Sp_Exception('Novedades Tto');
END Sp_Consultar_Novedades_Tto;

PROCEDURE Sp_Reset_Tp_Vehiculos AS

/*ISVA
Nombre     :Sp_Reset_Tp_Vehiculos
Autor      :Blados.Ospina
Fecha      :11/09/2018
Parametros :
Variables  :
Retorno    :        
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :restablece los datos por defecto
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/09/2018  Blados.Ospina    1.0                     */
Begin
      Tp_vehiculo.nro_placa := '';
      Tp_vehiculo.nombre_marca := '';
      Tp_vehiculo.nombre_linea := '';
      Tp_vehiculo.modelo := '';
      Tp_vehiculo.nombre_clase := '';
      Tp_vehiculo.nombre_servicio := '';
      Tp_vehiculo.nombre_carroceria := '';
      Tp_vehiculo.nro_puertas := '';
      Tp_vehiculo.potencia := '';
      Tp_vehiculo.id_secretaria :='';
      Tp_vehiculo.nombre_secretaria := '';
      Tp_vehiculo.cilindraje := '';
      Tp_vehiculo.cap_pasajeros := '';
      Tp_vehiculo.cap_toneladas := '';
      Tp_vehiculo.valor_factura := '';
      Tp_vehiculo.blindado := '';
      Tp_vehiculo.nombre_estado := '';
      Tp_vehiculo.clasico_antiguo := '';
      Tp_vehiculo.fecha_matriculo := '';
      Tp_vehiculo.caja := '';
      Tp_vehiculo.traccion := '';
      Tp_vehiculo.combustion := '';
ENd;

FUNCTION ft_transito (an_id_radicado NUMBER) RETURN VARCHAR AS

lv_transito VARCHAR2 (255 BYTE):='';

BEGIN
    SELECT Distinct fc.municipio INTO lv_transito FROM bd_transitos.st_maestro st
    INNER JOIN bd_fiscalizacion.fc_municipio_departamento fc ON st.id_secretaria = fc.divipo
    WHERE id_radicado = an_id_radicado And Rownum = 1;
        RETURN lv_transito;
        
EXCEPTION 
WHEN OTHERS THEN
   RETURN lv_transito;  
END ft_transito;

Procedure Sp_Datos_Vehiculos (av_placa Varchar, an_id_radicado Number)  As 

/*ISVA
Nombre     :Sp_Datos_Vehiculos
Autor      :Blados.Ospina
Fecha      :11/09/2018
Parametros :av_placa, an_id_radicado
Variables  :lcur_Vehiculos
Retorno    :        
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :Almacena las caracteristicas consultadas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/09/2018  Blados.Ospina    1.0                     */

Cursor lcur_Vehiculos Is Select nro_placa,nombre_marca,nombre_linea,modelo,nombre_clase,nombre_servicio,nombre_carroceria,
                                nro_puertas,potencia,id_secretaria,nombre_secretaria,cilindraje,cap_pasajeros,cap_toneladas,
                                valor_factura,blindado,nombre_estado,clasico_antiguo,fecha_matriculo,caja,traccion,combustion
                         From bd_transitos.st_vehiculos
                         Where Nro_placa = av_placa And id_radicado = an_id_radicado
                         Order By nro_placa,nombre_marca,nombre_linea ,modelo,nombre_clase,nombre_servicio,nombre_carroceria,
                                nro_puertas,potencia,id_secretaria,nombre_secretaria,cilindraje,cap_pasajeros,cap_toneladas,
                                valor_factura,blindado,nombre_estado,clasico_antiguo,fecha_matriculo,caja,traccion,combustion;


Begin
    For ln_index In lcur_Vehiculos Loop
        Begin
            Tp_vehiculo.nro_placa := ln_index.nro_placa;
            Tp_vehiculo.nombre_marca := ln_index.nombre_marca;
            Tp_vehiculo.nombre_linea := ln_index.nombre_linea;
            Tp_vehiculo.modelo := ln_index.modelo;
            Tp_vehiculo.nombre_clase := ln_index.nombre_clase;
            Tp_vehiculo.nombre_servicio := ln_index.nombre_servicio;
            Tp_vehiculo.nombre_carroceria := ln_index.nombre_carroceria;
            Tp_vehiculo.nro_puertas := ln_index.nro_puertas;
            Tp_vehiculo.potencia := ln_index.potencia;
            Tp_vehiculo.id_secretaria := ln_index.id_secretaria;
            Tp_vehiculo.nombre_secretaria := ln_index.nombre_secretaria;
            Tp_vehiculo.cilindraje := ln_index.cilindraje;
            Tp_vehiculo.cap_pasajeros := ln_index.cap_pasajeros;
            Tp_vehiculo.cap_toneladas := ln_index.cap_toneladas;
            Tp_vehiculo.valor_factura := ln_index.valor_factura;
            Tp_vehiculo.blindado := ln_index.blindado;
            Tp_vehiculo.nombre_estado := ln_index.nombre_estado;
            Tp_vehiculo.clasico_antiguo := ln_index.clasico_antiguo;
            Tp_vehiculo.fecha_matriculo := ln_index.fecha_matriculo;
            Tp_vehiculo.caja := ln_index.caja;
            Tp_vehiculo.traccion := ln_index.traccion;
            Tp_vehiculo.combustion := ln_index.combustion;
            Tp_vehiculo.transito :=ft_transito(an_id_radicado);
                 EXCEPTION
                 WHEN OTHERS THEN
                 Tp_Error.Id_Error:='Error_Placa'||';';
                 Tp_Error.Nombre_Error:=ln_index.nro_placa;
                 Tp_Lista_Error.Extend;
                 Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;
        End;
    End Loop;
End Sp_Datos_Vehiculos;

Procedure sp_Registrar_caracteristicas As

/*ISVA
Nombre     :sp_Registrar_caracteristicas
Autor      :Blados.Ospina
Fecha      :11/09/2018
Parametros :
Variables  :lv_Name_File, lb_encabezado, lutl_write
Retorno    :        
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :Genera el archivo plano con las caracteristicas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/09/2018  Blados.Ospina    1.0                     */

lv_Name_File Varchar2(255 byte):='Vehiculos Tto '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_encabezado Boolean:=False;
lutl_write UTL_FILE.FILE_TYPE;

Begin
    If Tp_Lista_Vehiculo.Count()>0 Then 
        lutl_write := UTL_FILE.FOPEN('DATA_TTO',lv_Name_File,'W'); 
        For ln_index In 1..Tp_Lista_Vehiculo.Count() Loop
            Begin
            
                 If  Tp_lista_vehiculo(Ln_Index).nro_placa is not null Then
                    If lb_encabezado = False Then
                         UTL_FILE.PUT_LINE(lutl_write,'NRO_PLACA;'||'NOMBRE_MARCA;'||'NOMBRE_LINEA;'||'MODELO;'||'NOMBRE_CLASE;'
                                ||'NOMBRE_SERVICIO;'||'NOMBRE_CARROCERIA;'||'NRO_PUERTAS;'||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'
                                ||'CILINDRAJE;'||'CAP_PASAJEROS;'||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'NOMBRE_ESTADO;'
                                ||'CLASICO_ANTIGUO;'||'FECHA_MATRICULO;'||'CAJA;'||'TRACCION;'||'COMBUSTION;'||'TRANSITO');
                         lb_encabezado:=True;
                    End If;
                    UTL_FILE.PUT_LINE(lutl_write,Tp_lista_vehiculo(Ln_Index).nro_placa||';'||Tp_lista_vehiculo(Ln_Index).nombre_marca||';'
                    ||Tp_lista_vehiculo(Ln_Index).nombre_linea||';'||Tp_lista_vehiculo(Ln_Index).modelo||';'||Tp_lista_vehiculo(Ln_Index).nombre_clase||';'
                    ||Tp_lista_vehiculo(Ln_Index).nombre_servicio||';'||Tp_lista_vehiculo(Ln_Index).nombre_carroceria||';'
                    ||Tp_lista_vehiculo(Ln_Index).nro_puertas||';'||Tp_lista_vehiculo(Ln_Index).potencia||';'
                    ||Tp_lista_vehiculo(Ln_Index).id_secretaria||';'||Tp_lista_vehiculo(Ln_Index).nombre_secretaria||';'
                    ||Tp_lista_vehiculo(Ln_Index).cilindraje||';'||Tp_lista_vehiculo(Ln_Index).cap_pasajeros||';'||Tp_lista_vehiculo(Ln_Index).cap_toneladas||';'
                    ||Tp_lista_vehiculo(Ln_Index).valor_factura||';'||Tp_lista_vehiculo(Ln_Index).blindado||';'||Tp_lista_vehiculo(Ln_Index).nombre_estado||';'
                    ||Tp_lista_vehiculo(Ln_Index).clasico_antiguo||';'||Tp_lista_vehiculo(Ln_Index).fecha_matriculo||';'||Tp_lista_vehiculo(Ln_Index).caja||';'
                    ||Tp_lista_vehiculo(Ln_Index).traccion||';'||Tp_lista_vehiculo(Ln_Index).combustion||';'||Tp_lista_vehiculo(Ln_Index).transito);   
                End If;
                Exception
                When Others Then
                    Tp_Error.Id_Error:='Error_Placa'||';';
                    Tp_Error.Nombre_Error:=Tp_lista_vehiculo(Ln_Index).nro_placa;
                    Tp_Lista_Error.Extend;
                    Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;
            End;
        End Loop;
      UTL_FILE.FCLOSE(lutl_write);  
    End If;
    
        Sp_Exception('Vehiculos Tto');
End sp_Registrar_caracteristicas;

Procedure Sp_Consult_Caracteristicas_Tto AS

/*ISVA
Nombre     :Sp_Caracteristicas
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :lt_Error_Nov, lv_Name_File, v_MyFileHandle
           :lcur_placa, lcur_vehiculos, lb_Existe, lb_Abrir
           :ld_fecha, ls_id_radicado
Retorno    :              
Proyecto   :QAS
Versi�n    :2.1
Objetivo   :Trae las caracteristicas de vehiculos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */
                   
lb_Existe Boolean:=False;
lb_Abrir Boolean:=False;
ld_fecha Date;
ls_id_radicado Number:=0;
--lv_placa Varchar2 (10 Byte):='';

Begin
        For ln_index In 1..Array_Placa.Count() Loop
            Begin
           Sp_Reset_Tp_Vehiculos;
            ls_id_radicado:=0;
                ld_fecha:= Substr(system.Pkg_utilitario.ft_Fecha_Maxima(Array_Placa(ln_index)),1,10);
                    If ld_fecha is not null Then
                        ls_id_radicado:= system.Pkg_utilitario.ft_Max_Rad_Vehiculos(Array_Placa(ln_index),(ld_fecha));
                            ls_id_radicado:=system.pkg_utilitario.ft_homologar_radicado (Array_Placa(ln_index),ls_id_radicado);
                                If  ls_id_radicado is not null And ls_id_radicado > 0 Then
                                    Sp_Datos_Vehiculos(Array_Placa(ln_index),ls_id_radicado);
                                Else
                                    Tp_vehiculo.Nro_placa:=Array_Placa(ln_index);
                                    Tp_vehiculo.Nombre_marca:='No hay Informacion';  
                                End If;
                    Else
                        lb_Existe:= system.Pkg_utilitario.ft_Existe_Registro_Vehiculo(av_placa => Array_Placa(ln_index));
                            If lb_Existe = True Then
                               ls_id_radicado:=system.pkg_utilitario.ft_Max_Rad_Vehiculos(av_placa => Array_Placa(ln_index));
                               Sp_Datos_Vehiculos(Array_Placa(ln_index),ls_id_radicado);
                            Else
                                Tp_vehiculo.Nro_placa:=Array_Placa(ln_index);
                                Tp_vehiculo.Nombre_marca:='No hay Informacion';
                            End If;
                    End If;
         Exception
         WHEN No_Data_Found THEN EXIT; 
         WHEN OTHERS THEN
             Tp_Error.Id_Error:='Error_Placa'||';';
             Tp_Error.Nombre_Error:=Array_Placa(ln_index);
             Tp_Lista_Error.Extend;
             Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;
    End;
    
     Tp_Lista_Vehiculo.Extend;
     Tp_Lista_Vehiculo(Tp_Lista_Vehiculo.Count()):=Tp_Vehiculo;
    End Loop;
        UTL_FILE.FCLOSE(ltul_read);
    sp_Registrar_caracteristicas;     
    
End Sp_Consult_Caracteristicas_Tto;

Procedure sp_reset_tp_propietario As

/*ISVA
Nombre     :Ft_Radica_Matricul_Ini
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/05/2018  Blados.Ospina   1.0                     */

Begin
        Tp_Propietario.Nro_Placa:='';
        Tp_Propietario.Tipo_Documento_Vendedor:='';
        Tp_Propietario.Id_Vendedor:='';
        Tp_Propietario.Tipo_Documento_Comprador:='';
        Tp_Propietario.Id_Comprador:='';
        Tp_Propietario.Porcentaje:='';
        Tp_Propietario.Fecha:='';
        Tp_Propietario.Transito:='';
        Tp_Propietario.Id_Documento_Propietario:='';
        Tp_Propietario.Id_Propieario:='';
        Tp_Propietario.estado:='';

End sp_reset_tp_propietario;

FUNCTION ft_fecha_traspaso (av_placa VARCHAR) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_fecha_traspaso
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :av_placa
Variables  :lv_fecha
Retorno    :lv_fecha             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :recupera la fecha maxima
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion
                                                    */

lv_fecha VARCHAR2(255 BYTE):='';

BEGIN
  SELECT MAX(TO_DATE(TRANSLATE(fecha,'.AaMmPpm','      '),'DD/MM/YY HH24:MI:SS')) INTO lv_fecha FROM bd_transitos.st_historiales_traspaso
  WHERE nro_placa = av_placa;
    
    RETURN lv_fecha;

EXCEPTION
WHEN OTHERS THEN
RETURN lv_fecha;

Tp_Error.Id_Error:='Error_Placa'||';';
Tp_Error.Nombre_Error:=av_placa;
Tp_Lista_Error.Extend;
Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;

DBMS_OUTPUT.PUT_LINE(av_placa);

END ft_fecha_traspaso;

PROCEDURE sp_historiales_traspaso_2 (av_placa VARCHAR) AS

/*ISVA
Nombre     :Ft_Historiales_Traspaso
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                     */

CURSOR lcur_histo_traspaso(ad_fecha VARCHAR) IS SELECT DISTINCT nro_Placa,Tipo_Documento_Usuario AS Documento_Vendedor, 
                                              Id_Usuario AS Vendedor,Tipo_Documento_Comprador AS Documento_Comprador, 
                                              Id_Comprador AS Comprador, Porcentaje AS Porcentaje,
                                              fecha As Fecha_Tramite, 
                                              Id_Radicado AS Transito
                                    FROM Bd_Transitos.St_Historiales_Traspaso
                                    WHERE Nro_Placa = av_placa
                                    AND TO_DATE(SUBSTR(fecha,1,8)) = ad_fecha;
BEGIN 
    iexception:=1;
  IF System.Pkg_Utilitario.Ft_Existe_His_Traspaso(av_placa) = TRUE THEN  
    FOR Ln_Index In lcur_histo_traspaso(ft_fecha_traspaso(av_placa)) LOOP
        BEGIN  
        Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
        Tp_Propietario.Tipo_Documento_Vendedor:= Ln_Index.Documento_Vendedor;
        Tp_Propietario.Id_Vendedor:=Ln_Index.Vendedor;
        Tp_Propietario.Tipo_Documento_Comprador:= Ln_Index.Documento_Comprador;
        Tp_Propietario.Id_Comprador:= Ln_Index.Comprador;
        Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
        Tp_Propietario.Fecha:= Ln_Index.Fecha_Tramite;
        Tp_Propietario.Estado := 'Traspaso';
        Tp_Propietario.Transito:= SYSTEM.Pkg_Utilitario.Ft_Registrar_Transito(Ln_Index.Transito);
        
             Tp_Lista_Propietario.EXTEND;
             Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
            EXCEPTION 
                WHEN OTHERS THEN
                    Tp_Error.Id_Error:=sqlerrm;
                    Tp_Error.Nombre_Error:=ln_index.Nro_Placa||';'||Dbms_Utility.Format_Error_Backtrace;
                    Tp_Lista_Error.EXTEND;
                    Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                    CONTINUE;
        END;
    END LOOP; 
  END IF;  
END sp_Historiales_Traspaso_2;

FUNCTION ft_historiales_traspaso (av_placa VARCHAR) RETURN Boolean AS

/*ISVA
Nombre     :Ft_Historiales_Traspaso
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Version    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                     */

lb_Existe BOOLEAN:=FALSE;

CURSOR lcur_histo_traspaso(ad_fecha VARCHAR) IS SELECT DISTINCT nro_Placa,Tipo_Documento_Usuario AS Documento_Vendedor, 
                                              Id_Usuario AS Vendedor,Tipo_Documento_Comprador AS Documento_Comprador, 
                                              Id_Comprador AS Comprador, Porcentaje AS Porcentaje,
                                              fecha As Fecha_Tramite, 
                                              Id_Radicado AS Transito
                                    FROM Bd_Transitos.St_Historiales_Traspaso
                                    WHERE Nro_Placa = av_placa
                                    AND TO_DATE(SUBSTR(fecha,1,10)) = ad_fecha;
BEGIN 
  IF System.Pkg_Utilitario.Ft_Existe_His_Traspaso(av_placa) = TRUE THEN  
    FOR Ln_Index In lcur_histo_traspaso(ft_fecha_traspaso(av_placa)) LOOP
        BEGIN  
        Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
        Tp_Propietario.Tipo_Documento_Vendedor:= Ln_Index.Documento_Vendedor;
        Tp_Propietario.Id_Vendedor:=Ln_Index.Vendedor;
        Tp_Propietario.Tipo_Documento_Comprador:= Ln_Index.Documento_Comprador;
        Tp_Propietario.Id_Comprador:= Ln_Index.Comprador;
        Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
        Tp_Propietario.Fecha:= Ln_Index.Fecha_Tramite;
        Tp_Propietario.Estado := 'Traspaso';
        Tp_Propietario.Transito:= SYSTEM.Pkg_Utilitario.Ft_Registrar_Transito(Ln_Index.Transito);
        
             Tp_Lista_Propietario.EXTEND;
             Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
            EXCEPTION 
                WHEN OTHERS THEN
                    Tp_Error.Id_Error:=sqlerrm;
                    Tp_Error.Nombre_Error:=ln_index.Nro_Placa||';'||Dbms_Utility.Format_Error_Backtrace;
                    Tp_Lista_Error.EXTEND;
                    Tp_Lista_Error(Tp_Lista_Error.COUNT()):=Tp_Error;
                    CONTINUE;
        END;
        lb_Existe:=TRUE;
    END LOOP; 
  END IF;  
    
        RETURN lb_Existe;

END Ft_Historiales_Traspaso;

FUNCTION ft_solo_propietario (av_nro_placa VARCHAR) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_solo_propietario
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :av_nro_placa
Variables  :lb_Existe, lcur_prop
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/05/2018  Blados.Ospina   1.0                     */

lb_Existe Boolean:=False;

Cursor lcur_prop Is Select Distinct sp.Nro_Placa As Nro_Placa, sp.Id_Documento As documento, sp.Id_Usuario As  Usuario,
                                    sp.porcentaje_prop As Porcentaje, fmd.municipio As Transito 
                    From bd_transitos.st_propietarios sp
                    Inner join bd_transitos.st_maestro sm On sm.id_radicado = sp.id_radicado
                    Inner Join bd_fiscalizacion.fc_municipio_departamento fmd On fmd.divipo = sm.id_secretaria
                    Where sp.nro_placa = av_nro_placa;


Begin
    For ln_index In lcur_prop Loop
          Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
          Tp_Propietario.Id_Documento_Propietario := Ln_Index.documento;
          Tp_Propietario.Id_Propieario := Ln_Index.usuario; 
          Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
          Tp_Propietario.Transito := Ln_Index.Transito;
          Tp_Propietario.Estado := 'Propietarios, no registra tramite';
          
           Tp_Lista_Propietario.Extend;
           Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
          
          lb_Existe:= True;
    End Loop;
  
    
    Return lb_Existe;
    
End ft_solo_propietario;

FUNCTION ft_radica_matricul_ini (av_placa VARCHAR,as_id_novedad SIMPLE_INTEGER) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_radica_matricul_ini
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :av_placa
Variables  :lb_Existe, lcur_histo_traspaso
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera los parametros para la cantidad de commit
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                            */

lb_Existe Boolean:=FALSE;

CURSOR lcur_radi_Maricula(ad_fecha DATE) IS SELECT DISTINCT St.Nro_Placa,Sp.Porcentaje_Prop AS Porcentaje, 
                          To_Date(CASE 
                               WHEN LENGTH(St.Fecha_Tramite) = 8 THEN
                                    St.Fecha_Tramite
                               WHEN LENGTH(St.Fecha_Tramite) > 8 THEN
                                  Substr(St.Fecha_Tramite,1,8)
                                WHEN LENGTH(St.Fecha_Tramite) = 7 THEN
                                  '0'||St.Fecha_Tramite
                              ELSE NULL END) AS Fecha_Tramite,
                                  --St.Id_Radicado As Transito_Tramite, 
                                  fmd.municipio AS Transito, 
                                  Sp.Id_Documento AS Documento, Sp.Id_Usuario AS Usuario
                          FROM Bd_Transitos.St_Tramites St
                          INNER JOIN Bd_Transitos.St_Propietarios Sp ON Sp.Nro_Placa = St.Nro_Placa
                          INNER JOIN Bd_Transitos.St_Maestro St1 ON St1.id_radicado = St.Id_Radicado
                          INNER JOIN Bd_Transitos.St_Maestro St2 ON St2.id_radicado =  Sp.Id_Radicado
                          INNER JOIN Bd_fiscalizacion.fc_municipio_departamento fmd ON fmd.divipo = st1.id_secretaria 
                          WHERE St.Nro_Placa = av_placa  And Id_Tramite = as_id_novedad AND st1.id_secretaria = st2.id_secretaria
                          AND TO_DATE(Decode(LENGTH(St.Fecha_Tramite),7,'0'||St.Fecha_Tramite,St.Fecha_Tramite)) = ad_fecha;
BEGIN
   
        IF SYSTEM.Pkg_Utilitario.ft_Existe_Registro (av_placa,as_id_novedad) = TRUE THEN
                    
                FOR Ln_Index IN lcur_radi_Maricula(SYSTEM.Pkg_Utilitario.ft_Fecha_Maxima (av_Placa,as_id_novedad )) LOOP
                     Tp_Propietario.Nro_Placa:= Ln_Index.Nro_placa;
                     Tp_Propietario.Porcentaje:= Ln_Index.Porcentaje;
                     Tp_Propietario.fecha := Ln_Index.Fecha_Tramite;
                     Tp_Propietario.Transito := Ln_Index.Transito;
                     Tp_Propietario.Id_Documento_Propietario := Ln_Index.documento;
                     Tp_Propietario.Id_Propieario := Ln_Index.usuario;
                     IF  as_id_novedad = 10 THEN
                        Tp_Propietario.Estado := 'Radicacion';
                     ELSE
                        Tp_Propietario.Estado := 'Matricula Inicial';
                     END IF;
                     
                     Tp_Lista_Propietario.EXTEND;
                     Tp_Lista_Propietario(Tp_Lista_Propietario.COUNT()):=Tp_Propietario;
                     
                    lb_Existe:= TRUE;
                END LOOP;
        END IF;
        
     RETURN lb_Existe;
     
END Ft_Radica_Matricul_Ini;

PROCEDURE Sp_Consultar_Propietarios_Tto AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Tto
Autor      :Blados.Ospina
Fecha      :05/12/2018
Parametros :
Variables  :lv_Name_File, v_prop, lcur_placas
Variables  :lb_Ingresado, lv_Resultado, tp_Placa
Variables  :lb_Existe
Retorno    :lb_Existe             
Proyecto   :PKG_HISTORIALES_TRASPASOS
Versi�n    :1.0
Objetivo   :Recupera las placas a procesar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_Name_File VARCHAR2(255 byte):='Propietarios Tto'||' '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_prop UTL_FILE.FILE_TYPE;
ltul_read UTL_FILE.FILE_TYPE; 

lb_Ingresado Boolean;
lv_Resultado VARCHAR2(1 BYTE);

lb_Existe Boolean:=FALSE;

BEGIN
    FOR ln_index_0 IN 1..Array_Placa.COUNT LOOP
       BEGIN
        lb_Ingresado := FALSE;
            sp_reset_tp_propietario;
                        
                        --Valido si tiene traspaso
                        lb_Ingresado := Ft_Historiales_Traspaso(Array_Placa(ln_index_0));
                        
                        iexception:=2;
                        --Radicacion
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado :=Ft_Radica_Matricul_Ini(Array_Placa(ln_index_0),is_Novedad_Radicacion);
                        END IF;
                        
                        --Matricula Inicial
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado :=Ft_Radica_Matricul_Ini(Array_Placa(ln_index_0),is_Novedad_Matricula);
                        END IF;
                        
                        --Solo Propietario
                        IF lb_Ingresado = FALSE THEN
                               lb_Ingresado:= ft_solo_propietario(Array_Placa(ln_index_0));
                        END IF;
                        
                        IF lb_Ingresado = FALSE THEN
                              Tp_Propietario.Nro_Placa:= Array_Placa(ln_index_0);
                              Tp_Propietario.Estado := 'No hay informacion';
          
                              Tp_Lista_Propietario.EXTEND;
                              Tp_Lista_Propietario(Tp_Lista_Propietario.Count()):=Tp_Propietario;
                        END IF; 
              EXCEPTION
              WHEN No_Data_Found THEN EXIT; 
              WHEN OTHERS THEN
                    IF iexception = 0 THEN
                        sp_historiales_traspaso_2(Array_Placa(ln_index_0));
                    ELSE
                          Tp_Error.Id_Error:='Error_Placa'||';';
                          Tp_Error.Nombre_Error:=Array_Placa(ln_index_0);
                          Tp_Lista_Error.Extend;
                          Tp_Lista_Error(Tp_Lista_Error.Count()):=Tp_Error;
                    END IF;    
        END;
    END LOOP;
          UTL_FILE.FCLOSE(ltul_read); 
        
    If Tp_Lista_Propietario.COUNT()>0 THEN
      v_prop:= UTL_FILE.FOPEN('DATA_TTO',lv_Name_File,'W');
            FOR Ln_Index IN 1..Tp_Lista_Propietario.COUNT() LOOP
                    IF lb_Existe = FALSE THEN
                        UTL_FILE.PUT_LINE(v_prop,'NRO_PLACA;'||'TIPO_DOCUMENTO_VENDEDOR;'||'ID_VENDECOR;'||
                                                         'TIPO_DOCUMENTO_COMPRADOR;'||'ID_COMPRADOR;'||'PORCENTAJE;'||'FECHA;'||
                                                         'TRANSITO;'||'ID_DOCUMENTO_PROPIETARIO;'||'ID_PROPIETARIOS;'||'ESTADO');
                        lb_Existe:=TRUE;
                    END IF;
                        UTL_FILE.PUT_LINE(v_prop,Tp_Lista_Propietario(Ln_Index).Nro_placa||';'
                        ||Tp_Lista_Propietario(Ln_Index).Tipo_Documento_Vendedor||';'||Tp_Lista_Propietario(Ln_Index).Id_Vendedor||';'
                        ||Tp_Lista_Propietario(Ln_Index).Tipo_Documento_Comprador||';'||Tp_Lista_Propietario(Ln_Index).Id_Comprador||';'
                        ||Tp_Lista_Propietario(Ln_Index).Porcentaje||';'||Tp_Lista_Propietario(Ln_Index).Fecha||';'
                        ||Tp_Lista_Propietario(Ln_Index).Transito||';'||Tp_Lista_Propietario(Ln_Index).Id_Documento_Propietario||';'
                        ||Tp_Lista_Propietario(ln_index).Id_Propieario||';'||Tp_Lista_Propietario(ln_index).estado);
                          
            END LOOP;
           UTL_FILE.FCLOSE(v_prop); 
         
    END IF;
        Sp_Exception('Propietarios Tto');
    
END Sp_Consultar_Propietarios_Tto;

Procedure Sp_Iniciar (as_Propietarios Simple_Integer,
                      as_Vehiculos Simple_Integer,
                      as_Novedades Simple_Integer,
                      as_Historico_Traspaso Simple_Integer) As

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Tto
Autor      :Blados.Ospina
Fecha      :11/05/18
Parametros :as_Propietarios, as_Vehiculos, as_Novedades
Variables  :
Retorno    :            
Proyecto   :PGK_CONSULTAS_MASIVAS_TTO
Versi�n    :1.0
Objetivo   :El encargado de iniciar y unir los procesos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/05/2018  Blados.Ospina   1.0                     */

Begin
    sp_cargar_parametro;
        
    If  as_Novedades = 1 Then
        Sp_Consultar_Novedades_Tto;
    End If;
    If as_Propietarios = 1 Then
        Sp_Consultar_Propietarios_Tto;
    End If;
    If as_Vehiculos = 1 Then
        Sp_Consult_Caracteristicas_Tto;
    End If; 
    If as_Historico_Traspaso = 1 Then
        sp_historico_traspaso;
    End If; 
    
End Sp_Iniciar;

END PGK_CONSULTAS_MASIVAS_TTO;

/
--------------------------------------------------------
--  DDL for Package Body PGK_REPORTE_VEHICULOS_ACTIVOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PGK_REPORTE_VEHICULOS_ACTIVOS" AS

PROCEDURE sp_generar_reporte AS


lv_Name_File Varchar2(255 byte):='Vehiculos Sujetos del cobro '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe_encabezado Boolean:=FALSE;
lu_escribir_archivo UTL_FILE.FILE_TYPE;
CURSOR lcur_vehi_activos IS SELECT NRO_PLACA, ID_TRANSITO, NOMBRE_TRANSITO, NOMBRE_MARCA, NOMBRE_LINEA, MODELO, 
                                   NOMBRE_CLASE, NOMBRE_SERVICIO, NOMBRE_CARROCERIA, CILINDRAJE, CAPACIDAD_CARGA, 
                                   FECHA_MATRICULA, MODALIDAD, COMBUSTIBLE 
                            FROM BD_FISCALIZACION.FC_AUTOMOTOR                            --CILINDARJE INFERIOR 125 CC
                            WHERE NOMBRE_SERVICIO IN ('PARTICULAR') AND NRO_PLACA NOT IN (SELECT NRO_PLACA from BD_FISCALIZACION.FC_AUTOMOTOR   
                            WHERE NOMBRE_CLASE IN ('CICLOMOTOR','CUADRICICLO','MOTOTRICICLO','MOTOCICLETA','MOTOCARRO','CUATRIMOTO') 
                            AND TO_NUMBER(CILINDRAJE) BETWEEN 48 AND 125 AND COMBUSTIBLE NOT IN ('ELECTRICO'))
                            UNION
                            --VEHICULOS OFICIALES CILINDRAJE MAYOR A 125 CC
                            SELECT NRO_PLACA, ID_TRANSITO, NOMBRE_TRANSITO, NOMBRE_MARCA, NOMBRE_LINEA, MODELO, 
                                   NOMBRE_CLASE, NOMBRE_SERVICIO, NOMBRE_CARROCERIA, CILINDRAJE, CAPACIDAD_CARGA, 
                                   FECHA_MATRICULA, MODALIDAD, COMBUSTIBLE 
                            FROM BD_FISCALIZACION.FC_AUTOMOTOR
                            WHERE NOMBRE_CLASE IN ('CICLOMOTOR','CUADRICICLO','MOTOTRICICLO','MOTOCICLETA','MOTOCARRO','CUATRIMOTO') 
                            AND NOMBRE_SERVICIO IN ('OFICIAL') AND TO_NUMBER(CILINDRAJE) > 125
                            UNION
                            -- MOTOCICLETAS OFICIALES Y ELECTRICOS
                            SELECT NRO_PLACA, ID_TRANSITO, NOMBRE_TRANSITO, NOMBRE_MARCA, NOMBRE_LINEA, MODELO, 
                                   NOMBRE_CLASE, NOMBRE_SERVICIO, NOMBRE_CARROCERIA, CILINDRAJE, CAPACIDAD_CARGA, 
                                   FECHA_MATRICULA, MODALIDAD, COMBUSTIBLE
                            FROM BD_FISCALIZACION.FC_AUTOMOTOR   FC_AUTOMOTOR
                            WHERE COMBUSTIBLE = 'ELECTRICO' AND NRO_PLACA NOT IN (SELECT NRO_PLACA FROM BD_FISCALIZACION.FC_AUTOMOTOR   
                            WHERE COMBUSTIBLE = 'ELECTRICO' AND NOMBRE_SERVICIO IN ('OFICIAL','DIPLOMATICO','PUBLICO')
                            AND NOMBRE_CLASE NOT IN ('CICLOMOTOR','CUADRICICLO','MOTOTRICICLO','MOTOCICLETA','MOTOCARRO','CUATRIMOTO'));

BEGIN
    lu_escribir_archivo := UTL_FILE.FOPEN('VEHICULOS_ACTIVOS',lv_Name_File,'W');
        FOR ln_index IN lcur_vehi_activos LOOP
            If lb_Existe_encabezado = False Then
                                  UTL_FILE.PUT_LINE(lu_escribir_archivo,
                                  'NRO_PLACA;'||'ID_TRANSITO;'||'NOMBRE_TRANSITO;'||'NOMBRE_MARCA;'||'NOMBRE_LINEA;'||'MODELO;'
                                  || 'NOMBRE_CLASE;'||'NOMBRE_SERVICIO;'||'NOMBRE_CARROCERIA;'||'CILINDRAJE;'||'CAPACIDAD_CARGA;'
                                  ||'FECHA_MATRICULA;'||'MODALIDAD;'||'COMBUSTIBLE');
                        lb_Existe_encabezado:=True;
            End If;
            
             UTL_FILE.PUT_LINE(lu_escribir_archivo,ln_index.nro_placa||';'||ln_index.id_transito||';'||ln_index.nombre_transito||';'
             ||ln_index.nombre_marca||';'||ln_index.nombre_linea||';'||ln_index.modelo||';'||ln_index.nombre_clase||';'||ln_index.nombre_servicio||';'
             ||ln_index.nombre_carroceria||';'||ln_index.cilindraje||';'||ln_index.capacidad_carga||';'||ln_index.fecha_matricula||';'
             ||ln_index.modalidad||';'||ln_index.combustible);
            
        END LOOP;
    UTL_FILE.FCLOSE(lu_escribir_archivo);
END sp_generar_reporte;

PROCEDURE sp_iniciar AS
BEGIN
    sp_generar_reporte;
END sp_iniciar;

END PGK_REPORTE_VEHICULOS_ACTIVOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_CONSULTAS_MASIVAS_RUNT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_CONSULTAS_MASIVAS_RUNT" AS

lv_placas VARCHAR2(10); 
ltul_read UTL_FILE.FILE_TYPE; 

Procedure sp_historico_traspaso As

/*ISVA
Nombre     :sp_historico_traspaso
Autor      :Blados.Ospina
Fecha      :17/09/2018
Variables  :lv_placas, lutl_read, lb_Existe
Variables  :lb_Existe_encabezado, lutl_write
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Consulta el historico de traspasos Runt
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
17/09/2018 Blados.Ospina   1.0                     */

lv_Name_File Varchar2(255 byte):='Historico_Traspasos runt '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
Cursor lcur_historico_traspaso(av_placa Varchar)  is Select Distinct nro_placa, id_usuario, tipo_documento, porcentaje, 
                                                                    fecha_inicio_propiedad,fecha_fin_propiedad
                                                     from bd_transitos.arunt_historico_traspaso
                                                     where nro_placa = av_placa
                                                     Order by fecha_inicio_propiedad Asc, fecha_fin_propiedad Asc;
lb_Existe_encabezado Boolean:=False;
lb_Existe Boolean;
lutl_write UTL_FILE.FILE_TYPE;  

Begin
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
    lutl_write := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
    Loop
        Begin
         UTL_FILE.GET_LINE(ltul_read,lv_placas); 
         lb_Existe:=False;
            If lb_Existe_encabezado = False Then
                  UTL_FILE.PUT_LINE(lutl_write,'NRO_PLACA;'||'ID_USUARIO;'||'TIPO_DOCUMENTO;'||'PORCENTAJE;'
                                                               ||'FECHA_INICIO_PROPIEDAD;'||'FECHA_FIN_PROPIEDAD');
                        lb_Existe_encabezado:=True;
            End If;
            For ln_index In lcur_historico_traspaso(lv_placas) Loop
                    UTL_FILE.PUT_LINE(lutl_write,
                            Ln_Index.Nro_Placa||';'
                            ||Ln_Index.id_usuario||';'
                            ||Ln_Index.tipo_documento||';'
                            ||Ln_Index.porcentaje||';'
                            ||Ln_Index.fecha_inicio_propiedad||';'
                            ||Ln_Index.fecha_fin_propiedad);
                        lb_Existe:= True;  
            End Loop;
            If lb_Existe = False Then
                UTL_FILE.PUT_LINE(lutl_write,lv_placas||';'||'No registra propietario');
            End If;
            
            EXCEPTION 
            WHEN No_Data_Found THEN EXIT;
            WHEN OTHERS THEN
            UTL_FILE.PUT_LINE(lutl_write,lv_placas||';'||'Error Placa');
        End;
    End Loop;
End sp_historico_traspaso;

Procedure Sp_Consultar_Propietarios_Runt AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

lb_Existe_encabezado Boolean:=False;
lb_Existe Boolean;
lv_Name_File Varchar2(255 byte):='Propietarios runt '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Cursor lcur_prop(av_nro_placa Varchar) Is Select Distinct Nro_Placa,id_usuario,id_documento,porcentaje_prop, fecha_propiedad 
                                          From Bd_Transitos.Arunt_Propietarios 
                                          Where Nro_Placa = av_nro_placa And Fecha_Propiedad In (Select Max(Fecha_Propiedad)  
                                                                                                 From Bd_Transitos.Arunt_Propietarios
                                                                                                 Where Nro_Placa = av_nro_placa);
Begin
  ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
  v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
    Loop
      Begin
        UTL_FILE.GET_LINE(ltul_read,lv_placas); 
        lb_Existe:=False;
              If lb_Existe_encabezado = False Then
                  UTL_FILE.PUT_LINE(v_MyFileHandle,'PLACA'||';'||'PROPIETARIO'||';'||'DOCUMENTO'||';'||
                                                         'PORCENTAJE'||';'||'FECHA_PROPIEDAD'||';'||'ESTADO');
                        lb_Existe_encabezado:=True;
              End If;
            For Ln_Index_2 In lcur_prop(lv_placas) Loop
               
                  UTL_FILE.PUT_LINE(v_MyFileHandle,
                            Ln_Index_2.Nro_Placa||';'
                            ||Ln_Index_2.id_usuario||';'
                            ||Ln_Index_2.id_documento||';'
                            ||Ln_Index_2.porcentaje_prop||';'
                            ||Ln_Index_2.fecha_propiedad);
                        lb_Existe:= True;
            End Loop;
        If lb_Existe = False Then
            UTL_FILE.PUT_LINE(v_MyFileHandle,
                        lv_placas||';'||';'||';'||';'||';'||'No registra propietario');
        End If;
        
        EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN 
                  UTL_FILE.PUT_LINE(v_MyFileHandle,
                        lv_placas||';'||';'||';'||';'||';'||'No registra propietario');
        
     End;
    End Loop;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
End Sp_Consultar_Propietarios_Runt;

Procedure Sp_Consultar_Novedades_Runt AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

lb_Existe_encabezado Boolean:=False;
lb_Existe Boolean;
lv_Name_File Varchar2(255 byte):='Novedades runt '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Cursor lcur_prop(av_nro_placa Varchar) Is Select Distinct nro_placa,nombre_tramite,fecha_tramite,id_secretaria_destino,
                                                          id_secretaria_origen,nombre_carroceria_anterior,nombre_carroceria_nueva,
                                                          nombre_servicio_anterior,nombre_servicio_nuevo,id_documento_anterior,
                                                          id_usuario_anterior,id_documento_nuevo,id_usuario_nuevo,porcentaje_prop,
                                                          blindado,nivel_blindado,desblindaje 
                                          From Bd_Transitos.Arunt_Tramites 
                                          Where Nro_Placa = av_nro_placa And Id_Tramite In (1,6,9,10,13,15,20,65)
                                          Order By 3 Desc;
Begin
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
    v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
        Loop 
            Begin
                UTL_FILE.GET_LINE(ltul_read,lv_placas); 
                If lb_Existe_encabezado = False Then
                      UTL_FILE.PUT_LINE(v_MyFileHandle,
                                        'NRO_PLACA'||';'||'NOMBRE_TRAMITE'||';'||'FECHA_TRAMITE'||';'||'ID_SECRETARIA_DESTINO'||';'
                                        ||'ID_SECRETARIA_ORIGEN'||';'||'NOMBRE_CARROCERIA_ANTERIOR'||';'||'NOMBRE_CARROCERIA_NUEVA'||';'
                                        ||'NOMBRE_SERVICIO_ANTERIOR'||';'||'NOMBRE_SERVICIO_NUEVO'||';'||'ID_DOCUMENTO_ANTERIOR'||';'
                                        ||' ID_USUARIO_ANTERIOR'||';'||'ID_DOCUMENTO_NUEVO'||';'||'ID_USUARIO_NUEVO'||';'
                                        ||'PORCENTAJE_PROP'||';'||'BLINDADO'||';'||'NIVEL_BLINDADO'||';'||'DESBLINDAJE');
                            lb_Existe_encabezado:=True;
                 End If;
            lb_Existe:=False;
                For Ln_Index_2 In lcur_prop(lv_placas) Loop
                        UTL_FILE.PUT_LINE(v_MyFileHandle,ln_index_2.NRO_PLACA||';'||ln_index_2.NOMBRE_TRAMITE||';'||ln_index_2.FECHA_TRAMITE||';'
                                          ||ln_index_2.ID_SECRETARIA_DESTINO||';'||ln_index_2.ID_SECRETARIA_ORIGEN||';'||ln_index_2.NOMBRE_CARROCERIA_ANTERIOR||';'
                                          ||ln_index_2.NOMBRE_CARROCERIA_NUEVA||';'||ln_index_2.NOMBRE_SERVICIO_ANTERIOR||';'||ln_index_2.NOMBRE_SERVICIO_NUEVO||';'
                                          ||ln_index_2.ID_DOCUMENTO_ANTERIOR||';'||ln_index_2.ID_USUARIO_ANTERIOR||';'||ln_index_2.ID_DOCUMENTO_NUEVO||';'
                                          ||ln_index_2.ID_USUARIO_NUEVO||';'||ln_index_2.PORCENTAJE_PROP||';'||ln_index_2.BLINDADO||';'||ln_index_2.NIVEL_BLINDADO||';'
                                          ||ln_index_2.DESBLINDAJE);
                            lb_Existe:= True;
                End Loop;
                If lb_Existe = False Then
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placas||';'||'No registra Novedad');
                End If; 
            EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN 
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placas||';'||'Error en la placa');
                    Continue;
          End;
        End Loop;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
End Sp_Consultar_Novedades_Runt;

Procedure Sp_Consult_Caracteris_Runt AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

lb_Existe_encabezado Boolean:=False;
lb_Existe Boolean;
lv_Name_File Varchar2(255 byte):='Vehiculos runt '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Cursor lcur_prop(av_nro_placa Varchar) Is Select Distinct nro_placa,nombre_marca,nombre_linea,modelo,nombre_clase,nombre_servicio,
                                                          nombre_carroceria,cilindraje,nro_puertas,nombre_combustible,
                                                          potencia,id_secretaria,nombre_secretaria,cap_pasajeros,cap_toneladas,valor_factura,
                                                          blindado,fecha_matriculo,caja,traccion,combustion,watt
                                          From Bd_Transitos.Arunt_Vehiculos 
                                          Where Nro_Placa = av_nro_placa And Id_Radicado In (Select Max(Id_Radicado)  
                                                                                             From Bd_Transitos.Arunt_vehiculos
                                                                                             Where Nro_Placa = av_nro_placa);

Begin
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
    v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
        Loop
           Begin
             UTL_FILE.GET_LINE(ltul_read,lv_placas); 
                lb_Existe:=False;
                    If lb_Existe_encabezado = False Then
                        UTL_FILE.PUT_LINE(v_MyFileHandle,
                                         'NRO_PLACA;'||'NOMBRE_MARCA;'||'NOMBRE_LINEA;'||'MODELO;'||'NOMBRE_CLASE;'
                                         ||'NOMBRE_SERVICIO;'||'NOMBRE_CARROCERIA;'||'CILINDRAJE;'||'NRO_PUERTAS;'
                                         ||'NOMBRE_COMBUSTIBLE;'||'POTENCIA;'||'ID_SECRETARIA;'||'NOMBRE_SECRETARIA;'||'CAP_PASAJEROS;'
                                         ||'CAP_TONELADAS;'||'VALOR_FACTURA;'||'BLINDADO;'||'FECHA_MATRICULO;'
                                         ||'CAJA;'||'TRACCION;'||'COMBUSTION;'||'WATT;'||'ESTADO');
                                lb_Existe_encabezado:=True;
                     End If;
                For Ln_Index_2 In lcur_prop(lv_placas) Loop
                     
                      UTL_FILE.PUT_LINE(v_MyFileHandle,
                      ln_index_2.NRO_PLACA||';'||ln_index_2.NOMBRE_MARCA||';'||ln_index_2.NOMBRE_LINEA||';'||ln_index_2.MODELO||';'
                      ||ln_index_2.NOMBRE_CLASE||';'||ln_index_2.NOMBRE_SERVICIO||';'||ln_index_2.NOMBRE_CARROCERIA||';'||ln_index_2.CILINDRAJE||';'
                      ||ln_index_2.NRO_PUERTAS||';'||ln_index_2.NOMBRE_COMBUSTIBLE||';'||ln_index_2.POTENCIA||';'||ln_index_2.ID_SECRETARIA||';'||ln_index_2.NOMBRE_SECRETARIA||';'
                      ||ln_index_2.CAP_PASAJEROS||';'||ln_index_2.CAP_TONELADAS||';'||ln_index_2.VALOR_FACTURA||';'||ln_index_2.BLINDADO||';'
                      ||ln_index_2.FECHA_MATRICULO||';'||ln_index_2.CAJA||';'||ln_index_2.TRACCION||';'||ln_index_2.COMBUSTION||';'||ln_index_2.WATT);
                    
                    lb_Existe:= True;
                    End Loop;
                   If lb_Existe = False Then
                        UTL_FILE.PUT_LINE(v_MyFileHandle,
                        lv_placas||';'||';'||';'||';'||';'||';'||';'||';'||';'||';'
                                          ||';'||';'||';'||';'||';'||';'||';'||';'||';'||';'
                                          ||';'||';'||'No registra Caracteristicas');
                   End If; 
                EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN 
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                        lv_placas||';'||';'||';'||';'||';'||';'||';'||';'||';'||';'
                                          ||';'||';'||';'||';'||';'||';'||';'||';'||';'||';'
                                          ||';'||'Error en la placa');
                 CONTINUE;
            End;
        End Loop;
    
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
Exception
 WHEN OTHERS THEN 
    dbms_output.Put_line( Dbms_Utility.Format_Error_Backtrace||sqlerrm);
End Sp_Consult_Caracteris_Runt;

Procedure Sp_Iniciar_Proceso (as_Propietarios Simple_Integer,as_Vehiculos Simple_Integer,as_Novedades Simple_Integer,
                              as_Historico_Traspaso Simple_Integer) As

/*ISVA
Nombre     :Sp_Iniciar_Proceso
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Inicia y genera los archivos a buscar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

Begin
    If  as_Novedades = 1 Then
        Sp_Consultar_Novedades_Runt;
    End If;
    If as_Propietarios = 1 Then
        Sp_Consultar_Propietarios_Runt;
    End If;
    If as_Vehiculos = 1 Then
        Sp_Consult_Caracteris_Runt;
    End If;
    If as_Historico_Traspaso = 1 Then
        sp_historico_traspaso;
    End If; 

End Sp_Iniciar_Proceso;

END PKG_CONSULTAS_MASIVAS_RUNT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DIRECCIONES_INTERLOCUTORES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_DIRECCIONES_INTERLOCUTORES" AS


itp_contribuyente tp_runt_contribuyentes := tp_runt_contribuyentes();
itp_list_contribuyente tp_runt_lista_contribuyentes := tp_runt_lista_contribuyentes();

iv_cedula VARCHAR2(255 BYTE):='';
iv_documento VARCHAR2(255 BYTE):='';
iv_placa VARCHAR2(255 BYTE):='';
iv_municipio VARCHAR2(255 BYTE):='';
iv_departamento VARCHAR2(255 BYTE):='';

FUNCTION ft_municipio_no_reporta (av_placa VARCHAR) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_calcular_digito_veri
Autor      :Blados.Ospina
Fecha      :26/11/2018
Argumento  :av_placa
Variables  :av_retorno
Retorno    :av_retorno              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :retorna el codigo y el nombre del municipio
           :registrado el vehiculos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_retorno VARCHAR2(255 BYTE):='';

BEGIN
    iv_municipio:='';
    iv_departamento:='';
    
    SELECT id_municipio,municipio,departamento INTO lv_retorno,iv_municipio,iv_departamento 
    FROM bd_fiscalizacion.fc_vehiculos 
    WHERE nro_placa = av_placa;
    
        RETURN lv_retorno||' '||iv_municipio;
EXCEPTION 
WHEN OTHERS THEN
RETURN lv_retorno;
END ft_municipio_no_reporta;

PROCEDURE sp_recuperar_datos (av_datos VARCHAR) AS

/*ISVA
Nombre     :sp_recuperar_datos
Autor      :Blados.Ospina
Fecha      :26/11/2018
Argumento  :av_datos
Variables  :
Retorno    :            
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :particiona una cadena en cedula, documento y placa
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_datos VARCHAR2(255 BYTE):=av_datos;
lv_cedula VARCHAR2(255 BYTE):='';
lv_documento VARCHAR2(255 BYTE):='';
lv_placa VARCHAR2(255 BYTE):='';

ln_posicion NUMBER:=0;
lv_datos_temp VARCHAR2(255 BYTE):='';

BEGIN
   iv_cedula:='';
   iv_documento:='';
   iv_placa:='';
   
   ln_posicion:= INSTR(lv_datos,';');   
   lv_cedula:= TRIM(SUBSTR(lv_datos,1,ln_posicion-1));
   iv_cedula:=lv_cedula;
   
   lv_datos_temp:=TRIM(SUBSTR(lv_datos,ln_posicion+1,LENGTH(lv_datos)));
   ln_posicion:= INSTR(lv_datos_temp,';');  
   IF ln_posicion = 0 THEN
        iv_documento:=lv_datos_temp;
        iv_cedula:=lv_cedula;
        iv_placa:=lv_placa;
   ELSE
    
    lv_documento:= TRIM(SUBSTR(lv_datos_temp,1,ln_posicion-1));
    iv_documento:=lv_documento;
    lv_placa:=SUBSTR(lv_datos_temp,ln_posicion+1,LENGTH(lv_datos));
    iv_placa:=lv_placa;
  END IF;

   

EXCEPTION
WHEN OTHERS THEN
iv_cedula:=lv_cedula;

   
END sp_recuperar_datos;

FUNCTION ft_fecha_max_traspaso (av_placa VARCHAR) RETURN VARCHAR as

lv_fecha VARCHAR2(15 BYTE):='';

BEGIN
    SELECT MAX(fecha_tramite) INTO lv_fecha FROM Bd_Transitos.Arunt_Tramites
    WHERE nro_placa = av_placa AND id_tramite = 16; 
    
    RETURN lv_fecha;

EXCEPTION
WHEN OTHERS THEN
RETURN lv_fecha;
    
END ft_fecha_max_traspaso;

Procedure sp_consultar_traspaso_runt AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

ltul_read UTL_FILE.FILE_TYPE; 
lv_placa VARCHAR2(10); 
lb_Existe_encabezado Boolean:=FALSE;
lb_Existe Boolean;
lv_Name_File Varchar2(255 byte):='Traspasos '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.csv';
v_MyFileHandle UTL_FILE.FILE_TYPE;
ld_fecha_max DATE;

Cursor lcur_prop(av_nro_placa varchar,ad_fecha_tramite Date) Is Select Distinct nro_placa,nombre_tramite,fecha_tramite,id_documento_anterior,
                                                          id_usuario_anterior,id_documento_nuevo,id_usuario_nuevo,porcentaje_prop
                                          From Bd_Transitos.Arunt_Tramites 
                                          Where Nro_Placa = av_nro_placa And Id_Tramite In (16) 
                                          And Fecha_Tramite = ad_fecha_tramite 
                                          AND (id_usuario_anterior <> id_usuario_nuevo)
                                          Order By 3 Desc;
Begin
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
    v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
        Loop 
            Begin
                UTL_FILE.GET_LINE(ltul_read,lv_placa); 
                If lb_Existe_encabezado = False Then
                      UTL_FILE.PUT_LINE(v_MyFileHandle,
                                        'NRO_PLACA'||';'||'NOMBRE_TRAMITE'||';'||'FECHA_TRAMITE'||';'
                                        ||'ID_DOCUMENTO_ANTERIOR'||';'||'ID_USUARIO_ANTERIOR'||';'
                                        ||'ID_DOCUMENTO_NUEVO'||';'||'ID_USUARIO_NUEVO'||';'||'PORCENTAJE_PROP');
                            lb_Existe_encabezado:=True;
                 End If;
            lb_Existe:=False;
                ld_fecha_max := ft_fecha_max_traspaso(lv_placa);
                For Ln_Index In lcur_prop(lv_placa, ld_fecha_max) Loop
                        UTL_FILE.PUT_LINE(v_MyFileHandle,ln_index.nro_placa||';'||ln_index.nombre_tramite||';'
                                          ||ln_index.fecha_tramite||';'||ln_index.id_documento_anterior||';'
                                          ||ln_index.id_usuario_anterior||';'||ln_index.id_documento_nuevo||';'
                                          ||ln_index.id_usuario_nuevo||';'||ln_index.porcentaje_prop);
                            lb_Existe:= True;
                End Loop;
                If lb_Existe = False Then
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placa||';'||'No registra Novedad');
                End If; 
            EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN 
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placa||';'||'Error en la placa');
                    Continue;
          End;
        End Loop;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
End sp_consultar_traspaso_runt;

FUNCTION ft_existe_prop (av_placa VARCHAR) RETURN VARCHAR AS

lv_fecha VARCHAR(15 BYTE):='';

BEGIN
    SELECT MAX(fecha_propiedad) INTO lv_fecha FROM bd_Transitos.arunt_propietarios
    WHERE nro_placa = av_placa;
    
    RETURN lv_fecha;

EXCEPTION
WHEN OTHERS THEN
RETURN lv_fecha;
END ft_existe_prop;

PROCEDURE sp_solo_propietario AS

/*ISVA
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :26/06/2018
Variables  :lb_Existe_encabezado, lb_Existe
Variables  :lv_Name_File, v_MyFileHandle
Variables  :lcur_placa_prop, lcur_prop
Retorno    :              
Proyecto   :PKG_CONSULTAS_MASIVAS_RUNT
Versi�n    :1.0
Objetivo   :Conltas masiva base de datos RUNT
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
26/06/2018  Blados.Ospina   1.0                     */

ltul_read UTL_FILE.FILE_TYPE; 
lv_placa VARCHAR2(10); 
lb_Existe_encabezado Boolean:=FALSE;
lb_Existe Boolean;
lv_Name_File Varchar2(255 byte):='Solo Propietarios '||To_Char(SYSDATE,'dd-mm-yyyy hh24-mi-ss')||'.csv';
v_MyFileHandle UTL_FILE.FILE_TYPE;
ld_fecha_max VARCHAR(15 BYTE);

CURSOR lcur_prop(av_placa VARCHAR, ad_fecha VARCHAR) IS SELECT DISTINCT nro_placa,id_usuario,id_documento,
                                                                        porcentaje_prop,fecha_propiedad
                                                     FROM bd_Transitos.arunt_propietarios
                                                     WHERE nro_Placa = av_placa 
                                                     AND fecha_propiedad = ad_fecha;
BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');	
    v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
        LOOP 
            BEGIN
                UTL_FILE.GET_LINE(ltul_read,lv_placa); 
                IF lb_Existe_encabezado = FALSE THEN
                      UTL_FILE.PUT_LINE(v_MyFileHandle,
                                        'NRO_PLACA'||';'||'ID_USUARIO'||';'||'ID_DOCUMENTO'||';'
                                        ||'PORCENTAJE'||';'||'FECHA_PROPIEDAD');
                            lb_Existe_encabezado:=TRUE;
                 END IF;
                lb_Existe:=FALSE;
                ld_fecha_max := ft_existe_prop(lv_placa);
                FOR ln_Index IN lcur_prop(lv_placa, ld_fecha_max) LOOP
                        UTL_FILE.PUT_LINE(v_MyFileHandle,ln_index.nro_placa||';'||ln_index.id_usuario||';'
                                          ||ln_index.id_documento||';'||ln_index.porcentaje_prop||';'
                                          ||ln_index.fecha_propiedad);
                            lb_Existe:= TRUE;
                END LOOP;
                IF lb_Existe = FALSE THEN
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placa||';'||'No registra propietarios');
                END IF; 
            EXCEPTION 
                WHEN No_Data_Found THEN EXIT; 
                WHEN OTHERS THEN 
                    UTL_FILE.PUT_LINE(v_MyFileHandle,
                                lv_placa||';'||'Error en la placa');
                    CONTINUE;
          END;
        END LOOP;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
END sp_solo_propietario;

FUNCTION ft_calcular_digito_veri (an_nit NUMBER) RETURN NUMBER AS

/*ISVA
Nombre     :ft_calcular_digito_veri
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :an_nit
Variables  :ln_digito_verificacion
Retorno    :ln_digito_verificacion              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :retorna el digito de verificacion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

ln_digito_verificacion VARCHAR2(1 BYTE):='';


BEGIN
    ln_digito_verificacion:=depuracion.pkg_ds_estandariza_registros.ft_calcular_digito_verifica(a_nit => an_nit);
    
    RETURN ln_digito_verificacion;

EXCEPTION
WHEN OTHERS THEN
    RETURN ln_digito_verificacion;
    
END ft_calcular_digito_veri;

FUNCTION ft_validar_numero (av_numero VARCHAR) RETURN NUMBER AS

/*ISVA
Nombre     :ft_validar_numero
Autor      :Blados.Ospina
Fecha      :20/11/2018
Argumento  :av_numero
Variables  :ln_numero
Retorno    :ln_numero              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :valida si el numero o celular es valido
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */


ln_numero NUMBER:=0;
lv_numero VARCHAR(10):='';
le_error EXCEPTION;

BEGIN
        ln_numero :=TO_NUMBER(depuracion.pkg_ds_estandariza_registros.ft_estandarizar_telefono(av_numero));
        
            IF LENGTH(ln_numero) IN (10,7) THEN
                RETURN ln_numero;
            ELSE
                RAISE le_error;
            END IF;
           
EXCEPTION 
WHEN OTHERS THEN
RETURN lv_numero;
END ft_validar_numero;

PROCEDURE sp_consultar_digito_veri AS 

/*ISVA
Nombre     :sp_consultar_digito_veri
Autor      :Blados.Ospina
Fecha      :20/11/2018
Argumento  :
Variables  :lv_id_usuario, ltul_read, lb_existe_mun
Variables  :lb_existe_dir
Retorno    :lb_existe            
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :Genera reporte con digito de verificacion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lb_Existe_encabezado Boolean:=FALSE;
lv_Name_File VARCHAR2(255 BYTE):='Nit con Digito Verificacion'||To_Char(Sysdate,'ddmmyyyy hh24-mi-ss')||'.csv';
v_MyFileHandle UTL_FILE.FILE_TYPE;

lv_id_usuario VARCHAR2(30); 
ltul_read UTL_FILE.FILE_TYPE; 
lv_digito VARCHAR2(255 BYTE);



BEGIN
     ltul_read := UTL_FILE.FOPEN('DATA_LOAD','id_usuarios.csv','R');	
     v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
     LOOP
        BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_id_usuario); 
            lv_digito:='';
          
              IF lb_Existe_encabezado = FALSE Then
                  UTL_FILE.PUT_LINE(v_MyFileHandle,'NIT'||';'||'DIGITO_VERIFICACION');
                        lb_Existe_encabezado:=TRUE;
              END IF;
            IF LENGTH(lv_id_usuario) = 9 THEN
                 lv_digito:= ft_calcular_digito_veri(lv_id_usuario);
            END IF;
                UTL_FILE.PUT_LINE(v_MyFileHandle,lv_id_usuario||';'||lv_digito);                  
        EXCEPTION
            WHEN No_Data_Found THEN 
            EXIT; 
            WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(Dbms_Utility.Format_Error_Backtrace);
        END;
    END LOOP;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    UTL_FILE.FCLOSE(ltul_read);
    
END sp_consultar_digito_veri;

FUNCTION ft_departamento (av_codigo_direccion VARCHAR2) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_departamento
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :av_codigo_direccion
Variables  :lv_departamento
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :Recupera el departamento
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_departamento VARCHAR2(255 BYTE):='';

BEGIN

SELECT departamento INTO lv_departamento  FROM bd_fiscalizacion.Fc_Municipio_Departamento
WHERE Divipo = av_codigo_direccion AND ROWNUM = 1;


    RETURN lv_departamento;

    EXCEPTION 
    WHEN OTHERS THEN
    RETURN lv_departamento;

END ft_departamento;

FUNCTION ft_validar_departamento (av_codigo_direccion VARCHAR2) RETURN VARCHAR AS

/*ISVA
Nombre     :ft_validar_departamento
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :av_codigo_direccion
Variables  :lb_existe
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :valida si el departamento esta homologado
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lb_existe VARCHAR2(10 BYTE):='FALSE';

BEGIN

SELECT DECODE(COUNT(1),1,'TRUE','FALSE') INTO lb_existe  FROM bd_fiscalizacion.Fc_Municipio_Departamento
WHERE Divipo = av_codigo_direccion AND ROWNUM = 1;


    RETURN lb_existe;

    EXCEPTION 
    WHEN OTHERS THEN
    RETURN lb_existe;

END ft_validar_departamento;

FUNCTION ft_validar_estructura (av_direccion varchar2) return number as

/*ISVA
Nombre     :ft_validar_estructura
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :av_direccion
Variables  :
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :valida si la direccion es valida
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1); 
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnCumple Number:=0;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(av_direccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
  
  --Permite validar las direcciones con estructura CL 10 1020 o CL 10B 1020
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return 0;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
       lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  

-- Valido que la direcci�n tenga estructura v�lida
Select count(1) into lnCumple
from bd_fiscalizacion.fc_estructura_Direccion 
where lvEstructura like '%' || Estructura ||'%';

If(lnCumple > 0)then
  Return 1;
else
  Return 0;
end if;

END ft_validar_estructura;

FUNCTION ft_validar_estructura_final (av_direccion VARCHAR) RETURN VARCHAR AS 

/*ISVA
Nombre     :ft_validar_estructura_final
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :av_direccion
Variables  :
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :vvalida otros tipos de direccion
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

TYPE tp_Array_dir IS VARRAY(5) OF VARCHAR2(100 BYTE);
array_dir tp_Array_dir:=tp_Array_dir('VRD','KM','FCA','CRG');

lv_validador VARCHAR2(10 BYTE) :='FALSE';
lv_direccion_estandarizada VARCHAR2(255 BYTE):='';
ln_dir_valida NUMBER:=0;

BEGIN
                            
lv_direccion_estandarizada := Trim(correccion_datos.pkg_ds_estandariza_runt.ft_estandarizar_direccion(av_direccion));
       FOR i IN 1..array_dir.COUNT LOOP
         --Varifica 
          ln_dir_valida := instr(lv_direccion_estandarizada,array_dir(i));
             IF ln_dir_valida > 0 then 
                    lv_validador := 'TRUE';
             END IF;       
       END LOOP;
       IF lv_validador = 'FALSE' THEN
            ln_dir_valida := ft_validar_estructura(lv_direccion_estandarizada);          
          IF ln_dir_valida > 0 THEN
               lv_validador := 'TRUE';   
         END IF;
       END IF;
    
    RETURN lv_validador;
    
END ft_validar_estructura_final; 

PROCEDURE Sp_Registrar_Direcciones AS

/*ISVA
Nombre     :Sp_Registrar_Direcciones
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :av_direccion
Variables  :
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :registra los datos procesados
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lb_Existe_encabezado Boolean:=FALSE;
lv_Name_File VARCHAR2(255 BYTE):='Direccion Contribuyentes runt '||To_Char(Sysdate,'ddmmyyyy hh24-mi-ss')||'.csv';
v_MyFileHandle UTL_FILE.FILE_TYPE;

Begin
   
    v_MyFileHandle := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
              IF lb_Existe_encabezado = FALSE Then
                  UTL_FILE.PUT_LINE(v_MyFileHandle,'IDENTIFICACION'||';'||'DOCUMENTO'||';'||'DIGITO_VERIFICACION'||';'||'NOMBRES'||';'
                                                    ||'APELLIDOS'||';'||'DIRECCION'||';'||'MUNICIPIO'||';'||'DEPARTAMENTO'||';'
                                                    ||'TELEFONO'||';'||'CELULAR'||';'||'EMAIL'||';'||'FECHA_DIRECCION'||';'||'ESTADO');
                        lb_Existe_encabezado:=TRUE;
              END IF;
                FOR Ln_Index IN 1..itp_list_contribuyente.COUNT()  LOOP
  
                        
                             UTL_FILE.PUT_LINE(v_MyFileHandle,
                            itp_list_contribuyente(ln_index).id_usuario||';'
                            ||itp_list_contribuyente(Ln_Index).id_documento||';'
                            ||itp_list_contribuyente(Ln_Index).digito_verificacion||';'
                            ||itp_list_contribuyente(Ln_Index).nombres||';'
                            ||itp_list_contribuyente(Ln_Index).apellidos||';'
                            ||itp_list_contribuyente(Ln_Index).direccion||';'
                            ||itp_list_contribuyente(Ln_Index).municipio||';'
                            ||itp_list_contribuyente(Ln_Index).departamento||';'
                            ||itp_list_contribuyente(Ln_Index).telefono||';'
                            ||itp_list_contribuyente(Ln_Index).celular||';'
                            ||itp_list_contribuyente(Ln_Index).email||';'
                            ||itp_list_contribuyente(Ln_Index).radicado||';'
                            ||itp_list_contribuyente(Ln_Index).estado);
            END LOOP;
    UTL_FILE.FCLOSE(v_MyFileHandle);
    
End Sp_Registrar_Direcciones;

PROCEDURE sp_resetar_var AS

/*ISVA
Nombre     :sp_resetar_var
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :
Variables  :
Retorno    :              
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :restablece los datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

BEGIN
     itp_contribuyente.id_usuario := '';    
     itp_contribuyente.id_documento := '';  
     itp_contribuyente.digito_verificacion := ''; 
     itp_contribuyente.nombres := ''; 
     itp_contribuyente.apellidos := ''; 
     itp_contribuyente.direccion := ''; 
     itp_contribuyente.telefono := '';   
     itp_contribuyente.fax :='';  
     itp_contribuyente.email := ''; 
     itp_contribuyente.celular := ''; 
     itp_contribuyente.municipio := ''; 
     itp_contribuyente.departamento := ''; 
     itp_contribuyente.estado := ''; 
     iv_municipio:='';
     iv_departamento:='';
END sp_resetar_var;

FUNCTION ft_fecha_radicado (an_radicado NUMBER) RETURN VARCHAR AS

lv_fecha VARCHAR2(20):='';

BEGIN
    SELECT SUBSTR(rango,14,10) INTO lv_fecha  FROM bd_transitos.arunt_maestro 
    WHERE id_radicado = an_radicado;
        
        RETURN lv_fecha;

EXCEPTION 
WHEN OTHERS THEN
RETURN lv_fecha;

END ft_fecha_radicado;
 
PROCEDURE sp_buscar_direcciones AS 

/*ISVA
Nombre     :sp_Iniciar
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :
Variables  :lv_id_usuario, ltul_read, lb_existe_mun
Variables  :lb_existe_dir
Retorno    :lb_existe            
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :recupera la cedula para consultar y validar la informacion 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_id_usuario VARCHAR2(30); 
ltul_read UTL_FILE.FILE_TYPE; 
lb_existe_mun VARCHAR2(255);
lb_existe_dir VARCHAR2(255);
lb_existe BOOLEAN;

Cursor lcur_dir(av_id_usuario VARCHAR, av_id_documento VARCHAR) Is SELECT DISTINCT  id_usuario, id_documento, nombres, apellidos, direccion,telefono ,
                                                           fax , email, celular, Id_Ciudad_Dir, id_direccion,id_radicado, nombre_ciudad_dir
                                            FROM bd_transitos.Arunt_Contribuyentes Ac
                                            WHERE Id_Usuario = av_id_usuario and id_documento = av_id_documento
                                            ORDER BY To_Number(id_radicado) Desc, To_Number(id_direccion) Desc;
BEGIN
     ltul_read := UTL_FILE.FOPEN('DATA_LOAD','id_usuarios.csv','R');	
     LOOP
        BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_id_usuario);

                sp_recuperar_datos(lv_id_usuario);
       
            
                FOR ln_index IN lcur_dir(iv_cedula,iv_documento) LOOP
                    lb_existe:=TRUE;
                    lb_existe_mun :='FALSE';
                    lb_existe_dir :='FALSE';
                    sp_resetar_var();
                    
                        lb_existe_mun :=ft_validar_departamento(ln_index.Id_Ciudad_Dir);
                        lb_existe_dir:=ft_validar_estructura_final(ln_index.direccion);
                       
                        IF lb_existe_mun = 'TRUE' AND lb_existe_dir  = 'TRUE' THEN
                            itp_contribuyente.id_usuario := ln_index.id_usuario;    
                            itp_contribuyente.id_documento := ln_index.id_documento;  
                            IF ln_index.id_documento IN ('N','NIT') AND LENGTH(ln_index.id_usuario) = 9  THEN
                                itp_contribuyente.digito_verificacion := ft_calcular_digito_veri(ln_index.id_usuario);  
                            END IF;
                            itp_contribuyente.nombres := ln_index.nombres;  
                            itp_contribuyente.apellidos := ln_index.apellidos;  
                            itp_contribuyente.direccion := Trim(correccion_datos.pkg_ds_estandariza_runt.ft_estandarizar_direccion(ln_index.direccion)); 
                            itp_contribuyente.telefono := ft_validar_numero(ln_index.telefono);  
                            itp_contribuyente.fax := ln_index.fax;  
                            itp_contribuyente.email := ln_index.email;
                            itp_contribuyente.celular := ft_validar_numero(ln_index.celular);
                            itp_contribuyente.municipio := ln_index.nombre_ciudad_dir;
                            itp_contribuyente.departamento := ft_departamento(ln_index.id_Ciudad_dir);
                            itp_contribuyente.radicado := ft_fecha_radicado(ln_index.id_radicado);
                            EXIT;
                        ELSE
                            itp_contribuyente.id_usuario := ln_index.id_usuario;    
                            itp_contribuyente.id_documento := ln_index.id_documento;  
                            IF ln_index.id_documento IN ('N', 'NIT') AND LENGTH(ln_index.id_usuario) = 9 THEN
                                itp_contribuyente.digito_verificacion := ft_calcular_digito_veri(ln_index.id_usuario);  
                            END IF;
                            itp_contribuyente.nombres := ln_index.nombres;  
                            itp_contribuyente.apellidos := ln_index.apellidos;  
                            itp_contribuyente.direccion := 'NO REPORTA - '||ft_municipio_no_reporta(iv_placa); 
                            itp_contribuyente.telefono := ft_validar_numero(ln_index.telefono);  
                            itp_contribuyente.fax := ln_index.fax;  
                            itp_contribuyente.email := ln_index.email;
                            itp_contribuyente.celular := ft_validar_numero(ln_index.celular);
                            itp_contribuyente.municipio := iv_municipio;
                            itp_contribuyente.departamento := iv_departamento;
                        END IF;
                        
                END LOOP;
                IF lb_existe = TRUE THEN
                    itp_list_contribuyente.Extend;
                    itp_list_contribuyente(itp_list_contribuyente.Count()):=itp_contribuyente;
                ELSE
                    itp_contribuyente.id_usuario := iv_cedula;  
                    itp_contribuyente.id_documento := iv_documento; 
                    itp_contribuyente.estado := 'No registra informacion';  
                    itp_list_contribuyente.Extend;
                    itp_list_contribuyente(itp_list_contribuyente.Count()):=itp_contribuyente;
                END IF;
                
                lb_existe:=FALSE;
                sp_resetar_var();
        EXCEPTION
            WHEN No_Data_Found THEN 
            EXIT; 
            WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(Dbms_Utility.Format_Error_Backtrace);
        END;
    END LOOP;
    
    Sp_Registrar_Direcciones;
        
    
END sp_buscar_direcciones;

PROCEDURE sp_buscar_dir_documento AS 

/*ISVA
Nombre     :sp_Iniciar
Autor      :Blados.Ospina
Fecha      :08/11/2018
Argumento  :
Variables  :lv_id_usuario, ltul_read, lb_existe_mun
Variables  :lb_existe_dir
Retorno    :lb_existe            
Proyecto   :PKG_DIRECCIONES_INTERLOCUTORES
Version    :1.0
Objetivo   :recupera la cedula para consultar y validar la informacion 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

lv_id_usuario VARCHAR2(30); 
ltul_read UTL_FILE.FILE_TYPE; 
lb_existe_mun VARCHAR2(255);
lb_existe_dir VARCHAR2(255);
lb_existe BOOLEAN;

Cursor lcur_dir(av_id_usuario VARCHAR) Is SELECT DISTINCT  id_usuario, id_documento, nombres, apellidos, direccion,telefono ,
                                                           fax , email, celular, Id_Ciudad_Dir, id_direccion,id_radicado, nombre_ciudad_dir
                                            FROM bd_transitos.Arunt_Contribuyentes Ac
                                            WHERE Id_Usuario = av_id_usuario
                                            ORDER BY To_Number(id_radicado) Desc, To_Number(id_direccion) Desc;
BEGIN
     ltul_read := UTL_FILE.FOPEN('DATA_LOAD','id_usuarios.csv','R');	
     LOOP
        BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_id_usuario);


       
            
                FOR ln_index IN lcur_dir(lv_id_usuario) LOOP
                    lb_existe:=TRUE;
                    lb_existe_mun :='FALSE';
                    lb_existe_dir :='FALSE';
                    sp_resetar_var();
                    
                        lb_existe_mun :=ft_validar_departamento(ln_index.Id_Ciudad_Dir);
                        lb_existe_dir:=ft_validar_estructura_final(ln_index.direccion);
                       
                        IF lb_existe_mun = 'TRUE' AND lb_existe_dir  = 'TRUE' THEN
                            itp_contribuyente.id_usuario := ln_index.id_usuario;    
                            itp_contribuyente.id_documento := ln_index.id_documento;  
                            IF ln_index.id_documento IN ('N','NIT') AND LENGTH(ln_index.id_usuario) = 9  THEN
                                itp_contribuyente.digito_verificacion := ft_calcular_digito_veri(ln_index.id_usuario);  
                            END IF;
                            itp_contribuyente.nombres := ln_index.nombres;  
                            itp_contribuyente.apellidos := ln_index.apellidos;  
                            itp_contribuyente.direccion := Trim(correccion_datos.pkg_ds_estandariza_runt.ft_estandarizar_direccion(ln_index.direccion)); 
                            itp_contribuyente.telefono := ft_validar_numero(ln_index.telefono);  
                            itp_contribuyente.fax := ln_index.fax;  
                            itp_contribuyente.email := ln_index.email;
                            itp_contribuyente.celular := ft_validar_numero(ln_index.celular);
                            itp_contribuyente.municipio := ln_index.nombre_ciudad_dir;
                            itp_contribuyente.departamento := ft_departamento(ln_index.id_Ciudad_dir);
                            itp_contribuyente.id_ciudad_dir := ln_index.id_Ciudad_dir;
                            itp_contribuyente.radicado := ft_fecha_radicado(ln_index.id_radicado);
                            EXIT;
                        ELSE
                            itp_contribuyente.id_usuario := ln_index.id_usuario;    
                            itp_contribuyente.id_documento := ln_index.id_documento;  
                            IF ln_index.id_documento IN ('N', 'NIT') AND LENGTH(ln_index.id_usuario) = 9 THEN
                                itp_contribuyente.digito_verificacion := ft_calcular_digito_veri(ln_index.id_usuario);  
                            END IF;
                            itp_contribuyente.nombres := ln_index.nombres;  
                            itp_contribuyente.apellidos := ln_index.apellidos;  
                            itp_contribuyente.direccion := 'NO REPORTA - '||ft_municipio_no_reporta(iv_placa); 
                            itp_contribuyente.telefono := ft_validar_numero(ln_index.telefono);  
                            itp_contribuyente.fax := ln_index.fax;  
                            itp_contribuyente.email := ln_index.email;
                            itp_contribuyente.celular := ft_validar_numero(ln_index.celular);
                            itp_contribuyente.municipio := iv_municipio;
                            itp_contribuyente.departamento := iv_departamento;
                            itp_contribuyente.id_ciudad_dir := ln_index.id_Ciudad_dir;
                        END IF;
                        
                END LOOP;
                IF lb_existe = TRUE THEN
                    itp_list_contribuyente.Extend;
                    itp_list_contribuyente(itp_list_contribuyente.Count()):=itp_contribuyente;
                ELSE
                    itp_contribuyente.id_usuario := lv_id_usuario;  
                    itp_contribuyente.id_documento := iv_documento; 
                    itp_contribuyente.estado := 'No registra informacion';  
                    itp_list_contribuyente.Extend;
                    itp_list_contribuyente(itp_list_contribuyente.Count()):=itp_contribuyente;
                END IF;
                
                lb_existe:=FALSE;
                sp_resetar_var();
        EXCEPTION
            WHEN No_Data_Found THEN 
            EXIT; 
            WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE(Dbms_Utility.Format_Error_Backtrace);
        END;
    END LOOP;
    
    Sp_Registrar_Direcciones;
        
    
END sp_buscar_dir_documento;
    
END PKG_DIRECCIONES_INTERLOCUTORES;

/
--------------------------------------------------------
--  DDL for Package Body PKG_PROPIETARIOS_AUTOMOTOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_PROPIETARIOS_AUTOMOTOR" AS

it_usuario tp_runt_contribuyentes := tp_runt_contribuyentes();
it_lista_usuario tp_runt_lista_contribuyentes := tp_runt_lista_contribuyentes();
TYPE tp_placa IS VARRAY(1500000) OF VARCHAR(10);
Array_Placa tp_placa:=tp_placa();

PROCEDURE Sp_Cargar_Parametro AS

/*ISVA
Nombre     :Sp_Cargar_Parametro
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  :lv_placa, ltul_read
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Recupera placas para procesar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */
lv_placa VARCHAR2 (10 BYTE):='';
ltul_read UTL_FILE.FILE_TYPE; 

BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
        LOOP
            BEGIN
                UTL_FILE.GET_LINE(ltul_read,lv_placa); 
                    Array_Placa.Extend;
                    Array_Placa(Array_Placa.Count) := lv_placa;
                EXCEPTION
                WHEN No_Data_Found THEN EXIT; 
            END;
        END LOOP;    
        
END Sp_Cargar_Parametro;

PROCEDURE sp_resetear AS

/*ISVA
Nombre     :sp_resetear
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Inicializa los parametro nulos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

BEGIN
   
        it_usuario.nro_placa :=''; 
        it_usuario.id_documento :='';
        it_usuario.id_usuario :='';
        it_usuario.nombres :='';
        it_usuario.direccion := '';
        it_usuario.telefono :='';
        it_usuario.municipio :='';
        it_usuario.departamento :='';
        it_usuario.estado :='';
END sp_resetear;

PROCEDURE sp_registrar_info AS

/*ISVA
Nombre     :sp_registrar_info
Autor      :Blados.Ospina
Fecha      :10/01/2019
Variables  :lv_Name_File, lb_Existe_encabezado
Variables  :lutl_write
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Resgistra la informacion 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

lv_Name_File VARCHAR2(255 byte):='Propietarios Automotor '||To_Char(SYSDATE,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_Existe_encabezado BOOLEAN:=FALSE;
lutl_write UTL_FILE.FILE_TYPE;  

BEGIN
    lutl_write := UTL_FILE.FOPEN('DATA_RUNT',lv_Name_File,'W'); 
        FOR ln_index IN 1..it_lista_usuario.COUNT() LOOP
            BEGIN 
                IF lb_Existe_encabezado = FALSE THEN
                      UTL_FILE.PUT_LINE(lutl_write,'NRO_PLACA;'||'DOCUMENTO;'||'TIPO_DOCUMENTO;'||'NOMBRES;'||'DIRECCION;'
                                                   ||'MUNICIPIO;'||'DEPARTAMENTO;'||'ESTADO');
                            lb_Existe_encabezado:=TRUE;
                END IF;
                    UTL_FILE.PUT_LINE(lutl_write,
                            it_lista_usuario(Ln_Index).Nro_Placa||';'
                            ||it_lista_usuario(Ln_Index).id_usuario||';'
                            ||it_lista_usuario(Ln_Index).id_documento||';'
                            ||it_lista_usuario(ln_Index).nombres||';'
                            ||it_lista_usuario(Ln_Index).direccion||';'
                            ||it_lista_usuario(Ln_Index).municipio||';'
                            ||it_lista_usuario(Ln_Index).departamento||';'
                            ||it_lista_usuario(Ln_Index).estado);
            END;
       END LOOP;
END sp_registrar_info;

FUNCTION ft_existe_propietario (av_placa VARCHAR) RETURN BOOLEAN AS

/*ISVA
Nombre     :ft_existe_propietario
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  :ln_existe, lb_existe
Argumentos :av_placa
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Valida si existe un registro
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

ln_existe NUMBER:=0;
lb_existe BOOLEAN:=FALSE;

BEGIN
    SELECT COUNT(1) INTO ln_existe FROM bd_fiscalizacion.fc_usuarios_runt
    WHERE NRO_PLACA = av_placa;
        
        IF ln_existe > 0 THEN
            lb_existe:= TRUE;
        END IF;
            RETURN lb_existe;
            
EXCEPTION
WHEN OTHERS THEN
RETURN lb_existe;
END ft_existe_propietario;

PROCEDURE sp_recupera_informacion (av_placa VARCHAR) AS 

/*ISVA
Nombre     :sp_recupera_informacion
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  :lcur_info
Argumentos :av_placa
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Recupera la informacion y la almacena
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

CURSOR lcur_info IS SELECT  nro_placa,id_documento,id_usuario,nombres,direccion,
                            telefono,municipio,departamento 
                     FROM bd_fiscalizacion.fc_usuarios_runt
                     WHERE nro_placa = av_placa;

BEGIN 
     FOR ln_index IN lcur_info lOOP
        
        it_usuario.nro_placa := ln_index.nro_placa; 
        it_usuario.id_documento := ln_index.id_documento;
        it_usuario.id_usuario := ln_index.id_usuario;
        it_usuario.nombres := ln_index.nombres;
        it_usuario.direccion := ln_index.direccion;
        it_usuario.telefono := ln_index.telefono;
        it_usuario.municipio := ln_index.municipio;
        it_usuario.departamento := ln_index.departamento;
        it_usuario.estado := 'Reporta propietario';
        
        it_lista_usuario.Extend;
        it_lista_usuario(it_lista_usuario.Count) := it_usuario;
              
     END LOOP;
END sp_recupera_informacion;

PROCEDURE sp_consulta_prop AS

/*ISVA
Nombre     :sp_consulta_prop
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  :lb_existe
Argumentos :
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Recupera la cantidad de registros a validar 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

lb_existe BOOLEAN;

BEGIN
    FOR ln_index IN 1..Array_Placa.COUNT() lOOP
        sp_resetear;
        lb_existe:=FALSE;
        
        lb_existe:= ft_existe_propietario(Array_Placa(ln_index));
        
        IF lb_existe = TRUE THEN
            sp_recupera_informacion(Array_Placa(ln_index));    
        ELSE
            it_usuario.nro_placa := Array_Placa(ln_index);
            it_usuario.estado := 'No registra informacion';
        
            it_lista_usuario.Extend;
            it_lista_usuario(it_lista_usuario.Count) := it_usuario;           
            
        END IF;
    END LOOP;
        
        
        
END sp_consulta_prop;

PROCEDURE sp_iniciar AS

/*ISVA
Nombre     :sp_iniciar
Autor      :Blados.Ospina
Fecha      :09/01/2019
Variables  :lb_existe
Argumentos :
Retorno    :              
Proyecto   :PKG_PROPIETARIOS_AUTOMOTOR
Version    :1.0
Objetivo   :Inicia los procesos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                      */

BEGIN
        Sp_Cargar_Parametro;
        sp_consulta_prop;
        sp_registrar_info;
END sp_iniciar;

END PKG_PROPIETARIOS_AUTOMOTOR;

/
--------------------------------------------------------
--  DDL for Package Body PKG_REPORTE_LUISA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_REPORTE_LUISA" AS

PROCEDURE sp_iniciar_reporte_pagos (an_vigencia number) AS


Ln_Contador number:=0;
lv_departamento Varchar2(255);
lv_municipio Varchar2(255);
lv_fecha_pago VARCHAR2(10);
ln_existe NUMBER;

Cursor lcur_placas Is Select nro_placa
                      From CORRECCION_DATOS.TEMP_PLACAS;

Begin
        For Ln_Index In lcur_placas Loop
            Begin
                lv_departamento :='';
                lv_municipio :='';
                ln_existe:=0;
                lv_fecha_pago := null;

                 
                 Select Count(1) into ln_existe
                 From bd_fiscalizacion.fc_reporte_pagos fp
                 where nro_placa = ln_index.nro_placa AND VIGENCIA = an_vigencia;
                    
         --    Temp_Placas 
     
                        If ln_existe > 0 Then
                             Select Distinct fp.departamento,fp.municipio, fp.fecha_pago
                             into lv_departamento, lv_municipio, lv_fecha_pago
                             From bd_fiscalizacion.fc_reporte_pagos fp
                             where nro_placa = ln_index.nro_placa AND VIGENCIA = an_vigencia And Rownum = 1;
                             
                                    Update CORRECCION_DATOS.TEMP_PLACAS Tp Set Tp.MUNICIPIO_RES2017= lv_municipio, Tp.DPTO_RES2017= lv_departamento,
                                    Tp.FECHA_PAGO2017 = lv_fecha_pago
                                    Where Tp.Nro_Placa = Ln_Index.Nro_Placa; 
                        Else
                            Update CORRECCION_DATOS.TEMP_PLACAS Tp Set Tp.FECHA_PAGO2017= 'No tiene Pago para la vigencia '||an_vigencia
                            Where Tp.Nro_Placa = Ln_Index.Nro_Placa; 
                        End IF;
                    
                        If Ln_Contador = 100 Then
                          Commit;
                          Ln_Contador := 0;
                        Else
                          Ln_Contador := Ln_Contador + 1;
                        End If;
                    EXCEPTION
                    WHEN OTHERS THEN
                        Update CORRECCION_DATOS.TEMP_PLACAS Tp Set Tp.FECHA_PAGO2017= 'Error Validar'||an_vigencia
                        Where Tp.Nro_Placa = Ln_Index.Nro_Placa; 
                    
             End; 
         End Loop;
         COMMIT;
END sp_iniciar_reporte_pagos;

END PKG_REPORTE_LUISA;

/
--------------------------------------------------------
--  DDL for Package Body PKG_REPORTE_OMISOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_REPORTE_OMISOS" AS

PROCEDURE sp_iniciar(an_vigencia_Anno NUMBER) AS

/*ISVA
Nombre     :sp_iniciar
Autor      :Blados.Ospina
Fecha      :03/01/2019
Argumento  :an_vigencia_Anno
Variables  :
Retorno    :              
Proyecto   :PKG_REPORTE_OMISOS
Version    :1.0
Objetivo   :Varias vigencias para detencion de omisos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
                                                    */

BEGIN
    
    FOR ln_vigencia IN an_vigencia_Anno..TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) LOOP
        bd_fiscalizacion.pkg_buscar_novedad_sap_final.sp_iniciar_omisos(ln_vigencia);
    END LOOP;
    

END sp_iniciar;

END PKG_REPORTE_OMISOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_REPORTE_PAGOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "CONSULTAS"."PKG_REPORTE_PAGOS" AS

iv_vigencia VARCHAR2 (4000 BYTE);
iv_cantidad_vigencia SIMPLE_INTEGER :=2020;

PROCEDURE sp_pagos_fecha_valor AS

/*ISVA 
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :lv_Name_File, lu_escribir_archivo
Variables  :lb_Existe_encabezado
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Recupera las placas a consultar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

lv_Name_File Varchar2(255 byte):='Pagos '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_existe BOOLEAN;
lb_Existe_encabezado Boolean:=FALSE;
lu_escribir_archivo UTL_FILE.FILE_TYPE;
ltul_read UTL_FILE.FILE_TYPE; 
lv_placas VARCHAR2(10); 

BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
    lu_escribir_archivo := UTL_FILE.FOPEN('CONSULTA_PAGOS',lv_Name_File,'W');
        LOOP
            BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_placas); 
                        --lb_existe:=ft_consultar_pago(TRIM(lv_placas));
                            If lb_Existe_encabezado = False Then
                                  UTL_FILE.PUT_LINE(lu_escribir_archivo,'NRO_PLACA;'||'VIGENCIAS');
                                        lb_Existe_encabezado:=True;
                             End If;
                        IF lb_existe = TRUE THEN
                            UTL_FILE.PUT_LINE(lu_escribir_archivo,lv_placas||';'||iv_vigencia);
                        ELSE
                            UTL_FILE.PUT_LINE(lu_escribir_archivo,lv_placas||';'||'No registra pagos');
                        END IF;
                    EXCEPTION 
                    WHEN No_Data_Found THEN EXIT; 
                END;
        END LOOP;
             
             UTL_FILE.FCLOSE(lu_escribir_archivo);
             UTL_FILE.FCLOSE(ltul_read);
  
END sp_pagos_fecha_valor;

FUNCTION ft_consultar_vigencias (av_placa VARCHAR) RETURN BOOLEAN AS

CURSOR lcur_vigencias IS SELECT  DISTINCT vigencia FROM BD_FISCALIZACION.FC_REPORTE_PAGOS
                         WHERE nro_placa = av_placa
                         UNION
                         SELECT  DISTINCT vigencia FROM BD_FISCALIZACION.FC_PAGOS_QX
                         WHERE nro_placa = av_placa;
lb_existe BOOLEAN:=FALSE;

BEGIN
    iv_vigencia:='';
    FOR ln_index IN lcur_vigencias LOOP
         iv_vigencia:= iv_vigencia ||ln_index.vigencia||';';
         lb_existe:=TRUE;
    END LOOP;
    
    RETURN lb_existe;
    
END ft_consultar_vigencias;

PROCEDURE sp_consultar_placas AS

/*ISVA 
Nombre     :Sp_Consultar_Propietarios_Runt
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :lv_Name_File, lu_escribir_archivo
Variables  :lb_Existe_encabezado
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Recupera las placas a consultar
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

lv_Name_File Varchar2(255 byte):='Pagos '||To_Char(Sysdate,'dd-mm-yyyy hh24-mi-ss')||'.txt';
lb_existe BOOLEAN;
lb_Existe_encabezado Boolean:=FALSE;
lu_escribir_archivo UTL_FILE.FILE_TYPE;
ltul_read UTL_FILE.FILE_TYPE; 
lv_placas VARCHAR2(10); 

BEGIN
    ltul_read := UTL_FILE.FOPEN('DATA_LOAD','placas.csv','R');
    lu_escribir_archivo := UTL_FILE.FOPEN('CONSULTA_PAGOS',lv_Name_File,'W');
        LOOP
            BEGIN
            UTL_FILE.GET_LINE(ltul_read,lv_placas); 
                        lb_existe:=ft_consultar_vigencias(TRIM(lv_placas));
                            If lb_Existe_encabezado = False Then
                                  UTL_FILE.PUT_LINE(lu_escribir_archivo,'NRO_PLACA;'||'VIGENCIAS');
                                        lb_Existe_encabezado:=True;
                             End If;
                        IF lb_existe = TRUE THEN
                            UTL_FILE.PUT_LINE(lu_escribir_archivo,lv_placas||';'||iv_vigencia);
                        ELSE
                            UTL_FILE.PUT_LINE(lu_escribir_archivo,lv_placas||';'||'No registra pagos');
                        END IF;
                    EXCEPTION 
                    WHEN No_Data_Found THEN EXIT; 
                END;
        END LOOP;
             
             UTL_FILE.FCLOSE(lu_escribir_archivo);
             UTL_FILE.FCLOSE(ltul_read);
  
END sp_consultar_placas;


FUNCTION ft_validar_pago (av_placa VARCHAR,av_vigencia NUMBER, an_parametro NUMBER) RETURN BOOLEAN AS

lb_existe BOOLEAN:=FALSE;

BEGIN
    iv_vigencia:='';
    
    IF an_parametro = 1 THEN
          SELECT (vigencia ||'|'|| fecha_pago ||'|'|| valor_pago) INTO iv_vigencia FROM bd_fiscalizacion.fc_reporte_pagos
          WHERE nro_placa = av_placa AND vigencia = av_vigencia AND ROWNUM = 1;
    ELSE
          SELECT (vigencia ||'|'|| fecha_pago ||'|'|| (impuesto + sancion + interes_mora)) INTO iv_vigencia 
          FROM bd_fiscalizacion.fc_pagos_QX
          WHERE nro_placa = av_placa AND vigencia = av_vigencia AND ROWNUM = 1;
    END IF;
            
            IF iv_vigencia IS NOT NULL THEN
                lb_existe := TRUE;
            END IF ;
            
            RETURN lb_existe;
            
EXCEPTION          
WHEN OTHERS THEN
RETURN lb_existe;
END ft_validar_pago;

PROCEDURE sp_reporte_pagos_2 AS 

/*ISVA 
Nombre     :sp_reporte_pagos
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :ln_vigencia_fin, lv_existe
Variables  :lv_sqltext, lv_placa, ln_commit
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Verifica cada uno de los pagos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

ln_vigencia_fin Number:=iv_cantidad_vigencia;
lb_existe BOOLEAN;
lv_sqltext VARCHAR2(255 BYTE);
lv_placa VARCHAR2(255 BYTE);
ln_commit NUMBER:=0;

CURSOR lcur_placa_vigencia IS SELECT DISTINCT nro_placa, modelo FROM reporte_pagos;

BEGIN
    FOR ln_index IN lcur_placa_vigencia LOOP
        FOR I IN (ln_index.modelo-1)..ln_vigencia_fin LOOP
            lb_existe:=FALSE;
            ln_commit:= ln_commit + 1;
            
            lb_existe := ft_validar_pago (ln_index.nro_placa, I, 1);
                IF lb_existe = TRUE THEN
                    lv_sqltext:= 'UPDATE REPORTE_PAGOS' ||
                    ' SET A_' || I || ' = ' ||''''|| iv_vigencia ||''''||
                    ' WHERE nro_placa = '||''''|| ln_index.nro_placa || ''''; 
                    --DBMS_OUTPUT.PUT_LINE(lv_sqltext);
                    EXECUTE IMMEDIATE lv_sqltext;           
                END IF;
                IF ln_commit = 100 THEN 
                   ln_commit:=0;
                   COMMIT;
                END IF;
        END LOOP;
    END LOOP;
END sp_reporte_pagos_2;

PROCEDURE sp_reporte_pagos_qx_2 AS 

/*ISVA 
Nombre     :sp_reporte_pagos
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :ln_vigencia_fin, lv_existe
Variables  :lv_sqltext, lv_placa, ln_commit
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Verifica cada uno de los pagos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

ln_vigencia_fin Number:=2012;
lb_existe BOOLEAN;
lv_sqltext VARCHAR2(255 BYTE);
lv_placa VARCHAR2(255 BYTE);
ln_commit NUMBER:=0;

CURSOR lcur_placa_vigencia IS SELECT DISTINCT nro_placa, modelo FROM reporte_pagos;

BEGIN
    FOR ln_index IN lcur_placa_vigencia LOOP
        FOR I IN (ln_index.modelo-1)..ln_vigencia_fin LOOP
            lb_existe :=FALSE; 
            ln_commit:= ln_commit + 1;
             lb_existe := ft_validar_pago(ln_index.nro_placa, I, 2);
                IF lb_existe =TRUE THEN
                    lv_sqltext:= 'UPDATE reporte_pagos' ||
                    ' SET A_' || I || ' = ' ||''''|| iv_vigencia ||''''||
                    ' WHERE nro_placa = '||''''|| ln_index.nro_placa || ''''; 
                    --DBMS_OUTPUT.PUT_LINE(lv_sqltext);
                    EXECUTE IMMEDIATE lv_sqltext;          
                END IF;
                IF ln_commit = 100 THEN 
                   ln_commit:=0;
                   COMMIT;
                END IF;
        END LOOP;
    END LOOP;
END sp_reporte_pagos_qx_2;


PROCEDURE sp_reporte_pagos AS 

/*ISVA 
Nombre     :sp_reporte_pagos
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :ln_vigencia_fin, lv_existe
Variables  :lv_sqltext, lv_placa, ln_commit
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Verifica cada uno de los pagos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

ln_vigencia_fin Number:=iv_cantidad_vigencia;
lv_existe VARCHAR2(5 BYTE);
lv_sqltext VARCHAR2(255 BYTE);
lv_placa VARCHAR2(255 BYTE);
ln_commit NUMBER:=0;

CURSOR lcur_placa_vigencia IS SELECT DISTINCT nro_placa, modelo FROM reporte_pagos;

BEGIN
    FOR ln_index IN lcur_placa_vigencia LOOP
        FOR I IN (ln_index.modelo-2)..ln_vigencia_fin LOOP
            ln_commit:= ln_commit + 1;
            SELECT DECODE(count(1),0,'FALSE','TRUE') INTO lv_existe FROM bd_fiscalizacion.fc_reporte_pagos
            WHERE nro_placa = ln_index.nro_placa AND vigencia = I;
                IF lv_existe = 'TRUE' THEN
                    lv_sqltext:= 'update reporte_pagos' ||
                    ' set A_' || I || ' = ' || I ||
                    ' where nro_placa = '||''''|| ln_index.nro_placa || ''''; 
                    --DBMS_OUTPUT.PUT_LINE(lv_sqltext);
                    EXECUTE IMMEDIATE lv_sqltext;
                    lv_existe :='FALSE';              
                END IF;
                IF ln_commit = 100 THEN 
                   ln_commit:=0;
                   COMMIT;
                END IF;
                  COMMIT;
        END LOOP;
    END LOOP;
    COMMIT;
END sp_reporte_pagos;

PROCEDURE sp_reporte_pagos_qx AS 

/*ISVA 
Nombre     :sp_reporte_pagos
Autor      :Blados.Ospina
Fecha      :10/09/2018
Variables  :ln_vigencia_fin, lv_existe
Variables  :lv_sqltext, lv_placa, ln_commit
Retorno    :              
Proyecto   :PKG_REPORTE_PAGOS
Versi�n    :1.0
Objetivo   :Verifica cada uno de los pagos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
10/09/2018  Blados.Ospina   1.0                     */

ln_vigencia_fin Number:=2020;
lv_existe VARCHAR2(5 BYTE);
lv_sqltext VARCHAR2(255 BYTE);
lv_placa VARCHAR2(255 BYTE);
ln_commit NUMBER:=0;

CURSOR lcur_placa_vigencia IS SELECT DISTINCT nro_placa, modelo FROM reporte_pagos;

BEGIN
    FOR ln_index IN lcur_placa_vigencia LOOP
        FOR I IN (ln_index.modelo-2)..ln_vigencia_fin LOOP
            ln_commit:= ln_commit + 1;
            SELECT DECODE(count(1),0,'FALSE','TRUE') INTO lv_existe FROM bd_fiscalizacion.fc_pagos_qx
            WHERE nro_placa = ln_index.nro_placa AND vigencia = I;
                IF lv_existe = 'TRUE' THEN
                    lv_sqltext:= 'update reporte_pagos' ||
                    ' set A_' || I || ' = ' || I ||
                    ' where nro_placa = '||''''|| ln_index.nro_placa || ''''; 
                    --DBMS_OUTPUT.PUT_LINE(lv_sqltext);
                    EXECUTE IMMEDIATE lv_sqltext;
                    lv_existe :='FALSE';              
                END IF;
                IF ln_commit = 100 THEN 
                   ln_commit:=0;
                   COMMIT;
                END IF;
                  COMMIT;
        END LOOP;
    END LOOP;
    COMMIT;
END sp_reporte_pagos_qx;

PROCEDURE SP_INICAR AS
BEGIN
    sp_reporte_pagos;
    sp_reporte_pagos_qx;
    
    --sp_reporte_pagos_2;
    --sp_reporte_pagos_qx_2;
END SP_INICAR;

END PKG_REPORTE_PAGOS;

/
--------------------------------------------------------
--  DDL for Function FT_DIGITO_VERIFICACION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "CONSULTAS"."FT_DIGITO_VERIFICACION" (av_nit VARCHAR) RETURN VARCHAR2 AS 


NIT VARCHAR2(255):=''; 
DIGITO VARCHAR2(255):='';

BEGIN
    DIGITO:=depuracion.pkg_ds_estandariza_registros.ft_calcular_digito_verifica(av_nit);
        
    RETURN av_nit||DIGITO;

EXCEPTION 
WHEN OTHERS THEN
    RETURN av_nit||DIGITO;
END FT_DIGITO_VERIFICACION;

/
