--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type CAMPOS_ARRAY
--------------------------------------------------------

  CREATE OR REPLACE TYPE "DEPURACION"."CAMPOS_ARRAY" AS TABLE OF NUMBER;

/
--------------------------------------------------------
--  DDL for Type SQLERR_ARRAY
--------------------------------------------------------

  CREATE OR REPLACE TYPE "DEPURACION"."SQLERR_ARRAY" 
AS TABLE OF VARCHAR2(4000);

/
--------------------------------------------------------
--  DDL for Trigger TRG_DS_TMP_CONTRIBUYENTES
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "DEPURACION"."TRG_DS_TMP_CONTRIBUYENTES" 
BEFORE INSERT ON DS_TMP_CONTRIBUYENTES
FOR EACH ROW 
DECLARE
  v_id_documento NUMBER;
BEGIN
      BEGIN
        SELECT MIN(ID_DOCUMENTO)
        INTO V_ID_DOCUMENTO
        FROM QUIPUX.TIPO_DOCUMENTO
        WHERE MIN_DOCUMENTO = UPPER(:NEW.ID_DOCUMENTO) AND
              ID_DOCUMENTO >= 0;
      EXCEPTION
      WHEN OTHERS THEN
        V_ID_DOCUMENTO := 0;
      END;
      
      IF V_ID_DOCUMENTO > 0 THEN
        :NEW.ID_DOCUMENTO := TO_CHAR(V_ID_DOCUMENTO);
      END IF;
      
      SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_DOCUMENTO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
        INTO :NEW.ID_DOCUMENTO FROM DUAL;
          
      IF NOT V_ID_DOCUMENTO = 6 THEN    
        SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_USUARIO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
          INTO :NEW.ID_USUARIO FROM DUAL;
      END IF;    
      
END;
/
ALTER TRIGGER "DEPURACION"."TRG_DS_TMP_CONTRIBUYENTES" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_DS_TMP_PROPIETARIOS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "DEPURACION"."TRG_DS_TMP_PROPIETARIOS" 

BEFORE INSERT ON DS_TMP_PROPIETARIOS

FOR EACH ROW
DECLARE
  v_id_documento NUMBER;
BEGIN
      BEGIN
        SELECT MIN(ID_DOCUMENTO)
        INTO V_ID_DOCUMENTO
        FROM QUIPUX.TIPO_DOCUMENTO
        WHERE MIN_DOCUMENTO = UPPER(:NEW.ID_DOCUMENTO) AND
              ID_DOCUMENTO >= 0;
      EXCEPTION
      WHEN OTHERS THEN
        V_ID_DOCUMENTO := 0;
      END;
      
      IF V_ID_DOCUMENTO > 0 THEN
        :NEW.ID_DOCUMENTO := TO_CHAR(V_ID_DOCUMENTO);
      END IF;
      
      SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.NRO_PLACA, 'nls_sort=binary_ai')))),' ',''),'[^0-9A-Z]','') 
				INTO :NEW.NRO_PLACA FROM DUAL;
      
      SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_DOCUMENTO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
				INTO :NEW.ID_DOCUMENTO FROM DUAL;		
          
      IF NOT V_ID_DOCUMENTO = 6 THEN
        SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.ID_USUARIO, 'nls_sort=binary_ai')))),' ',''),'[^0-9]','') 
          INTO :NEW.ID_USUARIO FROM DUAL;	
      END IF;   
END;
/
ALTER TRIGGER "DEPURACION"."TRG_DS_TMP_PROPIETARIOS" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_DS_TMP_TRAMITES
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "DEPURACION"."TRG_DS_TMP_TRAMITES" 

BEFORE INSERT ON DS_TMP_TRAMITES

FOR EACH ROW 
DECLARE
  v_id_documento NUMBER;
BEGIN
      BEGIN
        SELECT MIN(ID_DOCUMENTO)
        INTO V_ID_DOCUMENTO
        FROM QUIPUX.TIPO_DOCUMENTO
        WHERE MIN_DOCUMENTO = UPPER(:NEW.ID_DOCUMENTO_ANTERIOR) AND
              ID_DOCUMENTO >= 0;
      EXCEPTION
      WHEN OTHERS THEN
        V_ID_DOCUMENTO := 0;
      END;
      
      IF V_ID_DOCUMENTO > 0 THEN
        :NEW.ID_DOCUMENTO_ANTERIOR := TO_CHAR(V_ID_DOCUMENTO);
      END IF;
      
      BEGIN
        SELECT MIN(ID_DOCUMENTO)
        INTO V_ID_DOCUMENTO
        FROM QUIPUX.TIPO_DOCUMENTO
        WHERE MIN_DOCUMENTO = UPPER(:NEW.ID_DOCUMENTO_NUEVO) AND
              ID_DOCUMENTO >= 0;
      EXCEPTION
      WHEN OTHERS THEN
        V_ID_DOCUMENTO := 0;
      END;
      
      IF V_ID_DOCUMENTO > 0 THEN
        :NEW.ID_DOCUMENTO_NUEVO := TO_CHAR(V_ID_DOCUMENTO);
      END IF;
      
      
      SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.NRO_PLACA, 'nls_sort=binary_ai')))),' ',''),'[^0-9A-Z]','') 
				INTO :NEW.NRO_PLACA FROM DUAL;
      
      IF ( :NEW.ID_TRAMITE = 20 ) THEN
          UPDATE DEPURACION.DS_VEHICULO SET ID_ESTADO = 12 WHERE NRO_PLACA = :NEW.NRO_PLACA;
      END IF;
      
END;
/
ALTER TRIGGER "DEPURACION"."TRG_DS_TMP_TRAMITES" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_DS_TMP_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "DEPURACION"."TRG_DS_TMP_VEHICULOS" 
 
BEFORE INSERT ON DS_TMP_VEHICULOS 
FOR EACH ROW 
BEGIN
      SELECT regexp_replace(REPLACE(upper(utl_raw.cast_to_varchar2((nlssort(:NEW.NRO_PLACA, 'nls_sort=binary_ai')))),' ',''),'[^0-9A-Z]','') 
				INTO :NEW.NRO_PLACA FROM DUAL;
        
      IF (:NEW.ID_ESTADO IS NULL) THEN
          IF ( :NEW.NOMBRE_ESTADO = 'ACTIVO' ) THEN
                :NEW.ID_ESTADO := 1;
          ELSIF ( :NEW.NOMBRE_ESTADO = 'INACTIVO' ) THEN
                :NEW.ID_ESTADO := 12;
          ELSIF ( :NEW.NOMBRE_ESTADO = 'CANCELADO' ) THEN
                :NEW.ID_ESTADO := 8;
          END IF;
      END IF;
      
      IF (:NEW.IMPORTADO_NACIONAL IS NULL OR :NEW.IMPORTADO_NACIONAL NOT IN ('N','I')) THEN
        :NEW.IMPORTADO_NACIONAL := 'N';
     END IF;
END;
/
ALTER TRIGGER "DEPURACION"."TRG_DS_TMP_VEHICULOS" ENABLE;
--------------------------------------------------------
--  DDL for Procedure P_GENERA_SQL
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."P_GENERA_SQL" AS
CURSOR CSQLOBLIGATORIO IS
        SELECT DISTINCT  DS_TIPO_INCONSISTENCIA.ID_INCONSISTENCIA,
          DS_TIPO_REGISTRO.ESQUEMA,
          DS_TIPO_REGISTRO.NOMBRE_TABLA,
          DS_CAMPO_ARCHIVO.ID_CAMPO,
          DS_CAMPO_ARCHIVO.NOMBRE_CAMPO
        FROM DS_TIPO_INCONSISTENCIA
        INNER JOIN DS_VALIDACIONES_CAMPO
        ON DS_TIPO_INCONSISTENCIA.ID_INCONSISTENCIA = DS_VALIDACIONES_CAMPO.ID_INCONSISTENCIA
        INNER JOIN DS_CAMPO_ARCHIVO
        ON DS_CAMPO_ARCHIVO.ID_CAMPO = DS_VALIDACIONES_CAMPO.ID_CAMPO
        INNER JOIN DS_TIPO_REGISTRO
        ON DS_TIPO_REGISTRO.ID_TIPO_REGISTRO = DS_CAMPO_ARCHIVO.ID_TIPO_REGISTRO
        WHERE DS_TIPO_REGISTRO.ACTIVO        = 'S'
        AND DS_CAMPO_ARCHIVO.ACTIVO          = 'S'
        AND DS_CAMPO_ARCHIVO.OBLIGATORIO     = 'S'
        AND DS_VALIDACIONES_CAMPO.ACTIVO     = 'S'
        AND DS_TIPO_INCONSISTENCIA.ACTIVO    = 'S'
        AND DS_TIPO_INCONSISTENCIA.ID_INCONSISTENCIA = 102;

SQLTXT VARCHAR2(2000 BYTE);

BEGIN
    FOR XSQL IN CSQLOBLIGATORIO LOOP
        SQLTXT := 'SELECT COUNT(1) FROM '||XSQL.ESQUEMA||'.'||XSQL.NOMBRE_TABLA||' A WHERE A.'||TRIM(XSQL.NOMBRE_CAMPO)||' IS NOT NULL AND A.';
        dbms_output.put_line(SQLTXT);
        UPDATE DEPURACION.DS_VALIDACIONES_CAMPO VC SET VC.SQLTEXT = SQLTXT
            WHERE VC.ID_CAMPO = XSQL.ID_CAMPO AND VC.ID_INCONSISTENCIA = XSQL.ID_INCONSISTENCIA;
        COMMIT;
    END LOOP;
END;
 

/
--------------------------------------------------------
--  DDL for Procedure P_PLACAS_FOTO_DETECCION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."P_PLACAS_FOTO_DETECCION" AS 

v_archivo utl_file.file_type;
directorio varchar2(100);
BEGIN
  
  begin
    v_archivo := utl_file.fopen ('DS_DIR_SOSTENIBILIDAD', 'test_utl_file.txt', 'w');
  exception
  when utl_file.INVALID_OPERATION then
    dbms_output.put_line('SI');
    IF UTL_FILE.IS_OPEN(v_archivo) = TRUE Then
       dbms_output.put_line('SI');
    END IF;
  end;

  utl_file.put_line (v_archivo, 'Prueba de escritura');

  utl_file.put (v_archivo, 'Texto sin fin de l�nea');
  utl_file.put_line (v_archivo, ' que sigue y termina ac�.');

  utl_file.fclose(v_archivo); 

  
END;
 

/
--------------------------------------------------------
--  DDL for Procedure PRUEBA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."PRUEBA" AS 
ARCH UTL_FILE.FILE_TYPE;
BEGIN
  ARCH := UTL_FILE.FOPEN('DS_DIR_PRUEBA','otro.txt','w');
  UTL_FILE.PUT_LINE(ARCH,'PRUEBA');
  UTL_FILE.FCLOSE(ARCH);
END PRUEBA;
 

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_LINEA_TIPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."PS_ACTUALIZAR_LINEA_TIPO" AS 
Lv_Codigo_Tipo Varchar2(10);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
Select Tl.Id_Linea  Into Lv_Codigo_Tipo
From Quipux.Lic_Tto Lt
Inner Join Quipux.Qx_Tipo_Linea Qtl On Qtl.Runt_Linea = Lt.Id_Linea_Runt
Inner Join Quipux.Tipo_Linea Tl On Tl.Id_Linea_Qx = Qtl.Id_Linea_Qx
Where Lt.Nro_Placa = Ln_Index.NRO_PLACA
And Rownum = 1;

Update Quipux.Lic_Tto Lt Set Lt.Id_Linea = Lv_Codigo_Tipo
Where Lt.Nro_Placa = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.Observacion = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PS_ACTUALIZAR_LINEA_TIPO;

/
--------------------------------------------------------
--  DDL for Procedure PS_ACTUALIZAR_LINEA_TIPO3
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."PS_ACTUALIZAR_LINEA_TIPO3" AS 
Lv_Codigo_Tipo Varchar2(10);
Ln_Contador Number := 0;

Cursor Actualizar_Lic_Tto Is
Select * From Temp_Placas;

Begin

For Ln_Index In Actualizar_Lic_Tto Loop

Begin
Select Tl.Id_Linea Into Lv_Codigo_Tipo
From Quipux.Lic_Tto Lt
Inner Join Quipux.Qx_Tipo_Linea Qtl On Qtl.Runt_Linea = Lt.Id_Linea_Runt
Inner Join Quipux.Tipo_Linea Tl On Tl.Id_Linea_Qx = Qtl.Id_Linea_Qx
Inner Join sap_lineas SL On Tl.ID_LINEA_QX = SL.ID_LINEA_QX
Where Lt.Nro_Placa = Ln_Index.Nro_Placa AND TL.DESC_LINEA =SL.DESC_LINEA_QX
And Rownum = 1;

Update Quipux.Lic_Tto Lt Set Lt.Id_Linea = Lv_Codigo_Tipo
Where Lt.Nro_Placa = Ln_Index.Nro_Placa;

Exception
When Others Then

Update Temp_Placas Tp Set Tp.Observacion = 'Error al realizar el insert'
Where Tp.Nro_Placa = Ln_Index.Nro_Placa;

End;
If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

End Loop;
Commit;
END PS_ACTUALIZAR_LINEA_TIPO3;

/
--------------------------------------------------------
--  DDL for Procedure SP_COMPARACION_LINEAS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SP_COMPARACION_LINEAS" AS

vl_cor_marca_runt    temp_lineas_runt.cod_marca_runt%TYPE;
vl_cod_linea_runt    temp_lineas_runt.cod_linea_runt%TYPE;    
vs_nombre_linea_runt temp_lineas_runt.nombre_linea%TYPE;     
vs_cod_marca_sap     temp_lineas_sap.cod_marca%TYPE;
vs_cod_linea_sap     temp_lineas_sap.cod_linea%TYPE;
vs_nombre_linea_sap  temp_lineas_sap.nombre_linea%TYPE;
vl_cod_marc_runt_sap temp_lineas_sap.cod_marca_runt%TYPE; 
vs_log               temp_log.logs%TYPE; 
vl_cantidad_linea    NUMBER;
vl_cantidad_commit   NUMBER;


 cod number;
 cod_liean number;

CURSOR vc_lineas_sap IS
      SELECT cod_marca,cod_linea,nombre_linea,cod_marca_runt
      FROM temp_lineas_sap;

BEGIN
  vl_cantidad_linea:=0;
  vl_cantidad_commit:=0;
  
  OPEN vc_lineas_sap;
    LOOP
      FETCH vc_lineas_sap INTO vs_cod_marca_sap,vs_cod_linea_sap,vs_nombre_linea_sap,vl_cod_marc_runt_sap;
        EXIT WHEN vc_lineas_sap%NOTFOUND;
        
       vs_nombre_linea_sap := trim(vs_nombre_linea_sap);
        BEGIN
        SELECT COUNT(1)
        INTO vl_cantidad_linea
        FROM temp_lineas_runt
        WHERE nombre_linea =vs_nombre_linea_sap AND
              cod_marca_runt =vl_cod_marc_runt_sap;
     
        EXCEPTION WHEN OTHERS THEN 
          dbms_output.put_line(sqlerrm);
          CONTINUE;
        END;   
          
          --Si no encuentra valor inserta el log directamente
        IF vl_cantidad_linea =0 THEN
          vs_log :='';
          vs_log :='No se encontro informaci�n que cohincidera con la linea '||vs_nombre_linea_sap || ' verifique.';
            
          BEGIN
            INSERT INTO temp_log(cod_marca,cod_linea,nombre_linea,logs,filtro_log)
                        VALUES(vs_cod_marca_sap,vs_cod_linea_sap,vs_nombre_linea_sap,vs_log,'NO_EXISTE');
            EXCEPTION WHEN OTHERS THEN
                dbms_output.put_line(sqlerrm);
                ROLLBACK;
                CONTINUE;
            END;                
        ELSE
        
         IF vl_cantidad_linea >1 THEN
         
              vs_log :='';
              vs_log :='Se encontraron '||to_char(vl_cantidad_linea) || ' lineas RUNT para esta desc :'||vs_nombre_linea_sap ||' verifique.';
                  BEGIN
                    INSERT INTO temp_log(cod_marca,cod_linea,nombre_linea,logs,filtro_log)
                                VALUES(vs_cod_marca_sap,vs_cod_linea_sap,vs_nombre_linea_sap,vs_log,'REPETIDOS');
       
                    EXCEPTION WHEN OTHERS THEN
                      dbms_output.put_line(sqlerrm);
                      ROLLBACK;
                      CONTINUE;
                  END;
             
          ELSE
             --Si solo existe un registro inserto en la tabla de correctos
               BEGIN
                SELECT cod_marca_runt,cod_linea_runt,nombre_linea
                INTO vl_cor_marca_runt,vl_cod_linea_runt,vs_nombre_linea_runt
                FROM temp_lineas_runt
                WHERE nombre_linea =vs_nombre_linea_sap AND
                      cod_marca_runt =vl_cod_marc_runt_sap;
                
              EXCEPTION WHEN OTHERS THEN
                dbms_output.put_line(sqlerrm);
                ROLLBACK;
                CONTINUE;
              END;
                
              BEGIN 
                INSERT INTO temp_iguales(cod_marca_sap,cod_linea_sap,nombre_linea_sap,cod_marca_runt,cod_linea_runt,nombre_linea)
                    VALUES(vs_cod_marca_sap,
                           vs_cod_linea_sap,
                           vs_nombre_linea_sap,
                           vl_cor_marca_runt,
                           vl_cod_linea_runt,
                           vs_nombre_linea_runt);
                           
              EXCEPTION WHEN OTHERS THEN
                dbms_output.put_line(sqlerrm);
                ROLLBACK;
                CONTINUE;
              END;
          END IF;
        END IF;
       --Se valida para que cada 100 registros realice commit;
       IF vl_cantidad_commit =100 THEN
          vl_cantidad_commit :=0;
          COMMIT;
      END IF;
       

    END LOOP;
  CLOSE vc_lineas_sap;
  COMMIT;


 EXCEPTION WHEN OTHERS THEN 
      dbms_output.put_line(sqlerrm);

END SP_COMPARACION_LINEAS;

/
--------------------------------------------------------
--  DDL for Procedure SP_CURSOR_REGISTROS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SP_CURSOR_REGISTROS" (VTIPO_REGISTRO NUMBER, VRADICADO NUMBER, VDATO VARCHAR2, GB_REF_CURSOR IN OUT SYS_REFCURSOR)
IS
BEGIN
    IF ( VTIPO_REGISTRO = 1 ) THEN
        OPEN GB_REF_CURSOR FOR SELECT * FROM DEPURACION.DS_VEHICULO WHERE ID_RADICADO = VRADICADO AND NRO_PLACA = VDATO;
    ELSIF ( VTIPO_REGISTRO = 2 ) THEN
        OPEN GB_REF_CURSOR FOR SELECT * FROM DEPURACION.DS_CONTRIBUYENTE WHERE ID_RADICADO = VRADICADO AND ID_DOCUMENTO = SUBSTR(VDATO,1,1) AND ID_USUARIO = SUBSTR(VDATO,2,LENGTH(VDATO));
    ELSIF ( VTIPO_REGISTRO = 3 ) THEN
        OPEN GB_REF_CURSOR FOR SELECT * FROM DEPURACION.DS_PROPIETARIO WHERE ID_RADICADO = VRADICADO AND NRO_PLACA = VDATO;
    ELSIF ( VTIPO_REGISTRO = 4 ) THEN
        OPEN GB_REF_CURSOR FOR SELECT * FROM DEPURACION.DS_TRAMITE WHERE ID_RADICADO = VRADICADO AND NRO_PLACA = VDATO;
    END IF;
END;
 

/
--------------------------------------------------------
--  DDL for Procedure SP_EJEMPLO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SP_EJEMPLO" 
AS
Lv_id_usuario number(12);
Lv_PLACA varchar (20);
Lv_MARCA varchar (20);
Lv_MODELO varchar (20);
Lv_CODMARCA varchar (20);
Lv_CODCLASE varchar (20);
Lv_TIPO varchar (20);
Lv_USO varchar (20);
Lv_CODLINEA varchar (20);
Lv_CARROCERIA varchar (20);
Lv_CILINDRAJE varchar (20);
Lv_CAP_PASAJEROS varchar (20);
Lv_CAP_TONELADAS varchar (20);
Lv_MUNICIPIO  varchar (20);
Lv_DEPARTAMENTO varchar (20);
Lv_F_MATRICULA varchar (20);
Lv_ACTIVA varchar (20);
LV_NRO_PUERTAS varchar (20);
--Ln_Contador Number := 0;

Cursor  usuarios Is
Select NRO_PLACA From CORRECCION_DATOS.Temp_Placas;


Begin

For Ln_Index In usuarios Loop

Begin

Lv_PLACA := Ln_Index.NRO_PLACA;

select --DS.NRO_PLACA AS NRO_PLACA,
DS.NOMBRE_MARCA AS NOMBRE_MARCA,
DS.MODELO AS MODELO,
SL.ID_MARCA_SAP AS ID_MARCA,
SC.ID_CLASE_SAP AS CLASE,
SS.ID_SERVICIO_SAP AS USO,
SL.ID_LINEA_SAP AS ID_LINEA,
Sca.Id_Carroceria_Sap AS ID_CARROCERIA, 
Ds.Cilindraje AS CILINDRAJE, 
Ds.Cap_Pasajeros,
Ds.Cap_Toneladas,
SSEC.ID_SECRETARIA_SAP,
DS.FECHA_MATRICULA,
DS.NOMBRE_ESTADO, 
DS.NRO_PUERTAS into 
--Lv_PLACA,
Lv_MARCA,
Lv_MODELO,
Lv_CODMARCA,
Lv_CODCLASE,
Lv_USO,
Lv_CODLINEA,
Lv_CARROCERIA,
Lv_CILINDRAJE,
Lv_CAP_PASAJEROS,
Lv_CAP_TONELADAS,
Lv_MUNICIPIO ,
Lv_F_MATRICULA,
Lv_ACTIVA ,
LV_NRO_PUERTAS
from ds_vehiculo DS
inner join qx_tipo_linea qxtl ON qxtl.RUNT_LINEA=  DS.ID_LINEA
INNER JOIN TIPO_LINEA TIPL ON Tipl.Id_Linea_Qx = Qxtl.Id_Linea_Qx
INNER JOIN SAP_LINEAS SL ON Sl.Id_Linea_Qx = QXTL.ID_LINEA_QX
FULL OUTER join QX_TIPO_CLASE CLV ON CLV.RUNT_CLASE = DS.ID_CLASE
FULL OUTER join SAP_CLASE SC ON SC.ID_CLASE_QX = CLV.ID_CLASE_QX
FULL OUTER join TIPO_SERVICIO TSER ON TSER.RUNT_SERVICIO = DS.ID_SERVICIO
FULL OUTER join Sap_Servicio SS ON SS.ID_SERVICIO_QX =  TSER.ID_SERVICIO
FULL OUTER join QX_TIPO_CARROCERIA QXTC ON QXTC.RUNT_CARROCERIA = DS.ID_CARROCERIA
FULL OUTER join SAP_CARROCERIA SCA ON Sca.Id_Carroceria_Qx = QXTC.ID_CARROCERIA_QX
FULL OUTER join SECRETARIAS_TTO SCT ON SCT.RUNT_SECRETARIA = DS.ID_SECRETARIA
FULL OUTER  join SAP_SECRETARIA SSEC ON SSEC.ID_SECRETARIA_QX= SCT.ID_SECRETARIA
WHERE DS.NRO_PLACA IN Lv_PLACA AND DS.ID_RADICADO='453' AND DS.NOMBRE_LINEA = Sl.Desc_Linea_Sap and rownum <=1; 
 


--lv_digito := PKG_DS_ESTANDARIZA_REGISTROS.FT_CALCULAR_DIGITO_VERIFICA(Lv_id_usuario);

Update CORRECCION_DATOS.Temp_Placas Lt Set MARCA = Lv_MARCA
Where Lt.NRO_PLACA  = Lv_PLACA;

End;

End Loop;
Commit;


END SP_EJEMPLO;
END LUISA_CANSONA;				 
				

/
--------------------------------------------------------
--  DDL for Procedure SP_VALIDACION_CAMPOS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SP_VALIDACION_CAMPOS" (IDREGISTRO NUMBER,  -- codigo del registro 1 vehiculo, 2 contribuyentes, 3 propietarios, 4 tramites
                                          DATOREGISTRO VARCHAR2, -- Dato base del registro
                                          IDIDENTIFICADOR NUMBER ) -- Identificador uno de cada uno de los registros.
AS

  SQLPARAME           VARCHAR2(32000);
  SQLOBLIGA           VARCHAR2(32000);
  SQLVALIDA           VARCHAR2(32000);
  VCAMPOERR           VARCHAR2(80);
  VNRO_RADICADO       VARCHAR2(10);
  VDATOCAMPO          VARCHAR2(50);
  VNEGOCIO            NUMBER;
  VPARAMET            NUMBER;
  VOBLIGAT            NUMBER;
  VINCOSISTENCIA      NUMBER;
  V_ERROR             BOOLEAN;

  CURSOR CVALIDA(VID_REGISTRO NUMBER)
  IS
    SELECT DISTINCT DTR.ESQUEMA,
      DTR.ID_TIPO_REGISTRO,
      DTR.NOMBRE_TABLA,
      DCA.ID_CAMPO,
      DCA.NOMBRE_CAMPO,
      DCA.TIPO_DATO_CAMPO,
      DCA.APLICA_PARAMETRICA,
      DCA.APLICA_NEGOCIO,
      DCA.OBLIGATORIO
    FROM DEPURACION.DS_CAMPO_ARCHIVO DCA
    INNER JOIN DEPURACION.DS_TIPO_REGISTRO DTR
    ON DTR.ID_TIPO_REGISTRO = DCA.ID_TIPO_REGISTRO
    INNER JOIN DEPURACION.DS_VALIDACIONES_CAMPO DVC
    ON dvc.id_campo          = dca.id_campo
    WHERE DCA.APLICA_NEGOCIO = 'S'
    AND DCA.ACTIVO           = 'S'
    AND DTR.ID_TIPO_REGISTRO = VID_REGISTRO
    ORDER BY 4;
    
    
BEGIN
  
    
      FOR X IN CVALIDA(IDREGISTRO)
          LOOP
            IF ( X.OBLIGATORIO = 'S' ) THEN
                  IF ( IDREGISTRO IN (1 ,3 ,4 ) ) THEN
                        SQLOBLIGA := 'SELECT COUNT(1) FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND NRO_PLACA = '''||DATOREGISTRO||'''';
                  ELSE
                        SQLOBLIGA := 'SELECT COUNT(1) FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND ID_DOCUMENTO = '''||SUBSTR(DATOREGISTRO,1,1)||''' AND ID_USUARIO = '''||SUBSTR(DATOREGISTRO,2,LENGTH(DATOREGISTRO))||'''';
                  END IF;
                  EXECUTE IMMEDIATE SQLOBLIGA INTO VOBLIGAT;
                  IF ( VOBLIGAT = 0 ) THEN
                      INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VNRO_RADICADO, IDIDENTIFICADOR, IDREGISTRO, 1, 58, DATOREGISTRO, SYSDATE,NULL);
                      COMMIT;
                  END IF;          
            END IF;   
            IF ( X.APLICA_PARAMETRICA = 'S' ) THEN
                  IF ( IDREGISTRO IN (1 ,3 ,4 ) ) THEN
                        IF ( X.TIPO_DATO_CAMPO IN ('NUMBER','FLOAT') ) THEN
                             SQLVALIDA := 'SELECT TO_CHAR('||X.NOMBRE_CAMPO||') FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND NRO_PLACA = '''||DATOREGISTRO||'''';
                        ELSE
                             SQLVALIDA := 'SELECT '||X.NOMBRE_CAMPO||' FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND NRO_PLACA = '''||DATOREGISTRO||'''';
                        END IF;
                  ELSE
                     IF ( X.TIPO_DATO_CAMPO IN ('NUMBER','FLOAT') ) THEN          
                         SQLVALIDA := 'SELECT TO_CHAR('||X.NOMBRE_CAMPO||') FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND ID_DOCUMENTO = '''||SUBSTR(DATOREGISTRO,1,1)||''' AND ID_USUARIO = '''||SUBSTR(DATOREGISTRO,2,LENGTH(DATOREGISTRO))||'''';
                     ELSE                 
                         SQLVALIDA := 'SELECT '||X.NOMBRE_CAMPO||' FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND ID_DOCUMENTO = '''||SUBSTR(DATOREGISTRO,1,1)||''' AND ID_USUARIO = '''||SUBSTR(DATOREGISTRO,2,LENGTH(DATOREGISTRO))||'''';
                     END IF;
                  END IF;              
                  --SQLPARAME := FUNCTION FT_ARMADO_SQL_PARAMETRICO(X.ID_CAMPO);
                  EXECUTE IMMEDIATE SQLVALIDA INTO VDATOCAMPO;
                  CASE X.ID_CAMPO
                  WHEN 2 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 4 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 7 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 9 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 11 THEN
                    VCAMPOERR := VDATOCAMPO||'-'||VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO ;--,        X.ID_CLASE;
                  WHEN 14 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 16 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 19 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 32 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 33 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 42 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 49 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  WHEN 55 THEN
                    VCAMPOERR := VDATOCAMPO;
                    EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET USING VDATOCAMPO;
                  END CASE;
              IF ( VPARAMET = 0 ) THEN
                SELECT ID_INCOSISTENCIA INTO VINCOSISTENCIA FROM DEPURACION.DS_CAMPO_PARAMETRICO  WHERE ID_CAMPO = X.ID_CAMPO;
                INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VNRO_RADICADO, IDIDENTIFICADOR, IDREGISTRO, 1, VINCOSISTENCIA, DATOREGISTRO, SYSDATE, NULL);
                COMMIT;
              END IF;
            END IF;
            IF ( X.APLICA_NEGOCIO = 'S' ) THEN
                IF ( IDREGISTRO = 1 ) THEN
                    DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, DATOREGISTRO, X.ID_CAMPO, IDREGISTRO);
                ELSIF ( IDREGISTRO = 2 ) THEN
                    DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, DATOREGISTRO, X.ID_CAMPO, IDREGISTRO);
                ELSIF ( IDREGISTRO = 3 ) THEN
                    DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, DATOREGISTRO, X.ID_CAMPO, IDREGISTRO);
                ELSIF ( IDREGISTRO = 4 ) THEN
                    DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, DATOREGISTRO, X.ID_CAMPO, IDREGISTRO);
                END IF;
            END IF;
      END LOOP;
END;
 

/
--------------------------------------------------------
--  DDL for Procedure SP_VALIDADOR_REGISTROS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SP_VALIDADOR_REGISTROS" (NRORADICADO NUMBER)
    AS
    
        TYPE T_CURSOR IS REF CURSOR;
        RCURSOR T_CURSOR;    
       
        type t_veh is table of DEPURACION.DS_VEHICULO%rowtype; 
        type t_pro is table of DEPURACION.DS_PROPIETARIO%rowtype; 
        type t_con is table of DEPURACION.DS_CONTRIBUYENTE%rowtype; 
        type t_tra is table of DEPURACION.DS_TRAMITE%rowtype; 
        
        v_veh t_veh;
        v_pro t_pro;
        v_con t_con;
        v_tra t_tra;

        CURSOR CVEHICULOS(IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_VEHICULO
                WHERE ID_RADICADO = IDRADICADO
                  AND ESTADO_VALIDACION='VP';
          
        
        
        CURSOR CPROPIETARIOS(NROPLACA VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_PROPIETARIO
                 WHERE ID_RADICADO = IDRADICADO
                   AND NRO_PLACA = NROPLACA;
                   
        CURSOR CCONTRIBUYENTES(IDDOCUMENTO VARCHAR2, IDUSUARIO VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_CONTRIBUYENTE
               WHERE ID_DOCUMENTO = IDDOCUMENTO AND ID_USUARIO = IDUSUARIO AND ID_RADICADO = IDRADICADO;
               
        
        CURSOR CTRAMITES (NROPLACA VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_TRAMITE
               WHERE NRO_PLACA = NROPLACA AND ID_RADICADO = IDRADICADO;
        
        VCONTEO             NUMBER;

    
    BEGIN
       -- Cursor que recorre por cada uno de los registros
       FOR VR IN CVEHICULOS(NRORADICADO) LOOP
              SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_VEHICULO DV
                     INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DV.NRO_PLACA = DP.NRO_PLACA AND DV.ID_RADICADO = DP.ID_RADICADO)
                     INNER JOIN DS_TRAMITE DT ON (DV.ID_RADICADO = DT.ID_RADICADO AND DV.NRO_PLACA = DT.NRO_PLACA)
                     INNER JOIN DS_CONTRIBUYENTE DC ON (DP.ID_RADICADO = DC.ID_RADICADO AND DP.ID_USUARIO = DC.ID_USUARIO AND DP.ID_DOCUMENTO = DC.ID_DOCUMENTO)
               WHERE DV.NRO_PLACA = VR.NRO_PLACA AND DV.ID_RADICADO = NRORADICADO;
               IF ( VCONTEO = 0 ) THEN
                    UPDATE DEPURACION.DS_VEHICULO SET ESTADO_VALIDACION = 'VI'
                           WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    UPDATE DEPURACION.DS_PROPIETARIO SET ESTADO_VALIDACION = 'VI'
                           WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    UPDATE DEPURACION.DS_CONTRIBUYENTE DC SET ESTADO_VALIDACION = 'VI'
                           WHERE (DC.ID_DOCUMENTO, DC.ID_USUARIO) IN ( SELECT DP.ID_DOCUMENTO, DP.ID_USUARIO FROM DEPURACION.DS_PROPIETARIO DP
                                                                             WHERE DP.NRO_PLACA = VR.NRO_PLACA AND DP.ID_RADICADO = NRORADICADO)
                             AND DC.ID_RADICADO = NRORADICADO;
                            UPDATE DEPURACION.DS_TRAMITE DT SET ESTADO_VALIDACION = 'VI'
                                 WHERE DT.NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                             -- ID PROCESO = 60 ID PARAMETRO 7    
                            INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES(DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL,VR.ID_RADICADO,VR.NRO_IDENTIFICADOR, 1, 1, 54, VR.NRO_PLACA, SYSDATE, NULL);
                            COMMIT;
               ELSE
                    DEPURACION.SP_VALIDACION_CAMPOS(1,VR.NRO_PLACA, VR.NRO_IDENTIFICADOR);                         -- Abro la coleccion de Datos para le procesamiento.
                    FOR PR IN CPROPIETARIOS(VR.NRO_PLACA, NRORADICADO) LOOP
                        SP_VALIDACION_CAMPOS(2, PR.ID_DOCUMENTO||PR.ID_USUARIO, PR.NRO_IDENTIFICADOR);
                        FOR CR IN CCONTRIBUYENTES(PR.ID_DOCUMENTO, PR.ID_USUARIO, NRORADICADO) LOOP
                            SP_VALIDACION_CAMPOS(3, CR.ID_DOCUMENTO||CR.ID_USUARIO, CR.NRO_IDENTIFICADOR);
                        END LOOP;
                    END LOOP;
                    
                    FOR CT IN CTRAMITES(VR.NRO_PLACA, NRORADICADO) LOOP
                        SP_VALIDACION_CAMPOS(4, VR.NRO_PLACA, CT.NRO_IDENTIFICADOR);
                    END LOOP;
               END IF;
        END LOOP;
END;
 

/
--------------------------------------------------------
--  DDL for Procedure SUMA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "DEPURACION"."SUMA" (N1 INT,N2 INT, RESULTADO OUT INT)
AS
BEGIN 
  RESULTADO:= N1+N2;
   END;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_ACTUALIZACION_REGISTROS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_ACTUALIZACION_REGISTROS" AS 

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_ACTUALIZACION_REGISTROS"
    AUTOR:          FERNANDO BONILLA
    FECHA CREACION: 22/07/2013
    DESCRIPCION:    PAQUETE DONDE SE REALIZA LAS INSERCCIONES O ACTUALIZACIONES DE LOS REGISTROS QUE PASARON
                    LAS VALIDACIONES EXITOSAS DEL VALIDADOR.

    PARAMETROS:     NINGUNO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_PROCESAR_REGISTRO_LOTE: PROCEDIMIENTO MAESTRO DE INVOCACION EN INSERCCION O ACTUALIZACION DE DATOS
                                               POR CADA UNO DE LOS REGISTROS.
                                               
                   -- PROCEDIMIENTOS PARA EL REGISTRO DE VEHICULOS
                   FT_INSERTAR_VEHICULO:    INSERT LOS VEHICULOS CUANDO SON MATRICULA INICIAL
                   FT_ACTUALIZAR_VEHICULO:  ACTUALZIA LOS VEHICULOS CUANDO ES UN DATO DIFERENTE A MATRICULA INICIAL.
 
                   -- PROCEDIMIENTOS PARA EL REGISTRO DE USUARIOS COMPRADORES Y VENDEDORES
                   FT_INSERTAR_USUARIO:    INSERTA EL USUARIO SI NO EXISTE EN LA BASE DE DATOS DE COMPRADORES
                   FT_ACTUALIZAR_USUARIO:  ACTUALIZA LOS DOTOS DE LOS USUARIOS EN USUARIOS
                   FT_INSERTAR_DIRECCION:  INSERTA UNA NUEVA DIRECCION ACTUALIZADA AL USUARIO, SI LOS DATOS DE MODIFICACION SON RECIENTES.
                   
                   -- PROCEDIMIENTOS PARA EL REGISTRO DE PROPIETARIOS
                   FT_ACTUALIZAR_PROPIETARIO: -- ACTUALIZA EL PROPIETARIO SI EXISTE
                   FT_INSERTAR_PROPIETARIO:   -- INSERTA EL NUEVO PROPIETARIO DEL VEHICULO CON SU PROCENTAJE
                   
                   -- PROCEDIMIENTOS PARA EL REGISTRO DE TRAMITES.
                   FT_CANCELACION:  INSERTA LAS CANCELACIONES DEL VEHICULO Y ACTUALIZA EL ESTADO DEL VEHICULO
                   FT_TRASLADO:     INSERTA LOS TRASLADOS DE CUENTA A LAS NUEVAS SECRETARIAS
                   FT_RADICADO:     INSERTA LAS RADICACIONES  DELOS VEHICULOS
                   FT_CAMBIO_CARROCERIA: REGISTRA EL CAMBIO DE CARROCERIA Y ACTUALIZA EL VEHICULO EL CAMBIO
                   FT_CAMBIO_SERVICIO:   REGISTRO EL CAMBIO DE SERVICIO Y ACTUALIZA EL VEHICULO EL CAMBIO
                   FT_REMATRICULA:       REGISTRA UNA NUEVA MATRICULA PARA EL VEHICULO Y SE
                   FT_TRASPASO:          REGISTRA EL TRASPASO DE PROPIETARIO, JUNTO CON LA ACTUALIZACION DEL HISTORIAL
                   FT_MATRICULA_INICIAL: REGISTRA EL VEHICULO NUEVO
                   FT_BLINDADO:          REGISTRA EL BLINDAJE DEL VEHICULO Y SE ACTUALIZA A BLINDADO
                  
    RETORNA:        GUARDADO EN TABLA DS_CONTRIBUYENTE_ESTANDAR : DATOS CORREGIDOS.
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 22/07/2013   ||FERNANDO BONILLA          ||CREACION DEL PAQUETE.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES DE VALIDACIONES.
 09/04/2014   ||FERNANDO BONILLA          ||MEJORAS A FUNCIONALIDADES Y DOCUMENTACI�N.
 03/03/2015   ||FERNANDO BONILLA          ||CAMBIOS DE PROCEDIMIENTOS A FUNCIONES
*/

 GV_RADICADO NUMBER;
 MSERROR        VARCHAR2(4000 BYTE);
 
 PROCEDURE SP_PROCESAR_REGISTRO_LOTE(NRORADICADO NUMBER);
 
 -- PROCEDIMIENTOS PARA EL REGISTRO DE VEHICULOS
 FUNCTION FT_INSERTAR_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_ACTUALIZAR_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2) RETURN BOOLEAN; 
 PROCEDURE SP_GUARDAR_LOG_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2); 
 
 -- PROCEDIMIENTOS PARA EL REGISTRO DE USUARIOS COMPRADORES Y VENDEDORES
 FUNCTION FT_INSERTAR_USUARIO(A_RADICADO NUMBER, A_ID_DOCUMENTO NUMBER, A_ID_USUARIO VARCHAR2, A_ID_CIUDAD NUMBER, A_APELLIDOS VARCHAR2, A_NOMBRES VARCHAR2, A_DIRECCION VARCHAR2, A_TELEFONO VARCHAR2, A_EMP_O_PART VARCHAR2, A_SEXO VARCHAR2, A_FECHA_NACIMIENTO VARCHAR2, A_PAIS NUMBER, A_FAX VARCHAR2, A_EMAIL VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_ACTUALIZAR_USUARIO(A_RADICADO NUMBER,A_ID_DOCUMENTO NUMBER, A_ID_USUARIO VARCHAR2, A_ID_CIUDAD NUMBER, A_APELLIDOS VARCHAR2, A_NOMBRES VARCHAR2, A_DIRECCION VARCHAR2, A_TELEFONO VARCHAR2, A_EMP_O_PART VARCHAR2, A_SEXO VARCHAR2, A_FECHA_NACIMIENTO VARCHAR2, A_PAIS NUMBER, A_FAX VARCHAR2, A_EMAIL VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_INSERTAR_DIRECCION(A_RADICADO NUMBER,A_ID_USUARIO VARCHAR2,A_DIRECCION VARCHAR2,A_MUNICIPIO NUMBER,A_TELEFONO VARCHAR2,A_FAX VARCHAR2) RETURN BOOLEAN;
 
 -- PROCEDIMIENTOS PARA EL REGISTRO DE PROPIETARIOS
 FUNCTION FT_ACTUALIZAR_PROPIETARIO(A_PLACA VARCHAR2, A_VENDEDOR VARCHAR2, A_COMPRADOR VARCHAR2, A_PORCENTAJE_PROPIEDAD NUMBER) RETURN BOOLEAN;
 FUNCTION FT_INSERTAR_PROPIETARIO(A_PLACA VARCHAR2, A_IDENTIFICACION VARCHAR2, A_PORCENTAJE_PROPIEDAD NUMBER) RETURN BOOLEAN;
 
 -- PROCEDIMIENTOS PARA EL REGISTRO DE TRAMITES.
 FUNCTION FT_CANCELACION(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_TIPO_CANCELACION VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_TRASLADO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_SECRETARIA_DESTINO NUMBER, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN;
 FUNCTION FT_RADICADO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN;
 FUNCTION FT_CAMBIO_CARROCERIA(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_CARROCERIA_ANTERIOR NUMBER, A_ID_CARROCERIA_NUEVA NUMBER, I_RADICADO NUMBER) RETURN BOOLEAN;
 FUNCTION FT_CAMBIO_SERVICIO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_SERVICIO_ANTERIOR NUMBER, A_ID_SERVICIO_NUEVO NUMBER) RETURN BOOLEAN;
 FUNCTION FT_CAMBIO_MOTOR(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_CILINDRAJE_NUEVO NUMBER, A_CAP_TONELADAS NUMBER, A_CAP_PASAJEROS NUMBER, I_RADICADO NUMBER, A_CAP_TONELADAS_ANTERIOR NUMBER, A_CAP_PASAJEROS_ANTERIOR NUMBER) RETURN BOOLEAN;
 FUNCTION FT_REMATRICULA(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_TRASPASO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_USUARIO_ANTERIOR VARCHAR2, A_ID_USUARIO_NUEVO VARCHAR2, A_PORCENTAJE_PROP VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_MATRICULA_INICIAL(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_BLINDADO_DESBLINDADO(A_TRAMITE NUMBER, A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_BLINDAJE VARCHAR2) RETURN BOOLEAN;
 FUNCTION FT_CLASICO_ANTIGUO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN;

 FUNCTION FT_LOG_ACTUALIZACION(TABLA VARCHAR2, M_ERROR VARCHAR2, A_RADICADO NUMBER, IDENTIFICADOR VARCHAR2, A_FUNCION VARCHAR2) RETURN BOOLEAN;
 
END PKG_DS_ACTUALIZACION_REGISTROS;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_CARGA_ARCHIVOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_CARGA_ARCHIVOS" AS 
/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_CARGA_ARCHIVOS"
    AUTOR:          FERNANDO BONILLA
    FECHA CREACION: 22/07/2013
    DESCRIPCION:    PAQUETE PARA CARGAR LOS ARCHIVOS A PRODUCCI�N DE LA INFORMACI�N ENVIADA
                    POR RUNT REFERENTE A LOS VEHICULOS QUE SE LES VA A REALIZAR UN AVALUO
                    DE IMPUESTOS Y SE DEBE DEPURAR LA INFORMACI�N ANTES DE ACTUALZIARLA EN SAP

    PARAMETROS:     NINGUNO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_DISTRIBUCION_REGISTROS: PROCEDIMIENTO DE DISTRIBUIR LOS DATOS EN LAS TABLAS
                                               CORRESPONDIENTES PARA EL ANALISIS DE INFORMACI�N POR
                                               MEDIO DE VALIDACIONES DE NEGOCIO O CONFIGURACIONES
                                               PARAMETRICAS, ESTADANRIZACION DE DATOS Y CONTROL DE
                                               INCONSISTENCIAS PRELIMINARES.
                    
    RETORNA:        GUARDADO DE MENSAJE EN TABLA DS_MAESTRO : EXITOSO O ERROR
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 05/03/2014   ||FERNANDO BONILLA          ||CREACION DEL PAQUETE Y DOCUMENTACI�N.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES DE CARGUE EN TABLAS.
 09/04/2014   ||FERNANDO BONILLA          ||AJUSTES DE TOTALES PARA INFORME.
*/

  PROCEDURE SP_DISTRIBUCION_REGISTROS(NRORADICADO NUMBER, PROCESO NUMBER);
  
  FUNCTION FT_VALIDAR_ESTRUCTURA(A_ID_TIPO_REGISTRO NUMBER, A_ROW_VEHICULO DS_TMP_VEHICULOS%ROWTYPE, A_ROW_CONTRIBUYENTE DS_TMP_CONTRIBUYENTES%ROWTYPE, A_ROW_PROPIETARIO DS_TMP_PROPIETARIOS%ROWTYPE, A_ROW_TRAMITES DS_TMP_TRAMITES%ROWTYPE) RETURN VARCHAR2;
    
END PKG_DS_CARGA_ARCHIVOS;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_CORRECCION_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_CORRECCION_DATOS" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE SP_LECTURA_INCONSISTENCIAS(IDRADICADOP NUMBER, IDRADICADOH NUMBER);
  PROCEDURE SP_ACTUALIZA_ESTADO_REGISTRO(RADICADOP NUMBER, RADICADOH NUMBER);
  
END PKG_DS_CORRECCION_DATOS;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_ESTANDARIZA_REGISTROS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_ESTANDARIZA_REGISTROS" AS 

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_ESTANDARIZA_REGISTROS"
    AUTOR:          FRANCISCO ARBELAEZ
    FECHA CREACION: 22/07/2013
    DESCRIPCION:    PAQUETE PARA CORREGIR INCONSISTENCIAS EN LOS DATOS DE LOS CONTRIBUYENTES

    PARAMETROS:     NINGUNO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_ESTANDARIZAR_RADICADO: PROCEDIMIENTO MAESTRO DE INVOCACION Y ACTUALIZACION DE DATOS
                                              EN LOS CONTRIBUYENTES.
                    FT_ESTANDARIZAR_DIRECCION: ESTANDARIZA LA DIRECCION DE MANERA LEGIBLE EN ABREVIATURAS Y FORMATO ADECUADO.
                    FT_ESTANDARIZAR_NOM_APE: ESTANDARIZA LOS NOMBRES, QUITANDO CUALQUIER CARACTER ESPECIAL.
                    FT_ESTANDARIZAR_TELEFONO: ESTANDARIZA FORMATO, LONGITUDES
                    FT_ESTANDARIZAR_IDENTIFICACION: ESTANDARIZA EL FORMATO DE DOCUMENTO.
                    FT_CALCULAR_DIGITO_VERIFICA: SE CALCULA EL DIGITO DE VERIFICACION PARA LAS EMPRESAS SOLO APLICA AL TIPO NIT
                    FT_SEPARAR_PALABRAS_NUMEROS: SEPARAR NUMEROS DE LETRAS
                    FT_ELIMINAR_CARACTERES_ESPEC: QUITAR CUALQUEIR CARACTER ESPECIAL NO PERMITIDO.
                    FT_ELIMINAR_ESPACIOS: ELIMINAR ESPACIOS INNECESARIOS.
                    FT_ES_NUMERO: VERIFICA QUE LA CADENA EVALUADA SOLO TENGA DATOS NUMERICOS.
                    FT_CONSULTAR_SINONIMO: CONSULTA LA ABREVIATURA PARA LA DIRECCION, DE ACUERDO A LA TABLA DS_SINONIMO_DIRECCION.
                          
    RETORNA:        GUARDADO EN TABLA DS_CONTRIBUYENTE_ESTANDAR : DATOS CORREGIDOS.
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 22/07/2013   ||FRANCISCO ARBELAEZ        ||CREACION DEL PAQUETE.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES DE VALIDACIONES.
 09/04/2014   ||FERNANDO BONILLA          ||MEJORAS A FUNCIONALIDADES Y DOCUMENTACI�N.
*/

  FUNCTION FT_CONSULTAR_SINONIMO(A_PALABRA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ES_NUMERO(A_CARACTER VARCHAR2) RETURN NUMBER;
  FUNCTION FT_ELIMINAR_ESPACIOS(A_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ELIMINAR_CARACTERES_ESPEC(A_CADENA VARCHAR2, A_TIPO_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_SEPARAR_PALABRAS_NUMEROS(A_CADENA VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_CALCULAR_DIGITO_VERIFICA(A_NIT NUMBER) RETURN NUMBER;
  
  FUNCTION FT_ESTANDARIZAR_IDENTIFICACION(A_IDENTIFICACION VARCHAR2, A_ID_DOCUMENTO VARCHAR2) RETURN VARCHAR2;
  FUNCTION FT_ESTANDARIZAR_TELEFONO(A_TELEFONO VARCHAR2) RETURN VARCHAR2;--PENDIENTE
  FUNCTION FT_ESTANDARIZAR_NOM_APE(A_NOMBRE_APELLIDO VARCHAR2, A_TIPO VARCHAR) RETURN VARCHAR2;--PENDIENTE
  FUNCTION FT_ESTANDARIZAR_DIRECCION(A_DIRECCION VARCHAR2) RETURN VARCHAR2;--PENDIENTE
  
  PROCEDURE SP_ESTANDARIZAR_RADICADO(A_ID_RADICADO NUMBER);
  
END PKG_DS_ESTANDARIZA_REGISTROS;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_VALIDACIONES_REGISTRO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_VALIDACIONES_REGISTRO" 
AS 

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_VALIDACIONES_REGISTRO"
    AUTOR:          FERNANDO BONILLA
    FECHA CREACION: 22/03/2014
    DESCRIPCION:    PAQUETE QUE REALIZA TODAS LAS VALDIACIONES APLICADAS DE SOSTENIBILIDAD
                    VALIDACIONES PARAMETRICAS.
                    VALIDACIONES OBLIGATORIEDAD
                    VALIDACIONES DE NEGOCIO.

    PARAMETROS:     NUMERO DE RADICADO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_PROCESAR_DATOS: PROCEDIMIENTO QUE EVALUA EL REGISTRO DEL DATO ENVIADO DEL PAQUETE PKG_DS_VALIDADOR.
                                            
                    SP_GENERAR_EXCEPCION: PROCEDIMIENTO QUE INSERTA LAS INCONSISTENCIA ENCONTRADA EN LAS VALIDACIONES DE NEGOCIO ESTABLECIDAS.
                                          
                    
    RETORNA: CAMBIOS DE ESTADO EN LOS 4 REGISTROS EN VI
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 05/03/2014   ||FERNANDO BONILLA          ||CREACION DEL PAQUETE.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES VALIDACIONES DE CAMPOS.
 09/04/2014   ||FERNANDO BONILLA          ||AJUSTES DE TOTALES PARA INFORME Y DOCUMENTACI�N.
*/  

  NRADICADO       NUMBER := 0;       -- GUARDA EL RADICADO GLOBAL
  VALORDATO       VARCHAR2(40);      -- GUARDA EL VALOR EVALUADO
  NIDENTIFICADOR  NUMBER := 0;       -- GUARDA EL IDENTIFICADOR SECUENCIAL DE LA TABLA DEL REGISTROS EVALUADO
  NVALIDACION     BOOLEAN := FALSE;  -- SI CUMPLE O NO CON LAS VALIDACIONES.
  CAMPO_NOMBRE    VARCHAR2(30 BYTE); -- NOMBRE DEL CAMPO QUE SE ESTA EVALUANDO.
	DTIPOREGISTRO   NUMBER := 0;       -- TIPO DE REGISTRO DE LA TABLA.
  TIPO_ERROR      VARCHAR2(1 BYTE);  -- CONTIENE EL TIPO DE INCONSISTENCIA CONFIGURADO
  VALIDA_INCO     NUMBER := 0;
  
  /*ESTE PAQUETE HACE TODO EL PROCESAMIENTO DE LA VALIDACION DE LA INFORMACION REPORTADA POR EL RADICADO. */
  
  -- VALIDACIONES DEL VEHICULO
  FUNCTION FT_EXISTE_VEHICULO(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  --FUNCTION FT_REPORTA_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER,A_ID_USUARIO VARCHAR2, A_ID_DOCUMENTO NUMBER) RETURN BOOLEAN;
  FUNCTION FT_REPORTA_PROPIETARIO(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_REPORTA_TRAMITE(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER) RETURN BOOLEAN;
  FUNCTION FT_REPORTA_TRAMITE_X_TIPO(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER, A_TIPO_TRAMITE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_PLACA(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_COMBUSTIBLE(A_ID_COMBUSTIBLE NUMBER, A_ID_BATERIA NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_MODELO(A_MODELO NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_IMPORTADO_NACIONAL(A_IMPORTADO_NACIONAL VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_ESTADO(A_ESTADO NUMBER, I_PLACA VARCHAR2, I_RADICADO NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_VALOR_FACTURA(A_VALOR_FACTURA NUMBER, A_MODELO NUMBER, NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_CLASICO_ANTIGUO(A_CLASICO_ANTIGUO VARCHAR2, A_NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_CILINDRAJE(A_CILINDRAJE NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_PUERTAS(A_NRO_PUERTAS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TONELADAS(A_CAP_TONELADAS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_PASAJEROS(A_CAP_PASAJEROS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_BLINDADO(A_BLINDADO VARCHAR2, A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_LINEA(A_NRO_PLACA VARCHAR2, A_LINEA VARCHAR2) RETURN BOOLEAN;
  
  -- VALIDACIONES DEL PROPIETARIO
  FUNCTION FT_TIENE_PROPIETARIOS(A_PLACA VARCHAR2) RETURN BOOLEAN;   
  function FT_VALIDAR_IDENTIFICACION(A_IDENTIFICACION varchar2, A_ID_DOCUMENTO number) return BOOLEAN;
  FUNCTION FT_VALIDAR_PORCENTAJE_PROPIE(A_TRAMITE NUMBER, A_PLACA VARCHAR2, TIPO_REGISTRO NUMBER, A_PORCENTAJE NUMBER, A_COMPRADOR VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_APELLIDOS(A_ID_DOCUMENTO NUMBER, A_APELLIDOS VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_ID_DOCUMENTO NUMBER, A_IDENTIFICACION VARCHAR2, OPCION VARCHAR2) RETURN BOOLEAN;

  -- VALIDACIONES DEL CONTRIBUYENTE
  FUNCTION FT_EXISTE_CONTRIBUYENTE(A_ID_USUARIO VARCHAR2, A_NRO_PLACA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TIPO_DOCUMENTO(A_ID_DOCUMENTO NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_EMP_PART(A_EMP_PART VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_SEXO(A_SEXO VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_FECHA_NACIMIENTO(A_FECHA_NACIMIENTO VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDA_FECHA_ACTUALIZACION(A_ID_USUARIO VARCHAR2, A_FECHA DATE) RETURN BOOLEAN;  
  
  -- VALIDACIONES DEL TRAMITE
  FUNCTION FT_VALIDAR_FECHA_TRAMITE(A_FECHA DATE) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TIPO_CANCELACION(A_TIPO_CANCELACION VARCHAR2,A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TRAMITES(A_NRO_PLACA VARCHAR2,A_FECHA_TRAMITE DATE, A_TIPO_TRAMITE NUMBER, V_TIPO_DOCUMENTO NUMBER, A_VENDEDOR VARCHAR2, A_PORCENTAJE_VENDEDOR NUMBER, C_TIPO_DOCUMENTO NUMBER, A_COMPRADOR VARCHAR2) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_SECRETARIAS_TRAMITE(A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER, A_SECRETARIA_DESTINO NUMBER, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_TRANSFORMACION(A_TRAMITE NUMBER, A_NRO_PLACA VARCHAR2, A_CARROCERIA_NUEVA NUMBER, A_TONELADAS NUMBER, A_CILINDRAJE NUMBER, A_PASAJEROS NUMBER) RETURN BOOLEAN;
  FUNCTION FT_VALIDAR_CAMBIO_SERVICIO(A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER, A_SERVICIO_NUEVO NUMBER, A_SERVICIO_ANTERIOR NUMBER) RETURN BOOLEAN;
  
  -- INICIO DEL PROCESO DE VALIDACION DE DATOS DE
  --PROCEDURE SP_CURSOR_REGISTROS (VTIPO_REGISTRO NUMBER, VRADICADO NUMBER, VDATO VARCHAR2, GB_REF_CURSOR IN OUT SYS_REFCURSOR);  
  PROCEDURE SP_PROCESAR_DATOS(NRO_RADICADO NUMBER, NROIDENTIFICADOR VARCHAR2, IDCAMPOS DEPURACION.CAMPOS_ARRAY, IDREGISTRO NUMBER);
  PROCEDURE SP_GENERAR_EXCEPCION(A_REGISTRO_FALLO NUMBER, A_INCONSISTENCIA NUMBER);
  PROCEDURE SP_ACTUALIZAR_ESTADO_REGISTRO(NROIDENTIFICADOR NUMBER, NOMBRE_TABLA VARCHAR2, A_TIPO_REGISTRO NUMBER);
  
END PKG_DS_VALIDACIONES_REGISTRO;

/
--------------------------------------------------------
--  DDL for Package PKG_DS_VALIDADOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_DS_VALIDADOR" AS 

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_VALIDADOR"
    AUTOR:          FERNANDO BONILLA
    FECHA CREACION: 22/03/2014
    DESCRIPCION:    PAQUETE QUE IDENTIFICA Y DISTRIBUYE LAS DIFERENTES VALDIACIONES APLICADAS DE SOSTENIBILIDAD
                    VALIDACIONES PARAMETRICAS.
                    VALIDACIONES OBLIGATORIEDAD
                    VALIDACIONES DE NEGOCIO.

    PARAMETROS:     NUMERO DE RADICADO.
    OBJETOS:        PROCEDIMIENTO.
                    SP_VALIDADOR_REGISTROS: PROCEDIMIENTO QUE ARMA LA SECUENCIA DE EJECUCION DE TODAS LAS VALIDACIONES
                                            DE LOS CUATRO REGISTROS CARGADOS POR CADA CAMPO PARAMETRIZADO, PARA APLICAR 
                                            LAS REGLAS DEL VALIDADOR DEFINIDAS.
                                            
                    SP_VALIDACION_CAMPOS: PROCEDIMIENTO QUE EVALUA CAMPO A CAMPO POR CADA UNO DE LOS REGISTROS, LAS VALIDACIONES
                                          DE OBLIGATORIEDAD, HOMOLOGACION PARAMETRICA Y/O NEGOCIO.
                                          
                    SP_INFORME_REGISTROS: PROCEDIMIENTO QUE ACTUALIZA LOS TOTALES DEL PROCESO DE VALDIACIONES
                    
                    FT_ARMADO_SQL_PARAMETRICO: FUNCION QUE CONSULTA EL ARMADO AUTOMATICO DE LA VALDIACI�N DE TABLAS HOMOLOGADAS PARAMETRICAS.
                    
    RETORNA: CAMBIOS DE ESTADOS EN LOS 4 REGISTROS EN VE, VI, VP
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 05/03/2014   ||FERNANDO BONILLA          ||CREACION DEL PAQUETE.
 20/02/2014   ||FERNANDO BONILLA          ||AJUSTES VALIDACIONES DE CAMPOS.
 09/04/2014   ||FERNANDO BONILLA          ||AJUSTES DE TOTALES PARA INFORME Y DOCUMENTACI�N.
*/  

  FUNCTION   FT_ARMADO_SQL_PARAMETRICO(VIDCAMPO NUMBER) RETURN VARCHAR2;
  PROCEDURE  SP_VALIDACION_DIRECCION(IDIDENTIFICADOR NUMBER, NRORADICADO NUMBER);
  PROCEDURE  SP_VALIDADOR_REGISTROS(NRORADICADO NUMBER);
  PROCEDURE  SP_VALIDACION_CAMPOS(IDREGISTRO NUMBER,IDIDENTIFICADOR NUMBER, NRORADICADO NUMBER);
  PROCEDURE  SP_INFORME_REGISTROS(NRORADICADO NUMBER, PROCESO NUMBER);
  
END PKG_DS_VALIDADOR;

/
--------------------------------------------------------
--  DDL for Package PKG_VALIDAR_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "DEPURACION"."PKG_VALIDAR_DATOS" AS
PROCEDURE SP_COMPARACION_LINEAS;
FUNCTION F_INSERTAR_DOBLES(AVS_NOMBRE_LINEA VARCHAR2) RETURN NUMBER;
PROCEDURE QAS_CARACTERISTICAS2;
PROCEDURE ACTUALIZAR_CARACTERISTICAS2;
PROCEDURE ACTUALIZAR_MARCA;
PROCEDURE ACTUALIZAR_COD_MARCA_SAP;
PROCEDURE ACTUALIZAR_COD_LINEA_SAP;
END PKG_VALIDAR_DATOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_ACTUALIZACION_REGISTROS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_ACTUALIZACION_REGISTROS" AS

/*
===============================================================================================================================
===============================================================================================================================

                PROCEDIMIENTO GENERAL DE LAS ACTUALIZACIONES O INSERCCIONES DE LOS REGISTROS EXITOSOS

===============================================================================================================================
===============================================================================================================================
*/

  PROCEDURE SP_PROCESAR_REGISTRO_LOTE(NRORADICADO NUMBER) AS

  --- CURSOR PARA RECORRER LA PLACAS QUE ESTA BUENAS EN LOS 4 ARCHIVOS
  CURSOR CURGENERAL (VID_RADICADO NUMBER) IS
              SELECT DV.NRO_PLACA
              FROM DEPURACION.DS_VEHICULO DV
                     INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DV.NRO_PLACA = DP.NRO_PLACA AND DV.ID_RADICADO = DP.ID_RADICADO)
                     INNER JOIN DS_CONTRIBUYENTE DC ON (DP.ID_RADICADO = DC.ID_RADICADO AND DP.ID_USUARIO = DC.ID_USUARIO AND DP.ID_DOCUMENTO = DC.ID_DOCUMENTO)
                     inner join DS_TRAMITE DT on (DV.ID_RADICADO = DT.ID_RADICADO and DV.NRO_PLACA = DT.NRO_PLACA)                     
               WHERE DV.ID_RADICADO = VID_RADICADO
                 and DV.ESTADO_VALIDACION like 'VE' and DP.ESTADO_VALIDACION like 'VE' and (DC.ESTADO_VALIDACION like 'VE') and DT.ESTADO_VALIDACION like 'VE'
/*                             and not exists (select 1 from DEPURACION.DS_TRAMITE DT 
                                      where DT.ESTADO_VALIDACION = 'VI' and
                                             DT.NRO_PLACA = DV.NRO_PLACA and
                                             DT.ID_RADICADO = DV.ID_RADICADO)*/
               --AND DV.NRO_PLACA IN ('VSZ11D')
                 GROUP BY DV.NRO_PLACA
              UNION --TRAMITE TRASPASO INDETERMINADO NO TIENE INFORMACION DE CONTRIBUYENTE
              SELECT DV.NRO_PLACA
              FROM DEPURACION.DS_VEHICULO DV
                     INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DV.NRO_PLACA = DP.NRO_PLACA AND DV.ID_RADICADO = DP.ID_RADICADO)
                     INNER JOIN DS_TRAMITE DT ON (DV.ID_RADICADO = DT.ID_RADICADO AND DV.NRO_PLACA = DT.NRO_PLACA)                     
               WHERE DV.ID_RADICADO = VID_RADICADO
                 AND DT.ID_TRAMITE = 65 --TRASPASO INDETERMINADO
                 and DV.ESTADO_VALIDACION like 'VE' and DP.ESTADO_VALIDACION like 'VE' and DT.ESTADO_VALIDACION like 'VE'
                 --AND DV.NRO_PLACA IN ('VSZ11D')
                 GROUP BY DV.NRO_PLACA;              
  
  CURSOR ACTVEHICULOS(VHPLACA VARCHAR2,VHRADICADO NUMBER) IS
       SELECT * FROM DEPURACION.DS_VEHICULO WHERE ID_RADICADO = VHRADICADO AND NRO_PLACA = VHPLACA AND ESTADO_VALIDACION = 'VE';

  CURSOR ACTPROPIETARIOS(VNROPLACA VARCHAR2, VPRADICADO NUMBER) IS
       SELECT * FROM DEPURACION.DS_PROPIETARIO 
          WHERE ID_RADICADO = VPRADICADO 
            AND NRO_PLACA = VNROPLACA
            AND ESTADO_VALIDACION = 'VE';

  CURSOR ACTCONTRIBUYENTES(VIDDOCUMENTO NUMBER, VIDUSUARIO VARCHAR2, VCRADICADO NUMBER) IS
      SELECT DC.NRO_IDENTIFICADOR, DC.ID_RADICADO, DCE.ID_DOCUMENTO, DCE.ID_USUARIO, DCE.NOMBRES, DCE.APELLIDOS, DC.ID_CIUDAD_DIR, DCE.DIRECCION, DC.TELEFONO,
             DC.EMP_O_PART, DC.SEXO, DC.FECHA_NACIMIENTO, DC.ID_PAIS, DC.FECHA_MODIFICACION, DC.FAX, DC.EMAIL, DC.ESTADO_VALIDACION
      from DEPURACION.DS_CONTRIBUYENTE DC
      --INNER JOIN DEPURACION.DS_CONTRIBUYENTE_ESTANDAR DCE ON DC.NRO_IDENTIFICADOR = DCE.NRO_IDENTIFICADOR
      /*ELVIS ALEXIS BETANCUR L�PEZ
        Se realiza este cambio para que al monento de correr una actualizaci�n de un radicado anterior, el cursor pueda
        retornar algun valor, ya que al realizar la estandarizaci�n se borra de DS_CONTRIBUYENTE_ESTANDAR y se deja el identificador del nuevo radicado.
      */  
        INNER JOIN DEPURACION.DS_CONTRIBUYENTE_ESTANDAR DCE ON DC.ID_USUARIO = DCE.ID_USUARIO AND DC.ID_DOCUMENTO = DCE.ID_DOCUMENTO 
         WHERE ID_RADICADO = VCRADICADO
           AND DCE.ID_DOCUMENTO = VIDDOCUMENTO AND DCE.ID_USUARIO = VIDUSUARIO
           AND DC.ESTADO_VALIDACION = 'VE';
  
  CURSOR INSDIRECCIONES (NROIDENTIFICADOR NUMBER, VNRORADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_DIRECCIONES
                WHERE ID_RADICADO = VNRORADICADO
                      AND NRO_IDENTIFICADOR = NROIDENTIFICADOR
                      and ESTADO_VALIDACION = 'VE';
  
  cursor ACTTRAMITES(VNPLACA varchar2, VTRADICADO number) is
       select * from DEPURACION.DS_TRAMITE DT1
          where DT1.ID_RADICADO = VTRADICADO
            and DT1.NRO_PLACA = VNPLACA
            and DT1.ESTADO_VALIDACION = 'VE';


    --DECLARO VARIABLES NECESARIAS PARA ALMACENAR DATOS A INSERTAR DEL VEHICULO.
    V_NRO_PLACA VARCHAR2(7);
    V_ID_MARCA NUMBER(8,0);
    V_ID_LINEA NUMBER(8,0);
    V_CILINDRAJE NUMBER(5,0);
    V_POTENCIA NUMBER(10);
    V_MODELO NUMBER(4,0);
    V_ID_CLASE NUMBER(8,0);
    V_ID_SERVICIO NUMBER(8,0);
    V_ID_CARROCERIA NUMBER(8,0);
    V_NRO_PUERTAS NUMBER(3,0);
    V_CAP_TONELADAS NUMBER(10,1);
    V_CAP_PASAJEROS NUMBER(3,0);
    V_IMPORTADO_NACIONAL VARCHAR2(2);
    V_ID_COMBUSTIBLE NUMBER(8,0);
    V_ID_ESTADO NUMBER(4,0);
    V_VALOR_FACTURA NUMBER(10,0);
    V_ID_SECRETARIA NUMBER(8,0);
    V_CLASICO_ANTIGUO VARCHAR2(1);
    V_BLINDADO VARCHAR2(1);
    V_FECHA_MATRICULO DATE;
    V_ID_BATERIA NUMBER;
    REGISTRO_NUEVO VARCHAR2(1);
    
    SQLTEXT VARCHAR2(4000 BYTE) := NULL; -- CREACION DEL SQL PARA TRAER EL DATO PARAMETRICO HOMOLOGADO
    V_EXISTE BOOLEAN;                    -- VARIABLE QUE SE UTILIZA PARA ALGUNA VALIDACION DE ERROR.
    V_REPORTA_PROPIETARIO BOOLEAN;       -- SI REPORTA EL PROPIETARIO ACTUAL COMPRADOR DEL VEHICULO. 
    V_EXISTE_PROPIETARIO BOOLEAN;        -- SI TIENE PROPIETARIO ANTERIOR DEL VEHICULO ACTUAL EN EL TRASPASO
    V_EXISTE_ACTUALIZACION BOOLEAN;      -- SI EL DATO EXISTE SE REALIZA LA ACTUALIZACION DE LO CONTRARIO UNA INSERCCI�N
    
    V_ID_DOCUMENTO NUMBER(1);
    V_ID_USUARIO VARCHAR2(30);
    
    V_TONELADAS_ANTERIORES NUMBER;
    V_PASAJEROS_ANTERIORES NUMBER;
    V_CONTADOR_NUEVO NUMBER;
    
    V_FLAG_COMMIT BOOLEAN;

  BEGIN    
    GV_RADICADO := NRORADICADO;
    FOR XPLACAS IN CURGENERAL(NRORADICADO) LOOP
       V_FLAG_COMMIT := FALSE;
       BEGIN
          FOR XVH IN ACTVEHICULOS(XPLACAS.NRO_PLACA, NRORADICADO) LOOP
                V_NRO_PLACA := XVH.NRO_PLACA;
                V_CILINDRAJE := XVH.CILINDRAJE;
                V_POTENCIA := XVH.POTENCIA;
                V_ID_MARCA := XVH.ID_MARCA;
                V_MODELO := XVH.MODELO;
                V_NRO_PUERTAS := XVH.NRO_PUERTAS;
                V_CAP_TONELADAS := XVH.CAP_TONELADAS;
                V_CAP_PASAJEROS := XVH.CAP_PASAJEROS;
                V_IMPORTADO_NACIONAL := XVH.IMPORTADO_NACIONAL;
                V_ID_ESTADO := XVH.ID_ESTADO;
                V_VALOR_FACTURA := XVH.VALOR_FACTURA;
                V_CLASICO_ANTIGUO := XVH.CLASICO_ANTIGUO;
                V_BLINDADO := XVH.BLINDADO;
                V_FECHA_MATRICULO := XVH.FECHA_MATRICULA;
                V_ID_BATERIA := XVH.ID_BATERIA;
                V_CAP_TONELADAS := V_CAP_TONELADAS/1000;
                
                IF XVH.ESTADO_VALIDACION = 'VE' THEN
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(2),'COUNT(1)','A.ID_MARCA')||' '||XVH.ID_MARCA;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_MARCA;
                  /*SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(4),'COUNT(1)','A.ID_LINEA')||' '||XVH.ID_LINEA;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_LINEA;*/
                  V_ID_LINEA := NULL;
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(7),'COUNT(1)','A.ID_CLASE')||' '||XVH.ID_CLASE;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_CLASE;          
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(9),'COUNT(1)','A.ID_SERVICIO')||' '||XVH.ID_SERVICIO;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SERVICIO;          
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(REPLACE(REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(11),'COUNT(1)','A.ID_CARROCERIA'),':VP',XVH.ID_CARROCERIA),':VS',XVH.ID_CLASE);
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_CARROCERIA;                    
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(14),'COUNT(1)','A.ID_COMBUSTIBLE')||' '||XVH.ID_COMBUSTIBLE;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_COMBUSTIBLE;
                  SQLTEXT := '';
                  SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(19),'COUNT(1)','A.ID_SECRETARIA')||' '||XVH.ID_SECRETARIA;
                  EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SECRETARIA;       
                  --VALIDO SI YA EXISTE EL VEHICULO
                  V_EXISTE := DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_EXISTE_VEHICULO(V_NRO_PLACA);
                  IF V_EXISTE = TRUE THEN -- SI EXISTE SE ACTUALIZA EL VEHICULO.
                  
                      --CAPTURO LAS TONELADAS Y PASAJEROS ANTERIORES ANTES DE ACTUALIZAR EL REGISTRO DEL VEHICULO
                      BEGIN
                        SELECT LT.CAP_TONELADAS,
                                LT.CAP_PASAJEROS
                        INTO V_TONELADAS_ANTERIORES,
                              V_PASAJEROS_ANTERIORES
                        FROM QUIPUX.LIC_TTO LT
                        WHERE LT.NRO_PLACA = V_NRO_PLACA;
                      EXCEPTION
                      WHEN OTHERS THEN
                            V_TONELADAS_ANTERIORES := NULL;
                            V_PASAJEROS_ANTERIORES := NULL;
                      END;
                      
                      V_FLAG_COMMIT := FT_ACTUALIZAR_VEHICULO(V_NRO_PLACA, V_ID_MARCA, V_ID_LINEA, V_CILINDRAJE, V_POTENCIA, V_MODELO, V_ID_CLASE, V_ID_SERVICIO, V_ID_CARROCERIA, V_NRO_PUERTAS, V_CAP_TONELADAS, V_CAP_PASAJEROS, V_IMPORTADO_NACIONAL, V_ID_COMBUSTIBLE, V_ID_ESTADO, V_VALOR_FACTURA, V_ID_SECRETARIA, V_CLASICO_ANTIGUO, V_BLINDADO, V_FECHA_MATRICULO, V_ID_BATERIA, XVH.ID_LINEA, XVH.NOMBRE_LINEA);
                      
                      REGISTRO_NUEVO := 'M';
                  ELSE   
                      V_FLAG_COMMIT := FT_INSERTAR_VEHICULO(V_NRO_PLACA, V_ID_MARCA, V_ID_LINEA, V_CILINDRAJE, V_POTENCIA, V_MODELO, V_ID_CLASE, V_ID_SERVICIO, V_ID_CARROCERIA, V_NRO_PUERTAS, V_CAP_TONELADAS, V_CAP_PASAJEROS, V_IMPORTADO_NACIONAL, V_ID_COMBUSTIBLE, V_ID_ESTADO, V_VALOR_FACTURA, V_ID_SECRETARIA, V_CLASICO_ANTIGUO, V_BLINDADO, V_FECHA_MATRICULO, V_ID_BATERIA, XVH.ID_LINEA, XVH.NOMBRE_LINEA);
                      REGISTRO_NUEVO := 'N';
                  END IF;
                  IF NOT V_FLAG_COMMIT THEN
                      UPDATE DEPURACION.DS_VEHICULO SET ESTADO_VALIDACION = 'RA', ENVIO_SAP = REGISTRO_NUEVO WHERE NRO_IDENTIFICADOR = XVH.NRO_IDENTIFICADOR;
                  END IF;
                END IF;
                IF NOT V_FLAG_COMMIT THEN
                        FOR XTR IN ACTTRAMITES(V_NRO_PLACA, NRORADICADO) LOOP
                        --PRIMERO BORRO LOS PROPIETARIOS DEL VEHICULO YA QUE SE SUPONE QUE EN EL ARCHIVO DE PROPIETARIOS VIENEN TODOS LOS PROPIETARIOS ACTUALES QUE VAN A QUEDAR EN LA TABLA.
                              BEGIN
                                DELETE FROM QUIPUX.PROPIETARIOS_VEHICULO
                                WHERE NRO_PLACA=XVH.NRO_PLACA;
                              EXCEPTION
                              WHEN OTHERS THEN
                                NULL;
                              END;
                              
                              FOR XPR IN ACTPROPIETARIOS(XVH.NRO_PLACA, NRORADICADO) LOOP              
                                    FOR XCO IN ACTCONTRIBUYENTES(XPR.ID_DOCUMENTO, XPR.ID_USUARIO, NRORADICADO) LOOP
                                          IF XCO.ESTADO_VALIDACION = 'VE' THEN
                                            V_EXISTE_ACTUALIZACION := DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_EXISTE_USUARIO_PROPIETARIO(XVH.NRO_PLACA, XCO.ID_DOCUMENTO, XCO.ID_USUARIO, 'U');
                                            --VALIDO SI SE PUEDE ACTUALIZAR LA INFORMACION DEL USUARIO DEACUERDO A LA FECHA DE MODIFICACION DEL USUARIO
                                            IF V_EXISTE_ACTUALIZACION = TRUE THEN
                                              --XCO.NRO_IDENTIFICADOR, XCO.ID_RADICADO, 
                                                  FOR XDIR IN INSDIRECCIONES(XCO.NRO_IDENTIFICADOR, NRORADICADO) LOOP
                                                          V_FLAG_COMMIT := FT_INSERTAR_DIRECCION(NRORADICADO, XCO.ID_USUARIO, XDIR.DIRECCION, XDIR.ID_CIUDAD, XDIR.TELEFONO, XDIR.FAX);
                                                          IF NOT V_FLAG_COMMIT THEN
                                                                 UPDATE DEPURACION.DS_DIRECCIONES SET ESTADO_VALIDACION = 'RA'
                                                                     WHERE ID_DIRECCION = XDIR.ID_DIRECCION;
                                                          END IF;
                                                  END LOOP;
                                                  IF NOT V_FLAG_COMMIT THEN
                                                              V_FLAG_COMMIT := FT_ACTUALIZAR_USUARIO(NRORADICADO, XCO.ID_DOCUMENTO, XCO.ID_USUARIO, XCO.ID_CIUDAD_DIR, XCO.APELLIDOS, XCO.NOMBRES, XCO.DIRECCION, XCO.TELEFONO, XCO.EMP_O_PART, XCO.SEXO, XCO.FECHA_NACIMIENTO, XCO.ID_PAIS, XCO.FAX, XCO.EMAIL);
                                                              REGISTRO_NUEVO := 'M';                                        
                                                  END IF;
                                                  IF NOT V_FLAG_COMMIT THEN
                                                     UPDATE DEPURACION.DS_CONTRIBUYENTE set ESTADO_VALIDACION = 'RA', ENVIO_SAP = REGISTRO_NUEVO where NRO_IDENTIFICADOR = XCO.NRO_IDENTIFICADOR;
                                                  END IF;
                                            ELSE
                                            --IF FT_ES_PROPIETARIO(V_ID_USUARIO) THEN
                                                  -- ESTEBAN GOMEZ - ELVIS BETANCUR
                                                    V_FLAG_COMMIT := FT_INSERTAR_USUARIO(NRORADICADO, XCO.ID_DOCUMENTO, XCO.ID_USUARIO, XCO.ID_CIUDAD_DIR, XCO.APELLIDOS, XCO.NOMBRES, XCO.DIRECCION, XCO.TELEFONO, XCO.EMP_O_PART, XCO.SEXO, XCO.FECHA_NACIMIENTO, XCO.ID_PAIS, XCO.FAX, XCO.EMAIL);
                                                    REGISTRO_NUEVO := 'N'; 
                                                    
                                                    IF NOT V_FLAG_COMMIT THEN
                                                
                                                        FOR XDIR IN INSDIRECCIONES(XCO.NRO_IDENTIFICADOR, NRORADICADO) LOOP
                                                                IF NOT V_FLAG_COMMIT THEN
                                                                V_FLAG_COMMIT := FT_INSERTAR_DIRECCION(NRORADICADO, XCO.ID_USUARIO, XDIR.DIRECCION, XDIR.ID_CIUDAD, XDIR.TELEFONO, XDIR.FAX);
                                                               END IF;
                                                            
                                                                IF NOT V_FLAG_COMMIT THEN
                                                                       UPDATE DEPURACION.DS_DIRECCIONES SET ESTADO_VALIDACION = 'RA'
                                                                           WHERE ID_DIRECCION = XDIR.ID_DIRECCION;
                                                                END IF;
                                                        END LOOP;
                                                  
                                                /*  IF NOT V_FLAG_COMMIT THEN
                                                              V_FLAG_COMMIT := FT_INSERTAR_USUARIO(NRORADICADO, XCO.ID_DOCUMENTO, XCO.ID_USUARIO, XCO.ID_CIUDAD_DIR, XCO.APELLIDOS, XCO.NOMBRES, XCO.DIRECCION, XCO.TELEFONO, XCO.EMP_O_PART, XCO.SEXO, XCO.FECHA_NACIMIENTO, XCO.ID_PAIS, XCO.FAX, XCO.EMAIL);
                                                              REGISTRO_NUEVO := 'N';                                        
                                                  END IF;*/
                                                    IF NOT V_FLAG_COMMIT THEN
                                                           UPDATE DEPURACION.DS_CONTRIBUYENTE SET ESTADO_VALIDACION = 'RA', ENVIO_SAP = REGISTRO_NUEVO WHERE NRO_IDENTIFICADOR = XCO.NRO_IDENTIFICADOR;
                                                    END IF;
                                               END IF;                                                         
                                            END IF;
                                        END IF;
                                    END LOOP;  
                                    REGISTRO_NUEVO := NULL;
                                    IF NOT V_FLAG_COMMIT THEN
                                              IF XTR.ID_TRAMITE = 65 THEN
                                                V_ID_DOCUMENTO := 1;
                                                V_ID_USUARIO := '5134';
                                              ELSE
                                                V_ID_DOCUMENTO := XPR.ID_DOCUMENTO;
                                                V_ID_USUARIO := XPR.ID_USUARIO;
                                              END IF;
                                              
                                              V_EXISTE_PROPIETARIO := DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_EXISTE_USUARIO_PROPIETARIO(XPR.NRO_PLACA, V_ID_DOCUMENTO, V_ID_USUARIO, 'P');
                                              IF NOT V_EXISTE_PROPIETARIO THEN
                                                 V_FLAG_COMMIT := FT_INSERTAR_PROPIETARIO(XPR.NRO_PLACA, V_ID_USUARIO, XPR.PORCENTAJE_PROP);
                                                 REGISTRO_NUEVO := 'N';
                                              ELSE
                                                 REGISTRO_NUEVO := 'M';
                                              END IF; 
                                              IF NOT V_FLAG_COMMIT THEN
                                                  UPDATE DEPURACION.DS_PROPIETARIO SET ESTADO_VALIDACION = 'RA', ENVIO_SAP = REGISTRO_NUEVO WHERE NRO_IDENTIFICADOR = XPR.NRO_IDENTIFICADOR;                              
                                              END IF;
                                      END IF;
                              END LOOP;
                              
                              IF NOT V_FLAG_COMMIT THEN
                                      IF XTR.ESTADO_VALIDACION = 'VE' THEN
                                        --VARIFICO EL TIPO DE TRAMITE PARA SABER QUE DATOS TOMO Y QUE VALIDACIONES HAGO.
                                        CASE XTR.ID_TRAMITE
                                          WHEN 20 THEN --CANCELACION
                                                V_FLAG_COMMIT := FT_CANCELACION(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.TIPO_CANCELACION);
                                          WHEN 15 THEN --TRASLADO
                                                V_FLAG_COMMIT := FT_TRASLADO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_SECRETARIA_DESTINO, XTR.ID_SECRETARIA_ORIGEN);
                                          WHEN 6 THEN --CAMBIO SERVICIO
                                                V_FLAG_COMMIT := FT_CAMBIO_SERVICIO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_SERVICIO_ANTERIOR, XTR.ID_SERVICIO_NUEVO);
                                          WHEN 10 THEN --RADICADO
                                                V_FLAG_COMMIT := FT_RADICADO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_SECRETARIA_ORIGEN);
                                          WHEN 2 THEN --CAMBIO CARROCERIA
                                                V_FLAG_COMMIT := FT_CAMBIO_CARROCERIA(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_CARROCERIA_ANTERIOR, XTR.ID_CARROCERIA_NUEVA, XTR.ID_RADICADO);
                                          WHEN 13 THEN --REMATRICULA
                                                V_FLAG_COMMIT := FT_REMATRICULA(XTR.NRO_PLACA, XTR.FECHA_TRAMITE);
                                          WHEN 14 THEN --REPOTENCIACION
                                                V_FLAG_COMMIT := FT_CAMBIO_MOTOR(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.CILINDRAJE, XTR.CAP_TONELADAS, XTR.CAP_PASAJEROS, XTR.ID_RADICADO, V_TONELADAS_ANTERIORES, V_PASAJEROS_ANTERIORES);
                                          WHEN 16 THEN --TRASPASO
                                                  V_FLAG_COMMIT := FT_TRASPASO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_USUARIO_ANTERIOR, XTR.ID_USUARIO_NUEVO, XTR.PORCENTAJE_PROP);
                                                  FOR ITT IN (SELECT * FROM DEPURACION.DS_TRAMITE_TRASPASO 
                                                                                        WHERE NRO_PLACA = XTR.NRO_PLACA AND
                                                                                                     ID_RADICADO = XTR.ID_RADICADO AND
                                                                                                     NRO_IDENTIFICADOR = XTR.NRO_IDENTIFICADOR) LOOP
                                                                    IF NOT V_FLAG_COMMIT THEN
                                                                            V_FLAG_COMMIT := FT_TRASPASO(ITT.NRO_PLACA, ITT.FECHA_TRAMITE, ITT.ID_USUARIO_ANTERIOR, ITT.ID_USUARIO_NUEVO, ITT.PORCENTAJE_PROP);
                                                                    END IF;
                                                 END LOOP;
                                          WHEN 65 THEN --TRASPASO INDETERMINADO
                                                V_FLAG_COMMIT := FT_TRASPASO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE, XTR.ID_USUARIO_ANTERIOR, '5134', XTR.PORCENTAJE_PROP);
                                          WHEN 1 THEN --BLINDADO
                                                V_FLAG_COMMIT := FT_BLINDADO_DESBLINDADO(XTR.ID_TRAMITE, XTR.NRO_PLACA, XTR.FECHA_TRAMITE,XTR.NIVEL_BLINDADO);
                                          WHEN 5 THEN --DESBLINDADO
                                                V_FLAG_COMMIT := FT_BLINDADO_DESBLINDADO(XTR.ID_TRAMITE, XTR.NRO_PLACA, XTR.FECHA_TRAMITE,XTR.NIVEL_BLINDADO);
                                          WHEN 9 THEN --MATRICULA INICIAL
                                                V_FLAG_COMMIT := FT_MATRICULA_INICIAL(XTR.NRO_PLACA, XTR.FECHA_TRAMITE);
                                          WHEN 23 THEN --CLASICO ANTIGUO
                                                V_FLAG_COMMIT := FT_CLASICO_ANTIGUO(XTR.NRO_PLACA, XTR.FECHA_TRAMITE);
                                          ELSE
                                            NULL;
                                        END CASE;
                                        IF NOT V_FLAG_COMMIT  THEN
                                            UPDATE DEPURACION.DS_TRAMITE SET ESTADO_VALIDACION = 'RA', ENVIO_SAP = 'N' WHERE NRO_IDENTIFICADOR = XTR.NRO_IDENTIFICADOR;                        
                                        END IF;
                                      END IF;
                              END IF;
                         END LOOP;
                  END IF;
          END LOOP;
      EXCEPTION
          WHEN OTHERS THEN
                ROLLBACK;
                MSERROR := SQLERRM;
                INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'LIC_TTO',GV_RADICADO,NVL(V_NRO_PLACA,'PLACA NULA'),MSERROR, 3);    
                COMMIT;
      END;
      IF NOT V_FLAG_COMMIT THEN
          COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  END SP_PROCESAR_REGISTRO_LOTE;
  
/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO DEL LOG DE MODIFICACIONES DEL VEHICULO

===============================================================================================================================
===============================================================================================================================
*/

PROCEDURE SP_GUARDAR_LOG_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2) AS
  V_ID_REGISTRO_MODIFICADO NUMBER;
  V_ID_REGISTRO_NUEVO NUMBER;
BEGIN

  SELECT DEPURACION.SEQ_DS_LOG_VEHICULO_ACTUALIZA.NEXTVAL
  INTO V_ID_REGISTRO_MODIFICADO
  FROM DUAL;

  INSERT INTO DEPURACION.DS_LOG_VEHICULO_ACTUALIZADO (ID_REGISTRO,ID_REGISTRO_MODIFICADO,ID_RADICADO,FECHA,NRO_PLACA,ID_MARCA,ID_LINEA,CILINDRAJE,POTENCIA,MODELO,ID_CLASE,ID_SERVICIO,ID_CARROCERIA,PUERTAS,CAP_TONELADAS,CAP_PASAJEROS,IMPORTADO_NACIONAL,ID_COMBUSTIBLE,ID_ESTADO,VALOR_FACTURA,ID_SECRETARIA,ID_BATERIA,CLASICO_ANTIGUO,ID_LINEA_RUNT,NOMBRE_LINEA_RUNT)
  SELECT V_ID_REGISTRO_MODIFICADO,
        NULL,
        GV_RADICADO,
        SYSDATE,
        NRO_PLACA,
        ID_MARCA,
        ID_LINEA,
        CILINDRAJE,
        POTENCIA,
        MODELO,
        ID_CLASE,
        ID_SERVICIO,
        ID_CARROCERIA,
        PUERTAS,
        CAP_TONELADAS,
        CAP_PASAJEROS,
        IMPORTADO_NACIONAL,
        ID_COMBUSTIBLE,
        ID_ESTADO,
        VALOR_FACTURA,
        ID_SECRETARIA,
        ID_BATERIA,
        CLASICO_ANTIGUO,
        ID_LINEA_RUNT,
        NOMBRE_LINEA_RUNT
  FROM LIC_TTO
  WHERE NRO_PLACA = A_NRO_PLACA;
  
  SELECT DEPURACION.SEQ_DS_LOG_VEHICULO_ACTUALIZA.NEXTVAL
  INTO V_ID_REGISTRO_NUEVO
  FROM DUAL;
  
  INSERT INTO DEPURACION.DS_LOG_VEHICULO_ACTUALIZADO (ID_REGISTRO,ID_REGISTRO_MODIFICADO,ID_RADICADO,FECHA,NRO_PLACA,ID_MARCA,ID_LINEA,CILINDRAJE,POTENCIA,MODELO,ID_CLASE,ID_SERVICIO,ID_CARROCERIA,PUERTAS,CAP_TONELADAS,CAP_PASAJEROS,IMPORTADO_NACIONAL,ID_COMBUSTIBLE,ID_ESTADO,VALOR_FACTURA,ID_SECRETARIA,ID_BATERIA,CLASICO_ANTIGUO,ID_LINEA_RUNT,NOMBRE_LINEA_RUNT)
  VALUES (V_ID_REGISTRO_NUEVO,
        V_ID_REGISTRO_MODIFICADO,
        GV_RADICADO,
        SYSDATE,
        A_NRO_PLACA,
        A_ID_MARCA,
        A_ID_LINEA,
        A_CILINDRAJE,
        A_POTENCIA,
        A_MODELO,
        A_ID_CLASE,
        A_ID_SERVICIO,
        A_ID_CARROCERIA,
        A_NRO_PUERTAS,
        A_CAP_TONELADAS,
        A_CAP_PASAJEROS,
        A_IMPORTADO_NACIONAL,
        A_ID_COMBUSTIBLE,
        A_ID_ESTADO,
        A_VALOR_FACTURA,
        A_ID_SECRETARIA,
        A_ID_BATERIA,
        A_CLASICO_ANTIGUO,
        A_ID_LINEA_RUNT,
        A_NOMBRE_LINEA_RUNT);
  
END SP_GUARDAR_LOG_VEHICULO; 

/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO DE LAS ACTUALIZACIO DEL VEHICULO

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_ACTUALIZAR_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2) RETURN BOOLEAN
  AS
    V_UPDATE VARCHAR2(1000);
    V_CLASICO_ANTIGUO VARCHAR2(1);
    V_POTENCIA NUMBER;
    V_ID_BATERIA NUMBER;
    V_CILINDRAJE NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    --CREO EL STRING DEL UPDATE
    V_UPDATE := '';
    
    IF A_ID_CLASE = 10 AND A_ID_COMBUSTIBLE = 5 THEN
      V_POTENCIA := A_POTENCIA;
      V_ID_BATERIA := A_ID_BATERIA;
      V_CILINDRAJE := NULL;
    ELSE
      V_POTENCIA := NULL;
      V_ID_BATERIA := NULL;
      V_CILINDRAJE := A_CILINDRAJE;
    END IF;
    
    --A�ADO EL UPDATE
    V_UPDATE := 'UPDATE QUIPUX.LIC_TTO ';
    
    --A�ADO EL SET VALIDANDO QUE CAMPOS VOY A ACTULIZAR
    V_UPDATE := V_UPDATE || 'SET NRO_PLACA = ''' || A_NRO_PLACA || ''' ';
    IF A_ID_MARCA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_MARCA = ' || TO_CHAR(A_ID_MARCA) || ' ';
    END IF;
    /*IF A_ID_LINEA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_LINEA = ' || TO_CHAR(A_ID_LINEA) || ' ';
    END IF;*/
    IF V_CILINDRAJE IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', CILINDRAJE = ' || TO_CHAR(V_CILINDRAJE) || ' ';
    END IF;
    IF V_POTENCIA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', POTENCIA = ' || TO_CHAR(V_POTENCIA) || ' ';
    END IF;
    IF A_MODELO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', MODELO = ' || TO_CHAR(A_MODELO) || ' ';
    END IF;
    IF A_ID_CLASE IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_CLASE = ' || TO_CHAR(A_ID_CLASE) || ' ';
    END IF;
    IF A_ID_SERVICIO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_SERVICIO = ' || TO_CHAR(A_ID_SERVICIO) || ' ';
    END IF;
    IF A_ID_CARROCERIA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_CARROCERIA = ' || TO_CHAR(A_ID_CARROCERIA) || ' ';
    END IF;
    IF A_NRO_PUERTAS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', PUERTAS = ' || TO_CHAR(A_NRO_PUERTAS) || ' ';
    END IF;
    IF A_CAP_TONELADAS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', CAP_TONELADAS = ' || REPLACE(TO_CHAR(A_CAP_TONELADAS),',','.') || ' ';
    END IF;
    IF A_CAP_PASAJEROS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', CAP_PASAJEROS = ' || TO_CHAR(A_CAP_PASAJEROS) || ' ';
    END IF;
    IF A_IMPORTADO_NACIONAL IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', IMPORTADO_NACIONAL = ''' || A_IMPORTADO_NACIONAL || ''' ';
    END IF;
    IF A_ID_COMBUSTIBLE IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_COMBUSTIBLE = ' || TO_CHAR(A_ID_COMBUSTIBLE) || ' ';
    END IF;
    IF A_ID_ESTADO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_ESTADO = ' || TO_CHAR(A_ID_ESTADO) || ' ';
    END IF;
    IF A_VALOR_FACTURA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', VALOR_FACTURA = ' || TO_CHAR(A_VALOR_FACTURA) || ' ';
    END IF;
    IF A_ID_SECRETARIA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_SECRETARIA = ' || TO_CHAR(A_ID_SECRETARIA) || ' ';
    END IF;
    IF V_ID_BATERIA IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_BATERIA = ' || TO_CHAR(V_ID_BATERIA) || ' ';
    END IF;
    IF A_CLASICO_ANTIGUO IS NOT NULL THEN
      IF A_CLASICO_ANTIGUO = 'N' THEN
        V_CLASICO_ANTIGUO := NULL;
      ELSE
        V_CLASICO_ANTIGUO := A_CLASICO_ANTIGUO;
      END IF;
      V_UPDATE := V_UPDATE || ', CLASICO_ANTIGUO = ''' || V_CLASICO_ANTIGUO || ''' ';
    END IF;
    IF A_ID_LINEA_RUNT IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_LINEA_RUNT = ' || TO_CHAR(A_ID_LINEA_RUNT) || ' ';
    END IF;
    IF A_NOMBRE_LINEA_RUNT IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', NOMBRE_LINEA_RUNT = ''' || TO_CHAR(A_NOMBRE_LINEA_RUNT) || ''' ';
    END IF;
    
    --A�ADO EL WHERE
    V_UPDATE := V_UPDATE || 'WHERE NRO_PLACA = ''' || A_NRO_PLACA || ''' ';
    
    --GUARDO EL LOG
    SP_GUARDAR_LOG_VEHICULO(A_NRO_PLACA,A_ID_MARCA,A_ID_LINEA,A_CILINDRAJE,A_POTENCIA,A_MODELO,A_ID_CLASE,A_ID_SERVICIO,A_ID_CARROCERIA,A_NRO_PUERTAS,A_CAP_TONELADAS,A_CAP_PASAJEROS,A_IMPORTADO_NACIONAL,A_ID_COMBUSTIBLE,A_ID_ESTADO,A_VALOR_FACTURA,A_ID_SECRETARIA,A_CLASICO_ANTIGUO,A_BLINDADO,A_FECHA_MATRICULO, A_ID_BATERIA, A_ID_LINEA_RUNT, A_NOMBRE_LINEA_RUNT);
    
    --EJECUTO EL QUERY
    EXECUTE IMMEDIATE V_UPDATE;

    RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('LIC_TTO',MSERROR,GV_RADICADO,A_NRO_PLACA,'FT_ACTUALIZAR_VEHICULO');
            RETURN FLAG_ERROR;
            
  END FT_ACTUALIZAR_VEHICULO;

/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO INSERCCION DEL VEHICULO

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_INSERTAR_VEHICULO(A_NRO_PLACA VARCHAR2,A_ID_MARCA NUMBER,A_ID_LINEA NUMBER,A_CILINDRAJE NUMBER,A_POTENCIA NUMBER,A_MODELO NUMBER,A_ID_CLASE NUMBER,A_ID_SERVICIO NUMBER,A_ID_CARROCERIA NUMBER,A_NRO_PUERTAS NUMBER,A_CAP_TONELADAS NUMBER,A_CAP_PASAJEROS NUMBER,A_IMPORTADO_NACIONAL VARCHAR2,A_ID_COMBUSTIBLE NUMBER,A_ID_ESTADO NUMBER,A_VALOR_FACTURA NUMBER,A_ID_SECRETARIA NUMBER,A_CLASICO_ANTIGUO VARCHAR2,A_BLINDADO VARCHAR2,A_FECHA_MATRICULO DATE, A_ID_BATERIA NUMBER, A_ID_LINEA_RUNT NUMBER, A_NOMBRE_LINEA_RUNT VARCHAR2) RETURN BOOLEAN
  AS
    V_CLASICO_ANTIGUO VARCHAR2(1);
    V_IMPORTADO_NACIONAL VARCHAR2(1);
    V_POTENCIA NUMBER;
    V_CILINDRAJE NUMBER;
    V_ID_BATERIA NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

    IF A_ID_CLASE = 10 AND A_ID_COMBUSTIBLE = 5 THEN
      V_POTENCIA := A_POTENCIA;
      V_ID_BATERIA := A_ID_BATERIA;
      V_CILINDRAJE := NULL;
    ELSE
      V_POTENCIA := NULL;
      V_ID_BATERIA := NULL;
      V_CILINDRAJE := A_CILINDRAJE;
    END IF;

    IF A_IMPORTADO_NACIONAL IS NULL THEN
      V_IMPORTADO_NACIONAL := 'N';
    ELSE
      V_IMPORTADO_NACIONAL := A_IMPORTADO_NACIONAL;
    END IF;

    IF A_CLASICO_ANTIGUO IS NULL THEN
      V_CLASICO_ANTIGUO := 'N';
    ELSE
      V_CLASICO_ANTIGUO := A_CLASICO_ANTIGUO;
    END IF;
    
    --HAGO EL INSERT
    INSERT INTO QUIPUX.LIC_TTO
            (NRO_PLACA,
            ID_MARCA,
            ID_LINEA,
            CILINDRAJE,
            POTENCIA,
            MODELO,
            ID_CLASE,
            ID_SERVICIO,
            ID_CARROCERIA,
            PUERTAS,
            CAP_TONELADAS,
            CAP_PASAJEROS,
            IMPORTADO_NACIONAL,
            ID_COMBUSTIBLE,
            ID_ESTADO,
            VALOR_FACTURA,
            ID_SECRETARIA,
            CLASICO_ANTIGUO,
            ID_BATERIA,
            FECHA_INGRESO_TTO,
            ID_LINEA_RUNT,
            NOMBRE_LINEA_RUNT)
    VALUES (A_NRO_PLACA,
            A_ID_MARCA,
            A_ID_LINEA,
            V_CILINDRAJE,
            V_POTENCIA,
            A_MODELO,
            A_ID_CLASE,
            A_ID_SERVICIO,
            A_ID_CARROCERIA,
            A_NRO_PUERTAS,
            A_CAP_TONELADAS,
            A_CAP_PASAJEROS,
            V_IMPORTADO_NACIONAL,
            A_ID_COMBUSTIBLE,
            A_ID_ESTADO,
            A_VALOR_FACTURA,
            A_ID_SECRETARIA,
            V_CLASICO_ANTIGUO,
            V_ID_BATERIA,
            SYSDATE,
            A_ID_LINEA_RUNT,
            A_NOMBRE_LINEA_RUNT);

    RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('PROPIETARIOS_VEHICULO',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_INSERTAR_VEHICULO');
            RETURN FLAG_ERROR;
END FT_INSERTAR_VEHICULO;

/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO DE LA INSERCCION DEL PROPIETARIO

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_INSERTAR_PROPIETARIO(A_PLACA VARCHAR2, A_IDENTIFICACION VARCHAR2, A_PORCENTAJE_PROPIEDAD NUMBER) RETURN BOOLEAN
  AS
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

    --INSERTO
    INSERT INTO QUIPUX.PROPIETARIOS_VEHICULO
            (NRO_PLACA,
            ID_USUARIO,
            PORCENTAJE_PROP)
    VALUES (A_PLACA,
            A_IDENTIFICACION,
            A_PORCENTAJE_PROPIEDAD);
            
    RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('PROPIETARIOS_VEHICULO',MSERROR,GV_RADICADO,A_PLACA, 'FT_INSERTAR_PROPIETARIO');
            RETURN FLAG_ERROR;

  END FT_INSERTAR_PROPIETARIO;

/*
===============================================================================================================================
===============================================================================================================================

                                  PROCEDIMIENTO DE LAS ACTUALIZACIONES DE LOS USUARIOS REPORTADOS

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_ACTUALIZAR_USUARIO(A_RADICADO NUMBER, A_ID_DOCUMENTO NUMBER,A_ID_USUARIO VARCHAR2,A_ID_CIUDAD NUMBER,A_APELLIDOS VARCHAR2,A_NOMBRES VARCHAR2,A_DIRECCION VARCHAR2,A_TELEFONO VARCHAR2,A_EMP_O_PART VARCHAR2,A_SEXO VARCHAR2,A_FECHA_NACIMIENTO VARCHAR2 ,A_PAIS NUMBER,A_FAX VARCHAR2,A_EMAIL VARCHAR2) RETURN BOOLEAN
  AS
    V_UPDATE VARCHAR2(1000);
    V_DIRECCION VARCHAR(100);
    V_CIUDAD_DIR NUMBER;
    V_PAIS NUMBER;
    SQLTEXT VARCHAR2(4000);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

    --VALIDO LA DIRECCION QUE VA A INSERTAR
    IF LENGTH(A_DIRECCION) > 100 THEN
      V_DIRECCION := NULL;
      V_CIUDAD_DIR := NULL;
      V_PAIS := NULL;
    ELSE
      V_DIRECCION := A_DIRECCION;  
    END IF;

      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(77),'COUNT(1)','A.ID_CIUDAD')||A_ID_CIUDAD;
      EXECUTE IMMEDIATE SQLTEXT INTO V_CIUDAD_DIR;      
      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(42),'COUNT(1)','A.ID_PAIS')||A_PAIS;
      EXECUTE IMMEDIATE SQLTEXT INTO V_PAIS;    
      
    --CREO EL STRING DEL UPDATE
    V_UPDATE := '';
    
    --A�ADO EL UPDATE
    V_UPDATE := 'UPDATE QUIPUX.USUARIOS_TTO ';
    
    --A�ADO EL SET VALIDANDO QUE CAMPOS VOY A ACTULIZAR
    V_UPDATE := V_UPDATE || 'SET ID_USUARIO = ''' || A_ID_USUARIO || ''' ';
    IF A_ID_DOCUMENTO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_DOCUMENTO = ' || TO_CHAR(A_ID_DOCUMENTO) || ' ';
    END IF;
    IF A_APELLIDOS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', APELLIDOS = ''' || A_APELLIDOS || ''' ';
    END IF;
    IF A_NOMBRES IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', NOMBRES = ''' || A_NOMBRES || ''' ';
    END IF;
    IF V_DIRECCION IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', DIRECCION = ''' || V_DIRECCION || ''' ';
    END IF;
    IF V_CIUDAD_DIR IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', CIUDAD_DIR = ' || V_CIUDAD_DIR || ' ';
    END IF;
    IF A_TELEFONO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', TELEFONO = ''' || A_TELEFONO || ''' ';
    END IF;
    IF A_EMP_O_PART IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', EMP_O_PART = ''' || A_EMP_O_PART || ''' ';
    END IF;
    IF A_SEXO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', SEXO = ''' || A_SEXO || ''' ';
    END IF;
    IF A_FECHA_NACIMIENTO IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', FECHA_NACIMIENTO = TO_DATE('''||A_FECHA_NACIMIENTO||''',''DD/MM/YYYY'')';
    END IF;
    IF A_PAIS IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', ID_PAIS = ' || TO_CHAR(V_PAIS) || ' ';
    END IF;
    IF A_FAX IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', FAX = ''' || A_FAX || ''' '; 
    END IF;
    IF A_EMAIL IS NOT NULL THEN
      V_UPDATE := V_UPDATE || ', EMAIL = ''' || A_EMAIL || ''' ';
    END IF;
    
    --A�ADO EL WHERE
    V_UPDATE := V_UPDATE || 'WHERE ID_USUARIO = ''' || A_ID_USUARIO || ''' AND ID_DOCUMENTO = '||TO_CHAR(A_ID_DOCUMENTO);

    -- ACTUALIZAR EL REGISTRO DEL PROPIETARIO
    EXECUTE IMMEDIATE V_UPDATE;   
    
    --INSERTO LA DIRECCION
      FLAG_ERROR := FT_INSERTAR_DIRECCION(A_RADICADO, A_ID_USUARIO, A_DIRECCION, A_ID_CIUDAD, A_TELEFONO, A_FAX);
      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('USUARIOS_TTO',MSERROR,GV_RADICADO,A_ID_USUARIO, 'FT_ACTUALIZAR_USUARIO');
            RETURN FLAG_ERROR;
  END FT_ACTUALIZAR_USUARIO;
  
/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO DE LA INSERCCION DE LOS USUARIOS REPORTADOS

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_INSERTAR_USUARIO(A_RADICADO NUMBER, A_ID_DOCUMENTO NUMBER,A_ID_USUARIO VARCHAR2,A_ID_CIUDAD NUMBER,A_APELLIDOS VARCHAR2,A_NOMBRES VARCHAR2,A_DIRECCION VARCHAR2,A_TELEFONO VARCHAR2,A_EMP_O_PART VARCHAR2,A_SEXO VARCHAR2,A_FECHA_NACIMIENTO VARCHAR2,A_PAIS NUMBER,A_FAX VARCHAR2,A_EMAIL VARCHAR2) RETURN BOOLEAN
  AS
    V_DIRECCION VARCHAR(100);
    V_CIUDAD_DIR NUMBER;
    V_PAIS NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE) := NULL;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    V_DIRECCION := A_DIRECCION;

      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(77),'COUNT(1)','A.ID_CIUDAD')||A_ID_CIUDAD;
      EXECUTE IMMEDIATE SQLTEXT INTO V_CIUDAD_DIR;      
      SQLTEXT := '';
      SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(42),'COUNT(1)','A.ID_PAIS')||A_PAIS;
      EXECUTE IMMEDIATE SQLTEXT INTO V_PAIS;    
    
    --HAGO EL INSERT
    INSERT INTO QUIPUX.USUARIOS_TTO
            (ID_USUARIO,
            ID_DOCUMENTO,
            APELLIDOS,
            NOMBRES,
            DIRECCION,
            CIUDAD_DIR,
            TELEFONO,
            EMP_O_PART,
            SEXO,
            FECHA_NACIMIENTO,
            ID_PAIS,
            FAX)
    VALUES (A_ID_USUARIO,
            A_ID_DOCUMENTO,
            A_APELLIDOS,
            A_NOMBRES,
            V_DIRECCION,
            V_CIUDAD_DIR,
            A_TELEFONO,
            A_EMP_O_PART,
            A_SEXO,
            TO_DATE(A_FECHA_NACIMIENTO,'DD/MM/YYYY'),
            V_PAIS,
            A_FAX);
            
      --INSERTO LA DIRECCION
      FLAG_ERROR := FT_INSERTAR_DIRECCION(A_RADICADO, A_ID_USUARIO, A_DIRECCION, A_ID_CIUDAD, A_TELEFONO, A_FAX);
      RETURN FLAG_ERROR;
                                                    
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('USUARIOS_TTO',MSERROR,GV_RADICADO,A_ID_USUARIO, 'FT_INSERTAR_USUARIO');
            RETURN FLAG_ERROR;

  END FT_INSERTAR_USUARIO;
  
/*
===============================================================================================================================
===============================================================================================================================

                                        PROCEDIMIENTO DE INSERCCION DE LA NUEVA DIRECCION

===============================================================================================================================
===============================================================================================================================
*/
                                                       
  FUNCTION FT_INSERTAR_DIRECCION(A_RADICADO NUMBER, A_ID_USUARIO VARCHAR2,A_DIRECCION VARCHAR2,A_MUNICIPIO NUMBER,A_TELEFONO VARCHAR2,A_FAX VARCHAR2) RETURN BOOLEAN
  AS
    V_CONSECUTIVO NUMBER;
    V_TIPO_ENTIDAD VARCHAR2(2);
    V_CONFIRMACION_CONTACTO NUMBER;
    V_ID_FUENTE_DIRECCION NUMBER;
    V_ID_DEPARTAMENTO NUMBER;
    V_MUNICIPIO NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE) := NULL;
    V_TABLA VARCHAR2(30);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(77),'COUNT(1)','A.ID_CIUDAD')||A_MUNICIPIO;
    EXECUTE IMMEDIATE SQLTEXT INTO V_MUNICIPIO;
    
    --VERIFICO QUE TIPO DE ENTIDAD ES
    SELECT DSE.TIPO_ENTIDAD
        INTO V_TIPO_ENTIDAD
    FROM DS_MAESTRO DSM,
              DS_ENTIDAD DSE
    WHERE DSM.ID_ENTIDAD = DSE.ID_ENTIDAD AND
              DSM.ID_RADICADO = A_RADICADO;
    IF V_TIPO_ENTIDAD = 'EE' THEN
      V_CONFIRMACION_CONTACTO := 2;
      V_ID_FUENTE_DIRECCION := 16;
    ELSE
      V_CONFIRMACION_CONTACTO := 5;
      V_ID_FUENTE_DIRECCION := 15;
    END IF;
    
    --VALIDO SI YA EXISTE LA DIRECCION
    BEGIN
      SELECT  UTD.CONSECUTIVO_DIRECCION
      INTO  V_CONSECUTIVO
      FROM USUARIOS_TTO_DIRECCIONES UTD
      WHERE UPPER(UTD.DIRECCION) = UPPER(A_DIRECCION) AND
            UTD.ID_MUNICIPIO = V_MUNICIPIO AND
            UTD.TELEFONO = A_TELEFONO AND
            UTD.ID_USUARIO = A_ID_USUARIO;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_CONSECUTIVO := NULL;
    END;
    
    --CONSULTO EL CODIGO DEL DEPARTAMENTO PARA LA CIUDAD REPORTADA
    BEGIN
      SELECT C.ID_DEPARTAMENTO
      INTO V_ID_DEPARTAMENTO
      FROM CIUDADES C
      WHERE C.ID_CIUDAD = V_MUNICIPIO;
    EXCEPTION
    WHEN OTHERS THEN
      V_ID_DEPARTAMENTO := NULL;
    END;
          
    --SI NO EXISTE LA INSERTO SI YA EXISTE SOLO ACTUALIZO LA FECHA DE MODIFICACION
    IF V_CONSECUTIVO IS NULL THEN
      --CONSULTA EL MAXIMO CONSECUTIVO
      BEGIN
        SELECT MAX(UTD.CONSECUTIVO_DIRECCION)
        INTO V_CONSECUTIVO
        FROM USUARIOS_TTO_DIRECCIONES UTD
        WHERE UTD.ID_USUARIO = A_ID_USUARIO;
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_CONSECUTIVO := 0;
      END;
      
      IF V_CONSECUTIVO = 99 THEN
        RETURN TRUE;
      END IF;
      
      IF V_CONSECUTIVO IS NULL THEN
        V_CONSECUTIVO := 0;
      END IF;
      V_CONSECUTIVO := V_CONSECUTIVO + 1;
      
      --ACTUALIZO TODAS LAS DIRECCIONES DE ESTE USUARIO A PRINCIPAL N
      UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
      SET PRINCIPAL = 'N'
      WHERE ID_USUARIO = A_ID_USUARIO;
      
      V_TABLA := 'USUARIOS_TTO_DIRECCIONES';
      --INSERTO LA NUEVA DIRECCION COMO PRINCIPAL
      INSERT INTO QUIPUX.USUARIOS_TTO_DIRECCIONES
                  (ID_USUARIO,
                  CONSECUTIVO_DIRECCION,
                  DIRECCION,
                  ID_MUNICIPIO,
                  ID_TIPO_DIRECCION,
                  PRINCIPAL,
                  TELEFONO,
                  FAX,
                  TELEFONO2,
                  ACTIVA,
                  ID_CONFIRMACION_CONTACTO,
                  ID_DEPARTAMENTO)
          VALUES (A_ID_USUARIO,
                  V_CONSECUTIVO,
                  A_DIRECCION,
                  V_MUNICIPIO,
                  '1',
                  'S',
                  A_TELEFONO,
                  A_FAX,
                  NULL,
                  'S',
                  V_CONFIRMACION_CONTACTO,
                  V_ID_DEPARTAMENTO);
                  
          V_TABLA := 'USUARIOS_TTO_DIRECCION_FUENTE';
          --INSERTO EN USUARIOS_TTO_DIRECCION_FUENTE
          INSERT INTO QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE
                      (ID_USUARIO,
                      CONSECUTIVO_DIRECCION,
                      ID_FUENTE_DIRECCION,
                      FECHA_FUENTE,
                      IDENTIFICADOR_DIRECCION)
              VALUES (A_ID_USUARIO,
                      V_CONSECUTIVO,
                      V_ID_FUENTE_DIRECCION,
                      SYSDATE,
                      A_ID_USUARIO);              
      ELSE
           V_TABLA := 'USUARIOS_TTO_DIRECCION_FUENTE'; 
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE
          SET FECHA_FUENTE = SYSDATE,
              ID_FUENTE_DIRECCION = V_ID_FUENTE_DIRECCION
          WHERE ID_USUARIO = A_ID_USUARIO AND
                CONSECUTIVO_DIRECCION = V_CONSECUTIVO;
                
          --ACTUALIZO TODAS LAS DIRECCIONES DE ESTE USUARIO A PRINCIPAL N
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
          SET PRINCIPAL = 'N'
          WHERE ID_USUARIO = A_ID_USUARIO;
          V_TABLA := 'USUARIOS_TTO_DIRECCIONES';
          --ACTUALIZO COMO PRINCIPAL LA DIRECCION EXISTENTE
          UPDATE QUIPUX.USUARIOS_TTO_DIRECCIONES
          SET PRINCIPAL = 'S',
              ID_CONFIRMACION_CONTACTO = V_CONFIRMACION_CONTACTO
          WHERE ID_USUARIO = A_ID_USUARIO AND
                CONSECUTIVO_DIRECCION = V_CONSECUTIVO;
    END IF;

      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION(V_TABLA,MSERROR,GV_RADICADO,A_ID_USUARIO, 'FT_INSERTAR_DIRECCION');
            RETURN FLAG_ERROR;

  END FT_INSERTAR_DIRECCION;


/*
===============================================================================================================================
===============================================================================================================================

                            PROCEDIMIENTO PARA LAS ACTUALIZACIONES DE LOS PROPIETARIOS DEL VEHICULO

===============================================================================================================================
===============================================================================================================================
*/
  FUNCTION FT_ACTUALIZAR_PROPIETARIO(A_PLACA VARCHAR2, A_VENDEDOR VARCHAR2, A_COMPRADOR VARCHAR2, A_PORCENTAJE_PROPIEDAD NUMBER) RETURN BOOLEAN
  AS
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    --ACTUALIZO
    UPDATE QUIPUX.PROPIETARIOS_VEHICULO
    SET PORCENTAJE_PROP = A_PORCENTAJE_PROPIEDAD,
        ID_USUARIO = A_COMPRADOR
    WHERE NRO_PLACA = A_PLACA AND
          ID_USUARIO = A_VENDEDOR;

      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('PROPIETARIO_VEHICULO',MSERROR,GV_RADICADO,A_PLACA, 'FT_ACTUALIZAR_PROPIETARIO');
            RETURN FLAG_ERROR;
    
  END FT_ACTUALIZAR_PROPIETARIO;

/*
===============================================================================================================================
===============================================================================================================================

                    INICIA TODOS LOS PROCEDIMIENTOS DE ACTUALIZACION O REGISTRO DE LOS TRAMITES REPORTADOS

===============================================================================================================================
===============================================================================================================================
*/
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LAS CANCELACIONES E INSERTA EL TRAMITE*/
  FUNCTION FT_CANCELACION(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_TIPO_CANCELACION VARCHAR2) RETURN BOOLEAN
  AS
    V_TIPO_CANCELACION VARCHAR2(100 BYTE);
    V_EXISTE NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    --HAGO LA HOMOLOGACION DEL TIPO DE CANCELACION
    SQLTEXT := '';
    V_TIPO_CANCELACION := ''''||A_TIPO_CANCELACION||'''';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(55),'COUNT(1)','B.QX_TIPO_CANCELACION')||V_TIPO_CANCELACION;
    V_TIPO_CANCELACION := NULL;
    EXECUTE IMMEDIATE SQLTEXT INTO V_TIPO_CANCELACION;
      
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM QUIPUX.CANCELACIONES C
      WHERE C.NRO_PLACA = A_NRO_PLACA AND
            C.FECHA = TO_DATE(A_FECHA,'DD/MM/YYYY');
      
      --SI EL TRAMITE NO EXISTE LO INSERTO
      IF V_EXISTE = 0 THEN
        INSERT INTO QUIPUX.CANCELACIONES
                (NRO_PLACA,
                TIPO_CANCELACION,
                FECHA)
        VALUES (A_NRO_PLACA,
                V_TIPO_CANCELACION,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
                
        --ACTUALIZO EL ESTADO DEL VEHICULO
        UPDATE QUIPUX.LIC_TTO
        SET ID_ESTADO = 12,
            OBSERVACIONES = 'SE INACTIVA POR CANCELACION'
        WHERE NRO_PLACA = A_NRO_PLACA;
      END IF;

      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('CANCELACIONES',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_CANCELACION');
            RETURN FLAG_ERROR;

  END FT_CANCELACION;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS TRASLADOS E INSERTA EL TRAMITE*/
  FUNCTION FT_TRASLADO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_SECRETARIA_DESTINO NUMBER, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN
  AS
    V_ID_SECRETARIA NUMBER;
    V_ID_SECRETARIA_LIC_TTO NUMBER;
    V_EXISTE NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

    --VALIDO LA HOMOLOGACION DE LA SECRETARIA DESTINO
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(56),'COUNT(1)','A.ID_SECRETARIA')||A_SECRETARIA_DESTINO;
    EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SECRETARIA;       
    
    --VALIDO LA HOMOLOGACION DE LA SECRETARIA ORIGEN
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(56),'COUNT(1)','A.ID_SECRETARIA')||A_SECRETARIA_ORIGEN;
    EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SECRETARIA_LIC_TTO;
    
    --VERIFICO SI YA EXISTE EL TRAMITE
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM QUIPUX.TRASLADOS T
      WHERE T.NRO_PLACA = A_NRO_PLACA AND
            T.FECHA_TRASLADO >= TO_DATE(A_FECHA,'DD/MM/YYYY');
      
      --SI EL TRAMITE NO EXISTE LO INSERTO
      IF V_EXISTE = 0 THEN
        INSERT INTO QUIPUX.TRASLADOS
                (NRO_PLACA,
                ID_SECRETARIA,
                FECHA_TRASLADO)
        VALUES (A_NRO_PLACA,
                V_ID_SECRETARIA,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
        
        --ACTUALIZO EL ESTADO DEL VEHICULO
        UPDATE QUIPUX.LIC_TTO
        SET ID_ESTADO = 12,
            OBSERVACIONES = 'SE INACTIVA POR TRASLADO',
            ID_SECRETARIA = V_ID_SECRETARIA_LIC_TTO
        WHERE NRO_PLACA = A_NRO_PLACA;
      END IF;
    
      RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('TRASLADOS',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_TRASLADO');
            RETURN FLAG_ERROR;

  END FT_TRASLADO;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS RADICADOS E INSERTA EL TRAMITE*/
  FUNCTION FT_RADICADO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN
  AS
    V_ID_SECRETARIA NUMBER;
    V_EXISTE NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

    --VALIDO LA HOMOLOGACION DE LA SECRETARIA
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(57),'COUNT(1)','A.ID_SECRETARIA')||A_SECRETARIA_ORIGEN;
    EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SECRETARIA;       
      
      --VERIFICO SI YA EXISTE EL TRAMITE
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM RADICACIONES R
      WHERE R.NRO_PLACA = A_NRO_PLACA AND
            R.FECHA_RADICACION = TO_DATE(A_FECHA,'DD/MM/YYYY');
      
      --SI EL TRAMITE NO EXISTE LO INSERTO
      if V_EXISTE = 0 then
        INSERT INTO QUIPUX.RADICACIONES
                (NRO_PLACA,
                ID_SECRETARIA,
                FECHA_RADICACION)
        VALUES (A_NRO_PLACA,
                V_ID_SECRETARIA,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
      ELSE          
        --ACTUALIZO EL ESTADO DEL VEHICULO
        UPDATE QUIPUX.LIC_TTO
        SET ID_ESTADO = 1
        WHERE NRO_PLACA = A_NRO_PLACA;
      END IF;
    RETURN FLAG_ERROR;
 
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('RADICACIONES',MSERROR,GV_RADICADO,A_NRO_PLACA,'FT_RADICADO');
            RETURN FLAG_ERROR;
  END FT_RADICADO;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS CAMBIOS DE CARROCERIA E INSERTA EL TRAMITE*/
  FUNCTION FT_CAMBIO_CARROCERIA(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_CARROCERIA_ANTERIOR NUMBER, A_ID_CARROCERIA_NUEVA NUMBER, I_RADICADO NUMBER) RETURN BOOLEAN
  AS
    V_ID_CLASE NUMBER;
    SQLTEXT VARCHAR2(4000);
    V_ID_CARROCERIA_ANTERIOR NUMBER;
    V_ID_CARROCERIA_NUEVA NUMBER;
    V_EXISTE NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    --DEBO CONSULTAR LA CLASE DEL VEHICULO REPORTADA PARA PODER HACER LA HOMOLOGACION DE LA CARROCERIA
    BEGIN
      SELECT DSV.ID_CLASE
      INTO V_ID_CLASE
      FROM DEPURACION.DS_VEHICULO DSV
      WHERE DSV.NRO_PLACA = A_NRO_PLACA AND
            DSV.ID_RADICADO = I_RADICADO AND
            ROWNUM = 1;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_ID_CLASE := NULL;
    END;
    
    SELECT ID_CARROCERIA INTO V_ID_CARROCERIA_ANTERIOR FROM QUIPUX.LIC_TTO WHERE NRO_PLACA = A_NRO_PLACA;
     SQLTEXT := NULL;
    --VALIDO LA CARROCERIA NUEVA
     SQLTEXT := REPLACE(REPLACE(REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(11),'COUNT(1)','A.ID_CARROCERIA'),':VP',A_ID_CARROCERIA_NUEVA),':VS',V_ID_CLASE);
     EXECUTE IMMEDIATE SQLTEXT INTO V_ID_CARROCERIA_NUEVA;
      
    --VERIFICO SI YA EXISTE EL TRAMITE
    SELECT COUNT(1)
     INTO V_EXISTE
    FROM QUIPUX.CAMBIO_CARROCERIA CC
      WHERE CC.NRO_PLACA = A_NRO_PLACA AND
            CC.ID_CARROCERIA = V_ID_CARROCERIA_ANTERIOR AND
            CC.CARROCERIA_NUEVA = V_ID_CARROCERIA_NUEVA AND
            CC.FECHA = TO_DATE(A_FECHA,'DD/MM/YYYY');
      
    --SI EL TRAMITE NO EXISTE LO INSERTO
    IF V_EXISTE = 0 THEN
      INSERT INTO QUIPUX.CAMBIO_CARROCERIA
              (NRO_PLACA,
              ID_CARROCERIA,
              CARROCERIA_NUEVA,
              FECHA)
      VALUES (A_NRO_PLACA,
              V_ID_CARROCERIA_ANTERIOR,
              V_ID_CARROCERIA_NUEVA,
              TO_DATE(A_FECHA,'DD/MM/YYYY'));
    END IF;
    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('CAMBIO_CARROCERIA',MSERROR,GV_RADICADO,A_NRO_PLACA,'FT_CAMBIO_CARROCERIA');
            RETURN FLAG_ERROR;

  END FT_CAMBIO_CARROCERIA;

  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS CAMBIOS DE SERVICIO E INSERTA EL TRAMITE*/
  FUNCTION FT_CAMBIO_SERVICIO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_SERVICIO_ANTERIOR NUMBER, A_ID_SERVICIO_NUEVO NUMBER) RETURN BOOLEAN
  AS
    V_ID_SERVICIO_ANTERIOR NUMBER;
    V_ID_SERVICIO_NUEVO NUMBER;
    V_ESTADO NUMBER;
    V_EXISTE NUMBER;
    SQLTEXT VARCHAR2(4000 BYTE);
    FLAG_ERROR BOOLEAN := FALSE;    
  BEGIN

    --VALIDO EL SERVICIO ANTERIOR
    SELECT ID_SERVICIO
    INTO V_ID_SERVICIO_ANTERIOR
    FROM QUIPUX.LIC_TTO LT
    WHERE LT.NRO_PLACA = A_NRO_PLACA;
    --VALIDO LA SERVICIO NUEVA
    SQLTEXT := '';
    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(9),'COUNT(1)','A.ID_SERVICIO')||A_ID_SERVICIO_NUEVO;
    EXECUTE IMMEDIATE SQLTEXT INTO V_ID_SERVICIO_NUEVO;
    
    --VALIDO CAMPOS NECESARIOS PARA HACER EL INSERT
    IF A_NRO_PLACA IS NULL OR A_FECHA IS NULL OR V_ID_SERVICIO_ANTERIOR IS NULL OR V_ID_SERVICIO_NUEVO IS NULL THEN
        RETURN TRUE;
    END IF;
      
      --VERIFICO SI YA EXISTE EL TRAMITE
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM QUIPUX.CAMBIO_SERVICIO CS
      WHERE CS.NRO_PLACA = A_NRO_PLACA AND
            CS.ID_SERVICIO = V_ID_SERVICIO_ANTERIOR AND
            CS.SERVICIO_NUEVO = V_ID_SERVICIO_NUEVO AND
            CS.FECHA = TO_DATE(A_FECHA,'DD/MM/YYYY');
      
      --SI EL TRAMITE NO EXISTE LO INSERTO
      IF V_EXISTE = 0 THEN
        INSERT INTO QUIPUX.CAMBIO_SERVICIO
                (NRO_PLACA,
                ID_SERVICIO,
                SERVICIO_NUEVO,
                FECHA)
        VALUES (A_NRO_PLACA,
                V_ID_SERVICIO_ANTERIOR,
                V_ID_SERVICIO_NUEVO,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
                
        --ACTUALIZO EL ESTADO DEL VEHICULO DEACUERDO AL CAMBIO DE SERVICIO
        CASE V_ID_SERVICIO_NUEVO
          WHEN 1 THEN
            V_ESTADO := 1;            
          WHEN 2 THEN
            V_ESTADO := 12;
          WHEN 3 THEN
            V_ESTADO := 1;
          WHEN 4 THEN
            V_ESTADO := 12;
          ELSE
            V_ESTADO := 1;
        END CASE;
        
        UPDATE QUIPUX.LIC_TTO
        SET ID_ESTADO = V_ESTADO,
            ID_SERVICIO = V_ID_SERVICIO_NUEVO
        WHERE NRO_PLACA = A_NRO_PLACA;
    END IF;
    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('CAMBIO_SERVICIO',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_CAMBIO_SERVICIO');
            RETURN FLAG_ERROR;

  END FT_CAMBIO_SERVICIO;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS CAMBIOS DE MOTOR E INSERTA EL TRAMITE*/
  FUNCTION FT_CAMBIO_MOTOR(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_CILINDRAJE_NUEVO NUMBER, A_CAP_TONELADAS NUMBER, A_CAP_PASAJEROS NUMBER, I_RADICADO NUMBER, A_CAP_TONELADAS_ANTERIOR NUMBER, A_CAP_PASAJEROS_ANTERIOR NUMBER) RETURN BOOLEAN
  AS
    V_EXISTE NUMBER;   
    V_CILINDRAJE_ANTERIOR NUMBER;
    V_TIPO_VEHICULO NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
        
   --VERIFICO SI YA EXISTE EL TRAMITE
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM QUIPUX.CAMBIO_MOTOR CM
    WHERE CM.NRO_PLACA = A_NRO_PLACA AND
          CM.FECHA = TO_DATE(A_FECHA,'DD/MM/YYYY');
          
    BEGIN
      SELECT LV.CILINDRAJE
      INTO V_CILINDRAJE_ANTERIOR
      FROM DEPURACION.DS_LOG_VEHICULO_ACTUALIZADO LV
      WHERE LV.NRO_PLACA = A_NRO_PLACA AND
            LV.ID_RADICADO = GV_RADICADO AND
            LV.ID_REGISTRO_MODIFICADO IS NULL;
    EXCEPTION
    WHEN OTHERS THEN
      V_CILINDRAJE_ANTERIOR := NULL;
    END;
    
    --SI EL TRAMITE NO EXISTE LO INSERTO
    IF V_EXISTE = 0 THEN
      INSERT INTO QUIPUX.CAMBIO_MOTOR
              (NRO_PLACA,
              NUMERO_ANTERIOR,
              NUMERO_NUEVO,
              CC_ANTERIOR,
              CC_NUEVO,
              FECHA)
      VALUES (A_NRO_PLACA,
              '0',
              '0',
              V_CILINDRAJE_ANTERIOR,
              A_CILINDRAJE_NUEVO,
              TO_DATE(A_FECHA,'DD/MM/YYYY'));
              

    END IF;
    
    BEGIN
      SELECT TC.TIPO_VEHICULO
      INTO V_TIPO_VEHICULO
      FROM QUIPUX.QX_TIPO_CLASE TC
            INNER JOIN QUIPUX.CLASE_VEHICULOS CV
                    ON TC.ID_CLASE_QX = CV.ID_CLASE_QX
            INNER JOIN DEPURACION.DS_VEHICULO DV
                    ON DV.ID_CLASE = CV.ID_CLASE
      WHERE DV.NRO_PLACA = A_NRO_PLACA AND
            DV.ID_RADICADO = I_RADICADO;
    EXCEPTION
    WHEN OTHERS THEN
      V_TIPO_VEHICULO := NULL;
    END;
    
    IF V_TIPO_VEHICULO = 3 THEN
      INSERT INTO QUIPUX.CAMBIO_REAFORO
              (NRO_PLACA,
              ID_TRAMITE,
              REAFORO_ANTERIOR,
              REAFORO_NUEVO,
              FECHA)
      VALUES (A_NRO_PLACA,
              28,
              A_CAP_TONELADAS_ANTERIOR,
              A_CAP_TONELADAS/1000,
              TO_DATE(A_FECHA,'DD/MM/YYYY'));
    ELSIF V_TIPO_VEHICULO = 4 THEN
      INSERT INTO QUIPUX.CAMBIO_REAFORO
              (NRO_PLACA,
              ID_TRAMITE,
              REAFORO_ANTERIOR,
              REAFORO_NUEVO,
              FECHA)
      VALUES (A_NRO_PLACA,
              11,
              A_CAP_PASAJEROS_ANTERIOR,
              A_CAP_PASAJEROS,
              TO_DATE(A_FECHA,'DD/MM/YYYY'));
    END IF;

    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('CAMBIO_REAFORO O MOTOR',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_CAMBIO_MOTOR');
            RETURN FLAG_ERROR;

  END FT_CAMBIO_MOTOR;

  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LA REMATRICULA E INSERTA EL TRAMITE*/
  FUNCTION FT_REMATRICULA(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN
  AS
    V_EXISTE NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
      
      --VERIFICO SI YA EXISTE EL TRAMITE
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM REMATRICULAS R
      WHERE R.NRO_PLACA = A_NRO_PLACA AND
            R.FECHA >= TO_DATE(A_FECHA,'DD/MM/YYYY');
      
      --SI EL TRAMITE NO EXISTE LO INSERTO
      if V_EXISTE = 0 then
        INSERT INTO QUIPUX.REMATRICULAS
                (NRO_PLACA,
                FECHA)
        VALUES (A_NRO_PLACA,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
                
        --ACTUALIZO EL ESTADO DEL VEHICULO
        
        UPDATE QUIPUX.LIC_TTO
        SET ID_ESTADO = 1
        WHERE NRO_PLACA = A_NRO_PLACA;
      END IF;

    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('REMATRICULAS',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_REMATRICULA');
            RETURN FLAG_ERROR;

  END FT_REMATRICULA;

  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LOS TRASPSOS E INSERTA EL TRAMITE*/
  FUNCTION FT_TRASPASO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_ID_USUARIO_ANTERIOR VARCHAR2, A_ID_USUARIO_NUEVO VARCHAR2, A_PORCENTAJE_PROP VARCHAR2) RETURN BOOLEAN
  AS
    V_EXISTE NUMBER;
    V_PORCENTAJE_PROPIEDAD NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN

  FLAG_ERROR := FT_ACTUALIZAR_PROPIETARIO(A_NRO_PLACA, A_ID_USUARIO_ANTERIOR, A_ID_USUARIO_NUEVO, A_PORCENTAJE_PROP);
  --VERIFICO SI YA EXISTE EL TRAMITE
  SELECT COUNT(1)
    INTO V_EXISTE
  FROM QUIPUX.HISTORIALES_TRASPASOS HT
     WHERE HT.NRO_PLACA = A_NRO_PLACA AND
            HT.ID_USUARIO = A_ID_USUARIO_ANTERIOR AND
            HT.ID_COMPRADOR = A_ID_USUARIO_NUEVO AND
            TO_DATE(TO_CHAR(HT.FECHA,'DD/MM/YYYY'),'DD/MM/YYYY') = TO_DATE(A_FECHA,'DD/MM/YYYY');
      
   --SI EL TRAMITE NO EXISTE LO INSERTO
   if V_EXISTE = 0 then
        INSERT INTO QUIPUX.HISTORIALES_TRASPASOS
                (NRO_PLACA,
                ID_USUARIO,
                ID_COMPRADOR,
                PORCENTAJE,
                FECHA)
        VALUES (A_NRO_PLACA,
                A_ID_USUARIO_ANTERIOR,
                A_ID_USUARIO_NUEVO,
                A_PORCENTAJE_PROP,
                TO_DATE(A_FECHA,'DD/MM/YYYY'));
                
    END IF;
    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('HISTORIAL_TRASPASO',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_TRASPASO');
            RETURN FLAG_ERROR;
  END FT_TRASPASO;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LA MATRICULA INICIAL E INSERTA EL TRAMITE*/
  FUNCTION FT_MATRICULA_INICIAL(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN
  AS
    V_EXISTE NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    --VERIFICO SI YA EXISTE EL TRAMITE
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM QUIPUX.MATRICULAS_INICIALES MI
    WHERE MI.NRO_PLACA = A_NRO_PLACA AND
          MI.FECHA_MATRICULA = TO_DATE(A_FECHA,'DD/MM/YYYY');
    
    --SI EL TRAMITE NO EXISTE LO INSERTO
    if V_EXISTE = 0 then
      INSERT INTO QUIPUX.MATRICULAS_INICIALES
              (NRO_PLACA,
              FECHA_MATRICULA)
      VALUES (A_NRO_PLACA,
              TO_DATE(A_FECHA,'DD/MM/YYYY'));
              
          --ACTUALIZO EL ESTADO DEL VEHICULO  
          UPDATE QUIPUX.LIC_TTO
          SET ID_ESTADO = 1
          WHERE NRO_PLACA = A_NRO_PLACA;
    END IF;
    RETURN FLAG_ERROR;
  EXCEPTION 
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('MATRICULAS_INICIALES',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_MATRICULA_INICIAL');
            RETURN FLAG_ERROR;
  END FT_MATRICULA_INICIAL;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DE LA MATRICULA INICIAL E INSERTA EL TRAMITE*/
  FUNCTION FT_BLINDADO_DESBLINDADO(A_TRAMITE NUMBER, A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2, A_BLINDAJE VARCHAR2) RETURN BOOLEAN
  AS
    V_EXISTE NUMBER;
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
    
    --VERIFICO SI YA EXISTE EL TRAMITE
    IF ( A_TRAMITE = 1 ) THEN
        SELECT COUNT(1)
          INTO V_EXISTE
        FROM QUIPUX.BLINDADOS B
          WHERE B.NRO_PLACA = A_NRO_PLACA;
    
        --SI EL TRAMITE NO EXISTE LO INSERTO
        IF V_EXISTE = 0 THEN
          INSERT INTO QUIPUX.BLINDADOS
                  (NRO_PLACA,
                   DESCRIPCION,
                  FECHA)
          VALUES (A_NRO_PLACA,
                  A_BLINDAJE,
                  TO_DATE(A_FECHA,'DD/MM/YYYY'));
        ELSE
          UPDATE QUIPUX.BLINDADOS
          SET DESCRIPCION = A_BLINDAJE,
              FECHA = TO_DATE(A_FECHA,'DD/MM/YYYY')
          WHERE NRO_PLACA = A_NRO_PLACA;
        END IF;   
    ELSE
    
        UPDATE QUIPUX.BLINDADOS SET FECHA_DESBLINDAJE = TO_DATE(A_FECHA,'DD/MM/YYYY')
         WHERE (NRO_PLACA, FECHA) IN (SELECT NRO_PLACA, MAX(FECHA) FROM QUIPUX.BLINDADOS B
                                            WHERE B.NRO_PLACA = A_NRO_PLACA AND ROWNUM = 1 GROUP BY NRO_PLACA );
        
    END IF;
    RETURN FLAG_ERROR;
  EXCEPTION
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('BLINDADOS',MSERROR,GV_RADICADO,A_NRO_PLACA, 'FT_BLINDADO_DESBLINDADO');
            RETURN FLAG_ERROR;
  END FT_BLINDADO_DESBLINDADO;
  
  /****************************************************************************/
  /*ESTE PROCESO VALIDA LA INFORMACION DEL TRAMITE DE CLASICO ANTIGUO PARA ACTUALIZAR EN LIC_TTO*/
  FUNCTION FT_CLASICO_ANTIGUO(A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2)  RETURN BOOLEAN
  AS
    SQLTEXT VARCHAR2(4000);
    FLAG_ERROR BOOLEAN := FALSE;
  BEGIN
        
    --ACTUALIZO LA FECHA DEL TRAMITE EN LIC_TTO
    UPDATE QUIPUX.LIC_TTO
    SET FECHA_CLA_ANT = TO_DATE(A_FECHA,'DDMMYYYY')
    WHERE NRO_PLACA = A_NRO_PLACA;

    RETURN FLAG_ERROR;
    
  EXCEPTION
    WHEN OTHERS THEN
            MSERROR := SQLERRM;
            FLAG_ERROR := FT_LOG_ACTUALIZACION('CLASICO_ANTIGUO',MSERROR,GV_RADICADO,A_NRO_PLACA,'FT_CLASICO_ANTIGUO');
            RETURN FLAG_ERROR;
  END FT_CLASICO_ANTIGUO;

 FUNCTION FT_LOG_ACTUALIZACION(TABLA VARCHAR2, M_ERROR VARCHAR2, A_RADICADO NUMBER, IDENTIFICADOR VARCHAR2, A_FUNCION VARCHAR2) RETURN BOOLEAN
AS
       V_SEQ_LOG NUMBER;
       --PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
      ROLLBACK;
      V_SEQ_LOG := DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL;
      INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS 
                    VALUES(V_SEQ_LOG,TABLA,A_RADICADO,NVL(IDENTIFICADOR,'DATO NULO'),'Error en la funcion '||A_FUNCION||' del paquete de actualizaci�n -- '||M_ERROR, 3);      
      COMMIT;
      RETURN TRUE;      
END;


END PKG_DS_ACTUALIZACION_REGISTROS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_CARGA_ARCHIVOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_CARGA_ARCHIVOS" AS

/*
  PAQUETE PARA DISTRIBUIR LOS ARCHIVOS CARGADOS POR MEDIO DEL SQL*LOADER EN EVENTOS INVOCADOS POR LA APLICACI�N
  DESDE ARCHVIOS EJECUTABLES .BAT
*/

  PROCEDURE SP_DISTRIBUCION_REGISTROS(NRORADICADO NUMBER, PROCESO NUMBER) AS

  -- CURSOR PARA EL CARGUE INICIAL Y VALIDACION DE VEHICULOS REPETIDOS EN UNA CORRECCION CARGADA.
  CURSOR CVEHICULOS
      IS
         SELECT * FROM DEPURACION.DS_TMP_VEHICULOS TMV
                WHERE NOT EXISTS (SELECT 1 FROM DEPURACION.DS_VEHICULO VEH
                                          WHERE VEH.NRO_PLACA = TMV.NRO_PLACA
                                            AND VEH.ID_RADICADO = NRORADICADO);
  
  -- CURSOR PARA EL CARGUE INICIAL Y VALIDACION DE PROPIETARIOS REPETIDOS EN UNA CORRECCION CARGADA.
  CURSOR CPROPIETARIOS
      IS
         SELECT * FROM DEPURACION.DS_TMP_PROPIETARIOS TMP
                WHERE NOT EXISTS ( SELECT 1 FROM DEPURACION.DS_PROPIETARIO PRO
                                           WHERE (PRO.NRO_PLACA = TMP.NRO_PLACA
                                             AND (PRO.ID_DOCUMENTO||PRO.ID_USUARIO) = (TMP.ID_DOCUMENTO||TMP.ID_USUARIO))
                                             AND PRO.ID_RADICADO = NRORADICADO);
                                             
  -- CURSOR PARA EL CARGUE INICIAL Y VALIDACION DE CONTRIBUYENTES REPETIDOS EN UNA CORRECCION CARGADA.
  -- RECUPERA LOS REGISTROS DE CONTRIBUYENTES QUE TIENEN LA DIRECCION MAXIMA 
  CURSOR CCONTRIBUYENTES IS
         SELECT * FROM DEPURACION.DS_TMP_CONTRIBUYENTES TMC
              WHERE EXISTS ( SELECT 1 FROM ( 
                        ( SELECT ID_DOCUMENTO, ID_USUARIO, MAX(TO_NUMBER(ID_DIRECCION))  AS DIRECCION 
                              FROM DEPURACION.DS_TMP_CONTRIBUYENTES CON
                          GROUP BY ID_DOCUMENTO, ID_USUARIO )
                      ) DIRMAX WHERE (TMC.ID_DOCUMENTO = DIRMAX.ID_DOCUMENTO AND 
                                   TMC.ID_USUARIO = DIRMAX.ID_USUARIO AND
                                   TMC.ID_DIRECCION = DIRMAX.DIRECCION ));
        
  
  -- CURSOR PARA EL CARGUE INICIAL TRAMITES DIFERENTES A TRASPASOS 
  --Y VALIDACION DE TRAMITES REPETIDOS EN UNA CORRECCION CARGADA.         
  CURSOR CTRAMITES
      IS
         SELECT * FROM DEPURACION.DS_TMP_TRAMITES TMT
                 WHERE NOT EXISTS (SELECT * FROM DEPURACION.DS_TRAMITE TRA
                                         WHERE TRA.NRO_PLACA = TMT.NRO_PLACA
                                           AND TRA.ID_TRAMITE = TMT.ID_TRAMITE
                                           AND TRA.ID_RADICADO = NRORADICADO
                                           AND TRA.ID_tRAMITE <> 16)
                    AND TMT.ID_TRAMITE <> 16
      UNION ALL
        SELECT * FROM DEPURACION.DS_TMP_TRAMITES TMT
                    WHERE (TMT.NRO_PLACA, TO_DATE(TMT.FECHA_TRAMITE,'DD/MM/YYYY')) IN (
                                                SELECT TTR.NRO_PLACA, MAX(TO_DATE(TTR.FECHA_TRAMITE,'DD/MM/YYYY'))
                                                                        FROM DEPURACION.DS_TMP_TRAMITES TTR
                                                            WHERE TTR.ID_TRAMITE = 16
                                                GROUP BY TTR.NRO_PLACA)
                        AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_TRAMITE DTR
                                                                      WHERE DTR.NRO_PLACA = TMT.NRO_PLACA
                                                                                      AND DTR.ID_TRAMITE = TMT.ID_TRAMITE
                                                                                      AND DTR.ID_RADICADO = NRORADICADO
                                                                                      AND DTR.ID_TRAMITE = 16)
                       AND ID_TRAMITE = 16;        
                    
  -- VALIDACION DE TRAMITES DUPLICADOS EN UNA CORRECCION CARGADA.       
  CURSOR CTRAMITRES_TRASPASO
    IS
      SELECT * FROM DEPURACION.DS_TMP_TRAMITES TMT
              WHERE (TMT.NRO_PLACA, TO_DATE(TMT.FECHA_TRAMITE,'DD/MM/YYYY')) NOT IN (
                                          SELECT TTR.NRO_PLACA, MAX(TO_DATE(TTR.FECHA_TRAMITE,'DD/MM/YYYY'))
                                                                  FROM DEPURACION.DS_TMP_TRAMITES TTR
                                                      WHERE TTR.ID_TRAMITE = 16
                                          GROUP BY TTR.NRO_PLACA)
                 AND TMT.ID_TRAMITE = 16;


  -- CURSOR PRINCIPAL PARA EL INICIO DE EJECUCION DE LOS ARCHIVOS
  CURSOR VREGISTROS
      IS
        SELECT * FROM DEPURACION.DS_TIPO_REGISTRO
           WHERE ACTIVO = 'S';
               
         
  VNRO_RADICADO           NUMBER :=0; -- RADICADO
  VSEQ_REGISTRO           NUMBER :=0; -- SECUENCIA DE REGISTRO
  CONTADOR                    NUMBER :=0; -- CONTADOR PARA COMMIT DE REGISTROS
  VALIDACARGUE             NUMBER :=0; -- SI ES 4 PERMITE ES EL ESTADO DEL LOTE SI ES 1 NO PERMITE
  TRLEIDOS                      NUMBER :=0; -- TOTAL DE REGISTROS "PLACAS VEHICULOS" LEIDAS TOTAL DEL LOTE REAL.
  TRCARGADOS               NUMBER :=0; -- VARIABLE PARA REUTILIZAR EN CORRECCIONES DE CARGUE DE REGISTROS.
	TRREGISTROS              NUMBER :=0; -- VARIABLE PARA REUTILIZAR EN LA SUMA DE LOS TOTALES POR CADA REGISTRO.
  TRVEH                          NUMBER :=0; --  TOTAL VEHICULOS
  TRPRO                          NUMBER :=0; -- TOTAL PROPIETARIOS
  TRCON                          NUMBER :=0; -- TOTAL CONTRIBUYENTES
  TRTRA                          NUMBER :=0; -- TOTAL TRAMITES
  SWERROR                    NUMBER :=0; -- FLAG DE ERROR GLOBAL DE CARGUE INDICA UNA CORRECCION DE ARCHIVO
  PERMITECARGUE         NUMBER :=0; -- VARIABLE DE PORCENTAJE SI PERMITE EL CARGUE SIN HABER TERMINADO EL PROCESO DE UN LOTE ACTUAL 
	VERROR                       NUMBER :=0; -- FLAG DE ERROR INTERNO POR CADA CARGUE DE REGISTRO. NVL PARA ESTABLECER ESTADO DEL REGISTRO	
	
	VESTADO                     VARCHAR2( 1 BYTE); -- GUARDA EL ESTADO DEL LOTE 'S','E','N'
  MSERROR                    VARCHAR2(4000); -- GUARDA EL MENSAJE DE ERROR GENERADO POR EL RESTRICCION DE ORACLE EN UNA EJECUCION PRODUCTIVA.
  DATOPRIMARIO            VARCHAR2(4000); -- GUARDA LAS CLAVES PRIMARIAS DE LOS DATOS ERRONEOS POR RESTRICCION DE ORACLE
	  
  ERROR_CARGUE         EXCEPTION; -- CONTROL MANUAL DE EXCEPCION DE CARGUE POR ESTRUCTURAS ERRONEAS
  PORCENTAJE_ENV      NUMBER := 0; -- PORCENTAJE PARAMETRIZADO EN BASE DE DATOS
	CALCULO_PORCEN      NUMBER := 0; -- CALCULO DEL PORCENTAJE LLEVADO DEL LOTE DE ACTUAL PARA PERMITIR UN NUEVO CARGUE.
  VEXISTE                      NUMBER := 0; -- 
  VPORCEPROPIE           NUMBER := 0;
  VNRO_IDENTIFICADOR  NUMBER :=0;
  
  V_PORC_PROP             NUMBER := 0;--  VARIABLE PARA CONTROLAR EL PORCENTAJE DE PROPIEDAD
  V_CONT_PROP             NUMBER := 0;
  V_CONT_TRAM             NUMBER := 0;
  
  V_ID_USUARIO                    VARCHAR2(30);
  V_ID_USUARIO_ANTERIOR  varchar2(30);
  V_ID_USUARIO_NUEVO       VARCHAR2(30);
  V_IDDIRECCION                    number := 0; --VARIABLE ID_DIRECCION MAXIMA BUENA EN EL CURSOR DE CONTRIBUYENTES
  
  V_CONT_DIR_NOT_NULL NUMBER;

  BEGIN
     -- EXECUTE IMMEDIATE 'alter system flush buffer_cache'; -- Vaciar las areas de memoria SGA, Shared Pool y Buffer Cache
      -- GUARDAR PARAMETRO DE PORCENTAJE PERMITIDO PARA UN NUEVO CARGUE
      SELECT VALOR INTO PORCENTAJE_ENV FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO 
        WHERE ID_PROCESO = 60 AND ID_PARAMETRO = 6;      
      
      -- SI SE PERMITE EL CARGUE DE UN NUEVO LOTE CUANDO NO SE ENCUENTRE UNO EN PROCESO DE VALIDACION. 
      SELECT COUNT(1) INTO PERMITECARGUE
            FROM DEPURACION.DS_MAESTRO
              WHERE ID_ESTADO_DEPURACION = 1
                AND ACTIVO = 'S';
			
      -- VALIDACION LOTE ACTIVO.
			IF (PERMITECARGUE > 0 ) THEN
			    SELECT COUNT(1) INTO CALCULO_PORCEN FROM DEPURACION.DS_MAESTRO DM
							INNER JOIN DEPURACION.DS_INFORME_REGISTROS DIF ON DIF.ID_RADICADO = DM.ID_RADICADO
              WHERE DM.ID_ESTADO_DEPURACION = 1 AND DM.ACTIVO = 'S';
					IF ( CALCULO_PORCEN = 0 ) THEN
							 PERMITECARGUE := 0;
					ELSE
								SELECT ROUND(((SUM(TOTAL_ALERTAS)+SUM(TOTAL_CORRECTAS))/SUM(TOTAL_REGISTROS))*100) INTO CALCULO_PORCEN 
									FROM DEPURACION.DS_MAESTRO DM
							INNER JOIN DEPURACION.DS_INFORME_REGISTROS DIF ON DIF.ID_RADICADO = DM.ID_RADICADO
              WHERE DM.ID_ESTADO_DEPURACION = 1 AND DM.ACTIVO = 'S';
				  END IF;
			END IF;
				 
      VNRO_RADICADO := NRORADICADO;
      
      -- INICIO DEL CARGUE DE ACUERDO A CARGA INICIAL O POR PORCENTAJE DE CARGUE.   
			IF ( PERMITECARGUE = 0 OR CALCULO_PORCEN > PORCENTAJE_ENV) THEN
                -- VALIDACION PARA NO DUPLICAR CARGUES
              SELECT ID_ESTADO_DEPURACION, ACTIVO INTO VALIDACARGUE , VESTADO
                    FROM DEPURACION.DS_MAESTRO 
                        WHERE ID_RADICADO = VNRO_RADICADO;
                        
              IF ( VALIDACARGUE = 4 ) THEN   -- CARGA INICIAL      
                    IF ( PROCESO = 0 ) THEN  -- NO ES UNA CORRECCION DE DATOS DEL CARGUE INICIAL
                        DELETE DEPURACION.DS_INFORME_REGISTROS WHERE ID_RADICADO = VNRO_RADICADO;
                        DELETE DEPURACION.DS_INFORME_LOTE WHERE ID_RADICADO = VNRO_RADICADO;   
                        SELECT COUNT(1) INTO TRVEH FROM DEPURACION.DS_TMP_VEHICULOS;      -- TOTALIZAR VEHICULOS A DISTRIBUIR
                        SELECT COUNT(1) INTO TRPRO FROM DEPURACION.DS_TMP_PROPIETARIOS;   -- TOTALIZAR PROPIETARIOS A DISTRIBUIR
                        SELECT COUNT(1) INTO TRCON FROM DEPURACION.DS_TMP_CONTRIBUYENTES; -- TOTALIZAR CONTRIBUYENTES A DISTRIBUIR
                        SELECT COUNT(1) INTO TRTRA FROM DEPURACION.DS_TMP_TRAMITES;       -- TOTALIZAR TRAMITES A DISTRIBUIR
                        TRLEIDOS := TRVEH;-- + TRPRO + TRCON + TRTRA;
                        -- INSERCCION EN LAS TABLAS DE INFORME LOTE Y REGISTROS. VALORES INCIALES
                        INSERT INTO DEPURACION.DS_INFORME_LOTE VALUES(VNRO_RADICADO,TRLEIDOS,0,0,0,0,0); 
                        INSERT INTO DEPURACION.DS_INFORME_REGISTROS VALUES (VNRO_RADICADO, 1, TRVEH, 0, 0, 0, 0, 0, 0, 'E');
                        INSERT INTO DEPURACION.DS_INFORME_REGISTROS VALUES (VNRO_RADICADO, 2, TRCON, 0, 0, 0, 0, 0, 0, 'E');
                        INSERT INTO DEPURACION.DS_INFORME_REGISTROS VALUES (VNRO_RADICADO, 3, TRPRO, 0, 0, 0, 0, 0, 0, 'E');      
                        INSERT INTO DEPURACION.DS_INFORME_REGISTROS VALUES (VNRO_RADICADO, 4, TRTRA, 0, 0, 0, 0, 0, 0, 'E');
                        COMMIT;                    
										ELSE
                        -- CUANDO ES CORRECCION SE TOTALIZAN NUEVAMENTE LOS REGISTROS CARGADOS Y SI ES SUPERIOR EL CARGUE SE ACTUALIZAN LOS TOTALES REGISTRADOS INICIALMENTE
                        -- DE LO CONTRARIO SOLO SE ACTUALIZA EN LA DISTRIBUCCI�N DE REGISTROS.
                        SELECT COUNT(1) INTO TRVEH FROM DEPURACION.DS_TMP_VEHICULOS;
                        SELECT COUNT(1) INTO TRPRO FROM DEPURACION.DS_TMP_PROPIETARIOS;
                        SELECT COUNT(1) INTO TRCON FROM DEPURACION.DS_TMP_CONTRIBUYENTES;
                        SELECT COUNT(1) INTO TRTRA FROM DEPURACION.DS_TMP_TRAMITES;
												TRLEIDOS := TRVEH;-- + TRPRO + TRCON + TRTRA;
												SELECT TOTAL_REGISTROS INTO TRREGISTROS FROM DEPURACION.DS_INFORME_REGISTROS WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;
                          CASE PROCESO
															 WHEN 1 THEN
                                    IF ( TRREGISTROS < TRVEH ) THEN
                                      UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_REGISTROS = TRVEH WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;
                                    END IF;
															 WHEN 2 THEN
                                    IF ( TRREGISTROS < TRCON ) THEN
                                      UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_REGISTROS = TRCON WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;
                                    END IF;
															 WHEN 3 THEN
                                    IF ( TRREGISTROS < TRPRO ) THEN
                                      UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_REGISTROS = TRPRO WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;
                                    END IF;
															 WHEN 4 THEN
                                    IF ( TRREGISTROS < TRTRA ) THEN
                                      UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_REGISTROS = TRTRA WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;
                                    END IF;
															 ELSE
																	 NULL;
														END CASE;
												COMMIT;
                    END IF;

                    -- CONTROL DEL PROCESO DE ERROR DE ESTRUCTURAS ERRONEAS O CARGUES NULOS.
                    IF (PROCESO = 0 AND TRLEIDOS = 0 ) THEN
                        RAISE ERROR_CARGUE;
                    END IF;

                    -- DISTRIBUCION DEL ARCHIVO DS_VEHICULO                      
                    IF ( PROCESO = 1 OR PROCESO = 0 ) THEN
                        CONTADOR := 0;
                        TRVEH := 0;
												VERROR := 0;
                        FOR XV IN CVEHICULOS LOOP
                            BEGIN
                                DATOPRIMARIO := XV.NRO_PLACA;
                                INSERT INTO DEPURACION.DS_VEHICULO VALUES (DEPURACION.SEQ_DS_VEHICULO_ID_VEHICULO.NEXTVAL, VNRO_RADICADO, DATOPRIMARIO,	TRIM(XV.ID_MARCA),	TRIM(XV.NOMBRE_MARCA),	TRIM(XV.ID_LINEA),	TRIM(XV.NOMBRE_LINEA),	TRIM(XV.MODELO),	TRIM(XV.ID_CLASE),	TRIM(XV.NOMBRE_CLASE),	TRIM(XV.ID_SERVICIO),	TRIM(XV.NOMBRE_SERVICIO),	TRIM(XV.ID_CARROCERIA),	TRIM(XV.NOMBRE_CARROCERIA),	TRIM(XV.NRO_PUERTAS),	TRIM(XV.ID_COMBUSTIBLE),	TRIM(XV.NOMBRE_COMBUSTIBLE),	TRIM(XV.ID_BATERIA),	TRIM(XV.NOMBRE_BATERIA),	TRIM(XV.POTENCIA),	TRIM(XV.ID_SECRETARIA),	TRIM(XV.NOMBRE_SECRETARIA),	TRIM(XV.CILINDRAJE),	TRIM(XV.CAP_PASAJEROS),	TRIM(XV.CAP_TONELADAS),	TRIM(XV.VALOR_FACTURA),	TRIM(XV.BLINDADO),	TRIM(XV.IMPORTADO_NACIONAL),	TRIM(XV.ID_ESTADO),	TRIM(XV.NOMBRE_ESTADO),	TRIM(XV.CLASICO_ANTIGUO),	TRIM(TO_DATE(XV.FECHA_MATRICULO,'DD/MM/YYYY')), 'VP', 'N');
                                UPDATE QUIPUX.LIC_TTO
                                SET ID_LINEA_RUNT = TRIM(XV.ID_LINEA),
                                    NOMBRE_LINEA_RUNT = TRIM(XV.NOMBRE_LINEA)
                                WHERE NRO_PLACA = XV.NRO_PLACA;
                                IF (CONTADOR = 500 ) THEN
                                    COMMIT;
                                    CONTADOR := 0;
                                ELSE
                                  CONTADOR := CONTADOR + 1;
                                END IF;
                                TRVEH := TRVEH + 1;
                            EXCEPTION
                              WHEN OTHERS THEN
                                   MSERROR := ':';
                                   MSERROR := MSERROR || FT_VALIDAR_ESTRUCTURA(1, XV, NULL, NULL, NULL);
                                   INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                       VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_VEHICULOS',VNRO_RADICADO,NVL(XV.NRO_PLACA,'PLACA NULA'),MSERROR, 1);
                                   UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                                          WHERE ID_RADICADO = VNRO_RADICADO
                                            AND ID_TIPO_ARCHIVO = 1;                               
                                   COMMIT;
                                   SWERROR := 1;
																	 VERROR := 1;
                            END;
                        END LOOP;
                        --- ACTUALIZO CUANDO EL ARCHIVO ESTA COMPLETAMENTE CARGADO
                        IF (TRVEH = 0 ) THEN
														UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRVEH, ACTIVO = 'E'
																	 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 1;
                            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                   VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_VEHICULOS',VNRO_RADICADO,0,'ERROR EN DISTRIBUCI�N: NO HAY DATOS CARGADOS PARA EL ARCHIVO POR INCONSISTENCIAS.', 1);
														COMMIT;
												ELSE
														UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRVEH, ACTIVO = DECODE(VERROR,1,'E','S')
																	 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 1;                           												
                            COMMIT;
												END IF;
                    END IF;          
                    
                    -- DISTRIBUCION DEL ARCHIVO DS_PROPIETARIO
                    IF ( PROCESO = 3 OR PROCESO = 0 ) THEN                
                        CONTADOR  := 0;
                        TRPRO     := 0;
                        DATOPRIMARIO := 0;
												VERROR := 0;
                        FOR XP IN CPROPIETARIOS LOOP
                            BEGIN                   
                                V_PORC_PROP := TRIM(XP.PORCENTAJE_PROP);
                                IF V_PORC_PROP IS NULL OR V_PORC_PROP = 0 THEN
                                  SELECT COUNT(1) 
                                  INTO V_CONT_PROP
                                  FROM DEPURACION.DS_TMP_PROPIETARIOS TMP
                                  WHERE TMP.NRO_PLACA = XP.NRO_PLACA;
                                  
                                  IF V_CONT_PROP = 1 THEN
                                    V_PORC_PROP := 100;
                                  END IF;
                                END IF;
                                
                                V_ID_USUARIO := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XP.ID_USUARIO), TRIM(XP.ID_DOCUMENTO));

																DATOPRIMARIO := TRIM(XP.ID_DOCUMENTO)||' - '||V_ID_USUARIO;
                                INSERT INTO DEPURACION.DS_PROPIETARIO VALUES (DEPURACION.SEQ_DS_PROPIETARI_ID_PROPIETAR.NEXTVAL, VNRO_RADICADO, XP.NRO_PLACA ,V_ID_USUARIO , XP.ID_DOCUMENTO, V_PORC_PROP ,'VP' ,'N');
                                IF (CONTADOR = 500 ) THEN
                                    COMMIT;
                                    CONTADOR := 0;
                                ELSE
                                    CONTADOR := CONTADOR + 1;
                                END IF;
                                TRPRO := TRPRO + 1;
                            EXCEPTION
                              WHEN OTHERS THEN
                                   MSERROR := ':';
                                   MSERROR := MSERROR || FT_VALIDAR_ESTRUCTURA(3, NULL, NULL, XP, NULL);
                                   INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                       VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_PROPIETARIOS',VNRO_RADICADO,DATOPRIMARIO ,MSERROR, 1);                  
                                   UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                                          WHERE ID_RADICADO = VNRO_RADICADO
                                            AND ID_TIPO_ARCHIVO = 3;                               
                                   COMMIT;
                                   SWERROR := 1;
																	 VERROR := 1;
                            END;
                        END LOOP;                        
                        -- ACTUALIZAR REGISTROS CORRECTOS EN INFORME DE PROPIETARIOS
												IF (TRPRO = 0 ) THEN
														UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRPRO, ACTIVO = 'E'
																	 WHERE ID_RADICADO = VNRO_RADICADO  AND ID_TIPO_ARCHIVO = 3;
                            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                   VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_PROPIETARIOS',VNRO_RADICADO,0,'ERROR EN DISTRIBUCI�N: NO HAY DATOS CARGADOS PARA EL ARCHIVO POR INCONSISTENCIAS.', 1 );
														COMMIT;
												ELSE
														UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRPRO, ACTIVO = DECODE(VERROR,1,'E','S')
																	 WHERE ID_RADICADO = VNRO_RADICADO  AND ID_TIPO_ARCHIVO = 3;                         
														COMMIT;
												END IF;
                    END IF;
                    
                    -- DISTRIBUCION DEL ARCHIVO DS_CONTRIBUYENTES 
                    IF ( PROCESO = 2 OR PROCESO = 0 ) THEN                
                        CONTADOR := 0;
                        DATOPRIMARIO := 0;
                        TRCON := 0;
						            VERROR := 0;
                      
                         FOR XC IN CCONTRIBUYENTES LOOP
                                begin
                                    V_CONT_DIR_NOT_NULL := 0;
                                    V_ID_USUARIO := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XC.ID_USUARIO), TRIM(XC.ID_DOCUMENTO));                                
                                    DATOPRIMARIO := TRIM(XC.ID_DOCUMENTO)||'-'||V_ID_USUARIO;
                                    if ( TRIM(XC.TELEFONO) is null or TRIM(XC.DIRECCION) is null or TRIM(XC.ID_CIUDAD_DIR) is null) then
                                    
                                            select COUNT(1)
                                            INTO V_CONT_DIR_NOT_NULL
                                            from DEPURACION.DS_TMP_CONTRIBUYENTES
                                            where ID_USUARIO = XC.ID_USUARIO and
                                                  ID_DOCUMENTO = XC.ID_DOCUMENTO and 
                                                  TELEFONO is not null and 
                                                  DIRECCION is not null and 
                                                  ID_CIUDAD_DIR is not null and 
                                                  ID_DIRECCION not in (XC.ID_DIRECCION);
                                                  
                                            IF V_CONT_DIR_NOT_NULL > 0 THEN
                                    
                                                                 FOR ACTDIR IN (SELECT * FROM DEPURACION.DS_TMP_CONTRIBUYENTES
                                                                                             WHERE ID_USUARIO = XC.ID_USUARIO AND ID_DOCUMENTO = XC.ID_DOCUMENTO
                                                                                                  AND ID_DIRECCION = (SELECT MAX(ID_DIRECCION) FROM DEPURACION.DS_TMP_CONTRIBUYENTES
                                                                                                                                                    WHERE ID_USUARIO = XC.ID_USUARIO AND ID_DOCUMENTO = XC.ID_DOCUMENTO
                                                                                                                                                                                 AND TELEFONO IS NOT NULL
                                                                                                                                                                                 AND DIRECCION IS NOT NULL
                                                                                                                                                                                 AND ID_CIUDAD_DIR IS NOT NULL
                                                                                                                                                                                 AND ID_DIRECCION NOT IN (XC.ID_DIRECCION))) LOOP
                                                                                insert into DEPURACION.DS_CONTRIBUYENTE values (DEPURACION.SEQ_DS_CONTRIBUYE_ID_CONTRIBUY.NEXTVAL, VNRO_RADICADO, V_ID_USUARIO, TRIM(ACTDIR.ID_DOCUMENTO),	TRIM(ACTDIR.ID_CIUDAD),	TRIM(ACTDIR.NOMBRE_CIUDAD),	TRIM(ACTDIR.APELLIDOS),	TRIM(ACTDIR.NOMBRES),	NVL(TRIM(ACTDIR.DIRECCION),'NO REPORTA RUNT'),	TRIM(ACTDIR.TELEFONO),	TRIM(ACTDIR.EMP_O_PART),	TRIM(ACTDIR.SEXO),	TRIM(ACTDIR.FECHA_NACIMIENTO),	TRIM(ACTDIR.ID_PAIS),	TRIM(ACTDIR.NOMBRE_PAIS),	TRIM(ACTDIR.FECHA_MODIFICACION),	TRIM(ACTDIR.FAX),	TRIM(ACTDIR.EMAIL), NVL(TRIM(ACTDIR.FECHA_ACTUALIZACION), TO_CHAR(sysdate,'DDMMYYYY')),TO_NUMBER(ACTDIR.ID_CIUDAD_DIR), TRIM(ACTDIR.NOMBRE_CIUDAD_DIR), TO_NUMBER(ACTDIR.ID_DIRECCION), 'VP', 'N');
                                                                                V_IDDIRECCION := ACTDIR.ID_DIRECCION;
                                                                  end LOOP;
                                            else
                                              
                                                  INSERT INTO DEPURACION.DS_CONTRIBUYENTE 
                                                            values (DEPURACION.SEQ_DS_CONTRIBUYE_ID_CONTRIBUY.NEXTVAL, VNRO_RADICADO, V_ID_USUARIO, TRIM(XC.ID_DOCUMENTO),	TRIM(XC.ID_CIUDAD),	TRIM(XC.NOMBRE_CIUDAD),	TRIM(XC.APELLIDOS),	TRIM(XC.NOMBRES),	NVL(TRIM(XC.DIRECCION),'NO REPORTA RUNT'),	TRIM(XC.TELEFONO),	TRIM(XC.EMP_O_PART),	TRIM(XC.SEXO),	TRIM(XC.FECHA_NACIMIENTO),	TRIM(XC.ID_PAIS),	TRIM(XC.NOMBRE_PAIS),	TRIM(XC.FECHA_MODIFICACION),	TRIM(XC.FAX),	TRIM(XC.EMAIL), NVL(TRIM(XC.FECHA_ACTUALIZACION), TO_CHAR(sysdate,'DDMMYYYY')),TO_NUMBER(XC.ID_CIUDAD_DIR), TRIM(XC.NOMBRE_CIUDAD_DIR), TO_NUMBER(XC.ID_DIRECCION), 'VP', 'N');
                                                            V_IDDIRECCION := XC.ID_DIRECCION;
                                              
                                            END IF;
                                    ELSE
                                                    INSERT INTO DEPURACION.DS_CONTRIBUYENTE 
                                                            VALUES (DEPURACION.SEQ_DS_CONTRIBUYE_ID_CONTRIBUY.NEXTVAL, VNRO_RADICADO, V_ID_USUARIO, TRIM(XC.ID_DOCUMENTO),	TRIM(XC.ID_CIUDAD),	TRIM(XC.NOMBRE_CIUDAD),	TRIM(XC.APELLIDOS),	TRIM(XC.NOMBRES),	NVL(TRIM(XC.DIRECCION),'NO REPORTA RUNT'),	TRIM(XC.TELEFONO),	TRIM(XC.EMP_O_PART),	TRIM(XC.SEXO),	TRIM(XC.FECHA_NACIMIENTO),	TRIM(XC.ID_PAIS),	TRIM(XC.NOMBRE_PAIS),	TRIM(XC.FECHA_MODIFICACION),	TRIM(XC.FAX),	TRIM(XC.EMAIL), NVL(TRIM(XC.FECHA_ACTUALIZACION), TO_CHAR(SYSDATE,'DDMMYYYY')),TO_NUMBER(XC.ID_CIUDAD_DIR), TRIM(XC.NOMBRE_CIUDAD_DIR), TO_NUMBER(XC.ID_DIRECCION), 'VP', 'N');
                                                            V_IDDIRECCION := XC.ID_DIRECCION;
                                    END IF;
                                    -- RECUPERA LOS REGISTROS DE CONTRIBUYENTES QUE NO TIENEN LA MAXIMA FECHA DE ACTUALIZACION DE LA TABLA DS_TMP_CONTRIBUYENTES              
                                    -- CURSOR CCONTRIBUYENTES_DIRECCION(VNRODOC VARCHAR2) IS
                                    FOR XDIR IN ( SELECT * FROM DEPURACION.DS_TMP_CONTRIBUYENTES TMC
                                                                              WHERE TMC.ID_DOCUMENTO = XC.ID_DOCUMENTO AND 
                                                                                           TMC.ID_USUARIO = XC.ID_USUARIO AND
                                                                                           TMC.ID_DIRECCION <> V_IDDIRECCION) LOOP                               
                                                     -- INSERTAR DIRECCIONES DIFERENTES A LA MAXIMA ACTUAL EN EL HISTORICO
                                                     INSERT INTO DEPURACION.DS_DIRECCIONES 
                                                                  VALUES (XDIR.ID_DIRECCION,
                                                                          DEPURACION.SEQ_DS_CONTRIBUYE_ID_CONTRIBUY.CURRVAL,
                                                                          VNRO_RADICADO,
                                                                          XDIR.DIRECCION,
                                                                          XDIR.ID_CIUDAD_DIR,
                                                                          5,
                                                                          XDIR.TELEFONO,
                                                                          XDIR.FAX,
                                                                          XDIR.FECHA_MODIFICACION,
                                                                          XDIR.NOMBRE_CIUDAD_DIR,
                                                                          'VP');
                                                     CONTADOR := CONTADOR + 1;
                                                     TRCON := TRCON + 1;                                               
                                    END LOOP;
                                    IF (CONTADOR = 300 ) THEN
                                        COMMIT;
                                        CONTADOR := 0;
                                    ELSE
                                       CONTADOR := CONTADOR + 1;
                                    END IF;
                                    TRCON := TRCON + 1;
                                EXCEPTION
                                  WHEN OTHERS THEN
                                       MSERROR := ':';
                                       MSERROR := MSERROR || FT_VALIDAR_ESTRUCTURA(2, NULL, XC, NULL, NULL);
                                       INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                           VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_CONTRIBUYENTES',VNRO_RADICADO,DATOPRIMARIO,MSERROR, 1);                     
                                       UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                                              WHERE ID_RADICADO = VNRO_RADICADO
                                                AND ID_TIPO_ARCHIVO = 2;                               
                                       COMMIT;
                                       SWERROR := 1;
                                       VERROR := 1;
                                END;
                        END LOOP;
                        -- ACTUALIZAR REGISTROS CORRECTOS EN INFORME DE CONTRIBUYENTES  
                        V_CONT_TRAM := 0;
                        
                        SELECT COUNT(1)
                        INTO V_CONT_TRAM
                        FROM DS_TMP_TRAMITES DT
                        WHERE DT.ID_TRAMITE <> 65;
                              
												IF ( TRCON = 0 AND V_CONT_TRAM > 0 ) THEN
														UPDATE DEPURACION.DS_INFORME_REGISTROS  SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRCON, ACTIVO = 'E'
															 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 2;  
                            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                   VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_CONTRIBUYENTES',VNRO_RADICADO,0,'ERROR EN DISTRIBUCI�N: NO HAY DATOS CARGADOS PARA EL ARCHIVO POR INCONSISTENCIAS.', 1);
												ELSE
														UPDATE DEPURACION.DS_INFORME_REGISTROS  SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRCON, ACTIVO = DECODE(VERROR,1,'E','S')
															 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 2;                         
												END IF;
                        COMMIT;
                    END IF;
                    
                    -- DISTRIBUCION DEL ARCHIVO DS_TRAMITES     
                    IF ( PROCESO = 4 OR PROCESO = 0 ) THEN                                
                        CONTADOR := 0;
                        DATOPRIMARIO := 0;
                        TRTRA := 0;
												VERROR := 0;
                        FOR XT IN CTRAMITES LOOP
                            BEGIN
                                  DATOPRIMARIO := XT.NRO_PLACA;
                                  V_ID_USUARIO_ANTERIOR := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XT.ID_USUARIO_ANTERIOR), TRIM(XT.ID_DOCUMENTO_ANTERIOR));
                                  V_ID_USUARIO_NUEVO := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XT.ID_USUARIO_NUEVO), TRIM(XT.ID_DOCUMENTO_NUEVO)); 
                                  INSERT INTO DEPURACION.DS_TRAMITE VALUES (DEPURACION.SEQ_DS_TRAMITE_ID_TRAMITE_RECE.NEXTVAL, VNRO_RADICADO, DATOPRIMARIO,	TRIM(XT.ID_TRAMITE),	TRIM(XT.FECHA_TRAMITE), TRIM(XT.NOMBRE_TRAMITE),	TRIM(XT.TIPO_CANCELACION),	TRIM(XT.ID_SECRETARIA_DESTINO),	TRIM(XT.ID_SECRETARIA_ORIGEN),	TRIM(XT.ID_CARROCERIA_ANTERIOR),	TRIM(XT.NOMBRE_CARROCERIA_ANTERIOR),	TRIM(XT.ID_CARROCERIA_NUEVA),	TRIM(XT.NOMBRE_CARROCERIA_NUEVA),	TRIM(XT.ID_SERVICIO_ANTERIOR),	TRIM(XT.NOMBRE_SERVICIO_ANTERIOR),	TRIM(XT.ID_SERVICIO_NUEVO),	TRIM(XT.NOMBRE_SERVICIO_NUEVO), TRIM(XT.ID_DOCUMENTO_ANTERIOR),	V_ID_USUARIO_ANTERIOR,	TRIM(XT.ID_DOCUMENTO_NUEVO), V_ID_USUARIO_NUEVO,	TRIM(XT.PORCENTAJE_PROP),	TRIM(XT.CLASICO_ANTIGUO),	TRIM(XT.BLINDADO),	TRIM(XT.NIVEL_BLINDADO),	TRIM(XT.DESBLINDAJE),	TRIM(XT.CILINDRAJE),	TRIM(XT.CAP_PASAJEROS),	TRIM(XT.CAP_TONELADAS), 'VP','N');
                                  TRTRA := TRTRA + 1;
                                  IF (CONTADOR = 300 ) THEN
                                      COMMIT;
                                      CONTADOR := 0;
                                  ELSE
																			CONTADOR := CONTADOR + 1;
                                  END IF;                                  
                            EXCEPTION
                              WHEN OTHERS THEN
                                   MSERROR := ':';
                                   MSERROR := SQLERRM||' :';
                                   MSERROR := MSERROR || FT_VALIDAR_ESTRUCTURA(4, NULL, NULL, NULL, XT);
                                   INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                       VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_TRAMITES',VNRO_RADICADO,NVL(XT.NRO_PLACA,'PLACA NULA'),MSERROR, 1);                  
                                   UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                                          WHERE ID_RADICADO = VNRO_RADICADO
                                            AND ID_TIPO_ARCHIVO = 4;                               
                                   COMMIT;
                                   SWERROR := 1;
																	 VERROR := 1;
                            END;
                        END LOOP;		
                        COMMIT;
                        DATOPRIMARIO := 0;
												VERROR := 0;                        
                        FOR XTT IN CTRAMITRES_TRASPASO LOOP
                               BEGIN
                                        EXECUTE IMMEDIATE 'SELECT MAX(NRO_IDENTIFICADOR) FROM DEPURACION.DS_TRAMITE
                                                    WHERE ID_TRAMITE = 16 AND NRO_PLACA = '''||XTT.NRO_PLACA||'''' INTO VNRO_IDENTIFICADOR;
                                        DATOPRIMARIO := XTT.NRO_PLACA;
                                        V_ID_USUARIO_ANTERIOR := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XTT.ID_USUARIO_ANTERIOR), TRIM(XTT.ID_DOCUMENTO_ANTERIOR));
                                        V_ID_USUARIO_NUEVO := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ESTANDARIZAR_IDENTIFICACION(TRIM(XTT.ID_USUARIO_NUEVO), TRIM(XTT.ID_DOCUMENTO_NUEVO)); 
                                        INSERT INTO DEPURACION.DS_TRAMITE_TRASPASO VALUES (VNRO_IDENTIFICADOR, VNRO_RADICADO, DATOPRIMARIO,	TRIM(XTT.ID_TRAMITE),	TRIM(XTT.FECHA_TRAMITE), TRIM(XTT.NOMBRE_TRAMITE),	TRIM(XTT.TIPO_CANCELACION),	TRIM(XTT.ID_SECRETARIA_DESTINO),	TRIM(XTT.ID_SECRETARIA_ORIGEN),	TRIM(XTT.ID_CARROCERIA_ANTERIOR),	TRIM(XTT.NOMBRE_CARROCERIA_ANTERIOR),	TRIM(XTT.ID_CARROCERIA_NUEVA),	TRIM(XTT.NOMBRE_CARROCERIA_NUEVA),	TRIM(XTT.ID_SERVICIO_ANTERIOR),	TRIM(XTT.NOMBRE_SERVICIO_ANTERIOR),	TRIM(XTT.ID_SERVICIO_NUEVO),	TRIM(XTT.NOMBRE_SERVICIO_NUEVO), TRIM(XTT.ID_DOCUMENTO_ANTERIOR),	V_ID_USUARIO_ANTERIOR,	TRIM(XTT.ID_DOCUMENTO_NUEVO), V_ID_USUARIO_NUEVO,	TRIM(XTT.PORCENTAJE_PROP),	TRIM(XTT.CLASICO_ANTIGUO),	TRIM(XTT.BLINDADO),	TRIM(XTT.NIVEL_BLINDADO),	TRIM(XTT.DESBLINDAJE),	TRIM(XTT.CILINDRAJE),	TRIM(XTT.CAP_PASAJEROS),	TRIM(XTT.CAP_TONELADAS), 'VP','N');
                                        TRTRA := TRTRA + 1;
                              EXCEPTION
                                    WHEN OTHERS THEN
                                               MSERROR := ':';
                                               MSERROR := SQLERRM||' :';
                                               MSERROR := MSERROR || FT_VALIDAR_ESTRUCTURA(4, NULL, NULL, NULL, XTT);
                                               INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                                   VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_TRAMITES',VNRO_RADICADO,NVL(XTT.NRO_PLACA,'PLACA NULA'),MSERROR, 1);                  
                                               UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                                                      WHERE ID_RADICADO = VNRO_RADICADO
                                                        AND ID_TIPO_ARCHIVO = 4;                               
                                               COMMIT;
                                               SWERROR := 1;
                                               VERROR := 1;
                              END;                                        
                        END LOOP;                        
                        
                        -- ACTUALIZAR REGISTROS CORRECTOS EN INFORME DE TRAMITES
												IF ( TRTRA = 0 ) THEN
														UPDATE DEPURACION.DS_INFORME_REGISTROS  SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRTRA, ACTIVO = 'E'
															 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 4;
                            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
                                   VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_TRAMITES',VNRO_RADICADO,0,'ERROR EN DISTRIBUCI�N: NO HAY DATOS CARGADOS PARA EL ARCHIVO POR INCONSISTENCIAS.', 1);
												ELSE
														UPDATE DEPURACION.DS_INFORME_REGISTROS  SET TOTAL_CARGADOS = TOTAL_CARGADOS + TRTRA, ACTIVO = DECODE(VERROR,1,'E','S')
															 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 4;                       
												END IF;
                        COMMIT;
                    END IF;
                    -- SE VALIDA QUE NINGUNO DE LOS 4 CARGUES TUVO ERROR
                    IF ( SWERROR = 0 ) THEN -- SIN ERROR
                         IF ( PROCESO = 0 ) THEN
                                UPDATE DEPURACION.DS_INFORME_LOTE SET TOTAL_CARGADOS = TRVEH --+ TRPRO + TRCON + TRTRA)
                                   WHERE ID_RADICADO = VNRO_RADICADO;
                                COMMIT;                             
                              -- INVOCACION DEL PAQUETE DE ESTANDARIZACION DE RADICADOS
                              DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.SP_ESTANDARIZAR_RADICADO(VNRO_RADICADO);
                              EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_TRAMITES';
                              EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_CONTRIBUYENTES';
                              EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_PROPIETARIOS';
                              EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_VEHICULOS';
                              COMMIT;

                          -- SIN ERROR CARGA DE CORRECCION DE VEHICULOS
                          ELSIF ( PROCESO = 1 ) THEN
																	UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'S'
																			WHERE ID_RADICADO = VNRO_RADICADO
																				AND ID_TIPO_ARCHIVO = PROCESO;
																	EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_VEHICULOS';
																	COMMIT;
                          -- SIN ERROR CARGA DE CORRECCION DE CONTRIBUYENTES
                          ELSIF ( PROCESO = 2 ) THEN
																	UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'S'
																			WHERE ID_RADICADO = VNRO_RADICADO
																				AND ID_TIPO_ARCHIVO = PROCESO;
																	EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_CONTRIBUYENTES';                                  
                                  -- NUEVAMENTE SE INVOCA LA ESTANDARIZACION DE CONTRIBUYENTES
                                  DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.SP_ESTANDARIZAR_RADICADO(VNRO_RADICADO);                                  
																	COMMIT;
                          -- SIN ERROR CARGA DE CORRECCION DE PROPIETARIOS
                          ELSIF ( PROCESO = 3 ) THEN
																	UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'S'
																			WHERE ID_RADICADO = VNRO_RADICADO
																				AND ID_TIPO_ARCHIVO = PROCESO;
																	--EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_PROPIETARIOS';																				
																	COMMIT;
                          -- SIN ERROR CARGA DE CORRECCION DE TRAMITES
                          ELSIF ( PROCESO = 4 ) THEN
																	UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'S'
																			WHERE ID_RADICADO = VNRO_RADICADO
																				AND ID_TIPO_ARCHIVO = PROCESO;
		                              EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_TRAMITES';
				                          COMMIT;
                          END IF;
                          -- VALIDACION QUE LAS CORRECCIONES ESTE EXITOSAS.
                          SELECT COUNT(1) INTO VALIDACARGUE FROM DEPURACION.DS_INFORME_REGISTROS
                             WHERE ID_RADICADO = VNRO_RADICADO AND ACTIVO = 'S';
                             
                          -- LOS 4 REGISTROS FUERON EXITOSOS.
                          IF ( VALIDACARGUE = 4 ) THEN 
                              -- ACTUALIZACION DE TOTALES FINALES
															SELECT TOTAL_REGISTROS,TOTAL_CARGADOS INTO TRREGISTROS, TRCARGADOS FROM DEPURACION.DS_INFORME_REGISTROS
																	 WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 1;
                              UPDATE DEPURACION.DS_INFORME_REGISTROS SET  ACTIVO = 'S'
                                  WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = PROCESO;    
															UPDATE DEPURACION.DS_INFORME_LOTE SET TOTAL_REGISTROS = TRREGISTROS, TOTAL_CARGADOS = TRCARGADOS
															     WHERE ID_RADICADO = VNRO_RADICADO;
                              UPDATE DEPURACION.DS_MAESTRO SET ID_ESTADO_DEPURACION = 1, ACTIVO = 'S', MENSAJE_ERROR = 'CONFIRMACI�N ARCHIVOS: EL N�MERO DE LOTE :. '||LPAD(VNRO_RADICADO,10,'0')||' SE CARGO CORRECTAMENTE'
                                  WHERE ID_RADICADO = VNRO_RADICADO;
                              COMMIT;                              
                          END IF;
                    ELSE
                        -- ERROR DE CARGUE EN LOS ARCHIVOS
                        -- ACTUALZIACION DE MENSAJE DE ERROR EN MAESTRO
                        UPDATE DEPURACION.DS_MAESTRO SET ID_ESTADO_DEPURACION = 4, ACTIVO = 'E', MENSAJE_ERROR = 'ERROR EN DISTRIBUCI�N: DISTRIBUCCI�N DE DATOS ERRONEO'
                               WHERE ID_RADICADO = VNRO_RADICADO;                               
                        SELECT SUM(TOTAL_CARGADOS) INTO TRCARGADOS FROM DEPURACION.DS_INFORME_REGISTROS
                             WHERE ID_RADICADO = VNRO_RADICADO AND ID_TIPO_ARCHIVO = 1;
                        UPDATE DEPURACION.DS_INFORME_LOTE SET TOTAL_CARGADOS = TRCARGADOS
                           WHERE ID_RADICADO = VNRO_RADICADO;                           
                        -- ELIMINACION DE LOS CARGUES CON ERRORES.
                        EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_VEHICULOS';
                        EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_CONTRIBUYENTES';
                        EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_PROPIETARIOS';
                        EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_TRAMITES';
                        COMMIT;
                    END IF;        
              END IF;
        ELSE
            -- ERROR DE CARGUE POR LOTE ACTIVO Y NO CUMPLE CON EL PORCENTAJE PERMITIDO PARA UN NUEVO CARGUE.
            UPDATE DEPURACION.DS_MAESTRO SET ID_ESTADO_DEPURACION = 4, ACTIVO = 'E', MENSAJE_ERROR='ERROR DE CARGUE: NO SE PERMITE REALIZAR UN CARGUE DE LOTE HASTA QUE EL ACTUAL SE ENCUENTRE EN ESTADO FINALIZADO, O SU PORCENTAJE DE ENTREGA SEA MAYOR AL PARAMETRIZADO'
                   WHERE ID_RADICADO = VNRO_RADICADO;   
            COMMIT;
        END IF;

    EXCEPTION
        -- ERROR POR ESTRUCTURAS NULAS O ERRONEAS.
        WHEN ERROR_CARGUE THEN
            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_VEHICULOS',VNRO_RADICADO,0,'ERROR DE CARGUE', 1);
						INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_CONTRIBUYENTES',VNRO_RADICADO,0,'ERROR DE CARGUE', 1);
						INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_PROPIETARIOS',VNRO_RADICADO,0,'ERROR DE CARGUE', 1);
						INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_TMP_TRAMITES',VNRO_RADICADO,0,'ERROR DE CARGUE', 1);
            UPDATE DEPURACION.DS_MAESTRO SET ID_ESTADO_DEPURACION = 4, ACTIVO = 'E', MENSAJE_ERROR='ERROR DE CARGUE: REVISAR LOS LOGS CORRESPONDIENTES A LOS ARCHIVOS CARGADOS'
                   WHERE ID_RADICADO = VNRO_RADICADO;   
            -- BORRADO DE LAS TEMPORALES.
            EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_VEHICULOS';
            EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_CONTRIBUYENTES';
            EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_PROPIETARIOS';
            EXECUTE IMMEDIATE 'DELETE DEPURACION.DS_TMP_TRAMITES';
					  COMMIT;      
        WHEN OTHERS THEN
             -- ERROR PROPIO DEL PL
             -- COLOCA TODO EL LOTE EN ERROR.
             --MSERROR := SQLERRM;
             MSERROR := sqlerrm||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE;
             UPDATE DEPURACION.DS_MAESTRO SET ID_ESTADO_DEPURACION = 4, ACTIVO = 'E', MENSAJE_ERROR='ERROR DE BASE DE DATOS: '||MSERROR
                    WHERE ID_RADICADO = VNRO_RADICADO;   
             UPDATE DEPURACION.DS_INFORME_REGISTROS SET ACTIVO = 'E'
                WHERE ID_RADICADO = VNRO_RADICADO;
             INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES(DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'ERROR GENERAL',VNRO_RADICADO,0 ,'ERROR DE CARGUE'||MSERROR, 1);
            COMMIT;
  END SP_DISTRIBUCION_REGISTROS;
  
  /*ESTA FUNCION VALIDA QUE LOS DATOS DE ALGUNO DE LOS 4 ARCHIVOS SI CUMPLA CON LA ESTRUCTURA DE LA TABLA EN CUANTO A LONGITUD Y TIPO DE DATO*/
  FUNCTION FT_VALIDAR_ESTRUCTURA(A_ID_TIPO_REGISTRO NUMBER, A_ROW_VEHICULO DS_TMP_VEHICULOS%ROWTYPE, A_ROW_CONTRIBUYENTE DS_TMP_CONTRIBUYENTES%ROWTYPE, A_ROW_PROPIETARIO DS_TMP_PROPIETARIOS%ROWTYPE, A_ROW_TRAMITES DS_TMP_TRAMITES%ROWTYPE) RETURN VARCHAR2 IS
    
    CURSOR C_CAMPO_ARCHIVO (A_TIPO_REG NUMBER) IS
      SELECT ID_CAMPO,
              ID_TIPO_REGISTRO,
              NOMBRE_CAMPO,
              TIPO_DATO_CAMPO,
              LONGITUD
      FROM DS_CAMPO_ARCHIVO DCA
      WHERE DCA.ID_TIPO_REGISTRO = A_TIPO_REG
      ORDER BY ID_CAMPO;
      
    V_RETORNO VARCHAR2(4000);
    V_NUMERO NUMBER;
    V_FECHA DATE;
  BEGIN
    
    V_RETORNO := ' ';
    
    FOR X IN C_CAMPO_ARCHIVO(A_ID_TIPO_REGISTRO)
    LOOP
    
      IF A_ID_TIPO_REGISTRO = 1 THEN
        CASE X.NOMBRE_CAMPO
          WHEN 'NRO_PLACA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NRO_PLACA)) > X.LONGITUD THEN
              V_RETORNO := 'NRO_PLACA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_MARCA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_MARCA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_MARCA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_MARCA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_MARCA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_MARCA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_MARCA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_MARCA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_LINEA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_LINEA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_LINEA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_LINEA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_LINEA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_LINEA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_LINEA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_LINEA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'MODELO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.MODELO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'MODELO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.MODELO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'MODELO: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_CLASE' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_CLASE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_CLASE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_CLASE);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_CLASE: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_CLASE' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_CLASE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_CLASE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_SERVICIO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_SERVICIO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_SERVICIO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_SERVICIO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_SERVICIO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_SERVICIO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_CARROCERIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_CARROCERIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_CARROCERIA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_CARROCERIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_CARROCERIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_CARROCERIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'NRO_PUERTAS' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NRO_PUERTAS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NRO_PUERTAS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.NRO_PUERTAS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'NRO_PUERTAS: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_COMBUSTIBLE' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_COMBUSTIBLE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_COMBUSTIBLE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_COMBUSTIBLE);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_COMBUSTIBLE: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_COMBUSTIBLE' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_COMBUSTIBLE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_COMBUSTIBLE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_BATERIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_BATERIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_BATERIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_BATERIA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_BATERIA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_BATERIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_BATERIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_BATERIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'POTENCIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.POTENCIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'POTENCIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_SECRETARIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_SECRETARIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_SECRETARIA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_SECRETARIA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_SECRETARIA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_SECRETARIA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'CILINDRAJE' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.CILINDRAJE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CILINDRAJE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.CILINDRAJE);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CILINDRAJE: N�MERO NO VALIDO. ';
            END;
          WHEN 'CAP_PASAJEROS' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.CAP_PASAJEROS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CAP_PASAJEROS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.CAP_PASAJEROS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CAP_PASAJEROS: N�MERO NO VALIDO. ';
            END;
          WHEN 'CAP_TONELADAS' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.CAP_TONELADAS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CAP_TONELADAS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.CAP_TONELADAS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CAP_TONELADAS: N�MERO NO VALIDO. ';
            END;
          WHEN 'VALOR_FACTURA' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.VALOR_FACTURA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'VALOR_FACTURA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.VALOR_FACTURA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'VALOR_FACTURA: N�MERO NO VALIDO. ';
            END;
          WHEN 'BLINDADO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.BLINDADO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'BLINDADO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'IMPORTADO_NACIONAL' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.IMPORTADO_NACIONAL)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'IMPORTADO_NACIONAL: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_ESTADO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.ID_ESTADO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_ESTADO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_VEHICULO.ID_ESTADO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_ESTADO: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_ESTADO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.NOMBRE_ESTADO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_ESTADO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'CLASICO_ANTIGUO' THEN
            IF LENGTH(TRIM(A_ROW_VEHICULO.CLASICO_ANTIGUO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CLASICO_ANTIGUO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'FECHA_MATRICULA' THEN
            BEGIN
              V_FECHA := TO_DATE(A_ROW_VEHICULO.FECHA_MATRICULO,'DDMMYYYY');
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'FECHA_MATRICULA: FORMATO DE FECHA NO VALIDO. ';
            END;


        END CASE;
      END IF;
      
      
      IF A_ID_TIPO_REGISTRO = 2 THEN
        CASE X.NOMBRE_CAMPO
          WHEN 'ID_USUARIO' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.ID_USUARIO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_USUARIO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_DOCUMENTO' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.ID_DOCUMENTO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_CONTRIBUYENTE.ID_DOCUMENTO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_CIUDAD' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.ID_CIUDAD)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_CIUDAD: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_CONTRIBUYENTE.ID_CIUDAD);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_CIUDAD: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_CIUDAD' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.NOMBRE_CIUDAD)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_CIUDAD: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'APELLIDOS' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.APELLIDOS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'APELLIDOS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'NOMBRES' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.NOMBRES)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRES: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'DIRECCION' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.DIRECCION)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'DIRECCION: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'TELEFONO' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.TELEFONO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'TELEFONO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'EMP_O_PART' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.EMP_O_PART)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'EMP_O_PART: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'SEXO' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.SEXO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'SEXO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'FECHA_NACIMIENTO' THEN
            NULL;
          WHEN 'ID_PAIS' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.ID_PAIS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_PAIS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_CONTRIBUYENTE.ID_PAIS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_PAIS: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_PAIS' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.NOMBRE_PAIS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_PAIS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'FECHA_MODIFICACION' THEN
            NULL;
          WHEN 'FAX' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.FAX)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'FAX: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'EMAIL' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.EMAIL)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'EMAIL: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'FECHA_ACTUALIZACION' THEN
            NULL;
           WHEN 'ID_CIUDAD_DIR' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.ID_CIUDAD_DIR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID CIUDAD DIR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;                
           WHEN 'NOMBRE_CIUDAD_DIR' THEN
            IF LENGTH(TRIM(A_ROW_CONTRIBUYENTE.NOMBRE_CIUDAD_DIR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE CIUDAD DIR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;                



        END CASE;
      END IF;
      
    
      IF A_ID_TIPO_REGISTRO = 3 THEN
        CASE X.NOMBRE_CAMPO
          WHEN 'NRO_PLACA' THEN
            IF LENGTH(TRIM(A_ROW_PROPIETARIO.NRO_PLACA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NRO_PLACA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_USUARIO' THEN
            IF LENGTH(TRIM(A_ROW_PROPIETARIO.ID_USUARIO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_USUARIO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_DOCUMENTO' THEN
            IF LENGTH(TRIM(A_ROW_PROPIETARIO.ID_DOCUMENTO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_PROPIETARIO.ID_DOCUMENTO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO: N�MERO NO VALIDO. ';
            END;
          WHEN 'PORCENTAJE_PROP' THEN
            IF LENGTH(TRIM(A_ROW_PROPIETARIO.PORCENTAJE_PROP)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'PORCENTAJE_PROP: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_PROPIETARIO.PORCENTAJE_PROP);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'PORCENTAJE_PROP: N�MERO NO VALIDO. ';
            END;


        END CASE;
      END IF;
      
      
      IF A_ID_TIPO_REGISTRO = 4 THEN
        CASE X.NOMBRE_CAMPO
          WHEN 'NRO_PLACA' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NRO_PLACA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NRO_PLACA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_TRAMITE' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_TRAMITE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_TRAMITE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_TRAMITE);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_TRAMITE: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_TRAMITE' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NOMBRE_TRAMITE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_TRAMITE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'FECHA_TRAMITE' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.FECHA_TRAMITE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'FECHA_TRAMITE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'TIPO_CANCELACION' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.TIPO_CANCELACION)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'TIPO_CANCELACION: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_SECRETARIA_DESTINO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_SECRETARIA_DESTINO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA_DESTINO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_SECRETARIA_DESTINO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA_DESTINO: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_SECRETARIA_ORIGEN' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_SECRETARIA_ORIGEN)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA_ORIGEN: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_SECRETARIA_ORIGEN);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SECRETARIA_ORIGEN: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_CARROCERIA_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_CARROCERIA_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_CARROCERIA_ANTERIOR);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA_ANTERIOR: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_CARROCERIA_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NOMBRE_CARROCERIA_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_CARROCERIA_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_CARROCERIA_NUEVA' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_CARROCERIA_NUEVA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA_NUEVA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_CARROCERIA_NUEVA);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_CARROCERIA_NUEVA: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_CARROCERIA_NUEVA' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NOMBRE_CARROCERIA_NUEVA)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_CARROCERIA_NUEVA: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_SERVICIO_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_SERVICIO_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_SERVICIO_ANTERIOR);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO_ANTERIOR: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_SERVICIO_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NOMBRE_SERVICIO_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_SERVICIO_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_SERVICIO_NUEVO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_SERVICIO_NUEVO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO_NUEVO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_SERVICIO_NUEVO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_SERVICIO_NUEVO: N�MERO NO VALIDO. ';
            END;
          WHEN 'NOMBRE_SERVICIO_NUEVO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NOMBRE_SERVICIO_NUEVO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NOMBRE_SERVICIO_NUEVO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_DOCUMENTO_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_DOCUMENTO_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_DOCUMENTO_ANTERIOR);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO_ANTERIOR: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_USUARIO_ANTERIOR' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_USUARIO_ANTERIOR)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_USUARIO_ANTERIOR: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'ID_DOCUMENTO_NUEVO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_DOCUMENTO_NUEVO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO_NUEVO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.ID_DOCUMENTO_NUEVO);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'ID_DOCUMENTO_NUEVO: N�MERO NO VALIDO. ';
            END;
          WHEN 'ID_USUARIO_NUEVO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.ID_USUARIO_NUEVO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'ID_USUARIO_NUEVO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'PORCENTAJE_PROP' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.PORCENTAJE_PROP)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'PORCENTAJE_PROP: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.PORCENTAJE_PROP);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'PORCENTAJE_PROP: N�MERO NO VALIDO. ';
            END;
          WHEN 'CLASICO_ANTIGUO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.CLASICO_ANTIGUO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CLASICO_ANTIGUO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'BLINDADO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.BLINDADO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'BLINDADO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'NIVEL_BLINDADO' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.NIVEL_BLINDADO)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'NIVEL_BLINDADO: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'DESBLINDAJE' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.DESBLINDAJE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'DESBLINDAJE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
          WHEN 'CILINDRAJE' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.CILINDRAJE)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CILINDRAJE: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.CILINDRAJE);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CILINDRAJE: N�MERO NO VALIDO. ';
            END;
          WHEN 'CAP_PASAJEROS' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.CAP_PASAJEROS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CAP_PASAJEROS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.CAP_PASAJEROS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CAP_PASAJEROS: N�MERO NO VALIDO. ';
            END;
          WHEN 'CAP_TONELADAS' THEN
            IF LENGTH(TRIM(A_ROW_TRAMITES.CAP_TONELADAS)) > X.LONGITUD THEN
              V_RETORNO := V_RETORNO || 'CAP_TONELADAS: LONGITUD MAYOR QUE LA QUE PERMITE LA COLUMNA. ';
            END IF;
            BEGIN
              V_NUMERO := TO_NUMBER(A_ROW_TRAMITES.CAP_TONELADAS);
            EXCEPTION
            WHEN OTHERS THEN
              V_RETORNO := V_RETORNO || 'CAP_TONELADAS: N�MERO NO VALIDO. ';
            END;


        END CASE;
      END IF;
      
      
    END LOOP;
    
    RETURN V_RETORNO;
  END;

END PKG_DS_CARGA_ARCHIVOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_CORRECCION_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_CORRECCION_DATOS" AS

/*
/*******************************************************************************
    NOMBRE:         "PKG_DS_CORRECCION_DATOS"
    AUTOR:          FERNANDO BONILLA
    FECHA CREACION: 16/12/2014
    DESCRIPCION:    PAQUETE QUE IDENTIFICA LAS CORRECCIONES MASIVAS DEL RADICADO PADRE DESDE UN RADICADO H

    PARAMETROS:     N/A
    OBJETOS:        PROCEDIMIENTO.
                             SP_LECTURA_INCONSISTENCIAS: Lee las inconsistencias y las compara si fueron corregidos en el radicado hijo y actualiza el estado de la inconsistencia
                                                                                   del radicado padre
                             SP_ACTUALIZA_ESTADO_REGISTRO: Lee los estados de los registros del radicado padre vs el radicado hijo y si este fue actualizado en el hijo, cambia el estado 
                                                                                         del radicado padre
  
 *******************************************************************************
                            HISTORIAL DE CAMBIOS
 *******************************************************************************
 FECHA        ||MODIFICADO                ||DESCRIPCION
 -------------------------------------------------------------------------------
 16/12/2014   ||FERNANDO BONILLA          ||CREACION DEL PAQUETE.
 05/02/2014   ||FERNANDO BONILLA          ||AJUSTES A LAS ACTUALIZACIONES DE LOS ESTADOS DE LOS REGISTROS DE CORRECCION AL RADICADO PADRE
*/ 

  PROCEDURE SP_LECTURA_INCONSISTENCIAS(IDRADICADOP NUMBER, IDRADICADOH NUMBER) AS
  
  
  --- DEFINICION DE CURSOR PARA LAS INCONSISTENCIAS DEL RADICADO PADRE IDENTIFICAR SI ESTAS YA FUERON CORREGIDAS
      CURSOR CINCONSISTENCIAS(NRORADICADO NUMBER) IS
            SELECT DI.ID_EXCEPCION,
                DI.ID_RADICADO,
                DI.ID_TIPO_REGISTRO,
                DI.ID_INCONSISTENCIA,
                DI.IDENTIFICADOR AS CAMPO,
                DI.ID_REGISTRO_FALLO AS NRO_IDENTIFICADOR,
                DTR.ESQUEMA,
                DTR.NOMBRE_TABLA
            FROM DEPURACION.DS_INCONSISTENCIA DI
               INNER JOIN DEPURACION.DS_TIPO_REGISTRO DTR 
                    ON DTR.ID_TIPO_REGISTRO = DI.ID_TIPO_REGISTRO
            WHERE DI.ID_RADICADO = NRORADICADO
              --AND DI.ID_REGISTRO_FALLO = 1096
                ORDER BY DTR.ORDEN ASC, DI.ID_REGISTRO_FALLO;

     /* CURSOR CPROPIETARIOPLACA(IDDOCUSER VARCHAR2) IS
          SELECT NRO_PLACA FROM DEPURACION.DS_PROPIETARIO 
                  WHERE (TO_CHAR(ID_DOCUMENTO)||ID_USUARIO) = IDDOCUSER 
                        AND ID_RADICADO = IDRADICADOP
                        AND ESTADO_VALIDACION = 'VE';*/

      SQLTXT                VARCHAR2(4000); -- VARIABLE PARA ARMADO DE SQL EMBEBIDO
      SQLTEXT               VARCHAR2(4000); -- VARIABLE PARA ARMADO DE SQL EMBEBIDO
      MSERROR               VARCHAR2(4000); -- VARIABLE PARA CAPTURAR LOS ERRORES DE LA LECTURA DE INCONSISTENCIAS
      V_EXISTE              NUMBER;         -- VARIABLE PARA GUARDAR LA EXISTENCIA DE ALGUN REGISTRO 0 NO EXISTE, 1 EXISTE
      V_IDENTIFICADORP      VARCHAR2(30);   -- VARIABLE QUE GUARDA LA PLACA O EL USUARIO DE RADICADO PADRE
      V_IDENTIFICADOR       VARCHAR2(30) := 0; -- VARIABLE QUE GUARDA EL NRO_IDENTIFICADOR ACTUAL
      V_TABLA               VARCHAR2(80);      -- ESQUEMA Y TABLA ACTUALIZAR EL REGISTRO
      V_ACTESTADO           BOOLEAN      := FALSE; -- VARIABLE QUE INDICA SI SE INVOCA EL PROCESO DE ACTUALIZACION DE ESTADOS E INFORME
      V_RADICADO            NUMBER;            -- VARIABLE PARA GUARDAR EL RADICADO HIJO
  BEGIN
            FOR XINC IN CINCONSISTENCIAS(IDRADICADOP) LOOP
                V_RADICADO := IDRADICADOH;
                V_EXISTE := 0;
                BEGIN
                     SQLTXT := 'SELECT COUNT(1) FROM DEPURACION.DS_INCONSISTENCIA DI '||CHR(13);
                     CASE XINC.ID_TIPO_REGISTRO
                          WHEN 1 THEN
                               -- SE EXTRAE EL NUMERO DE PLACA O EL USUARIO DE ACUERDO AL TIPO DE ARCHIVO
                               SQLTEXT := 'SELECT NRO_PLACA FROM '||XINC.ESQUEMA||'.'||XINC.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||XINC.NRO_IDENTIFICADOR;
                               EXECUTE IMMEDIATE SQLTEXT INTO V_IDENTIFICADORP;
                               SQLTXT := SQLTXT || ' INNER JOIN DEPURACION.DS_VEHICULO DV '|| CHR(13) ||
                                                   '           ON DI.ID_REGISTRO_FALLO = DV.NRO_IDENTIFICADOR'|| CHR(13)||
                                                   '   WHERE DV.NRO_PLACA = '''||V_IDENTIFICADORP||''''|| CHR(13);
                          WHEN 2 THEN
                               SQLTEXT := 'SELECT ID_DOCUMENTO||ID_USUARIO FROM '||XINC.ESQUEMA||'.'||XINC.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||XINC.NRO_IDENTIFICADOR;
                               EXECUTE IMMEDIATE SQLTEXT INTO V_IDENTIFICADORP;
                               SQLTXT := SQLTXT || ' INNER JOIN DEPURACION.DS_CONTRIBUYENTE DC '|| CHR(13) ||
                                                    '           ON DI.ID_REGISTRO_FALLO = DC.NRO_IDENTIFICADOR'|| CHR(13)||
                                                    '     WHERE (DC.ID_DOCUMENTO||DC.ID_USUARIO) = '''||V_IDENTIFICADORP||''''|| CHR(13);
                              
                          WHEN 3 THEN
                               SQLTEXT := 'SELECT NRO_PLACA FROM '||XINC.ESQUEMA||'.'||XINC.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||XINC.NRO_IDENTIFICADOR;
                               EXECUTE IMMEDIATE SQLTEXT INTO V_IDENTIFICADORP;
                               SQLTXT := SQLTXT || ' INNER JOIN DEPURACION.DS_PROPIETARIO DP '|| CHR(13) ||
                                                    '           ON DI.ID_REGISTRO_FALLO = DP.NRO_IDENTIFICADOR'|| CHR(13)||
                                                    '   WHERE DP.NRO_PLACA = '''||V_IDENTIFICADORP||''''|| CHR(13);
                               
                          WHEN 4 THEN
                               SQLTEXT := 'SELECT NRO_PLACA FROM '||XINC.ESQUEMA||'.'||XINC.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||XINC.NRO_IDENTIFICADOR;
                               EXECUTE IMMEDIATE SQLTEXT INTO V_IDENTIFICADORP;
                               SQLTXT := SQLTXT || ' INNER JOIN DEPURACION.DS_TRAMITE DT '|| CHR(13) ||
                                                    '           ON DI.ID_REGISTRO_FALLO = DT.NRO_IDENTIFICADOR'|| CHR(13)||
                                                    '   WHERE DT.NRO_PLACA = '''||V_IDENTIFICADORP||''''|| CHR(13);
                          ELSE
                              NULL;
                     END CASE;
                     IF (XINC.ID_TIPO_REGISTRO <> 5 ) THEN
                         SQLTXT := SQLTXT ||'       AND DI.ID_RADICADO = '||IDRADICADOH||CHR(13)||
                                            '       AND DI.ID_TIPO_REGISTRO = '||XINC.ID_TIPO_REGISTRO||CHR(13)||
                                            '       AND DI.ID_INCONSISTENCIA = '||XINC.ID_INCONSISTENCIA||CHR(13)||
                                            '       AND DI.IDENTIFICADOR = '''||XINC.CAMPO||''''||CHR(13);
                                 V_IDENTIFICADOR := XINC.NRO_IDENTIFICADOR;
                                 V_TABLA := XINC.ESQUEMA||'.'||XINC.NOMBRE_TABLA;
                                 EXECUTE IMMEDIATE SQLTXT INTO V_EXISTE;
                                 IF (V_EXISTE = 0 ) THEN
                                      UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 3
                                              WHERE ID_EXCEPCION = XINC.ID_EXCEPCION;
                                      COMMIT;
                                      V_ACTESTADO := TRUE;
                                 END IF;
                    END IF;
                EXCEPTION
                     WHEN OTHERS THEN
                          MSERROR := SQLERRM;
                          INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'PROCESO CORRECCION', V_RADICADO,0,'ERROR DE ACTUALIZACION DE ESTADO '||MSERROR, 3);
                END;
            END LOOP;
            
            IF ( V_ACTESTADO ) THEN
                  SP_ACTUALIZA_ESTADO_REGISTRO(IDRADICADOP, IDRADICADOH);
                  UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_ALERTAS = 0,TOTAL_CORRECTAS= 0,TOTAL_ENVIADOS= 0,TOTAL_EXCEPCIONES= 0,TOTAL_PENDIENTES = 0
                               WHERE ID_RADICADO = IDRADICADOP;
                  UPDATE DEPURACION.DS_INFORME_LOTE SET TOTAL_CORRECTAS = 0, TOTAL_ENVIADOS = 0, TOTAL_ERRORES = 0, TOTAL_PENDIENTES = 0
                              WHERE ID_RADICADO = IDRADICADOP;
                  COMMIT;                  
                  DEPURACION.PKG_DS_VALIDADOR.SP_INFORME_REGISTROS(IDRADICADOP,1);
            END IF;
            
  END SP_LECTURA_INCONSISTENCIAS;
  
  PROCEDURE SP_ACTUALIZA_ESTADO_REGISTRO(RADICADOP NUMBER, RADICADOH NUMBER) AS
  
        CURSOR REGESTADO(NRADICADOP NUMBER, NRADICADOH NUMBER) IS
                SELECT DV1.NRO_IDENTIFICADOR IDENTIFICADOR, 1 AS ID_TIPO_REGISTRO,  DV2.ENVIO_SAP,
                              DV1.ESTADO_VALIDACION ESTADO_P, DV2.ESTADO_VALIDACION ESTADO_H
                   FROM DEPURACION.DS_VEHICULO DV1
                             INNER JOIN DEPURACION.DS_VEHICULO DV2 
                                          ON DV1.NRO_PLACA = DV2.NRO_PLACA AND DV2.ID_RADICADO = NRADICADOH
                               LEFT JOIN DEPURACION.DS_INCONSISTENCIA DI 
                                          ON DV1.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO AND DI.ID_TIPO_REGISTRO = 1
                   WHERE DV1.ID_RADICADO = NRADICADOP
                UNION ALL
                 SELECT DP1.NRO_IDENTIFICADOR IDENTIFICADOR, 2 AS ID_TIPO_REGISTRO, DP2.ENVIO_SAP,
                               DP1.ESTADO_VALIDACION ESTADO_P, DP2.ESTADO_VALIDACION ESTADO_H
                     FROM DEPURACION.DS_PROPIETARIO DP1
                               INNER JOIN DEPURACION.DS_PROPIETARIO DP2 
                                            ON DP1.NRO_PLACA = DP2.NRO_PLACA AND DP2.ID_RADICADO = NRADICADOH
                                 LEFT JOIN DEPURACION.DS_INCONSISTENCIA DI 
                                            ON DP1.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO AND DI.ID_TIPO_REGISTRO = 2
                    WHERE DP1.ID_RADICADO = NRADICADOP
                UNION ALL
                SELECT DC1.NRO_IDENTIFICADOR , 3 AS ID_TIPO_REGISTRO, DC2.ENVIO_SAP,
                              DC1.ESTADO_VALIDACION ESTADO_P , DC2.ESTADO_VALIDACION ESTADO_H
                   FROM DEPURACION.DS_CONTRIBUYENTE DC1 
                             INNER JOIN DEPURACION.DS_CONTRIBUYENTE DC2 
                                          ON DC1.ID_DOCUMENTO = DC2.ID_DOCUMENTO AND DC1.ID_USUARIO = DC2.ID_USUARIO  AND DC2.ID_RADICADO = NRADICADOH
                               LEFT JOIN DEPURACION.DS_INCONSISTENCIA DI
                                          ON DC1.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO AND DI.ID_TIPO_REGISTRO = 3
                    WHERE DC1.ID_RADICADO = NRADICADOP
                UNION ALL                                  
                SELECT DT1.NRO_IDENTIFICADOR IDENTIFICADOR, 4 AS ID_TIPO_REGISTRO, DT2.ENVIO_SAP,
                              DT1.ESTADO_VALIDACION ESTADO_P, DT2.ESTADO_VALIDACION ESTADO_H
                   FROM DEPURACION.DS_TRAMITE DT1
                             INNER JOIN DEPURACION.DS_TRAMITE DT2 
                                          ON DT1.NRO_PLACA = DT2.NRO_PLACA AND DT2.ID_RADICADO = NRADICADOH
                               LEFT JOIN DEPURACION.DS_INCONSISTENCIA DI 
                                           ON DT1.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO AND DI.ID_TIPO_REGISTRO = 4
                   WHERE DT1.ID_RADICADO = NRADICADOP;

      V_EXISTE NUMBER := 0;
      CONTADOR NUMBER := 0;
      MSERROR VARCHAR2(4000);
  BEGIN
              FOR XREG IN REGESTADO(RADICADOP, RADICADOH) LOOP
                        CASE 
                                WHEN ( XREG.ID_TIPO_REGISTRO = 1 ) THEN 
                                        IF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'RA') THEN
                                              UPDATE DEPURACION.DS_VEHICULO SET ESTADO_VALIDACION = 'RA' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                        ELSIF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'VE') THEN
                                              UPDATE DEPURACION.DS_VEHICULO SET ESTADO_VALIDACION = 'VE' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                        END IF;
                                WHEN ( XREG.ID_TIPO_REGISTRO = 2 ) THEN 
                                       IF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'RA') THEN
                                            UPDATE DEPURACION.DS_PROPIETARIO SET ESTADO_VALIDACION = 'RA' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                       ELSIF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'VE') THEN     
                                            UPDATE DEPURACION.DS_PROPIETARIO SET ESTADO_VALIDACION = 'VE' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                       END IF;
                                WHEN ( XREG.ID_TIPO_REGISTRO = 3 ) THEN 
                                       IF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'RA') THEN
                                            UPDATE DEPURACION.DS_CONTRIBUYENTE SET ESTADO_VALIDACION = 'RA' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                       ELSIF (XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'VE') THEN
                                            UPDATE DEPURACION.DS_CONTRIBUYENTE SET ESTADO_VALIDACION = 'VE' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                       END IF;
                                WHEN ( XREG.ID_TIPO_REGISTRO = 4 ) THEN 
                                        IF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'RA') THEN
                                            UPDATE DEPURACION.DS_TRAMITE SET ESTADO_VALIDACION = 'RA' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                        ELSIF ( XREG.ESTADO_P IN ('VI','VE') AND XREG.ESTADO_H = 'VE') THEN
                                            UPDATE DEPURACION.DS_TRAMITE SET ESTADO_VALIDACION = 'VE' WHERE NRO_IDENTIFICADOR = XREG.IDENTIFICADOR AND ID_RADICADO = RADICADOP;
                                        END IF;
                                ELSE
                                       NULL;
                        END CASE;
                        IF CONTADOR = 500 THEN
                            COMMIT;
                            CONTADOR := 1;
                        ELSE
                            CONTADOR := CONTADOR + 1;
                        END IF;
              END LOOP;
              COMMIT;
--  EXCEPTION
--       WHEN OTHERS THEN
--            MSERROR := SQLERRM;
--            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'PROCESO CORRECCION',RADICADOH,0,'ERROR DE ACTUALIZACION DE ESTADO '||MSERROR, 3);
  END SP_ACTUALIZA_ESTADO_REGISTRO;
END PKG_DS_CORRECCION_DATOS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_ESTANDARIZA_REGISTROS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_ESTANDARIZA_REGISTROS" AS

  /****************************************************************************/
  /*ESTA FUNCION CONSULTA EL SINONIMO ESTANDARIZADO DE UNA PALABRA Y SI LO
    RETORNA EN CASO DE QUE LO ENCUENTRE EN LA TABLA, SINO RETORNA CADENA VACIA.*/
  FUNCTION FT_CONSULTAR_SINONIMO(A_PALABRA VARCHAR2) RETURN VARCHAR2 AS
    V_SINONIMO VARCHAR2(30);
    V_PALABRA VARCHAR2(30);
  BEGIN
    
    V_PALABRA := A_PALABRA;
    --LE QUITO ESPACIOS AL INICIO Y AL FINAL A LA PALABRA QUE ESTAN CONSULTANDO
    V_PALABRA := TRIM(V_PALABRA);
    --PONGO LA PALABRA EN MAYUSCULAS PARA CONSULTARLA
    V_PALABRA := UPPER(V_PALABRA);
    
    BEGIN
      SELECT DSS.SINONIMO
      INTO V_SINONIMO
      FROM DS_SINONIMO_DIRECCION DSS
      WHERE DSS.PALABRA = V_PALABRA;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_SINONIMO := '';
    END;
    
    RETURN V_SINONIMO;
  END FT_CONSULTAR_SINONIMO;
  
  /****************************************************************************/
  /*ESTA FUNCION RETORNA UN 1 SI EL CARACTER ES UN NUMERO Y UN 0 SI NO ES*/
  FUNCTION FT_ES_NUMERO(A_CARACTER VARCHAR2) RETURN NUMBER AS
    V_POSICION NUMBER;
  BEGIN
    
    V_POSICION := 0;
    
    SELECT INSTR('0123456789',A_CARACTER)
    INTO V_POSICION
    FROM DUAL;
    
    IF V_POSICION > 0 THEN
       RETURN 1;
    ELSE
       RETURN 0;
    END IF;
    
  END FT_ES_NUMERO;
  
  /****************************************************************************/
  /*ESTA FUNCION ELIMINA LOS ESPACIOS EN BLANCO DE UNA CADENA DE CARACTERES*/
  FUNCTION FT_ELIMINAR_ESPACIOS(A_CADENA VARCHAR2) RETURN VARCHAR2 AS
    V_CADENA_RETORNO VARCHAR2(200);
    V_POSICION NUMBER;
  BEGIN
    V_CADENA_RETORNO := A_CADENA;
    --CAMBIO TABULACIONES POR ESPACIOS EN BLANCO
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    --ELIMINO ESPACIOS AL INICIO Y AL FINAL
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    
    --BUSCO SI LA CADENA TIENE ESPACIOS EN BLANCO Y LOS VOY ELIMINANDO
    V_POSICION := 0;
    V_POSICION := INSTR(V_CADENA_RETORNO, ' ');
    WHILE V_POSICION <> 0 
    LOOP
      V_CADENA_RETORNO := SUBSTR(V_CADENA_RETORNO, 1 , V_POSICION - 1) || SUBSTR(V_CADENA_RETORNO, V_POSICION + 1 , LENGTH(V_CADENA_RETORNO));
      V_POSICION := 0;
      V_POSICION := INSTR(V_CADENA_RETORNO, ' ');
    END LOOP;
    
    RETURN V_CADENA_RETORNO;
  END FT_ELIMINAR_ESPACIOS;
  
  /****************************************************************************/
  /*ESTA FUNCION ELIMINA LOS CARACTERES ESPECIALES Y LOS REEMPLAZA POR ESPACIO*/
  FUNCTION FT_ELIMINAR_CARACTERES_ESPEC(A_CADENA VARCHAR2, A_TIPO_CADENA VARCHAR2) RETURN VARCHAR2 AS
    /*EL TIPO ME INDICA SI ES CEDULA, TELEFONO, DIRECCION, NOMBRE, APELLIDO PARA
      SABER QUE CARACTERES ESPECIALES SE ADMITEN
      C - CEDULA
      T - TELEFONO
      D - DIRECCION
      N - NOMBRE
      A - APELLIDO*/
    V_CADENA_RETORNO VARCHAR2(1000);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_POSICION NUMBER;
  BEGIN
       
    IF A_CADENA = '' OR A_CADENA IS NULL THEN
      V_CADENA_RETORNO := '';
    END IF;
    
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(A_CADENA);
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := SUBSTR(A_CADENA, V_CONTADOR, 1);
      V_POSICION := 0;
      V_POSICION := INSTR('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ',UPPER(V_CARACTER),1,1);
      IF V_POSICION > 0 THEN
        V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
      ELSE
        CASE A_TIPO_CADENA
          /*WHEN 'C' THEN
            IF V_CARACTER = '-' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            END IF;*/
          WHEN 'T' THEN
            IF V_CARACTER = '(' OR V_CARACTER = ')' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'D' THEN
            IF V_CARACTER = '#' OR V_CARACTER = '�' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'N' THEN
            IF V_CARACTER = '�' OR V_CARACTER = '.' OR V_CARACTER = '&' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          WHEN 'A' THEN
            IF V_CARACTER = '�' THEN
              V_CADENA_RETORNO := V_CADENA_RETORNO || V_CARACTER;
            ELSE
              V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
            END IF;
          ELSE
            V_CADENA_RETORNO := V_CADENA_RETORNO || ' ';
        END CASE;
        
      END IF;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    RETURN V_CADENA_RETORNO;
  END FT_ELIMINAR_CARACTERES_ESPEC;
  
  /****************************************************************************/
  /*ESTA FUNCION TOMA UNA CADENA Y SEPARA LA PARTE NUMERICA DEL TEXTO Y VICEBERSA
    SI LA CADENA TIENE CARACTERES ESPECIALES ESTOS SE TOMAN COMO TEXTO*/
  FUNCTION FT_SEPARAR_PALABRAS_NUMEROS(A_CADENA VARCHAR2) RETURN VARCHAR2 AS
    V_CADENA_RETORNO VARCHAR2(500);
    V_CADENA_RETORNO2 VARCHAR2(500);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_ANTERIOR NUMBER;
    V_POSICION NUMBER;
  BEGIN
    V_CADENA_RETORNO := A_CADENA;
    
    V_CADENA_RETORNO := TRIM(V_CADENA_RETORNO);
    V_CADENA_RETORNO := REPLACE(V_CADENA_RETORNO, CHR(9), ' ');
    /*RECCORRO LA CADENA CARACTER POR CARACTER Y SI CUANDO ENCUENTRE UN CARACTER
      Y UN NUMERO SEGUIDOS LOS SEPARO*/
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(V_CADENA_RETORNO);
    V_ANTERIOR := 0;
    V_CADENA_RETORNO2 := '';
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := SUBSTR(V_CADENA_RETORNO, V_CONTADOR, 1);
      IF FT_ES_NUMERO(V_CARACTER) <> V_ANTERIOR THEN
        V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || ' ' || V_CARACTER;
        V_ANTERIOR := FT_ES_NUMERO(V_CARACTER);
      ELSE
        V_CADENA_RETORNO2 := V_CADENA_RETORNO2 || V_CARACTER;
      END IF;
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    --ELIMINO POSIBLES ESPACIOS AL INICIO Y DOBLES ESPACION
    V_CADENA_RETORNO2 := TRIM(V_CADENA_RETORNO2);
    V_POSICION := 0;
    V_POSICION := INSTR(V_CADENA_RETORNO2, '  ', 1, 1);
    WHILE V_POSICION > 0
    LOOP
      V_CADENA_RETORNO2 := REPLACE(V_CADENA_RETORNO2, '  ', ' ');
      V_POSICION := INSTR(V_CADENA_RETORNO2, '  ', 1, 1);
    END LOOP;
    
    RETURN V_CADENA_RETORNO2;
  END FT_SEPARAR_PALABRAS_NUMEROS;
  
  /****************************************************************************/
  /*ESTA FUNCION CALCULA EL DIGITO DE VERIFICACION DE UN NIT*/
  FUNCTION FT_CALCULAR_DIGITO_VERIFICA(A_NIT NUMBER) RETURN NUMBER AS
    V_DIGITO_VERICACION NUMBER;
    V_DIGITO NUMBER;
    V_NIT NUMBER;
    V_NIT_15 VARCHAR2(15);
    V_CONTADOR NUMBER;
  BEGIN
    V_NIT := A_NIT;
    --TOMO COMO LONGITUD DE CADENA 15 SI NO LOS TIENE COMPLETO CON CEROS A LA IZQUIERDA
    V_NIT_15 := LPAD(TO_CHAR(V_NIT),15,'0');
    V_CONTADOR := 1;
    V_DIGITO_VERICACION := 0;
    --REALIZO EL CALCULO DEL DIGITO DE VERIFICACION
    WHILE V_CONTADOR <= 15
    LOOP
      V_DIGITO := TO_NUMBER(SUBSTR(V_NIT_15,V_CONTADOR,1));
      CASE V_CONTADOR
        WHEN 1 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 71);
        WHEN 2 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 67);
        WHEN 3 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 59);
        WHEN 4 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 53);
        WHEN 5 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 47);
        WHEN 6 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 43);
        WHEN 7 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 41);
        WHEN 8 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 37);
        WHEN 9 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 29);
        WHEN 10 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 23);
        WHEN 11 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 19);
        WHEN 12 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 17);
        WHEN 13 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 13);
        WHEN 14 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 7);
        WHEN 15 THEN
          V_DIGITO_VERICACION := V_DIGITO_VERICACION + (V_DIGITO * 3);
        ELSE
          NULL;
      END CASE;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    V_DIGITO_VERICACION := MOD(V_DIGITO_VERICACION, 11);
    IF V_DIGITO_VERICACION > 1 THEN
      V_DIGITO_VERICACION := 11 - V_DIGITO_VERICACION;
    END IF;
    
    RETURN V_DIGITO_VERICACION;
  END FT_CALCULAR_DIGITO_VERIFICA;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA EL NUMERO DE IDENTIFICACION*/
  FUNCTION FT_ESTANDARIZAR_IDENTIFICACION(A_IDENTIFICACION VARCHAR2, A_ID_DOCUMENTO VARCHAR2) RETURN VARCHAR2 AS
    V_IDENTIFICACION_RETORNO VARCHAR2(15);
    V_CARACTER VARCHAR2(1);
    V_LONGITUD NUMBER;
    V_CONTADOR NUMBER;
    V_DIGITO_VERIFICACION NUMBER;
    V_EXCEPCION BOOLEAN;
  BEGIN 
    V_IDENTIFICACION_RETORNO := A_IDENTIFICACION;
    --ELIMINO LOS CARACTERES ESPECIALES
    V_IDENTIFICACION_RETORNO := FT_ELIMINAR_CARACTERES_ESPEC(V_IDENTIFICACION_RETORNO, 'C');
    --ELIMINO ESPACIOS EN BLANCO
    V_IDENTIFICACION_RETORNO := FT_ELIMINAR_ESPACIOS(V_IDENTIFICACION_RETORNO);
    
    V_EXCEPCION := FALSE;
    V_CONTADOR := 1;
    V_LONGITUD := LENGTH(V_IDENTIFICACION_RETORNO);
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      --VERIFICO QUE NO CONTENGA LETRAS
      V_CARACTER := SUBSTR(V_IDENTIFICACION_RETORNO, V_CONTADOR, 1);
      IF FT_ES_NUMERO(V_CARACTER) = 0 THEN
        V_EXCEPCION := TRUE;
      END IF;
      
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    --REALIZO VALIDACIONES DE NIT, SI NO TIENE DIGITO DE VERIFICACION LO CALCULO
    IF A_ID_DOCUMENTO = '2' AND NOT V_EXCEPCION THEN
      --SI SOLO TIENE 9 DIGITOS CALCULO EL DIGITO DE VERIFICACION
      IF LENGTH(V_IDENTIFICACION_RETORNO) = 9 THEN
        V_DIGITO_VERIFICACION := FT_CALCULAR_DIGITO_VERIFICA(TO_NUMBER(V_IDENTIFICACION_RETORNO));
        V_IDENTIFICACION_RETORNO := V_IDENTIFICACION_RETORNO || TO_CHAR(V_DIGITO_VERIFICACION);
      END IF;
    END IF;
    
    RETURN V_IDENTIFICACION_RETORNO;
  END FT_ESTANDARIZAR_IDENTIFICACION;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA EL NUMERO DE TELEFONO */
  FUNCTION FT_ESTANDARIZAR_TELEFONO(A_TELEFONO VARCHAR2) RETURN VARCHAR2 AS
    V_TELEFONO_RETORNO VARCHAR2(30);
    V_TELEFONO_TEMP VARCHAR2(30);
    V_POSICION NUMBER;
    V_SINONIMO VARCHAR2(30);
    V_PALABRA VARCHAR2(30);
  BEGIN
    V_TELEFONO_TEMP := A_TELEFONO;
    
    --ELIMINO CARACTERES ESPECIALES
    V_TELEFONO_TEMP := FT_ELIMINAR_CARACTERES_ESPEC(V_TELEFONO_TEMP, 'T');
    --ELIMINO LOS ESPACIOS EN BLANCO
    V_TELEFONO_TEMP := FT_ELIMINAR_ESPACIOS(V_TELEFONO_TEMP);
    --SEPARO LETRAS DE NUMEROS
    V_TELEFONO_TEMP := FT_SEPARAR_PALABRAS_NUMEROS(V_TELEFONO_TEMP);
       
    --QUITO ESPACIOS AL INICIO Y AL FINAL.
    V_TELEFONO_TEMP := TRIM(V_TELEFONO_TEMP);
    V_TELEFONO_RETORNO := '';
    V_POSICION := 0;
    WHILE LENGTH(V_TELEFONO_TEMP) > 0
    LOOP
      V_SINONIMO := '';
      V_PALABRA := '';
      V_POSICION := INSTR(V_TELEFONO_TEMP,' ', 1, 1);
      IF V_POSICION > 0 THEN
        V_PALABRA := SUBSTR(V_TELEFONO_TEMP, 1, V_POSICION - 1);
        V_TELEFONO_TEMP := SUBSTR(V_TELEFONO_TEMP, V_POSICION + 1, LENGTH(V_TELEFONO_TEMP));
      ELSE
        V_PALABRA := V_TELEFONO_TEMP;
        V_TELEFONO_TEMP := '';
      END IF;
      
      V_PALABRA := UPPER(V_PALABRA);
      IF V_PALABRA IN ('E','EX','EXT') THEN
        IF V_TELEFONO_TEMP IS NOT NULL THEN
          V_TELEFONO_RETORNO := V_TELEFONO_RETORNO || ' ' || 'EXT';
        END IF;
      ELSE
        V_TELEFONO_RETORNO := V_TELEFONO_RETORNO || ' ' || V_PALABRA;
      END IF;
    END LOOP;
    --ELIMINO POSIBLES ESPACIOS EN BLANCO AL INICIO Y AL FINAL
    V_TELEFONO_RETORNO := FT_ELIMINAR_ESPACIOS(V_TELEFONO_RETORNO);
    
    --SI TIENE PARENTESIS ESTOS NO DEBEN QUEDAR SEPARADOS DE LOS NUMERO
    V_TELEFONO_RETORNO := REPLACE(V_TELEFONO_RETORNO,'( ', '(');
    V_TELEFONO_RETORNO := REPLACE(V_TELEFONO_RETORNO,' )', ')');
    
    IF LENGTH(V_TELEFONO_RETORNO) > 14 THEN
      V_POSICION := INSTR(V_TELEFONO_RETORNO, 'EXT');
      V_TELEFONO_RETORNO := SUBSTR(V_TELEFONO_RETORNO, 1, V_POSICION - 1);
    END IF;
    
    RETURN V_TELEFONO_RETORNO;
  END FT_ESTANDARIZAR_TELEFONO;
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA LOS NOMBRES Y APELLIDOS EL PARAMETRO A_TIPO INDICA
    SI ES NOMBRE O APELLIDO N - NOMBRE, A - APELLIDO*/
  
  FUNCTION FT_ESTANDARIZAR_NOM_APE(A_NOMBRE_APELLIDO VARCHAR2, A_TIPO VARCHAR) RETURN VARCHAR2 AS
    V_NOM_APE_RETORNO VARCHAR2(80);
    V_POSICION NUMBER;
  BEGIN
    V_NOM_APE_RETORNO := A_NOMBRE_APELLIDO;
    
    --ELIMINO TILDES Y �'S
    V_NOM_APE_RETORNO := TRANSLATE(V_NOM_APE_RETORNO, '����������������������', 'AEIOUAEIOUAEIOUAEIOUNN');
    --PERMITO LOS CARACTERES ' PERO COMO �
    V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, '''', '�');
    --ELIMINO LOS CARACTERES ESPECIALES
    V_NOM_APE_RETORNO := FT_ELIMINAR_CARACTERES_ESPEC(V_NOM_APE_RETORNO, A_TIPO);
    --ELIMINO CUANDO HALLAN 2 ESPACIOS SEGUIDOS
    V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, CHR(9), ' ');
    V_POSICION := 0;
    V_POSICION := INSTR(V_NOM_APE_RETORNO, '  ', 1, 1);
    WHILE V_POSICION > 0
    LOOP
      V_NOM_APE_RETORNO := REPLACE(V_NOM_APE_RETORNO, '  ', ' ');
      V_POSICION := INSTR(V_NOM_APE_RETORNO, '  ', 1, 1);
    END LOOP;
    
    --ELIMINO ESPCIOS EN BLANCO AL INICIO Y L FINAL.
    V_NOM_APE_RETORNO := TRIM(V_NOM_APE_RETORNO);
    --LO PONGO EN MAYUSCULAS
    V_NOM_APE_RETORNO := UPPER(V_NOM_APE_RETORNO);
    RETURN V_NOM_APE_RETORNO;
  END FT_ESTANDARIZAR_NOM_APE;
  
  
  /****************************************************************************/
  /*ESTA FUNCION ESTANDARIZA LA DIRECCION*/
  FUNCTION FT_ESTANDARIZAR_DIRECCION(A_DIRECCION VARCHAR2) RETURN VARCHAR2 AS
    V_DIRECCION_RETORNO VARCHAR2(100);
    V_DIRECCION_RETORNO_TEMP VARCHAR2(100);
    V_PALABRA VARCHAR2(30);
    V_SINONIMO VARCHAR2(30);
    V_POSICION NUMBER;
  BEGIN
    V_DIRECCION_RETORNO_TEMP := A_DIRECCION;
    
    --ELIMINO TILDES Y �'S
    V_DIRECCION_RETORNO_TEMP := TRANSLATE(V_DIRECCION_RETORNO_TEMP, '����������������������', 'AEIOUAEIOUAEIOUAEIOUNN');
    --ELIMINO CARACTERES ESPECIALES
    V_DIRECCION_RETORNO_TEMP := FT_ELIMINAR_CARACTERES_ESPEC(V_DIRECCION_RETORNO_TEMP,'D');
    --SEPARO LOS NUMEROS DEL TEXTO
    V_DIRECCION_RETORNO_TEMP := FT_SEPARAR_PALABRAS_NUMEROS(V_DIRECCION_RETORNO_TEMP);
    
    --QUITO ESPACIOS AL INICIO Y AL FINAL.
    V_DIRECCION_RETORNO_TEMP := TRIM(V_DIRECCION_RETORNO_TEMP);
    V_DIRECCION_RETORNO := '';
    V_POSICION := 0;
    WHILE LENGTH(V_DIRECCION_RETORNO_TEMP) > 0
    LOOP
      V_SINONIMO := '';
      V_PALABRA := '';
      V_POSICION := INSTR(V_DIRECCION_RETORNO_TEMP,' ', 1, 1);
      IF V_POSICION > 0 THEN
        V_PALABRA := SUBSTR(V_DIRECCION_RETORNO_TEMP, 1, V_POSICION - 1);
        V_DIRECCION_RETORNO_TEMP := SUBSTR(V_DIRECCION_RETORNO_TEMP, V_POSICION + 1, LENGTH(V_DIRECCION_RETORNO_TEMP));
      ELSE
        V_PALABRA := V_DIRECCION_RETORNO_TEMP;
        V_DIRECCION_RETORNO_TEMP := '';
      END IF;
      
      V_SINONIMO := FT_CONSULTAR_SINONIMO(V_PALABRA);
      IF V_SINONIMO = '' OR V_SINONIMO IS NULL THEN
        V_DIRECCION_RETORNO := V_DIRECCION_RETORNO || ' ' || V_PALABRA;
      ELSE
        V_DIRECCION_RETORNO := V_DIRECCION_RETORNO || ' ' || V_SINONIMO;
      END IF;
    END LOOP;
    --ELIMINO POSIBLES ESPACIOS EN BLANCO AL INICIO Y AL FINAL
    V_DIRECCION_RETORNO := TRIM(V_DIRECCION_RETORNO);
    --LA PONGO EN MAYUSCULAS
    V_DIRECCION_RETORNO := UPPER(V_DIRECCION_RETORNO);
    RETURN V_DIRECCION_RETORNO;
  END FT_ESTANDARIZAR_DIRECCION;
  
  /****************************************************************************/
  /*ESTE PROCESDIMIENTO RECUPERA LA LISTA DE CONTRIBUYENTES DE UN RADICADO 
    PASADO COMO PARAMETRO Y LE REALIZA LA ESTANDARIZACION DE LOS DATOS*/
PROCEDURE SP_ESTANDARIZAR_RADICADO(A_ID_RADICADO NUMBER) IS
    
    CURSOR CONTRIBUYENTES(V_RAD NUMBER) IS
    SELECT  DSC.NRO_IDENTIFICADOR,
            DSC.ID_USUARIO,
            DSC.ID_DOCUMENTO,
            DSC.TELEFONO,
            DSC.NOMBRES,
            DSC.APELLIDOS,
            DSC.DIRECCION
    FROM DEPURACION.DS_CONTRIBUYENTE DSC
    WHERE DSC.ID_RADICADO = V_RAD
      AND DSC.ESTADO_VALIDACION = 'VP';
      
      
    CURSOR DIRECCIONES(IDRADICADO NUMBER) IS
         SELECT * FROM DEPURACION.DS_DIRECCIONES
           WHERE ID_RADICADO = IDRADICADO
                 AND ESTADO_VALIDACION = 'VP';
    
    V_ID_USUARIO_ESTANDARIZADO VARCHAR2(15);
    V_TELEFONO_ESTANDARIZADO   VARCHAR2(14);
    V_FAX_ESTANDARIZADO        VARCHAR2(14);
    V_NOMBRES_ESTANDARIZADO    VARCHAR2(80);
    V_APELLIDOS_ESTANDARIZADO  VARCHAR2(80);
    V_DIRECCION_ESTANDARIZADO  VARCHAR2(100);
    V_ERROR                    VARCHAR2(200);

    V_EXISTE                   NUMBER := 0;
    V_CONTADOR_COMMIT          NUMBER := 0;
    V_ID_REGISTRO              NUMBER := 0;    
    --CONTROL_REGISTRO UTL_FILE.FILE_TYPE;
    
  BEGIN
    V_CONTADOR_COMMIT := 0;
    
    --POR CADA CONTRIBUYENTE DE ESTE RADICADO REALIZO LA ESTANDARIZACION DE LOS DATOS
    FOR X IN CONTRIBUYENTES(A_ID_RADICADO) LOOP
         BEGIN
         
            V_CONTADOR_COMMIT := V_CONTADOR_COMMIT + 1;
            
            --ESTANDARIZO IDENTIFICACION, TELEFONO, NOMBRES, APELLIDOS, DIRECCION.
            V_ID_USUARIO_ESTANDARIZADO := FT_ESTANDARIZAR_IDENTIFICACION(X.ID_USUARIO, X.ID_DOCUMENTO);
            V_TELEFONO_ESTANDARIZADO := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_NOMBRES_ESTANDARIZADO := FT_ESTANDARIZAR_NOM_APE(X.NOMBRES, 'N');
            V_APELLIDOS_ESTANDARIZADO := FT_ESTANDARIZAR_NOM_APE(X.APELLIDOS, 'A');
            V_DIRECCION_ESTANDARIZADO := FT_ESTANDARIZAR_DIRECCION(X.DIRECCION);
            
            V_EXISTE := 0;
            V_ID_REGISTRO := X.NRO_IDENTIFICADOR;
            
            --VERIFICO SI EL REGISTRO YA EXISTE EN LA TABLA DE CONTRIBUYENTES ESTANDARIZADOS
            SELECT COUNT(1)
            INTO V_EXISTE
            FROM DEPURACION.DS_CONTRIBUYENTE_ESTANDAR DSCE
               INNER JOIN DEPURACION.DS_CONTRIBUYENTE DC ON DC.NRO_IDENTIFICADOR = DSCE.NRO_IDENTIFICADOR
            WHERE DSCE.NRO_IDENTIFICADOR = X.NRO_IDENTIFICADOR
              AND DC.ID_RADICADO = A_ID_RADICADO;
            
            DELETE FROM DEPURACION.DS_CONTRIBUYENTE_ESTANDAR WHERE ID_USUARIO = X.ID_USUARIO AND ID_DOCUMENTO = X.ID_DOCUMENTO AND NRO_IDENTIFICADOR <> X.NRO_IDENTIFICADOR;
            --SI YA EXISTE ACTUALIZO, SINO INSERTO
            IF V_EXISTE > 0 then
              
              UPDATE DEPURACION.DS_CONTRIBUYENTE_ESTANDAR
              SET ID_USUARIO = V_ID_USUARIO_ESTANDARIZADO,
                  TELEFONO = V_TELEFONO_ESTANDARIZADO,
                  NOMBRES = V_NOMBRES_ESTANDARIZADO,
                  APELLIDOS = V_APELLIDOS_ESTANDARIZADO,
                  DIRECCION = V_DIRECCION_ESTANDARIZADO
              WHERE NRO_IDENTIFICADOR = X.NRO_IDENTIFICADOR;
            ELSE              

              INSERT INTO DEPURACION.DS_CONTRIBUYENTE_ESTANDAR
                      (NRO_IDENTIFICADOR,
											ID_DOCUMENTO,
                      ID_USUARIO,
                      TELEFONO,
                      NOMBRES,
                      APELLIDOS,
                      DIRECCION)
              VALUES  (X.NRO_IDENTIFICADOR,
											X.ID_DOCUMENTO,
                      V_ID_USUARIO_ESTANDARIZADO,
                      V_TELEFONO_ESTANDARIZADO,
                      V_NOMBRES_ESTANDARIZADO,
                      V_APELLIDOS_ESTANDARIZADO,
                      V_DIRECCION_ESTANDARIZADO);
            END IF;            
            COMMIT;            
         EXCEPTION
            WHEN OTHERS THEN
            V_ERROR := SQLERRM;
            INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,
                                                                        2,
                                                                        A_ID_RADICADO,
                                                                        V_ID_REGISTRO,
                                                                        V_ERROR, 4
                                                                       );
            UPDATE DEPURACION.DS_CONTRIBUYENTE SET ESTADO_VALIDACION = 'RE'
                   WHERE NRO_IDENTIFICADOR = V_ID_REGISTRO
                     AND ID_RADICADO = A_ID_RADICADO;
              
            COMMIT;
         END;
    END LOOP;

    V_CONTADOR_COMMIT := 0;
    FOR X IN DIRECCIONES(A_ID_RADICADO) LOOP
        
            V_CONTADOR_COMMIT := V_CONTADOR_COMMIT + 1;
            
            --ESTANDARIZO IDENTIFICACION, TELEFONO, NOMBRES, APELLIDOS, DIRECCION.
            --V_ID_USUARIO_ESTANDARIZADO := FT_ESTANDARIZAR_IDENTIFICACION(X.ID_USUARIO, X.ID_DOCUMENTO);
            V_TELEFONO_ESTANDARIZADO  := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_FAX_ESTANDARIZADO       := FT_ESTANDARIZAR_TELEFONO(X.TELEFONO);
            V_DIRECCION_ESTANDARIZADO := FT_ESTANDARIZAR_DIRECCION(X.DIRECCION);
            
            V_EXISTE := 0;
            V_ID_REGISTRO := X.ID_DIRECCION;           

              UPDATE DEPURACION.DS_DIRECCIONES
              SET TELEFONO = V_TELEFONO_ESTANDARIZADO,
                  DIRECCION = V_DIRECCION_ESTANDARIZADO,
                  FAX = V_FAX_ESTANDARIZADO
              WHERE ID_DIRECCION = X.ID_DIRECCION;

            IF (V_CONTADOR_COMMIT = 500 ) THEN
                COMMIT;
                V_CONTADOR_COMMIT := 0;
            END IF;
    END LOOP;
    COMMIT;
    
  END SP_ESTANDARIZAR_RADICADO;

END PKG_DS_ESTANDARIZA_REGISTROS;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_VALIDACIONES_REGISTRO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_VALIDACIONES_REGISTRO" 
AS

/*
=======================================================================================================================
=======================================================================================================================

                                    VALIDACIONES DE NEGOCIO PARA VEHICULOS

=======================================================================================================================
=======================================================================================================================
*/

  /****************************************************************************/
  /*ESTA FUNCION VERIFICA SI LA PLACA YA EXISTE EN LA BD.*/
  FUNCTION FT_EXISTE_VEHICULO(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    VERR BOOLEAN;
  BEGIN
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM QUIPUX.LIC_TTO
    WHERE NRO_PLACA = A_NRO_PLACA;

    IF V_EXISTE = 0 THEN
        RETURN FALSE;
    ELSE
        RETURN TRUE;
    END IF;
  
  END FT_EXISTE_VEHICULO;

  /****************************************************************************/
  /*ESTA FUNCION VERIFICA SI LA PLACA SI REPORTA UN PROPIETARIO.*/
--  FUNCTION FT_REPORTA_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER,A_ID_USUARIO VARCHAR2, A_ID_DOCUMENTO NUMBER) RETURN BOOLEAN AS
  FUNCTION FT_REPORTA_PROPIETARIO(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
            
    V_EXISTE NUMBER := 0;
    V_VALIDA NUMBER := 0;
    V_ID_USUARIO VARCHAR2(15);
    PARAMETRO VARCHAR2(2);
    CURSOR TRAMITE_PROPIETARIO
       IS SELECT ID_TRAMITE, ID_DOCUMENTO_NUEVO, ID_USUARIO_NUEVO FROM DEPURACION.DS_TRAMITE
          WHERE ID_RADICADO = NRADICADO AND NRO_PLACA = A_NRO_PLACA AND ID_TRAMITE = 16;
  BEGIN
    --VERIFICO SI EN ESTE RADICADO TAMBIEN SE REPORTO EL PROPIETARIO DEL VEHICULO
    
    FOR XPROPIE IN TRAMITE_PROPIETARIO LOOP
    
        IF XPROPIE.ID_TRAMITE <> 65 THEN --CONTRIBUYENTE SE VALIDA SI EL TRAMITE ES DIFERENTE A TRASPASO INDETERMINADO
            SELECT VALOR INTO PARAMETRO FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO
               WHERE ID_PROCESO = 38 AND ID_PARAMETRO = 134;
            IF ( PARAMETRO = 'N') THEN
                      SELECT COUNT(1)
                      INTO V_VALIDA
                      FROM DEPURACION.DS_PROPIETARIO DSP
                      WHERE DSP.NRO_PLACA = A_NRO_PLACA AND
                            DSP.ID_RADICADO = NRADICADO AND
                            ID_USUARIO = XPROPIE.ID_USUARIO_NUEVO AND
                            ID_DOCUMENTO = XPROPIE.ID_DOCUMENTO_NUEVO;
                       
                      IF V_VALIDA = 0 THEN        
                          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 87);
                          V_EXISTE := 1;
                      END IF;            
  
                      SELECT COUNT(1) INTO V_VALIDA
                          FROM DEPURACION.DS_CONTRIBUYENTE DSC 
                          INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DP.ID_DOCUMENTO = DSC.ID_DOCUMENTO AND DP.ID_USUARIO = DSC.ID_USUARIO)
                          WHERE DP.ID_USUARIO = XPROPIE.ID_USUARIO_NUEVO AND
                                DP.ID_DOCUMENTO = XPROPIE.ID_DOCUMENTO_NUEVO AND
                                DP.ID_RADICADO = NRADICADO AND
                                DP.NRO_PLACA = A_NRO_PLACA;

                      IF V_VALIDA = 0 THEN        
                          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 88);
                          V_EXISTE := 1;
                      END IF;

            ELSE
                      SELECT COUNT(1)
                      INTO V_VALIDA
                      FROM DEPURACION.DS_PROPIETARIO DSP
                      WHERE DSP.NRO_PLACA = A_NRO_PLACA AND
                            DSP.ID_RADICADO = NRADICADO AND
                            ID_USUARIO = XPROPIE.ID_USUARIO_NUEVO AND
                            ID_DOCUMENTO = XPROPIE.ID_DOCUMENTO_NUEVO;
                       
                      IF V_VALIDA = 0 THEN        
                          IF NOT FT_EXISTE_USUARIO_PROPIETARIO(NULL, XPROPIE.ID_DOCUMENTO_NUEVO, XPROPIE.ID_USUARIO_NUEVO, 'U') THEN
                                 SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 87);
                                 SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 88);
                                 V_EXISTE := 1;
                          END IF;
                      END IF;            

            END IF;
        END IF;
    END LOOP;
    
    IF ( V_EXISTE = 1 ) THEN
         RETURN TRUE;
    ELSE
         RETURN FALSE;
    END IF;
      
  END FT_REPORTA_PROPIETARIO;
  
  /****************************************************************************/
  /*ESTA FUNCION VERIFICA SI PARA ESTA PLACA SE REPORTO ALMENOS UN TRAMITE EN
    ESTE RADICADO*/
  FUNCTION FT_REPORTA_TRAMITE(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    --VARIFICO QUE TENGA AL MENOS UN TRAMITE
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM DS_TRAMITE DST
    WHERE DST.NRO_PLACA = A_NRO_PLACA AND
          DST.ID_RADICADO = A_RADICADO;
          
    IF V_EXISTE > 0 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_REPORTA_TRAMITE;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA SI PARA ESTA PLACA SE REPORTO EL TRAMITE DE CANCELACION*/
  FUNCTION FT_REPORTA_TRAMITE_X_TIPO(A_NRO_PLACA VARCHAR2, A_RADICADO NUMBER, A_TIPO_TRAMITE NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    --VARIFICO SI PARA ESTA PLACA EN ESTE RADICADO SE REPORTO TRAMITE DE CANCELACION
    BEGIN
      SELECT COUNT(1)
      INTO V_EXISTE
      FROM DS_TRAMITE DST
      WHERE DST.NRO_PLACA = A_NRO_PLACA AND
            DST.ID_RADICADO = A_RADICADO AND
            DST.ID_TRAMITE = A_TIPO_TRAMITE;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_EXISTE := 0;
    END;
    
    IF V_EXISTE > 0 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_REPORTA_TRAMITE_X_TIPO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL FORMATO DE LA PLACA*/
  FUNCTION FT_VALIDAR_PLACA(A_NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
    V_PLACA VARCHAR(7);
    V_EXISTE NUMBER := 0;
  BEGIN
    V_PLACA := A_NRO_PLACA;  
    --LA PONGO EN MAYUSCULA
    V_PLACA := UPPER(V_PLACA);
    
    --REMPLAZO CARACTERES LETRAS POR "~" Y NUMEROS POR "@" PARA COMPARAR MAS FACILMENTE EL FORMATO
    V_PLACA := TRANSLATE(V_PLACA,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
    V_PLACA := TRANSLATE(V_PLACA,'0123456789','@@@@@@@@@@');
    
    --DENTRO DEL RESULTADO BUSCO UNO DE LOS FORMATOS VALIDOS
    IF V_PLACA NOT IN ('~~~@@@', '~~~@@','~~~@@~', '~~@@@@', '~~@@@','@@@~~~') THEN
      V_EXISTE := 1;
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
		  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 1);
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_PLACA;

  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL COMBUSTIBLE SI ES ELECTRICO SE VALIDA LA BATERIAO*/
FUNCTION FT_VALIDAR_COMBUSTIBLE(A_ID_COMBUSTIBLE NUMBER, A_ID_BATERIA NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN AS
  VEXISTE NUMBER := 0;
  VVALIDA NUMBER := 0;
BEGIN
  IF ( A_ID_COMBUSTIBLE = 5 ) AND (A_ID_CLASE = 10) THEN
     IF ( A_ID_BATERIA IS NULL ) THEN
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 70);
        VEXISTE := 1;
     ELSE
        SELECT COUNT(1) INTO VVALIDA FROM QUIPUX.TIPO_BATERIA WHERE ID_BATERIA = A_ID_BATERIA;
        IF VVALIDA = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 10);
            VEXISTE := 1;
        END IF;
    END IF;
  END IF;
  
  IF VEXISTE = 1 THEN
      RETURN TRUE;
  ELSE
      RETURN FALSE;
  END IF;
END;

  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL CODIGO DEL SERVICIO*/
  FUNCTION FT_VALIDAR_MODELO(A_MODELO NUMBER) RETURN BOOLEAN AS
     V_EXISTE NUMBER := 0;
  BEGIN
    --VALIDO QUE SEA MAYOR A 1900 Y MENOR AL A�O ACTUAL + 1
    IF A_MODELO <= 1900 OR A_MODELO > (TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) + 1) THEN
      V_EXISTE := 1;
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
			SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 57);
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_MODELO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO IMPORTADO/NACIONAL*/
  FUNCTION FT_VALIDAR_IMPORTADO_NACIONAL(A_IMPORTADO_NACIONAL VARCHAR2) RETURN BOOLEAN AS
     V_EXISTE NUMBER := 0;
  BEGIN
       
    --VALIDO QUE EL DATO SEA I O N
    IF A_IMPORTADO_NACIONAL NOT IN ('I','N') THEN
      V_EXISTE := 1;
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
			SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 11);		
      RETURN TRUE;
    ELSE      
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_IMPORTADO_NACIONAL;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL ESTADO REPORTADO*/
  FUNCTION FT_VALIDAR_ESTADO(A_ESTADO NUMBER, I_PLACA VARCHAR2, I_RADICADO NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    --VALIDO LOS ESTADOS
    IF A_ESTADO = 12 THEN
        --ESTADO CANCELADO VALIDO QUE SE HAYA REPORTADO LA CANCELACION
        IF NOT FT_REPORTA_TRAMITE_X_TIPO(I_PLACA, I_RADICADO, 20) THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 12);
            V_EXISTE := 1;
        END IF;
/*      WHEN 9 THEN
        V_ID_ESTADO := 9;
        --ESTADO TRASLADADO VALIDO QUE SE HAYA REPORTADO EL TRASLADO
        IF NOT FT_REPORTA_TRAMITE_X_TIPO(I_PLACA, I_RADICADO, 15) THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 13);
            V_EXISTE := 1;
        END IF;
			ELSE
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 14);
            V_EXISTE := 1;	*/		   
    END IF;
    
    IF ( V_EXISTE = 1 ) THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_ESTADO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL VALOR DE LA FACTURA*/
  FUNCTION FT_VALIDAR_VALOR_FACTURA(A_VALOR_FACTURA NUMBER, A_MODELO NUMBER, NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
  V_EXISTE NUMBER := 0;
  BEGIN

    IF NOT FT_EXISTE_VEHICULO(NRO_PLACA) AND A_VALOR_FACTURA <> 1 THEN

        --VALIDO DATO OBLIGATORIO PARA A�O ACTUAL Y A�O ACTUAL + 1
        IF A_MODELO >= (TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))) THEN
            --VALIDO QUE EL VALOR NO TENGA MENOS DE 7 NI MAS DE 10 DIGITOS
            IF (LENGTH(TO_CHAR(A_VALOR_FACTURA)) < 7) OR (LENGTH(TO_CHAR(A_VALOR_FACTURA)) > 10) THEN
              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 9);
              V_EXISTE := 1;
            END IF;
            
            IF A_VALOR_FACTURA IS NULL THEN
                SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 2);
                V_EXISTE := 1;
            END IF;
        END IF;          

    END IF;
    
    IF V_EXISTE = 1 THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;

  END FT_VALIDAR_VALOR_FACTURA;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO CLASICO/ANTIGUO*/
  FUNCTION FT_VALIDAR_CLASICO_ANTIGUO(A_CLASICO_ANTIGUO VARCHAR2, A_NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
    V_CLASICO_ANTIGUO VARCHAR2(1);
    V_EXISTE NUMBER := 0;
    V_TRAMITE BOOLEAN;
    V_CLASICO_ANTIGUO_TRAMITE VARCHAR2(1);
  BEGIN
    
    IF ( DTIPOREGISTRO IN (1,4) ) THEN
        IF A_CLASICO_ANTIGUO IS NULL THEN
          V_CLASICO_ANTIGUO := 'N';
        ELSE
          V_CLASICO_ANTIGUO := A_CLASICO_ANTIGUO;
        END IF;
        --VALIDO QUE TENGA UN DATO VALIDO
        IF V_CLASICO_ANTIGUO NOT IN ('C','A','N') THEN
          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 15);
          V_EXISTE := 1;
        END IF;
     END IF;

    IF ( DTIPOREGISTRO = 4 ) THEN     
        IF ( V_CLASICO_ANTIGUO <> 'N' ) THEN
             SELECT CLASICO_ANTIGUO INTO V_CLASICO_ANTIGUO_TRAMITE FROM DEPURACION.DS_VEHICULO WHERE ID_RADICADO = NRADICADO AND NRO_PLACA = A_NRO_PLACA;
             IF ( V_CLASICO_ANTIGUO_TRAMITE <> V_CLASICO_ANTIGUO ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 94);
                  V_EXISTE := 1;          
            END IF;
        END IF;
    END IF;
    
    IF ( V_EXISTE = 1 ) THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
  END FT_VALIDAR_CLASICO_ANTIGUO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO DEL CILINDRAJE SEGUN LA CLASE RUNT*/
  FUNCTION FT_VALIDAR_CILINDRAJE(A_CILINDRAJE NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN AS
    V_VALIDA NUMBER := 0;
    V_EXISTE NUMBER := 0;
  BEGIN
   
    V_VALIDA := 0;
    --VALIDO QUE EL CILINDRAJE ESTE DENTRO DEL RANGO VALIDO
    SELECT COUNT(1)
    INTO V_VALIDA
    FROM DS_RUNT_RANGOS_X_CLASE DSR
    WHERE DSR.ID_CLASE = TO_CHAR(A_ID_CLASE) AND
          DSR.CILINDRAJE_MINIMO <= A_CILINDRAJE AND
          DSR.CILINDRAJE_MAXIMO >= A_CILINDRAJE;
    
    --SI NO ESTA DENTRO DEL RANGO GENERO LA EXCEPCION      
    IF V_VALIDA = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 58);
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_CILINDRAJE;
 
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL NRO DE PUERTAS*/
  FUNCTION FT_VALIDAR_PUERTAS(A_NRO_PUERTAS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN AS
    V_VALIDA NUMBER := 0;
    V_NRO_PUERTAS NUMBER := 0;
    V_EXISTE NUMBER := 0;
  BEGIN
    
    IF A_NRO_PUERTAS IS NULL THEN
      V_NRO_PUERTAS := 0;
    ELSE
      V_NRO_PUERTAS := A_NRO_PUERTAS;
    END IF;
    
    --VALIDO QUE EL NUMERO DE PUERTAS NO SEA MENOR QUE CERO
    IF V_NRO_PUERTAS < 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 4);
      V_EXISTE := 1;
    END IF;
    
    V_VALIDA := 0;
    --VALIDO QUE LAS PUERTAS SEA VALIDO PARA LA CLASE DEL VEHICULO
    SELECT COUNT(1)
    INTO V_VALIDA
    FROM DS_RUNT_RANGOS_X_CLASE DSR
    WHERE DSR.ID_CLASE = TO_CHAR(A_ID_CLASE) AND
          DSR.MAXIMO_PUERTAS >= V_NRO_PUERTAS;
    
    --SI NO ESTA DENTRO DEL RANGO GENERO LA EXCEPCION      
    IF V_VALIDA = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 3);
      V_EXISTE := 1;
    END IF;
    
    IF ( V_EXISTE = 1 ) THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;

  END FT_VALIDAR_PUERTAS;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA LA CAPACIDAD DE TONELADAS*/
  FUNCTION FT_VALIDAR_TONELADAS(A_CAP_TONELADAS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN AS
    V_VALIDA NUMBER;
    V_KILOS NUMBER;
    V_CAP_TONELADAS NUMBER;
    V_EXISTE NUMBER := 0;
    
  BEGIN
    
    --VALIDO DATO OBLIGATORIO
    IF A_CAP_TONELADAS IS NULL THEN
      V_CAP_TONELADAS := 0;
    ELSE
      V_CAP_TONELADAS := A_CAP_TONELADAS;
    END IF;
    
    --VALIDO QUE LA CAPACIDAD DE TONELADAS NO SEA MENOR QUE CERO
    IF V_CAP_TONELADAS < 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 8);
      V_EXISTE := 1;
    END IF;
    
    V_VALIDA := 0;
    --EN LA TABLA ESTA ALMACENADA EN KILOS
    V_KILOS := V_CAP_TONELADAS;
    --VALIDO QUE LA CAPACIDAD DE TONELADAS ESTE DENTRO DEL RANGO VALIDO
    SELECT COUNT(1)
    INTO V_VALIDA
    FROM DS_RUNT_RANGOS_X_CLASE DSR
    WHERE DSR.ID_CLASE = TO_CHAR(A_ID_CLASE) AND
          DSR.MAXIMO_KILOGRAMOS >= V_KILOS;
    
    --SI NO ESTA DENTRO DEL RANGO GENERO LA EXCEPCION      
    IF V_VALIDA = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 7);
      V_EXISTE := 1;
    END IF;
    
    IF ( V_EXISTE = 1 ) THEN
       RETURN TRUE;
    ELSE
       RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_TONELADAS;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA LA CAPACIDAD DE PASAJEROS*/
  FUNCTION FT_VALIDAR_PASAJEROS(A_CAP_PASAJEROS NUMBER, A_ID_CLASE NUMBER) RETURN BOOLEAN AS
    V_VALIDA NUMBER := 0;
    V_EXISTE NUMBER := 0;
  BEGIN
   
    --VALIDO QUE LA CAPACIDAD DE PASAJEROS NO SEA MENOR QUE CERO
    IF A_CAP_PASAJEROS < 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 6);
      V_EXISTE := 1;
    END IF;
    
    V_VALIDA := 0;
    --VALIDO QUE LA CAPACIDAD DE PASAJEROS ESTE DENTRO DEL RANGO VALIDO
    SELECT COUNT(1)
    INTO V_VALIDA
    FROM DS_RUNT_RANGOS_X_CLASE DSR
    WHERE DSR.ID_CLASE = TO_CHAR(A_ID_CLASE) AND
          DSR.MAXIMO_PASAJEROS >= A_CAP_PASAJEROS;
    
    --SI NO ESTA DENTRO DEL RANGO GENERO LA EXCEPCION      
    IF V_VALIDA = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 5);
      V_EXISTE := 1;
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_PASAJEROS;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO BLINDADO*/
  FUNCTION FT_VALIDAR_BLINDADO(A_BLINDADO VARCHAR2, A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER) RETURN BOOLEAN AS
    V_VALIDA NUMBER := 0;
    V_EXISTE NUMBER := 0;
    V_TRAMITE BOOLEAN;
    BLINDAJE VARCHAR2(1);
    A_FECHA VARCHAR2(10);
    NROIDENTIFICAVEH NUMBER := 0;
    TIPOREGISTRO NUMBER := 0;
    CAMPONOMBRE VARCHAR2(30);
  BEGIN

    --VALIDO UN VALOR VALIDO
    IF (A_BLINDADO NOT IN ('S','N') OR A_BLINDADO IS NULL) THEN        
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 60);
        V_EXISTE := 1;     
    END IF;
    
    SELECT BLINDADO, NRO_IDENTIFICADOR INTO BLINDAJE, NROIDENTIFICAVEH FROM DEPURACION.DS_VEHICULO WHERE ID_RADICADO = NRADICADO AND NRO_PLACA = A_NRO_PLACA;            
    
    IF (A_TRAMITE = 1 ) THEN
        --SI NO REPORTO EL TRAMITE VERIFICO QUE YA ESTE REGISTRADO COMO BLINDADO            
        
        IF ( A_BLINDADO = 'N') THEN
                SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 95);
                V_EXISTE := 1;      
        END IF;
        
        IF (BLINDAJE = 'S' AND A_BLINDADO = 'S' ) THEN
                
            SELECT COUNT(1) INTO V_VALIDA
                FROM QUIPUX.BLINDADOS B
                WHERE B.NRO_PLACA = A_NRO_PLACA AND B.FECHA > TO_DATE(A_FECHA,'DD/MM/YYYY');
            --SI NO ESTA REGISTRADO COMO BLINDADO GENERO LA EXCEPCION
            IF V_VALIDA > 0 THEN        
               SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 91);
               V_EXISTE := 1;
            END IF;
       ELSE
            -- REPORTAR QUE EL VEHICULO ESTA ERRONEO EN BLINDAJE DESDE EL TRAMITE
            TIPOREGISTRO := DTIPOREGISTRO;
            CAMPONOMBRE := CAMPO_NOMBRE;
            CAMPO_NOMBRE := 'BLINDADO';
            --DTIPOREGISTRO := 1;
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 89);
            V_EXISTE := 1;
            DTIPOREGISTRO := TIPOREGISTRO;
            CAMPO_NOMBRE := CAMPONOMBRE;            
      END IF;
      -- NO VOLVER HACER UN BLINDAJE SI ESTA DESBLINDADO
      SELECT COUNT(1) INTO V_VALIDA FROM QUIPUX.BLINDADOS WHERE NRO_PLACA = A_NRO_PLACA AND FECHA_DESBLINDAJE IS NOT NULL;
      IF ( V_VALIDA > 0 ) THEN
           SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 99);
           V_EXISTE := 1;                            
      END IF;      
    END IF;
    
    IF (A_TRAMITE = 5 ) THEN    
        IF ( A_BLINDADO = 'N') THEN
                SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 95);
                V_EXISTE := 1;      
        END IF;
        -- SI EL DESBLINDAJE ES DE ESTADO S CUANDO DEBE SER N
        IF ( BLINDAJE = 'S' ) THEN
             SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 90);
             V_EXISTE := 1;                    
        END IF;        
        -- VALIDAR QUE TENGA UN BLINDAJE PARA DESBLINDAR
        SELECT COUNT(1) INTO V_VALIDA FROM QUIPUX.BLINDADOS WHERE NRO_PLACA = A_NRO_PLACA AND FECHA_DESBLINDAJE IS NULL;
        IF ( V_VALIDA = 0 ) THEN
             SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 98);
             V_EXISTE := 1;                            
        END IF;
        
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_BLINDADO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA SI LA LINEA REPORTADA CORRESPONDE A LA LINEA DEL VEHICULO QUE ESTA REGISTRADA*/
  FUNCTION FT_VALIDAR_LINEA(A_NRO_PLACA VARCHAR2, A_LINEA VARCHAR2) RETURN BOOLEAN AS
    V_DESC_LINEA_QX VARCHAR2(40);
    V_CONTADOR NUMBER;
    V_EXISTE NUMBER := 0;
  BEGIN
    BEGIN
    /*  SELECT TL.DESC_LINEA
      INTO V_DESC_LINEA_QX
      FROM QUIPUX.LIC_TTO LT
            INNER JOIN QUIPUX.TIPO_LINEA TL
                    ON LT.ID_LINEA = TL.ID_LINEA
      WHERE LT.NRO_PLACA = A_NRO_PLACA;*/
      SELECT SL.DESC_LINEA_SAP INTO V_DESC_LINEA_QX
          FROM QUIPUX.LIC_TTO LT 
            INNER JOIN QUIPUX.TIPO_LINEA TL ON LT.ID_LINEA = TL.ID_LINEA
            INNER JOIN QUIPUX.QX_TIPO_LINEA QT ON TL.ID_LINEA_QX = QT.ID_LINEA_QX
            INNER JOIN DEPURACION.SAP_LINEAS SL  ON QT.ID_LINEA_QX = SL.ID_LINEA_QX
        WHERE LT.NRO_PLACA = A_NRO_PLACA AND
        ROWNUM = 1;      
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN FALSE;
    END;
    
    SELECT COUNT(1)
    INTO V_CONTADOR
    FROM DUAL
    WHERE INSTR(UPPER(V_DESC_LINEA_QX),UPPER(A_LINEA),1) > 0;
    
    IF V_CONTADOR = 0 THEN
    
      SELECT COUNT(1)
      INTO V_CONTADOR
      from DUAL
      WHERE INSTR(UPPER(A_LINEA),UPPER(V_DESC_LINEA_QX),1) > 0;
      
      IF V_CONTADOR = 0 THEN
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 102);
        V_EXISTE := 1;      
       END IF;
       
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_LINEA;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA SI UN VEHICULO TIENE REGISTRADO PROPIETARIO O NO*/
  FUNCTION FT_TIENE_PROPIETARIOS(A_PLACA VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    --VALIDO QUE TENGA PROPIETARIOS
    
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM QUIPUX.PROPIETARIOS_VEHICULO PV
    WHERE PV.NRO_PLACA = A_PLACA;
    
    --SI SI EXISTE RETORNO TRUE SI NO RETORNO FALSE
    IF V_EXISTE > 0 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_TIENE_PROPIETARIOS;

/*
=======================================================================================================================
=======================================================================================================================

                                    VALIDACIONES DE NEGOCIO PARA PROPIETARIOS

=======================================================================================================================
=======================================================================================================================
*/

  /****************************************************************************/
  /*ESTE FUNCION VALIDA SI EL PROPIETARIO YA EXISTE EN LA BD DE IMPUESTOS.*/
  FUNCTION FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA VARCHAR2, A_ID_DOCUMENTO NUMBER, A_IDENTIFICACION VARCHAR2, OPCION VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    V_IDENTIFICACION VARCHAR(15);
  BEGIN
    
    -- PARA NITS SE LES QUITA EL DIGITO DE VERIFICACION EN LA BUSQUEDA
    IF ( A_ID_DOCUMENTO = 2 ) THEN
          V_IDENTIFICACION := SUBSTR(A_IDENTIFICACION,1,9);
    END IF;
    --VERIFICO SI ESTE USUARIO ESTA REGISTRADO COMO PROPIETARIO DEL VEHICULO
    IF ( OPCION = 'P' ) THEN
        SELECT COUNT(1)
        INTO V_EXISTE
        FROM QUIPUX.PROPIETARIOS_VEHICULO PV
        WHERE PV.NRO_PLACA = A_NRO_PLACA AND
                     (PV.ID_USUARIO = A_IDENTIFICACION OR PV.ID_USUARIO = V_IDENTIFICACION);
              
        --SI EXITE RETORNO TRUE SI NO RETORNO FALSE
        IF V_EXISTE > 0 THEN
          RETURN TRUE;
        ELSE
          RETURN FALSE;
        END IF;
    ELSE
        SELECT COUNT(1) INTO V_EXISTE FROM QUIPUX.USUARIOS_TTO
              WHERE ID_DOCUMENTO = A_ID_DOCUMENTO AND
                           (ID_USUARIO = A_IDENTIFICACION OR ID_USUARIO = V_IDENTIFICACION);
        
        --SI EXITE RETORNO TRUE SI NO RETORNO FALSE
        IF V_EXISTE > 0 THEN
          RETURN TRUE;
        ELSE
          RETURN FALSE;
        END IF;
        
    END IF;
  END FT_EXISTE_USUARIO_PROPIETARIO;

  /****************************************************************************/
  /*ESTE FUNCION VALIDA LOS NUMEROS DE IDENTIFICACION.*/
  FUNCTION FT_VALIDAR_IDENTIFICACION(A_IDENTIFICACION VARCHAR2, A_ID_DOCUMENTO NUMBER) RETURN BOOLEAN AS
    V_LONGITUD NUMBER;
    V_IDENTIFICACION NUMBER;
    V_EXISTE NUMBER := 0;
  BEGIN
       
      V_LONGITUD := LENGTH(A_IDENTIFICACION);
      V_IDENTIFICACION := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(A_IDENTIFICACION, 'NLS_SORT=BINARY_AI')))),' ',''),'[^0-9]',''));
      --SOLO EL PASAPORTE(6) PUEDE TENER LETRAS 
      IF A_ID_DOCUMENTO <> 6  AND V_LONGITUD <> V_IDENTIFICACION THEN
          --SP_EXCEPCION('EL NUMERO DE IDENTIFICACION DEL USUARIO SOLO PUEDE TENER LETRAS CUANDO ES PASAPORTE.');
          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 16);
          V_EXISTE := 1;
      END IF;
    
    --LA LONGITUD DEL NIT DEBE SER 10 DIGITOS
    IF A_ID_DOCUMENTO = 2 THEN
      --SI SOLO TIENE 9 DIGITOS CALCULO EL DIGITO DE VERIFICACION
      IF LENGTH(A_IDENTIFICACION) NOT IN (9,10) THEN
        --SP_EXCEPCION('EL NIT DEBE TENER 10 DIGITOS.');
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 17);
        V_EXISTE := 1;--
      END IF;
    END IF;
    IF V_EXISTE = 1 THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
  END;  
  
/****************************************************************************/
/*VALIDO EL PORCENTAJE DE PROPIEDAD REPORTADO PARA EL VEHICULO*/
FUNCTION FT_VALIDAR_PORCENTAJE_PROPIE(A_TRAMITE NUMBER, A_PLACA VARCHAR2, TIPO_REGISTRO NUMBER, A_PORCENTAJE NUMBER, A_COMPRADOR VARCHAR2) RETURN BOOLEAN AS
  V_PORCENTAJE         number := 0;
  V_PORCENTAJE_TRAMITES  NUMBER := 0;
  V_EXISTE                   NUMBER := 0;
  V_EXISTE_PROP        NUMBER := 0;                   
BEGIN

      IF (TIPO_REGISTRO = 3) THEN              
              -- VALIDAR EL PORCENTAJE DEL PROPIETARIO ENVIADO
              IF ( A_PORCENTAJE IS NULL ) THEN
                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 40);
                      V_EXISTE := 1;
              END IF;
              
            -- VALIDAR EL PORCENTAJE DEL VEHICULO PARA LOS PROPIETARIOS ACTUALES SEA EL 100
            SELECT SUM(DSP.PORCENTAJE_PROP)
                   INTO V_PORCENTAJE
            FROM DEPURACION.DS_PROPIETARIO DSP
                    WHERE DSP.ID_RADICADO = NRADICADO AND DSP.NRO_PLACA = A_PLACA;
              -- VIENE NULO
              IF ( V_PORCENTAJE IS NULL ) THEN
                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 52);
                      V_EXISTE := 1;
              END IF;
              -- VIENE DIFERENTE DE CIEN O MENOR A CERO
              IF ( V_PORCENTAJE <> 100  OR  V_PORCENTAJE < 0 ) THEN
                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 41);
                      V_EXISTE := 1;
              END IF;
      END IF;
      
      IF ( A_TRAMITE IN  (16, 65) ) THEN
            IF ( A_PORCENTAJE IS NULL ) THEN
                    SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 52);
                    V_EXISTE := 1;
            END IF;
            
            SELECT COUNT(1) INTO V_EXISTE_PROP FROM DEPURACION.DS_PROPIETARIO
                              WHERE ID_RADICADO = NRADICADO AND NRO_PLACA = A_PLACA
                                   AND ID_DOCUMENTO||ID_USUARIO = A_COMPRADOR;
            IF (V_EXISTE_PROP > 0 ) THEN
                    SELECT SUM(DST.PORCENTAJE_PROP) INTO V_PORCENTAJE
                              FROM DEPURACION.DS_PROPIETARIO DST
                                  where DST.ID_RADICADO = NRADICADO and DST.NRO_PLACA = A_PLACA
                                        and DST.ID_DOCUMENTO||DST.ID_USUARIO = A_COMPRADOR;
                                        
                      select SUM(DST.PORCENTAJE_PROP) into V_PORCENTAJE_TRAMITES
                              from DEPURACION.DS_TRAMITE DST
                                  where DST.ID_RADICADO = NRADICADO and DST.NRO_PLACA = A_PLACA
                                        and DST.ID_DOCUMENTO_NUEVO||DST.ID_USUARIO_NUEVO = A_COMPRADOR
                                        AND DST.ID_TRAMITE IN (16, 65);                                        
                      
                      IF ( V_PORCENTAJE IS NULL OR V_PORCENTAJE = 0 ) THEN
                              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 40);
                              V_EXISTE := 1;
                      END IF;
                      IF ( V_PORCENTAJE_TRAMITES <> V_PORCENTAJE ) THEN
                              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 41);
                              V_EXISTE := 1;
                      END IF;
             END IF;
      END IF;
      IF ( V_EXISTE > 0 ) THEN
              RETURN TRUE;
      ELSE
              RETURN FALSE;
      END IF;

END;
/*  
========================================================================================================================
========================================================================================================================

                              VALIDACIONES DE NEGOCIO PARA CONTRIBUYENTES
  
========================================================================================================================
========================================================================================================================
*/  

  /****************************************************************************/
  /*ESTA FUNCION VERIFICA SI EL NUMERO DE IDENTIFICACION YA EXISTE EN LA BD.*/
  FUNCTION FT_EXISTE_CONTRIBUYENTE(A_ID_USUARIO VARCHAR2, A_NRO_PLACA VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN    
    
    SELECT COUNT(1)
    INTO V_EXISTE
    FROM DEPURACION.DS_CONTRIBUYENTE DC
    INNER JOIN DEPURACION.DS_PROPIETARIO DP ON ( DP.ID_DOCUMENTO = DC.ID_DOCUMENTO AND
                                                 DP.ID_USUARIO = DC.ID_USUARIO AND 
                                                 DP.NRO_PLACA = A_NRO_PLACA)
    WHERE DC.ID_USUARIO = A_ID_USUARIO;
    
    --SI YA EXISTE RETORNO TRUE SINO RETORNO FALSE
    IF V_EXISTE = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 79);
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_EXISTE_CONTRIBUYENTE;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA QUE EL TIPO DE DOCUMENTO REPORTADO SEA UN TIPO VALIDO.*/
  FUNCTION FT_VALIDAR_TIPO_DOCUMENTO(A_ID_DOCUMENTO NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    
    --VALIDO LOS TIPOS DE DOUMENTOS
    IF A_ID_DOCUMENTO NOT IN (1,2,3,4,6) THEN
      --SP_EXCEPCION('EL TIPO DE IDENTIFICAI�N REPORTADO NO ES UN TIPO DE IDENTIFICACION VALIDO.');
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 18);
      V_EXISTE := 1;
    END IF;
    
    --VERIFICO SI HAY EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_TIPO_DOCUMENTO;


  FUNCTION FT_VALIDAR_APELLIDOS(A_ID_DOCUMENTO NUMBER, A_APELLIDOS VARCHAR2) RETURN BOOLEAN AS
    BEGIN
    
    IF ( A_ID_DOCUMENTO <> 2 AND A_APELLIDOS IS NULL ) THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
  END FT_VALIDAR_APELLIDOS;
  
  /****************************************************************************/
  /*ESTA FUNCION REALIZA LAS VALIDACIONES DE LA DIRECCION.*/
  FUNCTION FT_VALIDAR_DIRECCION(A_DIRECCION VARCHAR2, OPCIONDIR NUMBER) RETURN BOOLEAN AS
    V_DIRECCION_TEMPORAL VARCHAR2(100);
    V_DIRECCION VARCHAR2(100);
    V_CONSONANTES VARCHAR2(100);
    V_LONGITUD NUMBER;
    V_TIENE_NUMEROS NUMBER := 0;
    V_TIENE_CARACTERES NUMBER := 0;
    V_POSICION NUMBER;
    V_EXISTE NUMBER := 0;
  BEGIN
     
    --LA DIRECCION NO PUEDE TENER UNA LONGITUD MENOR A 7 CARACTERES
    IF LENGTH(A_DIRECCION) <= 7 THEN
      --SP_EXCEPCION('LA DIRECCION DEBE TENER MAS DE 7 CARACTERES.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 21);
      END IF;
      V_EXISTE := 1;
    END IF;
    
    --VALIDO QUE NO TENGA SOLO NUMEROS Y QUE NO TENGA SOLO LETRAS A NO SER QUE SEA VEREDA
    V_DIRECCION_TEMPORAL := DEPURACION.PKG_DS_ESTANDARIZA_REGISTROS.FT_ELIMINAR_ESPACIOS(A_DIRECCION);
    V_LONGITUD := LENGTH(V_DIRECCION_TEMPORAL);
    V_TIENE_CARACTERES := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^0-9]',''));
    V_TIENE_NUMEROS    := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(V_DIRECCION_TEMPORAL, 'NLS_SORT=BINARY_AI')))),' ',''),'[^A-Z]',''));

    --SOLO NUMEROS
    IF V_TIENE_CARACTERES = 0 THEN
      --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO NUMEROS.');
      V_POSICION := 0;
      V_POSICION := INSTR(V_DIRECCION_TEMPORAL,'VRD');
      IF V_POSICION = 0 THEN
         --SP_EXCEPCION('LA DIRECCION NO PUEDE CONTENER SOLO LETRAS A NO SER QUE SEA VEREDA.');
         IF OPCIONDIR = 0 THEN
              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 23);
         END IF;
         V_EXISTE := 1;
      END IF;      
    END IF;
    --SOLO LETRAS
    IF V_TIENE_NUMEROS = 0 THEN
        IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 22); 
        END IF;
        V_EXISTE := 1;
    END IF;
    
    --VALIDO QUE NO TENGA TRES CONSONANTES SEGUIDAS, VALIDAS(VRD, BRR, CRV, CRT, BLV, APTDO, CRG, DPTO, CTRAL)
    V_CONSONANTES := A_DIRECCION;
    V_CONSONANTES := UPPER(V_CONSONANTES);
    V_CONSONANTES := REPLACE(V_CONSONANTES,'VRD','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'BRR','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRV','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRT','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'BLV','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'APTDO','*****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CRG','***');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'DPTO','****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'CTRAL','*****');
    V_CONSONANTES := REPLACE(V_CONSONANTES,'STR','***');--INDUSTRIAL
    V_CONSONANTES := REPLACE(V_CONSONANTES,'NDR','***');--ANDRES
    V_CONSONANTES := REPLACE(V_CONSONANTES,'NTR','***');--ENTRE
    V_CONSONANTES := TRANSLATE(V_CONSONANTES,'BCDFGHJKLMNPQRSTVWXYZ','~~~~~~~~~~~~~~~~~~~~~');
    
    IF INSTR(V_CONSONANTES,'~~~') > 0 THEN
      --SP_EXCEPCION('LA DIRECCI�N NO PUEDE CONTENER TRES CONSONANTES SEGUIDAS.');
      IF OPCIONDIR = 0 THEN
          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 24); 
      END IF;
      V_EXISTE := 1;
    END IF;
    
    --VALIDO SI HUBIERON EXEPCIONES.
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_DIRECCION;
  
  /****************************************************************************/
  /*ESTA FUNCION HACE LAS VALIDACIONES DEL TELEFONO.
    EL TIPO INDICA SI ES TELEFONO(T) O FAX(F)*/
  FUNCTION FT_VALIDAR_TELEFONO_FAX(A_TELEFONO VARCHAR2, A_TIPO VARCHAR2, OPCIONDIR NUMBER) RETURN BOOLEAN AS
    V_TELEFONO_TEMP VARCHAR2(14);
    V_POSICION NUMBER;
    V_CONTADOR NUMBER;
    V_LONGITUD NUMBER;
    V_CARACTER VARCHAR2(1);
    V_EXCEPCION BOOLEAN;
    V_EXISTE NUMBER := 0;
  BEGIN
    
   --VALIDO QUE TENGA UN NUMERO DE TELEFONO VALIDO POR LO MENOS 7 DIGITOS SEGUIDOS Y LOS UNICOS CARACTERES PERMITIDOS SON "EXT"
    V_TELEFONO_TEMP := NVL(A_TELEFONO,' ');
    V_TELEFONO_TEMP := TRANSLATE(V_TELEFONO_TEMP,'0123456789()','**********~~');
    V_TELEFONO_TEMP := REPLACE(V_TELEFONO_TEMP,'EXT','~~~');
    V_POSICION := INSTR(V_TELEFONO_TEMP, '*******');
    IF V_POSICION = 0 THEN
      IF A_TIPO = 'T' THEN
--        SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 25); 
        END IF;
        V_EXISTE := 1;                  
      ELSE
--        SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, DEBE CONTENER POR LO MENOS 7 DIGITOS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 33); 
        END IF;
        V_EXISTE := 1;                  
      END IF;
    END IF;
    
    V_LONGITUD := LENGTH(V_TELEFONO_TEMP);
    V_CONTADOR := 1;
    V_EXCEPCION := FALSE;
    WHILE V_CONTADOR <= V_LONGITUD
    LOOP
      V_CARACTER := '';
      V_CARACTER := SUBSTR(V_TELEFONO_TEMP, V_CONTADOR, 1);
      IF V_CARACTER <> '*' AND V_CARACTER <> '~' THEN
        V_EXCEPCION := TRUE;
      END IF;
      V_CONTADOR := V_CONTADOR + 1;
    END LOOP;
    
    IF V_EXCEPCION THEN
      IF A_TIPO = 'T' THEN
        --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
        IF OPCIONDIR = 0 THEN        
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 26); 
        END IF;
        V_EXISTE := 1;         
      ELSE
        --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, CONTIENE CARACTERES NO VALIDOS.');
        IF OPCIONDIR = 0 THEN        
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 34); 
        END IF;
        V_EXISTE := 1; 
      END IF;
    END IF;
    
    V_POSICION := 0;
    V_POSICION := INSTR(A_TELEFONO, '0000000')+INSTR(A_TELEFONO, '1111111')+INSTR(A_TELEFONO, '2222222')+INSTR(A_TELEFONO, '3333333')+INSTR(A_TELEFONO, '4444444')+INSTR(A_TELEFONO, '5555555')+INSTR(A_TELEFONO, '6666666')+INSTR(A_TELEFONO, '7777777')+INSTR(A_TELEFONO, '8888888')+INSTR(A_TELEFONO, '9999999')+INSTR(A_TELEFONO, '1234567')+INSTR(A_TELEFONO, '7654321');
    IF V_POSICION > 0 THEN
      IF A_TIPO = 'T' THEN
        --SP_EXCEPCION('EL NUMERO DE TELEFONO NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 27); 
        END IF;
        V_EXISTE := 1;         
      ELSE
        --SP_EXCEPCION('EL NUMERO DE FAX NO ES VALIDO, NO PUEDE TENER 7 CEROS CONSECUTIVOS.');
        IF OPCIONDIR = 0 THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 35); 
        END IF;
        V_EXISTE := 1; 
      END IF;
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_TELEFONO_FAX;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO DE EMP O PART.*/
  FUNCTION FT_VALIDAR_EMP_PART(A_EMP_PART VARCHAR2) RETURN BOOLEAN AS
     V_EXISTE NUMBER := 0;
  BEGIN
      
    --VALIDO QUE EL DATO SEA UNA LETRA "E" O "P"
    IF A_EMP_PART <> 'E' AND A_EMP_PART <> 'P' THEN
      --SP_EXCEPCION('EL VALOR DEL CAMPO EMP_O_PART DEBE SER UNA "E" O UNA "P".');
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 28); 
      V_EXISTE := 1;       
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_EMP_PART;
  
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL DATO DEL CAMPO SEXO.*/
  FUNCTION FT_VALIDAR_SEXO(A_SEXO VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    
       --VALIDO QUE EL DATO SEA UNA LETRA "M" O "F"
    IF A_SEXO <> 'M' AND A_SEXO <> 'F' THEN
      --SP_EXCEPCION('EL VALOR DEL CAMPO SEXO DEBE SER UNA "M" O UNA "F".');
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 29); 
      V_EXISTE := 1;      
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_SEXO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA LA FECHA DE NACIMIENTO.*/
  FUNCTION FT_VALIDAR_FECHA_NACIMIENTO(A_FECHA_NACIMIENTO VARCHAR2) RETURN BOOLEAN AS
     V_EXISTE NUMBER := 0;
  BEGIN

			BEGIN    
					--VALIDO QUE LA FECHA NO SEA MENOR A 01/01/1900 O MAYOR A LA FECHA ACTUAL
					IF A_FECHA_NACIMIENTO IS NOT NULL AND TO_DATE(A_FECHA_NACIMIENTO,'DD/MM/YYYY') < TO_DATE('01/01/1900','DD/MM/YYYY') THEN
						--SP_EXCEPCION('LA FECHA DE NACIMIENTO NO ES VALIDA, ES MENOR AL 01 DE ENERO DE 1900.');
						SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 30); 
						V_EXISTE := 1;        
					END IF;
					
					IF TO_DATE(A_FECHA_NACIMIENTO,'DD/MM/YYYY') > SYSDATE THEN
						--SP_EXCEPCION('LA FECHA DE NACIMIENTO NO ES VALIDA, ES MAYOR A LA FECHA ACTUAL.');
						SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 31); 
						V_EXISTE := 1;  
					END IF;
					
					--VERIFICO SI HUBIERON EXCEPCIONES
					IF V_EXISTE = 1 THEN
						RETURN TRUE;
					ELSE
						RETURN FALSE;
					END IF;
			EXCEPTION
			    WHEN OTHERS THEN
						SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 31); 
						RETURN TRUE;
			END;
    
  END FT_VALIDAR_FECHA_NACIMIENTO;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA LOS DATOS DEL CAMPO EMAIL.*/
  FUNCTION FT_VALIDAR_EMAIL(A_EMAIL VARCHAR2) RETURN BOOLEAN AS
    V_POSICION NUMBER;
    V_EMAIL_RETORNA VARCHAR2(50);
    V_EXISTE NUMBER := 0;
    
  BEGIN

    
    V_EMAIL_RETORNA := REPLACE(A_EMAIL,' ','');
    
    --VALIDO QUE TENGA @
    V_POSICION := INSTR(V_EMAIL_RETORNA, '@');
    IF V_EMAIL_RETORNA IS NOT NULL AND V_POSICION = 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 61); 
      V_EXISTE := 1;  
    END IF;
    
    --VALIDO QUE LA LONGITUD SEA MAYOR A 7
    IF V_EMAIL_RETORNA IS NOT NULL AND LENGTH(V_EMAIL_RETORNA) <= 7 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 62); 
      V_EXISTE := 1;  
    END IF;
    
    --VALIDO QUE EL EMAIL NO TENGA LAS PALABRAS NOTIENE NOREGISTRA
    IF INSTR(LOWER(V_EMAIL_RETORNA),'NOTIENE') > 0 OR INSTR(LOWER(V_EMAIL_RETORNA),'NOREGISTRA') > 0 THEN
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 63); 
      V_EXISTE := 1;  
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END FT_VALIDAR_EMAIL;
  
  /****************************************************************************/
  /*ESTA FUNCION VERIFICA SI EL NUMERO DE IDENTIFICACION YA EXISTE EN LA BD.*/
  FUNCTION FT_VALIDA_FECHA_ACTUALIZACION(A_ID_USUARIO VARCHAR2, A_FECHA DATE) RETURN BOOLEAN AS
    V_FECHA_ULTIMA_CONFIRMACION DATE;
    V_CANT_DIAS_PARA_ACTUALIZAR NUMBER;
  BEGIN
    /*VALIDO SI SE PUEDE ACTUALIZAR LA INFO DEL CONTRIBUYENTE DEACUERDO A LA 
      FECHA DE MODIFICACION REPORTADA COMPARADA CONTRA LA ULTIMA FECHA DE 
      CONFIRMACION DE FUENTES EXTERNAS*/
    
    --CONSULTO LA ULTIMA FECHA DE CONFIRMACI�N DE DIRECCION HECHA POR FUENTE EXTERNA
    BEGIN
      SELECT MAX(UTDF.FECHA_FUENTE)
      INTO V_FECHA_ULTIMA_CONFIRMACION
      FROM QUIPUX.USUARIOS_TTO_DIRECCION_FUENTE UTDF,
            QUIPUX.USUARIOS_TTO_DIRECCIONES UTD
      WHERE UTDF.ID_USUARIO = UTD.ID_USUARIO AND
            UTDF.CONSECUTIVO_DIRECCION = UTD.CONSECUTIVO_DIRECCION AND
            UTD.ID_CONFIRMACION_CONTACTO = 2 AND
            UTDF.ID_FUENTE_DIRECCION = 16 AND
            UTD.ID_USUARIO = A_ID_USUARIO;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      --SI NO LA ENCUENTRO ES PORQUE NO HAN HECHO CONFIRMACION CON FUENTE EXTERNA Y PUEDO ACTUALIZAR
      V_FECHA_ULTIMA_CONFIRMACION := NULL;
    END;
    
    IF V_FECHA_ULTIMA_CONFIRMACION IS NULL THEN
      RETURN TRUE;
    END IF;
    
    --SI SE ENCONTRO LA FECHA DE CONFIRMACION ENTONCES VALIDO SI YA HAN PASADO LOS
    --DIAS PARAMETRIZADOS PARA PODER REALIZAR LA ACTUALIZACION DE LOS DATOS
    
    --CONSULTO LA CANTIDAD DE DIAS PARAMETRIZADA (60,5)
    BEGIN
      SELECT QXPPT.VALOR
      INTO V_CANT_DIAS_PARA_ACTUALIZAR
      FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO QXPPT
      WHERE QXPPT.ID_PROCESO = 60 AND
            QXPPT.ID_PARAMETRO = 5;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      --SI NO ENCUENTRO EL PARAMETRO LO DEJO EN 0 DIAS
      V_CANT_DIAS_PARA_ACTUALIZAR := 0;
    END;
          
    --SUMO LA CANTIDAD DE DIAS A LA ULTIMA FECHA DE CONFIRMACION.
    V_FECHA_ULTIMA_CONFIRMACION := V_FECHA_ULTIMA_CONFIRMACION + V_CANT_DIAS_PARA_ACTUALIZAR;
    
    --SI LA FECHA PASADA COMO PARAMETRO ES MAYOR A ESTA FECHA ENTONCES PUEDE REALIZAR LA ACTUALIZACION.
    IF A_FECHA >= V_FECHA_ULTIMA_CONFIRMACION THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDA_FECHA_ACTUALIZACION;

/*
========================================================================================================================
========================================================================================================================

                                          VALIDACIONES DE LOS TRAMITES

========================================================================================================================
========================================================================================================================
*/
 
  /****************************************************************************/
  /*ESTA FUNCION VALIDA QUE LA FECHA SEA UNA FECHA VALIDA*/
  FUNCTION FT_VALIDAR_FECHA_TRAMITE(A_FECHA DATE) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
  BEGIN
    
    --LA FECHA DEBE SER MAYOR A 1900 Y MENOR A LA FECHA ACTUAL
    IF (A_FECHA < TO_DATE('01/01/1900', 'DD/MM/YYYY') OR A_FECHA > SYSDATE) THEN
      --SP_EXCEPCION('LA FECHA DEL TRAMITE NO ES VALIDA.');
      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 45); 
      V_EXISTE := 1;       
    END IF;
    
    --VERIFICO SI HUBIERON EXCEPCIONES
    IF V_EXISTE = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
    
  END FT_VALIDAR_FECHA_TRAMITE;
  
  /****************************************************************************/
  /*ESTA FUNCION VALIDA QUE QUE EL TIPO DE CANCELACION SEA VALIDA*/  
  FUNCTION FT_VALIDAR_TIPO_CANCELACION(A_TIPO_CANCELACION VARCHAR2,A_NRO_PLACA VARCHAR2, A_FECHA VARCHAR2) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    V_VALIDA NUMBER := 0;
    NRO_IDENT_REMTRAICULA NUMBER :=0;
  BEGIN

		IF (A_TIPO_CANCELACION IS NOT NULL ) THEN 
        V_VALIDA := LENGTH(REGEXP_REPLACE(REPLACE(UPPER(UTL_RAW.CAST_TO_VARCHAR2((NLSSORT(A_TIPO_CANCELACION, 'NLS_SORT=BINARY_AI')))),' ',''),'[^0-9A-Z]',''));
				IF (V_VALIDA = 0) THEN
					SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 46); 
					V_EXISTE := 1;         
				END IF;
        --I.	CONSULTA SI EXISTE UNA CANCELACI�N EN LA TABLA CANCELACIONES PARA LA MISMA FECHA DE NOVEDAD Y PARA LA MISMA PLACA
        SELECT COUNT(1) INTO V_VALIDA FROM QUIPUX.CANCELACIONES WHERE NRO_PLACA = A_NRO_PLACA AND TO_DATE(A_FECHA,'DD/MM/YYYY') <= FECHA;
        IF V_VALIDA > 0 THEN
               SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 86);
               V_EXISTE := 1;
               SELECT COUNT(1) INTO V_VALIDA FROM DEPURACION.DS_TRAMITE WHERE NRO_PLACA = A_NRO_PLACA AND ID_RADICADO = NRADICADO AND ID_TRAMITE = 13;
               IF ( V_VALIDA > 0 ) THEN
                  SELECT NRO_IDENTIFICADOR INTO NRO_IDENT_REMTRAICULA FROM DEPURACION.DS_TRAMITE WHERE NRO_PLACA = A_NRO_PLACA AND ID_RADICADO = NRADICADO AND ID_TRAMITE = 13;
                        UPDATE DEPURACION.DS_TRAMITE SET ESTADO_VALIDACION = 'VI' WHERE NRO_IDENTIFICADOR = NRO_IDENT_REMTRAICULA;
                        SP_GENERAR_EXCEPCION(NRO_IDENT_REMTRAICULA, 86);
                        V_EXISTE := 1;
               END IF;
        END IF;        
    ELSE
					SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 65); 
					V_EXISTE := 1;                 
		END IF;
			
    IF V_EXISTE = 1 THEN
					RETURN TRUE;
		ELSE
					RETURN FALSE;
		END IF;

END FT_VALIDAR_TIPO_CANCELACION;

  /****************************************************************************/
  /*ESTA FUNCION VALIDA EL TRASLADO DE CUENTA DEL VEHICULO SEA VALIDO */  
FUNCTION FT_VALIDAR_SECRETARIAS_TRAMITE(A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER, A_SECRETARIA_DESTINO NUMBER, A_SECRETARIA_ORIGEN NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    V_VALIDA NUMBER := 0;
    V_ID_SECRE_VEHICULO NUMBER := 0;
    V_ID_SECRE_LIC_TTO NUMBER := 0;
  BEGIN
    
    BEGIN
      SELECT ID_SECRETARIA
      INTO V_ID_SECRE_VEHICULO
      FROM DEPURACION.DS_VEHICULO
      WHERE NRO_PLACA = A_NRO_PLACA AND
            ID_RADICADO = NRADICADO;
    EXCEPTION
    WHEN OTHERS THEN
      V_ID_SECRE_VEHICULO := NULL;
    END;
    
    BEGIN      
      SELECT ST.RUNT_SECRETARIA
      INTO V_ID_SECRE_LIC_TTO
      FROM LIC_TTO LT
            INNER JOIN SECRETARIAS_TTO ST
                    ON ST.ID_SECRETARIA = LT.ID_SECRETARIA
      WHERE LT.NRO_PLACA = A_NRO_PLACA;
    EXCEPTION
    WHEN OTHERS THEN
      V_ID_SECRE_LIC_TTO := NULL;
    END;
    
    -- TRASLADO
		IF (A_TRAMITE = 15) THEN 
      IF A_SECRETARIA_DESTINO IS NULL THEN
				SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 47); 
				V_EXISTE := 1;
      END IF;
      IF A_SECRETARIA_DESTINO <> V_ID_SECRE_VEHICULO THEN
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 97); 
				V_EXISTE := 1;
      END IF;
      IF V_ID_SECRE_VEHICULO = V_ID_SECRE_LIC_TTO THEN
        --DTIPOREGISTRO := 1;
        CAMPO_NOMBRE := 'ID_SECRETARIA';
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 106); 
				V_EXISTE := 1;
      END IF;
    END IF;
    
    --RADICACION
    IF (A_TRAMITE = 10) THEN
      IF A_SECRETARIA_ORIGEN IS NULL THEN
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 47); 
        V_EXISTE := 1;
      END IF;
      IF A_SECRETARIA_ORIGEN = V_ID_SECRE_VEHICULO THEN
        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 97); 
				V_EXISTE := 1;
      END IF;
		END IF;
			
    IF V_EXISTE = 1 THEN
					RETURN TRUE;
		ELSE
					RETURN FALSE;
		END IF;

END FT_VALIDAR_SECRETARIAS_TRAMITE;

  /****************************************************************************/
  /*ESTA FUNCION VALIDA QUE CAMBIO DE CARROCERIA SEA VALIDO */  
FUNCTION FT_VALIDAR_TRANSFORMACION(A_TRAMITE NUMBER, A_NRO_PLACA VARCHAR2, A_CARROCERIA_NUEVA NUMBER, A_TONELADAS NUMBER, A_CILINDRAJE NUMBER, A_PASAJEROS NUMBER) RETURN BOOLEAN AS
    V_EXISTE              NUMBER := 0;
    V_VALIDA              NUMBER := 0;
    A_CARROCERIA_ANTERIOR NUMBER := 0; 
    A_TIPO_VEHICULO       NUMBER := 0;
    A_CILINDRAJE_ANTERIOR NUMBER := 0;
    V_CONTEO              NUMBER := 0;
    V_CILINDRAJE_VEHICULO NUMBER := 0;
    V_PASAJEROS_VEHICULO  NUMBER := 0;
    V_TONELADAS_VEHICULO  NUMBER := 0;
    V_CAMPO_NOMBRE_TEMP VARCHAR2(30);
  BEGIN

        IF ( A_TRAMITE = 2 ) THEN
    
            SELECT COUNT(1) INTO V_VALIDA FROM DEPURACION.DS_VEHICULO WHERE ID_CARROCERIA = A_CARROCERIA_NUEVA AND NRO_PLACA = A_NRO_PLACA AND ID_RADICADO = NRADICADO;
            IF ( V_VALIDA > 0 ) THEN 
            
                  BEGIN
                    SELECT RUNT_CARROCERIA INTO A_CARROCERIA_ANTERIOR 
                      FROM QUIPUX.LIC_TTO LT 
                        INNER JOIN QUIPUX.TIPO_CARROCERIA TC ON TC.ID_CARROCERIA = LT.ID_CARROCERIA
                          INNER JOIN QUIPUX.CLASE_VEHICULOS CV ON CV.ID_CLASE = LT.ID_CLASE
                              INNER JOIN QUIPUX.QX_TIPO_CLASE QTS ON QTS.ID_CLASE_QX = CV.ID_CLASE_QX
                              INNER JOIN DEPURACION.DS_RUNT_CARROCERIA_X_CLASE	RCC ON RCC.ID_CARROCERIA_QX = TC.ID_CARROCERIA_QX
                                                                                       AND RCC.RUNT_CLASE = QTS.RUNT_CLASE                     
                                WHERE LT.NRO_PLACA = A_NRO_PLACA;
                  EXCEPTION
                  WHEN OTHERS THEN
                    A_CARROCERIA_ANTERIOR := NULL;
                  END;
                              
                SELECT COUNT(1) INTO V_VALIDA FROM QUIPUX.TIPO_CARROCERIA A
                INNER JOIN DEPURACION.DS_RUNT_CARROCERIA_X_CLASE B ON B.ID_CARROCERIA_QX = A.ID_CARROCERIA_QX
                INNER JOIN DEPURACION.DS_VEHICULO DV ON (DV.ID_CLASE = B.RUNT_CLASE AND DV.NRO_PLACA = A_NRO_PLACA AND ID_RADICADO = NRADICADO)
                WHERE B.RUNT_CARROCERIA = A_CARROCERIA_NUEVA;
                
                IF ( V_VALIDA = 0 ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 48); 
                  V_EXISTE := 1;         
                END IF;                  
                
                IF (A_CARROCERIA_ANTERIOR = A_CARROCERIA_NUEVA) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 74); 
                  V_EXISTE := 1;         
                END IF;
                IF (A_CARROCERIA_NUEVA IS NULL) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 75); 
                  V_EXISTE := 1;        
                END IF;            
            ELSE
                    SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 85); 
                    V_EXISTE := 1;                
            END IF;
        ELSIF ( A_TRAMITE = 14 ) THEN
            SELECT COUNT(1) INTO V_VALIDA FROM QUIPUX.LIC_TTO LT WHERE LT.NRO_PLACA = A_NRO_PLACA;
            V_CAMPO_NOMBRE_TEMP := CAMPO_NOMBRE;
            CAMPO_NOMBRE := 'CILINDRAJE';
            
            IF (V_VALIDA > 0 ) THEN
                SELECT LT.CILINDRAJE INTO A_CILINDRAJE_ANTERIOR FROM QUIPUX.LIC_TTO LT 
                      WHERE LT.NRO_PLACA = A_NRO_PLACA;
                IF ( A_CILINDRAJE_ANTERIOR > A_CILINDRAJE ) THEN
                     SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 82);
                     V_EXISTE := 1;
                END IF;
                IF ( A_CILINDRAJE = 0 OR A_CILINDRAJE IS NULL ) THEN
                     SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 83);
                     V_EXISTE := 1;        
                END IF;   
                BEGIN
                  SELECT CILINDRAJE
                  INTO V_CILINDRAJE_VEHICULO
                  FROM DS_VEHICULO
                  WHERE NRO_PLACA = A_NRO_PLACA AND
                        ID_RADICADO = NRADICADO;
                EXCEPTION
                WHEN OTHERS THEN
                  V_CILINDRAJE_VEHICULO := NULL;
                END;
                IF ( A_CILINDRAJE <> V_CILINDRAJE_VEHICULO OR V_CILINDRAJE_VEHICULO IS NULL ) THEN
                     SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 104);
                     V_EXISTE := 1;        
                END IF;                
            ELSE
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 83); 
                  V_EXISTE := 1;        
            END IF;        

            BEGIN            
                      SELECT TC.TIPO_VEHICULO,
                              DV.CAP_PASAJEROS,
                              DV.CAP_TONELADAS
                      INTO   A_TIPO_VEHICULO,
                              V_PASAJEROS_VEHICULO,
                              V_TONELADAS_VEHICULO
                      FROM   QUIPUX.QX_TIPO_CLASE TC 
                             INNER JOIN QUIPUX.CLASE_VEHICULOS CV 
                                     ON TC.ID_CLASE_QX = CV.ID_CLASE_QX 
                             INNER JOIN DEPURACION.DS_VEHICULO DV 
                                     ON DV.ID_CLASE = TC.RUNT_CLASE 
                      WHERE  DV.NRO_PLACA = A_NRO_PLACA 
                             AND DV.ID_RADICADO = NRADICADO;
            EXCEPTION
                    WHEN OTHERS THEN
                       SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 80); 
                       V_EXISTE := 1;
            END;       
            CAMPO_NOMBRE := V_CAMPO_NOMBRE_TEMP;       
            IF ( A_TIPO_VEHICULO = 3 ) THEN
              IF ( A_TONELADAS <= 0 ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 81); 
                  V_EXISTE := 1;                  
              END IF;
              IF ( A_TONELADAS IS NULL ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 80); 
                  V_EXISTE := 1;                  
              END IF;
              IF ( A_TONELADAS <> V_TONELADAS_VEHICULO ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 107); 
                  V_EXISTE := 1;                  
              END IF;
            END IF;
            IF ( A_TIPO_VEHICULO = 4 ) THEN
              IF ( A_PASAJEROS <= 0 ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 6); 
                  V_EXISTE := 1;                  
              END IF;
              IF ( A_PASAJEROS <> V_PASAJEROS_VEHICULO ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 108); 
                  V_EXISTE := 1;                  
              END IF;
            END IF;    
        END IF;
        
			IF V_EXISTE = 1 THEN
					RETURN TRUE;
			ELSE
					RETURN FALSE;
			END IF;

END FT_VALIDAR_TRANSFORMACION;

  /****************************************************************************/
  /*ESTA FUNCION VALIDA QUE CAMBIO DE SERVICIO SEA VALIDO */  
FUNCTION FT_VALIDAR_CAMBIO_SERVICIO(A_NRO_PLACA VARCHAR2, A_TRAMITE NUMBER, A_SERVICIO_NUEVO NUMBER, A_SERVICIO_ANTERIOR NUMBER) RETURN BOOLEAN AS
    V_EXISTE NUMBER := 0;
    V_VALIDA NUMBER := 0;
    SERVICIO_ANTERIOR NUMBER := 0;
  BEGIN
    
		IF (A_TRAMITE IS NOT NULL AND A_TRAMITE = 6 ) THEN 
        
        BEGIN
          SELECT ID_SERVICIO INTO SERVICIO_ANTERIOR FROM QUIPUX.LIC_TTO LT WHERE NRO_PLACA = A_NRO_PLACA;
        EXCEPTION
        WHEN OTHERS THEN
          SERVICIO_ANTERIOR := NULL;
        END;
        IF (SERVICIO_ANTERIOR = A_SERVICIO_NUEVO) THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 77); 
            V_EXISTE := 1;         
        END IF;
        IF (A_SERVICIO_NUEVO IS NULL) THEN
            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 76); 
            V_EXISTE := 1;         
        END IF;
        
        IF FT_EXISTE_VEHICULO (A_NRO_PLACA) THEN
          IF (SERVICIO_ANTERIOR IS NULL) THEN
              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 49); 
              V_EXISTE := 1;         
          END IF;
        END IF;  
        
		END IF;	
    IF V_EXISTE = 1 THEN
					RETURN TRUE;
		ELSE
					RETURN FALSE;
    END IF;

END FT_VALIDAR_CAMBIO_SERVICIO;

/* FUNCION PARA VALIDAR DIFERENTES TRAMITES*/
FUNCTION FT_VALIDAR_TRAMITES(A_NRO_PLACA VARCHAR2,A_FECHA_TRAMITE DATE, A_TIPO_TRAMITE NUMBER, V_TIPO_DOCUMENTO NUMBER, A_VENDEDOR VARCHAR2, A_PORCENTAJE_VENDEDOR NUMBER, C_TIPO_DOCUMENTO NUMBER, A_COMPRADOR VARCHAR2) RETURN BOOLEAN
AS
VVALIDA NUMBER := 0;
VEXISTE NUMBER := 0;
V_PORCENTAJE_PROPIEDAD NUMBER := 0;
V_TRAMITE BOOLEAN;
SECRETARIA_ORIGEN VARCHAR2(10);
SECRETARIA_DESTINO VARCHAR2(10);
FECHA_TRASLADO DATE;
SQLTEXT VARCHAR2(4000);
A_TIPO_DOCUMENTO NUMBER;
V_COMPRADOR VARCHAR2(30);
V_TIPO_DOC_VEN NUMBER;
V_VENDEDOR VARCHAR2(30);
V_VALOR_FACTURA NUMBER;
V_EXISTE_TRASANTERIOR NUMBER;
BEGIN
  IF ( A_TIPO_TRAMITE IS NOT NULL ) THEN
					IF ( A_TIPO_TRAMITE = 13 ) THEN-- REMATRICULA							
                SELECT COUNT(1) 
                INTO VVALIDA 
                FROM QUIPUX.CANCELACIONES 
                WHERE NRO_PLACA = A_NRO_PLACA AND FECHA <= A_FECHA_TRAMITE;
                
                IF ( VVALIDA = 0 ) THEN
                      IF NOT FT_REPORTA_TRAMITE_X_TIPO(A_NRO_PLACA , NRADICADO , 20) THEN
                            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 43);
                            VEXISTE := 1;
                      ELSE
                            SELECT COUNT(1)
                            INTO VVALIDA
                            FROM DS_TRAMITE DST
                            WHERE DST.NRO_PLACA = A_NRO_PLACA AND
                                  DST.ID_RADICADO = NRADICADO AND
                                  DST.ID_TRAMITE = 20 AND
                                  TO_DATE(DST.FECHA_TRAMITE,'DD/MM/RRRR') > A_FECHA_TRAMITE;
                        
                            IF VVALIDA > 0 THEN
                                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 66);
                                  VEXISTE := 1;
                            END IF;
                      END IF;                  
                      SELECT COUNT(1)  INTO VVALIDA FROM QUIPUX.CANCELACIONES 
                              WHERE NRO_PLACA = A_NRO_PLACA AND FECHA > A_FECHA_TRAMITE;                
                      IF VVALIDA > 0 THEN
                            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 66);
                            VEXISTE := 1;                    
                      END IF;          
                END IF;
          ELSIF ( A_TIPO_TRAMITE = 9 ) THEN -- MI
              SELECT COUNT(1) INTO VVALIDA FROM QUIPUX.MATRICULAS_INICIALES WHERE NRO_PLACA = A_NRO_PLACA;
              IF ( VVALIDA > 0 ) THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 96);
                  VEXISTE := 1;              
              END IF;
              
              BEGIN
                      SELECT VALOR_FACTURA  INTO V_VALOR_FACTURA FROM DEPURACION.DS_VEHICULO
                                    WHERE NRO_PLACA = A_NRO_PLACA AND ID_RADICADO = NRADICADO;
              EXCEPTION
                    WHEN OTHERS THEN
                            V_VALOR_FACTURA := NULL;
              END;
              
              IF V_VALOR_FACTURA IS NULL THEN
                  SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 111);
                  VEXISTE := 1;              
              END IF;
          ELSIF ( A_TIPO_TRAMITE = 15) THEN
                    SQLTEXT := '';
                    SQLTEXT := REPLACE(DEPURACION.PKG_DS_VALIDADOR.FT_ARMADO_SQL_PARAMETRICO(56),'COUNT(1)','A.ID_SECRETARIA')||A_VENDEDOR;
                    EXECUTE IMMEDIATE SQLTEXT INTO SECRETARIA_DESTINO;       
                    SELECT COUNT(1) INTO VVALIDA FROM QUIPUX.TRASLADOS WHERE NRO_PLACA = A_NRO_PLACA;
                    IF ( VVALIDA > 0 ) THEN
                        SELECT ID_SECRETARIA INTO SECRETARIA_ORIGEN FROM QUIPUX.LIC_TTO WHERE NRO_PLACA = A_NRO_PLACA;
                        SELECT COUNT(1) INTO VVALIDA FROM DUAL  WHERE SECRETARIA_ORIGEN = SECRETARIA_DESTINO;
                        IF ( VVALIDA > 0 ) THEN
                              SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 97);
                              VEXISTE := 1;                             
                        END IF;
                    END IF;
					ELSIF ( A_TIPO_TRAMITE IN (16, 65 )) THEN --TRASPASO Y TRASPASO INDETERMINADO
                  IF A_TIPO_TRAMITE = 65 THEN
                           A_TIPO_DOCUMENTO := 1;
                           V_COMPRADOR := '5134';
                  ELSE
                           A_TIPO_DOCUMENTO := V_TIPO_DOCUMENTO;
                           V_COMPRADOR := A_COMPRADOR;
                           V_VENDEDOR := A_VENDEDOR;
                        -- VALIDAR QUE EL VENDEDOR ESTE COMO PROPIETARIO ANTERIOR
                        IF NOT FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA,A_TIPO_DOCUMENTO, A_VENDEDOR,'P') THEN
                        -- VALIDAR QUE EL VENDEDOR ESTE REGISTRADO COMO USUARIO
                               IF NOT FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA,A_TIPO_DOCUMENTO, A_VENDEDOR,'U') THEN
                                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 67);
                                      VEXISTE := 1;
                               END IF;
                        END IF;
                        SELECT COUNT(1) INTO VVALIDA FROM DEPURACION.DS_PROPIETARIO 
                                        WHERE ID_DOCUMENTO = C_TIPO_DOCUMENTO AND ID_USUARIO = A_COMPRADOR AND NRO_PLACA = A_NRO_PLACA
                                               AND ID_RADICADO = NRADICADO;
                        IF ( VVALIDA = 0 ) THEN                               
                               IF NOT FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA,C_TIPO_DOCUMENTO, A_COMPRADOR,'U') THEN
                                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 87);
                                      SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 51);
                                      VEXISTE := 1;
                               END IF;
                        END IF;                 
                        -- VALIDACION DE LOS TRASPASOS CON FECHA MENOR
                        FOR XTT IN (SELECT * FROM DEPURACION.DS_TRAMITE_TRASPASO 
                                                            WHERE ID_RADICADO = NRADICADO AND ID_TRAMITE IN (16,65)
                                                                 AND NRO_PLACA = A_NRO_PLACA
                                                                 AND NRO_IDENTIFICADOR = NIDENTIFICADOR) LOOP
                                  IF NOT FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA,XTT.ID_DOCUMENTO_ANTERIOR, XTT.ID_USUARIO_ANTERIOR,'U') THEN
                                             SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 50);
                                             VEXISTE := 1;
                                  END IF;
                                  IF NOT FT_EXISTE_USUARIO_PROPIETARIO(A_NRO_PLACA,XTT.ID_DOCUMENTO_NUEVO, XTT.ID_USUARIO_NUEVO,'U') THEN
                                             SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 50);
                                             VEXISTE := 1;
                                  END IF;                            
                         END LOOP;
                  END IF;
          END IF;
    END IF;
     IF ( VEXISTE = 1 ) THEN
				RETURN TRUE;
		 ELSE
		    RETURN FALSE;
		 END IF;
END FT_VALIDAR_TRAMITES;


  /*ESTE PROCEDIMIENTO ABRE LOS CURSORES GLOBALES PARA EL TIPO DE REGISTRO Y VALIDAR LOS REGISTROS CONSULTADOS*/
PROCEDURE SP_PROCESAR_DATOS(NRO_RADICADO NUMBER, NROIDENTIFICADOR VARCHAR2, IDCAMPOS DEPURACION.CAMPOS_ARRAY, IDREGISTRO NUMBER) AS
   
  

	   
  TYPE T_VEH IS TABLE OF DEPURACION.DS_VEHICULO%ROWTYPE;  
  TYPE T_PRO IS TABLE OF DEPURACION.DS_PROPIETARIO%ROWTYPE;  
  TYPE T_CON IS TABLE OF DEPURACION.DS_CONTRIBUYENTE%ROWTYPE;  
  TYPE T_TRA IS TABLE OF DEPURACION.DS_TRAMITE%ROWTYPE;  
  CVEHI    T_VEH;
  CPROP    T_PRO;
  CCONT    T_CON;
  CTRAM    T_TRA;
  
	
	CURSOR CURVEH IS SELECT * FROM DEPURACION.DS_VEHICULO WHERE NRO_IDENTIFICADOR = NROIDENTIFICADOR;
	CURSOR CURPRO IS SELECT * FROM DEPURACION.DS_PROPIETARIO WHERE NRO_IDENTIFICADOR = NROIDENTIFICADOR;
	CURSOR CURCON IS SELECT * FROM DEPURACION.DS_CONTRIBUYENTE WHERE NRO_IDENTIFICADOR = NROIDENTIFICADOR;
	CURSOR CURTRA IS SELECT * FROM DEPURACION.DS_TRAMITE WHERE NRO_IDENTIFICADOR = NROIDENTIFICADOR;
  
	V_ERROR BOOLEAN;
  V_EXISTE BOOLEAN;
  
  REG_VALIDADO NUMBER := 0;
  
  CURSOR EST_CONTRIBUYENTE(IDCONTRIBUYENTE NUMBER) IS
          SELECT * FROM DEPURACION.DS_CONTRIBUYENTE_ESTANDAR
              WHERE NRO_IDENTIFICADOR = IDCONTRIBUYENTE;

  BEGIN      
  
      IF ( IDREGISTRO = 1 ) THEN
			
					DTIPOREGISTRO := 1;
					
          OPEN CURVEH;
                FETCH CURVEH BULK COLLECT INTO CVEHI;
          CLOSE CURVEH;  
              
          -- RECORRRER LOS CAMPOS DE VEHICULOS
          FOR Y IN 1 .. CVEHI.COUNT LOOP  
              V_ERROR := FALSE;      
              NIDENTIFICADOR  := CVEHI(Y).NRO_IDENTIFICADOR;
              NRADICADO := CVEHI(Y).ID_RADICADO;
              FOR CPOS IN 1..IDCAMPOS.COUNT LOOP
                       --dbms_output.put_line('my_tab(1) is '||IDCAMPOS(CPOS));
                      BEGIN 
                              SELECT NOMBRE_CAMPO INTO CAMPO_NOMBRE FROM DEPURACION.DS_CAMPO_ARCHIVO 
                                          WHERE ID_CAMPO = IDCAMPOS(CPOS);
                      EXCEPTION
                          WHEN OTHERS THEN
                                 CAMPO_NOMBRE := NULL;
                      END;
                      CASE IDCAMPOS(CPOS)
                                    WHEN 1 THEN
                                      --VALIDO LA PLACA
                                        V_ERROR := FT_VALIDAR_PLACA(CVEHI(Y).NRO_PLACA);
                                    WHEN 5 THEN
                                      --VALIDO LA PLACA
                                        V_ERROR := FT_EXISTE_VEHICULO(CVEHI(Y).NRO_PLACA);
                                        IF NOT V_ERROR THEN
                                            SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 103);                              
                                        ELSE
                                            V_ERROR := FT_VALIDAR_LINEA(CVEHI(Y).NRO_PLACA, CVEHI(Y).NOMBRE_LINEA);
                                        END IF;
                                    WHEN 6 THEN
                                      --VALIDO EL MODELO
                                        V_ERROR := FT_VALIDAR_MODELO(CVEHI(Y).MODELO);
                                    WHEN 13 THEN
                                      --VALIDO EL NRO DE PUERTAS
                                        V_ERROR := FT_VALIDAR_PUERTAS(CVEHI(Y).NRO_PUERTAS, CVEHI(Y).ID_CLASE);
                                    --WHEN 14 THEN
                                      --VALIDO EL TIPO DE COMBUSTIBLE SEA ELECTRICO SE REVISA LA BATERIA
                                        --V_ERROR := FT_VALIDAR_COMBUSTIBLE(CVEHI(Y).ID_COMBUSTIBLE, CVEHI(Y).ID_BATERIA);
                                    WHEN 16 THEN
                                      --VALIDO EL TIPO DE COMBUSTIBLE SEA ELECTRICO SE REVISA LA BATERIA
                                        V_ERROR := FT_VALIDAR_COMBUSTIBLE(CVEHI(Y).ID_COMBUSTIBLE, CVEHI(Y).ID_BATERIA, CVEHI(Y).ID_CLASE);
                                    WHEN 21 THEN
                                      --VALIDO EL CILINDRAJE
                                        V_ERROR := FT_VALIDAR_CILINDRAJE(CVEHI(Y).CILINDRAJE, CVEHI(Y).ID_CLASE);            
                                    WHEN 22 THEN
                                      --VALIDO LA CAPACIDAD DE PASAJEROS
                                        V_ERROR := FT_VALIDAR_PASAJEROS(CVEHI(Y).CAP_PASAJEROS, CVEHI(Y).ID_CLASE);
                                    WHEN 23 THEN
                                      --VALIDO LA CAPACIDAD DE LAS TONELADAS
                                        V_ERROR := FT_VALIDAR_TONELADAS(CVEHI(Y).CAP_TONELADAS, CVEHI(Y).ID_CLASE);
                                    WHEN 24 THEN
                                      --VALIDO EL VALOR DE LA FACTURA
                                        V_ERROR := FT_VALIDAR_VALOR_FACTURA(CVEHI(Y).VALOR_FACTURA, CVEHI(Y).MODELO, CVEHI(Y).NRO_PLACA);
                                    WHEN 25 THEN
                                      --VALIDO EL DATO DEL CAMPO BLINDADO S O N
                                        IF (CVEHI(Y).BLINDADO NOT IN ('S','N') OR CVEHI(Y).BLINDADO IS NULL) THEN
                                          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 60);
                                          V_ERROR := TRUE;
                                        END IF;
                                    WHEN 26 THEN
                                      --VALIDO EL CAMPO IMPORTADO/NACIONAL
                                        V_ERROR := FT_VALIDAR_IMPORTADO_NACIONAL(CVEHI(Y).IMPORTADO_NACIONAL);
                                    WHEN 27 THEN
                                      --VALIDO EL ESTADO
                                        V_ERROR := FT_VALIDAR_ESTADO(CVEHI(Y).ID_ESTADO, CVEHI(Y).NRO_PLACA, NRADICADO);
                                    WHEN 29 THEN
                                      --VALIDO EL CAMPO CLASICO/ANTIGUO
                                        V_ERROR := FT_VALIDAR_CLASICO_ANTIGUO(CVEHI(Y).CLASICO_ANTIGUO, CVEHI(Y).NRO_PLACA);
                                    ELSE
                                        IF (CAMPO_NOMBRE IS NOT NULL ) THEN
                                              V_ERROR := TRUE;
                                        END IF;
                                END CASE;
                    END LOOP;
              END LOOP;
              
              SP_ACTUALIZAR_ESTADO_REGISTRO(NIDENTIFICADOR,'DS_VEHICULO', IDREGISTRO);
              
			 -- RECORRRER LOS CAMPOS DE PROPIETARIOS
       ELSIF ( IDREGISTRO = 3 ) THEN
			 
						DTIPOREGISTRO := 3;
						
            OPEN CURPRO;
                FETCH CURPRO BULK COLLECT INTO CPROP;
            CLOSE CURPRO;  
          
            FOR CP IN 1 .. CPROP.COUNT LOOP
                V_ERROR := FALSE;      
                NIDENTIFICADOR  := CPROP(CP).NRO_IDENTIFICADOR;
                NRADICADO := CPROP(CP).ID_RADICADO;
                FOR CPOS IN 1..IDCAMPOS.COUNT LOOP
                      BEGIN 
                              SELECT NOMBRE_CAMPO INTO CAMPO_NOMBRE FROM DEPURACION.DS_CAMPO_ARCHIVO 
                                          WHERE ID_CAMPO = IDCAMPOS(CPOS);
                      EXCEPTION
                          WHEN OTHERS THEN
                                 CAMPO_NOMBRE := NULL;
                      END;
                      CASE IDCAMPOS(CPOS)
                                 WHEN 47 THEN
                                      --VALIDO LA PLACA
                                      V_ERROR := FT_VALIDAR_PLACA(CPROP(CP).NRO_PLACA);
                                WHEN 48 THEN
                                      V_ERROR := FT_VALIDAR_IDENTIFICACION(CPROP(CP).ID_USUARIO, CPROP(CP).ID_DOCUMENTO);                        
                                 WHEN 49 THEN
                                      -- VALIDO LA INFORMACION DEL DOCUMENTO Y TIPO DE DOCUMENTO
                                      V_ERROR := FT_VALIDAR_IDENTIFICACION(CPROP(CP).ID_USUARIO, CPROP(CP).ID_DOCUMENTO);
                                 WHEN 50 THEN
                                      -- VALIDO EL % DE PROPIEDAD DEL VEHICULO PRO CADA PROPIETARIO
                                      V_ERROR := FT_VALIDAR_PORCENTAJE_PROPIE(0,CPROP(CP).NRO_PLACA,DTIPOREGISTRO, CPROP(CP).PORCENTAJE_PROP, CPROP(CP).ID_DOCUMENTO||CPROP(CP).ID_USUARIO);
                                 ELSE
                                      IF (CAMPO_NOMBRE IS NOT NULL ) THEN
                                              V_ERROR := TRUE;
                                      END IF;
                              END CASE;
                    END LOOP;
            END LOOP;

            SP_ACTUALIZAR_ESTADO_REGISTRO(NIDENTIFICADOR,'DS_PROPIETARIO', IDREGISTRO);		
           
			 -- RECORRRER LOS CAMPOS DE CONTRIBUYENTES
       ELSIF ( IDREGISTRO = 2 ) THEN
			 
						DTIPOREGISTRO := 2;
						
            OPEN CURCON;
                FETCH CURCON BULK COLLECT INTO CCONT;
            CLOSE CURCON;  
                          
            FOR CC IN 1 .. CCONT.COUNT LOOP
                V_ERROR := FALSE;
                NIDENTIFICADOR  := CCONT(CC).NRO_IDENTIFICADOR;
                NRADICADO := CCONT(CC).ID_RADICADO;
                FOR CPOS IN 1..IDCAMPOS.COUNT LOOP
                      BEGIN 
                              SELECT NOMBRE_CAMPO INTO CAMPO_NOMBRE FROM DEPURACION.DS_CAMPO_ARCHIVO 
                                          WHERE ID_CAMPO = IDCAMPOS(CPOS);
                      EXCEPTION
                          WHEN OTHERS THEN
                                 CAMPO_NOMBRE := NULL;
                      END;
                      FOR XC IN EST_CONTRIBUYENTE(CCONT(CC).NRO_IDENTIFICADOR) LOOP
                             CASE IDCAMPOS(CPOS)
                                    WHEN 31 THEN
                                        V_ERROR := FT_VALIDAR_IDENTIFICACION(XC.ID_USUARIO, CCONT(CC).ID_DOCUMENTO);
                                    WHEN 32 THEN
                                        V_ERROR := FT_VALIDAR_IDENTIFICACION(XC.ID_USUARIO, CCONT(CC).ID_DOCUMENTO);                          
                                    WHEN 35 THEN
                                        V_ERROR := FT_VALIDAR_APELLIDOS(CCONT(CC).ID_DOCUMENTO, XC.APELLIDOS);
                                    WHEN 37 THEN
                                        V_ERROR := FT_VALIDAR_DIRECCION(XC.DIRECCION,0);
                                    WHEN 38 THEN 
                                        V_ERROR := FT_VALIDAR_TELEFONO_FAX(XC.TELEFONO,'T',0);
                                    WHEN 39 THEN
                                        V_ERROR := FT_VALIDAR_EMP_PART(CCONT(CC).EMP_O_PART);
                                    WHEN 40 THEN
                                        V_ERROR := FT_VALIDAR_SEXO(CCONT(CC).SEXO);
                                    WHEN 41 THEN
                                        V_ERROR := FT_VALIDAR_FECHA_NACIMIENTO(CCONT(CC).FECHA_NACIMIENTO);
                                    WHEN 45 THEN
                                        V_ERROR := FT_VALIDAR_TELEFONO_FAX(CCONT(CC).FAX,'F',0);
                                    WHEN 46 THEN
                                        V_ERROR := FT_VALIDAR_EMAIL(CCONT(CC).EMAIL);
                                    ELSE 	
                                        IF (CAMPO_NOMBRE IS NOT NULL ) THEN
                                              V_ERROR := TRUE;
                                        END IF;
                                  END CASE;
                           END LOOP;
                  END LOOP;
            END LOOP;
        
      SP_ACTUALIZAR_ESTADO_REGISTRO(NIDENTIFICADOR,'DS_CONTRIBUYENTE', IDREGISTRO);
        
			 -- RECORRRER LOS CAMPOS DE LOS TRAMITES
       ELSIF ( IDREGISTRO = 4 ) THEN
					
					DTIPOREGISTRO := 4;
					
          OPEN CURTRA;
                FETCH CURTRA BULK COLLECT INTO CTRAM;
          CLOSE CURTRA;  
                      
          FOR CT IN 1 .. CTRAM.COUNT LOOP
                V_ERROR := FALSE;  
                NIDENTIFICADOR  := CTRAM(CT).NRO_IDENTIFICADOR;
                NRADICADO := CTRAM(CT).ID_RADICADO;
                FOR CPOS IN 1..IDCAMPOS.COUNT LOOP
                      BEGIN 
                              SELECT NOMBRE_CAMPO INTO CAMPO_NOMBRE FROM DEPURACION.DS_CAMPO_ARCHIVO 
                                          WHERE ID_CAMPO = IDCAMPOS(CPOS);
                      EXCEPTION
                          WHEN OTHERS THEN
                                 CAMPO_NOMBRE := NULL;
                      END;
                      CASE IDCAMPOS(CPOS)
                                  WHEN 51 THEN -- PLACA
                                     V_ERROR := FT_VALIDAR_PLACA(CTRAM(CT).NRO_PLACA);
                                  WHEN 52 THEN -- ID_TRAMITE
                                     IF (CTRAM(CT).ID_TRAMITE IS NULL ) THEN
                                        SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 44);
                                        V_ERROR := TRUE;
                                     ELSE
                                        IF ( CTRAM(CT).ID_TRAMITE = 13 ) THEN
                                              V_ERROR := FT_VALIDAR_TRAMITES(CTRAM(CT).NRO_PLACA,TO_DATE(CTRAM(CT).FECHA_TRAMITE,'DD/MM/RRRR'), CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_DOCUMENTO_ANTERIOR, CTRAM(CT).ID_USUARIO_ANTERIOR, CTRAM(CT).PORCENTAJE_PROP, CTRAM(CT).ID_DOCUMENTO_NUEVO, CTRAM(CT).ID_USUARIO_NUEVO);
                                        END IF;
                                        IF ( CTRAM(CT).ID_TRAMITE = 9 ) THEN
                                              V_ERROR := FT_VALIDAR_TRAMITES(CTRAM(CT).NRO_PLACA,TO_DATE(CTRAM(CT).FECHA_TRAMITE,'DD/MM/RRRR'), CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_DOCUMENTO_ANTERIOR, CTRAM(CT).ID_USUARIO_ANTERIOR, CTRAM(CT).PORCENTAJE_PROP, CTRAM(CT).ID_DOCUMENTO_NUEVO, CTRAM(CT).ID_USUARIO_NUEVO);
                                        END IF;                        
                                        /*IF ( CTRAM(CT).ID_TRAMITE = 15 ) THEN
                                              V_ERROR := FT_VALIDAR_TRAMITES(CTRAM(CT).NRO_PLACA,TO_DATE(CTRAM(CT).FECHA_TRAMITE,'DD/MM/RRRR'), CTRAM(CT).ID_TRAMITE, 0, CTRAM(CT).ID_SECRETARIA_DESTINO, 0, CTRAM(CT).ID_USUARIO_NUEVO);
                                        END IF;*/                        
                                     end if;
                                  WHEN 66 THEN -- VALIDACION TRAMITES Y TRASPASO (VALIDA PROPIETARIO VEHICULO Y USUARIOS_TTO)
                                      IF ( CTRAM(CT).ID_TRAMITE = 16 OR CTRAM(CT).ID_TRAMITE = 65) THEN
                                        V_ERROR := FT_VALIDAR_TRAMITES(CTRAM(CT).NRO_PLACA,TO_DATE(CTRAM(CT).FECHA_TRAMITE,'DD/MM/RRRR'), CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_DOCUMENTO_ANTERIOR, CTRAM(CT).ID_USUARIO_ANTERIOR, CTRAM(CT).PORCENTAJE_PROP, CTRAM(CT).ID_DOCUMENTO_NUEVO, CTRAM(CT).ID_USUARIO_NUEVO);
                                      end if;
                                  WHEN 67 THEN -- VALIDACION USUARIO NUEVO CONTRIBUYENTE (VALIDA DS_PROPIETARIO Y USUARIOS_TTO)
                                     IF ( CTRAM(CT).ID_TRAMITE = 16 OR CTRAM(CT).ID_TRAMITE = 65) THEN
                                        --V_ERROR := FT_REPORTA_PROPIETARIO(CTRAM(CT).NRO_PLACA, NRADICADO,CTRAM(CT).ID_USUARIO_NUEVO, CTRAM(CT).ID_DOCUMENTO_NUEVO);
                                        V_ERROR := FT_REPORTA_PROPIETARIO(CTRAM(CT).NRO_PLACA);
                                     END IF;
                                  WHEN 54 THEN -- VALIDAR FECHA
                                     V_ERROR := FT_VALIDAR_FECHA_TRAMITE(TO_DATE(CTRAM(CT).FECHA_TRAMITE,'DD/MM/RRRR'));
                                  WHEN 55 THEN
                                     IF ( CTRAM(CT).ID_TRAMITE = 20 ) THEN
                                        V_ERROR := FT_VALIDAR_TIPO_CANCELACION(CTRAM(CT).TIPO_CANCELACION, CTRAM(CT).NRO_PLACA, CTRAM(CT).FECHA_TRAMITE );
                                     END IF;
                                  WHEN 56  THEN
                                      IF CTRAM(CT).ID_TRAMITE = 15 THEN
                                            V_ERROR := FT_VALIDAR_SECRETARIAS_TRAMITE(CTRAM(CT).NRO_PLACA,CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_SECRETARIA_DESTINO, CTRAM(CT).ID_SECRETARIA_ORIGEN);
                                      END IF;
                                  WHEN 57 THEN
                                      IF CTRAM(CT).ID_TRAMITE = 10 THEN
                                              V_ERROR := FT_VALIDAR_SECRETARIAS_TRAMITE(CTRAM(CT).NRO_PLACA,CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_SECRETARIA_DESTINO, CTRAM(CT).ID_SECRETARIA_ORIGEN);
                                      END IF;
                                  WHEN 60 THEN -- CAMBIO DE CARROCERIA
                                          V_ERROR := FT_VALIDAR_TRANSFORMACION(CTRAM(CT).ID_TRAMITE, CTRAM(CT).NRO_PLACA, CTRAM(CT).ID_CARROCERIA_NUEVA, CTRAM(CT).CAP_TONELADAS, CTRAM(CT).CILINDRAJE, CTRAM(CT).CAP_PASAJEROS);
                                  WHEN 64 THEN -- CAMBIO DE SERVICIO
                                     V_ERROR := FT_VALIDAR_CAMBIO_SERVICIO(CTRAM(CT).NRO_PLACA, CTRAM(CT).ID_TRAMITE, CTRAM(CT).ID_SERVICIO_NUEVO, CTRAM(CT).ID_SERVICIO_ANTERIOR);
                                  WHEN 68 THEN
                                     if ( CTRAM(CT).ID_TRAMITE in (16, 65)) then -- TRASPASO
                                        V_ERROR := FT_VALIDAR_PORCENTAJE_PROPIE(CTRAM(CT).ID_TRAMITE,CTRAM(CT).NRO_PLACA,IDREGISTRO, CTRAM(CT).PORCENTAJE_PROP,CTRAM(CT).ID_DOCUMENTO_NUEVO||CTRAM(CT).ID_USUARIO_NUEVO);
                                     END IF;                    
                                  WHEN 69 THEN
                                      IF ( CTRAM(CT).ID_TRAMITE = 23 ) THEN -- CLASICO_ANTIGUO
                                          V_ERROR := FT_VALIDAR_CLASICO_ANTIGUO(CTRAM(CT).CLASICO_ANTIGUO, CTRAM(CT).NRO_PLACA);
                                      END IF;
                                  WHEN 70 THEN
                                      IF ( CTRAM(CT).ID_TRAMITE = 1) THEN -- AND CTRAM(CT).BLINDADO IS NOT NULL AND CTRAM(CT).DESBLINDAJE IS NULL ) THEN -- BLINDAJE
                                          V_ERROR := FT_VALIDAR_BLINDADO(CTRAM(CT).BLINDADO, CTRAM(CT).NRO_PLACA,CTRAM(CT).ID_TRAMITE);
                                      ELSE
                                          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 100);
                                          V_ERROR := TRUE;                      
                                      END IF;
                                  WHEN 72 THEN
                                      IF ( CTRAM(CT).ID_TRAMITE = 5) THEN-- AND CTRAM(CT).BLINDADO IS NULL AND CTRAM(CT).DESBLINDAJE IS NOT NULL ) THEN
                                          V_ERROR := FT_VALIDAR_BLINDADO(CTRAM(CT).DESBLINDAJE, CTRAM(CT).NRO_PLACA,CTRAM(CT).ID_TRAMITE);
                                      ELSE
                                          SP_GENERAR_EXCEPCION(NIDENTIFICADOR, 100); 
                                          V_ERROR := TRUE;                          
                                      END IF;                                            
                                  ELSE
                                        IF (CAMPO_NOMBRE IS NOT NULL ) THEN
                                              V_ERROR := TRUE;
                                        END IF;										 
                                END CASE;
                    END LOOP;
             END LOOP;    

             SP_ACTUALIZAR_ESTADO_REGISTRO(NIDENTIFICADOR,'DS_TRAMITE', IDREGISTRO);             
            
       END IF;
--			 EXCEPTION
--			    WHEN OTHERS THEN
--								DBMS_OUTPUT.PUT_LINE('LINEA DEL ERROR: '||SQLERRM);
  END SP_PROCESAR_DATOS;
  
/****************************************************************************/
  /*ESTE PROCEDIMIENTO INSERTA UNA EXEPCION PARA POR CADA UNO DE LOS ITEMS EVALUADOS DE LOS REGISTROS VALIDADOS.*/
PROCEDURE SP_GENERAR_EXCEPCION(A_REGISTRO_FALLO NUMBER, A_INCONSISTENCIA NUMBER) IS
  
  NDIAS           NUMBER := 0;
  VINCOSISTENCIA  NUMBER := 0;
  CONTADOR        NUMBER := 0;
  VEXISTE         NUMBER := 0;
  BEGIN

      SELECT VALOR INTO NDIAS FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO 
             WHERE ID_PROCESO = 60 AND ID_PARAMETRO = 7; 

--    TIPOERROR := NULL;
      
      SELECT COUNT(1) INTO CONTADOR FROM DEPURACION.DS_VALIDACIONES_CAMPO WHERE ID_INCONSISTENCIA = A_INCONSISTENCIA AND ACTIVO = 'S';
      IF (CONTADOR > 0 ) THEN

          SELECT ID_INCONSISTENCIA, TIPO_INCONSISTENCIA INTO VINCOSISTENCIA, TIPO_ERROR FROM DEPURACION.DS_TIPO_INCONSISTENCIA 
                 WHERE ID_INCONSISTENCIA = A_INCONSISTENCIA AND ACTIVO = 'S';

          SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
               WHERE ID_RADICADO = NRADICADO AND
                     ID_REGISTRO_FALLO = A_REGISTRO_FALLO AND
                     ID_TIPO_REGISTRO = DTIPOREGISTRO AND
                     ID_ESTADO_EXCEPCION = 1 AND
                     IDENTIFICADOR = CAMPO_NOMBRE AND
                     ID_INCONSISTENCIA = VINCOSISTENCIA;
                     
          IF VEXISTE = 0 THEN
            
            SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
               WHERE ID_RADICADO = NRADICADO AND
                     ID_REGISTRO_FALLO = A_REGISTRO_FALLO AND
                     ID_TIPO_REGISTRO = DTIPOREGISTRO AND
                     ID_ESTADO_EXCEPCION = 2 AND
                     IDENTIFICADOR = CAMPO_NOMBRE AND
                     ID_INCONSISTENCIA = VINCOSISTENCIA;

            IF ( VEXISTE > 0 ) THEN
                  
                  UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 4
                       WHERE ID_RADICADO = NRADICADO AND
                             ID_REGISTRO_FALLO = A_REGISTRO_FALLO AND
                             ID_TIPO_REGISTRO = DTIPOREGISTRO AND
                             ID_ESTADO_EXCEPCION = 2 AND
                             IDENTIFICADOR = CAMPO_NOMBRE AND
                             ID_INCONSISTENCIA = VINCOSISTENCIA;
                  VALIDA_INCO := 1;
            END IF;
            
            INSERT INTO DEPURACION.DS_INCONSISTENCIA
                  VALUES  (DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL,
                          NRADICADO,
                          A_REGISTRO_FALLO,
                          DTIPOREGISTRO,
                          1,
                          NVL(VINCOSISTENCIA,0),
                          CAMPO_NOMBRE,
                          SYSDATE,
                          SYSDATE + NDIAS);
            VALIDA_INCO := 1;
            
          END IF;
      ELSE
          VALIDA_INCO := 0;
      END IF;
      COMMIT;
  END SP_GENERAR_EXCEPCION;

  PROCEDURE SP_ACTUALIZAR_ESTADO_REGISTRO(NROIDENTIFICADOR NUMBER, NOMBRE_TABLA VARCHAR2, A_TIPO_REGISTRO NUMBER)
  IS
  
  SQLTEXT VARCHAR2(4000);
  REG_VALIDADO NUMBER := 0;
  
  BEGIN
       SQLTEXT := 'SELECT COUNT(1) FROM DEPURACION.'||NOMBRE_TABLA||' TD '||CHR(13)
                         || '                INNER JOIN DEPURACION.DS_INCONSISTENCIA DI ON TD.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO '||CHR(13) 
                         || '                                                                        AND DI.ID_TIPO_REGISTRO = '||A_TIPO_REGISTRO||CHR(13)
                         || '                INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA '||CHR(13)
                         || '                                                                        AND DTI.TIPO_INCONSISTENCIA = ''E'''||CHR(13)
                         || '                 WHERE TD.NRO_IDENTIFICADOR = '||NROIDENTIFICADOR;
       EXECUTE IMMEDIATE SQLTEXT INTO REG_VALIDADO;
       IF ( REG_VALIDADO > 0) THEN
                             SQLTEXT := NULL;
                             SQLTEXT := 'UPDATE DEPURACION.'||NOMBRE_TABLA||' SET ESTADO_VALIDACION = ''VI'' WHERE NRO_IDENTIFICADOR = '||NROIDENTIFICADOR;
                             EXECUTE IMMEDIATE SQLTEXT;
       ELSE
                             SQLTEXT := NULL;
                             SQLTEXT := 'UPDATE DEPURACION.'||NOMBRE_TABLA||' SET ESTADO_VALIDACION = ''VE'' WHERE NRO_IDENTIFICADOR = '||NROIDENTIFICADOR;
                             EXECUTE IMMEDIATE SQLTEXT;
       END IF;

  END SP_ACTUALIZAR_ESTADO_REGISTRO;

  
END PKG_DS_VALIDACIONES_REGISTRO;

/
--------------------------------------------------------
--  DDL for Package Body PKG_DS_VALIDADOR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_DS_VALIDADOR" AS

  FUNCTION FT_ARMADO_SQL_PARAMETRICO(VIDCAMPO NUMBER) RETURN VARCHAR2 
  AS
      
  --- CURSOR PARA EL ARMADO DE LOS SQL COMPLEJOS DE JOIN.      
      CURSOR SQL_COMPUESTO(IDCAMPOSC NUMBER) IS
          SELECT VP2.ID_PARAMETRICA,
                  VP2.ESQUEMA_PARAMETRICA   AS ESQUEMA_ORI,
                  VP2.TABLA_PARAMETRICA     AS TABLA_ORI,
                  VP2.CAMPO_PARAMETRICA     AS CAMPO_ORI,
                  VP2.TIPO_DATO_PARAMETRICA AS DATO_ORI,
                  VP1.ESQUEMA_PARAMETRICA   AS ESQUEMA_DES,
                  VP1.TABLA_PARAMETRICA     AS TABLA_DES,
                  VP1.CAMPO_PARAMETRICA     AS CAMPO_DES,
                  VP1.TIPO_DATO_PARAMETRICA AS DATO_DES,
                  VP1.CAMPO_VALIDACION1     AS CAMPO_WH1,
                  VP1.TIPO_DATO1            AS DATO_WH1,
                  VP1.CAMPO_VALIDACION2     AS CAMPO_WH2,
                  VP1.TIPO_DATO2            AS DATO_WH2,
                  DCP.ID_CAMPO              AS CAMPO_EVALUA
          FROM DS_VALIDACION_PARAMETRICA VP1
          LEFT JOIN DS_VALIDACION_PARAMETRICA VP2 ON VP2.ID_UNION_PARAMETRICA = VP1.ID_PARAMETRICA
          INNER JOIN DS_CAMPO_PARAMETRICO DCP ON DCP.ID_PARAMETRICA           = VP2.ID_PARAMETRICA
          WHERE VP2.ID_UNION_PARAMETRICA IS NOT NULL
            AND DCP.ID_CAMPO = IDCAMPOSC;
  
  --- CURSOR PARA EL ARMADO DE LOS SQL SENCILLOS.
    CURSOR SQL_SENCILLO(IDCAMPOSS NUMBER) IS 
        SELECT DVP.ID_PARAMETRICA,
          DVP.ESQUEMA_PARAMETRICA,
          DVP.TABLA_PARAMETRICA,
          DVP.CAMPO_PARAMETRICA,
          DVP.TIPO_DATO_PARAMETRICA,
          DCP.ID_CAMPO
        FROM DS_VALIDACION_PARAMETRICA DVP
          INNER JOIN DS_CAMPO_PARAMETRICO DCP ON DCP.ID_PARAMETRICA = DVP.ID_PARAMETRICA
          WHERE DVP.ID_UNION_PARAMETRICA IS NULL
          AND NOT EXISTS
            (SELECT 1
                FROM DS_VALIDACION_PARAMETRICA VP1
                    LEFT JOIN DS_VALIDACION_PARAMETRICA VP2 ON VP2.ID_UNION_PARAMETRICA = VP1.ID_PARAMETRICA
                    WHERE VP2.ID_UNION_PARAMETRICA IS NOT NULL
                      AND (VP2.ID_PARAMETRICA         = DVP.ID_PARAMETRICA
                       OR VP1.ID_PARAMETRICA           = DVP.ID_PARAMETRICA)
            )
         AND DCP.ID_CAMPO = IDCAMPOSS;  
  
  SQLTXT VARCHAR2(2000);

  BEGIN
      
          FOR X IN SQL_COMPUESTO(VIDCAMPO) LOOP
                      -- ARMADO DEL SQL COMPLEJO
                      SQLTXT := 'SELECT COUNT(1) FROM '||X.ESQUEMA_ORI||'.'||X.TABLA_ORI||' A '||CHR(13);
                      IF ( X.DATO_ORI = X.DATO_DES ) THEN
                          SQLTXT := SQLTXT || '    INNER JOIN '||X.ESQUEMA_DES||'.'||X.TABLA_DES||' B ON B.'||X.CAMPO_DES||' = A.'||X.CAMPO_ORI||CHR(13);
                      ELSIF ( X.DATO_DES = 'FLOAT' OR X.DATO_DES = 'VARCHAR2' ) THEN
                          SQLTXT := SQLTXT || '    INNER JOIN '||X.ESQUEMA_DES||'.'||X.TABLA_DES||' B ON TO_NUMBER(B.'||X.CAMPO_DES||') = A.'||X.CAMPO_ORI||CHR(13);
                      ELSIF (X.DATO_DES = 'VARCHAR2' ) THEN
                          SQLTXT := SQLTXT || '    INNER JOIN '||X.ESQUEMA_DES||'.'||X.TABLA_DES||' B ON A.'||X.CAMPO_DES||' = TO_NUMBER(B.'||X.CAMPO_ORI||')'||CHR(13);
                      END IF;
                      -- ARMADO DEL SEGUNDO FILTRO DEL JOIN
                      IF ( X.CAMPO_WH2 IS NOT NULL ) THEN
                          SQLTXT := SQLTXT || '    WHERE ROWNUM = 1 '||CHR(13)||'      AND B.'||X.CAMPO_WH1|| ' = '':VP'''||CHR(13)
                                  || '      AND B.'||X.CAMPO_WH2||' = '':VS''';
                      ELSE
                          SQLTXT := SQLTXT || '    WHERE ROWNUM = 1 '||CHR(13)||'      AND B.'||X.CAMPO_WH1|| ' = ';
                      END IF;
          END LOOP;

          FOR Z IN SQL_SENCILLO(VIDCAMPO) LOOP
                  -- ARMADO DEL SQL SENCILLO
                  SQLTXT := 'SELECT COUNT(1) FROM '||Z.ESQUEMA_PARAMETRICA||'.'||Z.TABLA_PARAMETRICA||' A '||CHR(13)
                         || '      WHERE ROWNUM = 1 '||CHR(13)
                         || '        AND A.'||Z.CAMPO_PARAMETRICA||' = ';
          END LOOP;

      RETURN SQLTXT;
  EXCEPTION
       WHEN OTHERS THEN
           RETURN NULL;
  END FT_ARMADO_SQL_PARAMETRICO;


  PROCEDURE  SP_VALIDADOR_REGISTROS(NRORADICADO NUMBER) AS
    
        
    --ESPECIFICACION DE CURSORES POR REGISTRO.
    
        CURSOR CVEHICULOS(IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_VEHICULO
                WHERE ID_RADICADO = IDRADICADO
                  AND ESTADO_VALIDACION='VP';
                 -- AND NRO_PLACA = 'MNI603';
          
        CURSOR CPROPIETARIOS(NROPLACA VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_PROPIETARIO
                 WHERE ID_RADICADO = IDRADICADO
                   AND NRO_PLACA = NROPLACA;
                   
        CURSOR CCONTRIBUYENTES(IDDOCUMENTO VARCHAR2, IDUSUARIO VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_CONTRIBUYENTE
               WHERE ID_DOCUMENTO = IDDOCUMENTO AND ID_USUARIO = IDUSUARIO AND ID_RADICADO = IDRADICADO;
               
        
        CURSOR CTRAMITES (NROPLACA VARCHAR2, IDRADICADO NUMBER) IS
            SELECT * FROM DEPURACION.DS_TRAMITE
               WHERE NRO_PLACA = NROPLACA AND ID_RADICADO = IDRADICADO;
        
        VCONTEO             NUMBER := 0; -- REGISTRA SI LA PLACA EXISTE EN LOS 4 REGISTROS 1 = SI / 0 = NO
				SWVALIDA            NUMBER := 0; -- SI NO PRESENTO NINGUN ERROR AL MOMENTO DE REALZIAR TODAS LAS VALIDACIONES CORRESPONDIENTES
        NDIAS               NUMBER := 0; -- GUARDA EL NUMERO DE DIAS PARAMETRIZADOS PARA LA REVISION DE LAS INCONSISTENCIAS.
        NROREGISTRO         NUMBER := 0; -- GUARDA EL NUMERO DE IDENTIFICADOR DEL REGISTRO UNICO PARA REGISTRAR LA INCONSISTENCIA NO EXISTENTE EN LOS 4 REGISTROS
        VEXISTE             NUMBER := 0;
        V_ID_TRAMITE        NUMBER := 0;
        V_ERROR VARCHAR2(1000);
    
    BEGIN
    
      
      SELECT VALOR INTO NDIAS FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO 
			 			 WHERE ID_PROCESO = 60 AND ID_PARAMETRO = 7;     
       -- CURSOR QUE RECORRE POR CADA UNO DE LOS REGISTROS
       
       FOR VR IN CVEHICULOS(NRORADICADO) LOOP
       
              BEGIN
                SELECT ID_TRAMITE
                INTO V_ID_TRAMITE
                FROM DS_TRAMITE DT
                WHERE DT.NRO_PLACA = VR.NRO_PLACA AND
                      DT.ID_RADICADO = NRORADICADO AND
                      ROWNUM = 1;
               EXCEPTION
               WHEN OTHERS THEN
                V_ID_TRAMITE := 0;
               END;
               
              -- VALIDACION QUE LA PLACA VENGA EN LOS 3 REGISTROS ADICIONALES DIFERENTE AL DE VEHICULOS.
              IF V_ID_TRAMITE <> 65 THEN
                SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_VEHICULO DV
                       INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DV.NRO_PLACA = DP.NRO_PLACA AND DV.ID_RADICADO = DP.ID_RADICADO)
                       INNER JOIN DS_CONTRIBUYENTE DC ON (DP.ID_RADICADO = DC.ID_RADICADO AND DP.ID_USUARIO = DC.ID_USUARIO AND DP.ID_DOCUMENTO = DC.ID_DOCUMENTO)
                       INNER JOIN DS_TRAMITE DT ON (DV.ID_RADICADO = DT.ID_RADICADO AND DV.NRO_PLACA = DT.NRO_PLACA)                     
                 WHERE DV.NRO_PLACA = VR.NRO_PLACA AND DV.ID_RADICADO = NRORADICADO;
              ELSE --VALIDACION PARA TRASPASO INDETERMINADO, EN ESTE CASO NO VIENE INFORMACION DE CONTRIBUYENTE
                SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_VEHICULO DV
                       INNER JOIN DEPURACION.DS_PROPIETARIO DP ON (DV.NRO_PLACA = DP.NRO_PLACA AND DV.ID_RADICADO = DP.ID_RADICADO)
                       INNER JOIN DS_TRAMITE DT ON (DV.ID_RADICADO = DT.ID_RADICADO AND DV.NRO_PLACA = DT.NRO_PLACA)                     
                 WHERE DV.NRO_PLACA = VR.NRO_PLACA AND DV.ID_RADICADO = NRORADICADO;
              END IF;
              
               IF ( VCONTEO = 0 ) THEN -- SI NO EXISTE                    
                    -- SE MARCA TODO EL DATOS DE CADA UNO DE LOS REGISTROS COMO INCONSISTENCIA.
                      UPDATE DEPURACION.DS_VEHICULO SET ESTADO_VALIDACION = 'VI'
                             WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    
                    -- SE INSERTA LA INCONSISTENCIA PARA EL REGISTRO DE VEHICULOS.
                    
                    VEXISTE := 0;
                    
                    SELECT COUNT(1) 
                    INTO VEXISTE 
                    FROM DEPURACION.DS_INCONSISTENCIA
                    WHERE ID_RADICADO = VR.ID_RADICADO AND
                        ID_REGISTRO_FALLO = VR.NRO_IDENTIFICADOR AND
                        ID_TIPO_REGISTRO = 1 AND
                        ID_ESTADO_EXCEPCION = 1 AND
                        IDENTIFICADOR = 'INCOMPLETO' AND
                        ID_INCONSISTENCIA = 55;
                    
                    IF VEXISTE = 0 THEN
                      
                      SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
                         WHERE ID_RADICADO = VR.ID_RADICADO AND
                                ID_REGISTRO_FALLO = VR.NRO_IDENTIFICADOR AND
                                ID_TIPO_REGISTRO = 1 AND
                                ID_ESTADO_EXCEPCION = 2 AND
                                IDENTIFICADOR = 'INCOMPLETO' AND
                                ID_INCONSISTENCIA = 55;
          
                      IF ( VEXISTE > 0 ) THEN
                            
                              UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 4
                                   WHERE ID_RADICADO = VR.ID_RADICADO AND
                                          ID_REGISTRO_FALLO = VR.NRO_IDENTIFICADOR AND
                                          ID_TIPO_REGISTRO = 1 AND
                                          ID_ESTADO_EXCEPCION = 2 AND
                                          IDENTIFICADOR = 'INCOMPLETO' AND
                                          ID_INCONSISTENCIA = 55;
                            
                      END IF;
                      
                      INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES(DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL,VR.ID_RADICADO,VR.NRO_IDENTIFICADOR, 1, 1, 55, 'INCOMPLETO', SYSDATE, SYSDATE + NDIAS);                      
                    END IF;
                    
                    -- REGISTRAR INCONSISTENCIA DE PROPIETARIO POR NO EXISTENCIA DEL MISMO PARA LA PLACA. 
                      UPDATE DEPURACION.DS_PROPIETARIO SET ESTADO_VALIDACION = 'VI'
                             WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    
                    SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_PROPIETARIO
                           WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;                    
                    IF (VCONTEO > 0) THEN
                        /*SELECT NRO_IDENTIFICADOR INTO NROREGISTRO FROM DEPURACION.DS_PROPIETARIO
                                WHERE NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES(DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VR.ID_RADICADO, NROREGISTRO, 3, 1, 55, 'INCOMPLETO', SYSDATE, SYSDATE + NDIAS);*/
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA
                        SELECT DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VR.ID_RADICADO, DP.NRO_IDENTIFICADOR, 3, 1, 55, 'INCOMPLETO', SYSDATE, SYSDATE + NDIAS
                        FROM DEPURACION.DS_PROPIETARIO DP
                        WHERE DP.NRO_PLACA = VR.NRO_PLACA AND DP.ID_RADICADO = NRORADICADO;
                    END IF;
                    -- REGISTRAR INCONSISTENCIA DE CONTRIBYENTE POR NO EXISTENCIA DEL MISMO PARA EL PROPIETARIO DE LA PLACA RELACIONADA.
                    VCONTEO := 0;
                    SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_CONTRIBUYENTE DC
                           WHERE (DC.ID_DOCUMENTO, DC.ID_USUARIO) IN ( SELECT DP.ID_DOCUMENTO, DP.ID_USUARIO FROM DEPURACION.DS_PROPIETARIO DP
                                                                             WHERE DP.NRO_PLACA = VR.NRO_PLACA AND DP.ID_RADICADO = NRORADICADO)
														AND DC.ID_RADICADO = NRORADICADO;
                            
                      UPDATE DEPURACION.DS_CONTRIBUYENTE DC SET ESTADO_VALIDACION = 'VI'
                             WHERE (DC.ID_DOCUMENTO, DC.ID_USUARIO) IN ( SELECT DP.ID_DOCUMENTO, DP.ID_USUARIO FROM DEPURACION.DS_PROPIETARIO DP
                                                                               WHERE DP.NRO_PLACA = VR.NRO_PLACA AND DP.ID_RADICADO = NRORADICADO)
                              AND DC.ID_RADICADO = NRORADICADO;
                    
                    IF (VCONTEO > 0) THEN
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA
                        SELECT DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VR.ID_RADICADO, DC.NRO_IDENTIFICADOR, 2, 1, 55, 'INCOMPLETO', SYSDATE, SYSDATE + NDIAS
                        FROM DEPURACION.DS_CONTRIBUYENTE DC
                        WHERE (DC.ID_DOCUMENTO, DC.ID_USUARIO) IN ( SELECT DP.ID_DOCUMENTO, DP.ID_USUARIO FROM DEPURACION.DS_PROPIETARIO DP
                                                                                 WHERE DP.NRO_PLACA = VR.NRO_PLACA AND DP.ID_RADICADO = NRORADICADO)
                                AND DC.ID_RADICADO = NRORADICADO;
                    END IF;
                    -- REGISTRAR INCONSISTENCIA DEL TRAMITE POR NO EXISTENCIA DEL MISMO PARA LA PLACA RELACIONADA.
                    VCONTEO := 0;
                    SELECT COUNT(1) INTO VCONTEO FROM DEPURACION.DS_TRAMITE DT
                            WHERE DT.NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;     
                    
                      UPDATE DEPURACION.DS_TRAMITE DT SET ESTADO_VALIDACION = 'VI'
                             WHERE DT.NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    
                    IF (VCONTEO > 0 ) THEN
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA
                        SELECT DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL,VR.ID_RADICADO, DT.NRO_IDENTIFICADOR, 4, 1, 55, 'INCOMPLETO', SYSDATE, SYSDATE + NDIAS
                        FROM DEPURACION.DS_TRAMITE DT
                        WHERE DT.NRO_PLACA = VR.NRO_PLACA AND ID_RADICADO = NRORADICADO;
                    END IF;
                    COMMIT;
               ELSE                    
                    
                    -- INVOCO LA COLECCION DE CAMPOS PARA LE PROCESAMIENTO DE CADA UNO DE LOS DATOS PARA LOS REGISTROS.
                    SP_VALIDACION_CAMPOS(1, VR.NRO_IDENTIFICADOR, NRORADICADO);                         
                    FOR PR IN CPROPIETARIOS(VR.NRO_PLACA, VR.ID_RADICADO) LOOP
                        SP_VALIDACION_CAMPOS(3, PR.NRO_IDENTIFICADOR, PR.ID_RADICADO);
                        
                        IF V_ID_TRAMITE <> 65 THEN --APLICO VALIDACIONES PARA CONTRIBUYENTES EXCEPTO PARA TRAMITE DE TRASPASO INDETERMINADO(65)
                          FOR CR IN CCONTRIBUYENTES(PR.ID_DOCUMENTO, PR.ID_USUARIO, PR.ID_RADICADO) LOOP
                              SP_VALIDACION_CAMPOS(2, CR.NRO_IDENTIFICADOR, CR.ID_RADICADO);
                              SP_VALIDACION_DIRECCION(CR.NRO_IDENTIFICADOR, CR.ID_RADICADO);
                          END LOOP;
                        END IF;
                    END LOOP;                    
                    FOR CT IN CTRAMITES(VR.NRO_PLACA, NRORADICADO) LOOP
                        SP_VALIDACION_CAMPOS(4, CT.NRO_IDENTIFICADOR, NRORADICADO);
                    END LOOP;
                    SWVALIDA := 1;
                    
               END IF;
        END LOOP;
        
				-- DESPUES DE RECORRER TODOS LOS DATOS DE LOS 4 REGISTROS Y AQUELLOS QUE SUFRIERON INCONSISTENCIAS PERO QUE NO SON DE TIPO EXCEPCION RESPECTO A LAS VALIDACIONES REALIZADAS
        -- SE DA POR HECHO QUE EL DATO ESTA CORRECTO EN LOS 4 REGISTROS Y SE PUEDE PASAR A UN ESTADO EXITOSO.
        IF (SWVALIDA = 1 ) THEN
        -- ACTUALIZACION DE VEHICULOS QUE NO TIENEN INCONSISTENCIAS O QUE SOLO TIENE ALERTAS
            UPDATE DEPURACION.DS_VEHICULO DV SET DV.ESTADO_VALIDACION = 'VE' 
                WHERE DV.ESTADO_VALIDACION LIKE 'VP' AND DV.ID_RADICADO = NRORADICADO;
            UPDATE DEPURACION.DS_VEHICULO DV SET DV.ESTADO_VALIDACION = 'VE' 
                WHERE DV.ESTADO_VALIDACION LIKE 'VI' AND DV.ID_RADICADO = NRORADICADO
                AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_INCONSISTENCIA DI
                                  INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA                      
                                      WHERE DTI.TIPO_INCONSISTENCIA = 'E' AND DI.ID_REGISTRO_FALLO = DV.NRO_IDENTIFICADOR
                           );
            -- ACTUALIZACION DE CONTRIBUYENTE QUE NO TIENEN INCONSISTENCIAS O QUE SOLO TIENE ALERTAS           
            UPDATE DEPURACION.DS_CONTRIBUYENTE DC SET DC.ESTADO_VALIDACION = 'VE' 
                WHERE DC.ESTADO_VALIDACION LIKE 'VP' AND DC.ID_RADICADO = NRORADICADO;
            UPDATE DEPURACION.DS_CONTRIBUYENTE DC SET DC.ESTADO_VALIDACION = 'VE' 
                WHERE DC.ESTADO_VALIDACION LIKE 'VI' AND DC.ID_RADICADO = NRORADICADO
                AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_INCONSISTENCIA DI
                                  INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA                      
                                      WHERE DTI.TIPO_INCONSISTENCIA = 'E' AND DI.ID_REGISTRO_FALLO = DC.NRO_IDENTIFICADOR
                           );
            -- ACTUALIZACION DE PROPIETARIOS QUE NO TIENEN INCONSISTENCIAS O QUE SOLO TIENE ALERTAS           						
            UPDATE DEPURACION.DS_PROPIETARIO DP SET DP.ESTADO_VALIDACION = 'VE' 
                WHERE DP.ESTADO_VALIDACION LIKE 'VP' AND DP.ID_RADICADO = NRORADICADO;
            UPDATE DEPURACION.DS_PROPIETARIO DP SET DP.ESTADO_VALIDACION = 'VE' 
                WHERE DP.ESTADO_VALIDACION LIKE 'VI' AND DP.ID_RADICADO = NRORADICADO
                AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_INCONSISTENCIA DI
                                  INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA                      
                                      WHERE DTI.TIPO_INCONSISTENCIA = 'E' AND DI.ID_REGISTRO_FALLO = DP.NRO_IDENTIFICADOR
                           );
            -- ACTUALIZACION DE TRAMITES QUE NO TIENEN INCONSISTENCIAS O QUE SOLO TIENE ALERTAS           						
            UPDATE DEPURACION.DS_TRAMITE DT SET DT.ESTADO_VALIDACION = 'VE' 
                WHERE DT.ESTADO_VALIDACION LIKE 'VP' AND DT.ID_RADICADO = NRORADICADO;
            UPDATE DEPURACION.DS_TRAMITE DT SET DT.ESTADO_VALIDACION = 'VE' 
                WHERE DT.ESTADO_VALIDACION LIKE 'VI' AND DT.ID_RADICADO = NRORADICADO
                AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_INCONSISTENCIA DI
                                  INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA                      
                                      WHERE DTI.TIPO_INCONSISTENCIA = 'E' AND DI.ID_REGISTRO_FALLO = DT.NRO_IDENTIFICADOR
                           );                       
						COMMIT;
        END IF;
        -- INVOCAR EL PROCEDIMIENTO DE CALCULO DE INFORME DE REGISTROS.
        SP_INFORME_REGISTROS(NRORADICADO,1);        
        -- INOVACAR EL PAQUETE DE ACTUALIZACION DE REGISTROS.
        DEPURACION.PKG_DS_ACTUALIZACION_REGISTROS.SP_PROCESAR_REGISTRO_LOTE(NRORADICADO);
        
  END SP_VALIDADOR_REGISTROS;

 PROCEDURE SP_VALIDACION_DIRECCION(IDIDENTIFICADOR NUMBER, NRORADICADO NUMBER) AS
      
      CURSOR DIRECCIONES IS
           SELECT * FROM DEPURACION.DS_DIRECCIONES
                  WHERE NRO_IDENTIFICADOR = IDIDENTIFICADOR
                        AND ID_RADICADO = NRORADICADO
                        AND ESTADO_VALIDACION = 'VP';
                        
      V_ERROR BOOLEAN := FALSE;   ---- Variable para verificar si existe o no inconsistencias en el historico de direcciones    
      SQLPARAME VARCHAR2(4000);  --- Variable para guardar  el SQL parametrico para validar la homologacion  
      VPARAMET NUMBER;                 --- variable para guardar el resultado del SQL parametrico para validar la homologacion  
 BEGIN
      FOR XDIR IN DIRECCIONES LOOP
            BEGIN                  
                  SQLPARAME := FT_ARMADO_SQL_PARAMETRICO(33);
                  SQLPARAME := SQLPARAME||''''||XDIR.ID_CIUDAD||'''';
                  EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET;
                  IF (VPARAMET = 0 ) THEN
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, NRORADICADO, IDIDENTIFICADOR, 5, 5, 19, 'ID_CIUDAD', SYSDATE, SYSDATE + 0);
                        V_ERROR := TRUE;
                  END IF;
                  IF ( DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_VALIDAR_DIRECCION(XDIR.DIRECCION,1) ) THEN
                       INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, NRORADICADO, IDIDENTIFICADOR, 5, 5, 112, 'DIRECCION', SYSDATE, SYSDATE + 0);
                       V_ERROR := TRUE;
                  END IF;
                  IF ( DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_VALIDAR_TELEFONO_FAX(XDIR.TELEFONO,'T',1)) THEN
                      INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, NRORADICADO, IDIDENTIFICADOR, 5, 5, 113, 'TELEFONO', SYSDATE, SYSDATE + 0);
                      V_ERROR := TRUE;
                  END IF;
                  IF ( DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.FT_VALIDAR_TELEFONO_FAX(XDIR.TELEFONO,'F',1)) THEN
                      INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, NRORADICADO, IDIDENTIFICADOR, 5, 5, 113, 'FAX', SYSDATE, SYSDATE + 0);
                      V_ERROR := TRUE;
                  END IF; 
                  
                  IF V_ERROR THEN
                        UPDATE DEPURACION.DS_DIRECCIONES set ESTADO_VALIDACION = 'VI'
                            WHERE ID_DIRECCION = XDIR.ID_DIRECCION;                  
                  ELSE
                        UPDATE DEPURACION.DS_DIRECCIONES set ESTADO_VALIDACION = 'VE'
                            WHERE ID_DIRECCION = XDIR.ID_DIRECCION;
                  END IF;
            commit;
             EXCEPTION
                     WHEN OTHERS THEN
														INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
																	 VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_DIRECCIONES',NRORADICADO,IDIDENTIFICADOR,'ERROR: EN LA DEPURACION DE DATOS :. ', 2);                     
--                          DBMS_OUTPUT.PUT_LINE('ERROR: '||SQLERRM);
             END;
      END LOOP;
 END SP_VALIDACION_DIRECCION;

  PROCEDURE  SP_VALIDACION_CAMPOS(IDREGISTRO NUMBER,IDIDENTIFICADOR NUMBER, NRORADICADO NUMBER) AS

  SQLPARAME           VARCHAR2(32000); -- VARIABLE QUE CONTIENE EL SQL DE LAS HOMOLOGACIONES PARAMETRICAS
  SQLOBLIGA           VARCHAR2(32000); -- VARIABLE QUE CONTIENE EL SQL DE LA OBLIGATORIEDAD DE LOS CAMPOS REQUERIDOS
  SQLVALIDA           VARCHAR2(32000); -- VARIABLE QUE CONTIENE LA CONSTRUCCION DEL SQL PARA EL CAMPO A EVALUAR.
  SQLUPDATE           VARCHAR2(32000); -- VARIABLE QUE CONTIENE EL SQL DE ACTUALIZACION DEL ESTADO DEL REGISTRO EN LA VALIDACION DE CAMPOS
  VCAMPOERR           VARCHAR2(80);    -- VARIABLE QUE CONTIENE EL CAMPO ERRONEO
  VNRO_RADICADO       VARCHAR2(10);    -- VARIABLE QUE GUARDA EL NUMERO DEL RADICADO DEL LOTE PROCESADO.
  VDATOCAMPO          VARCHAR2(50);    -- VARIABLE QUE GUARDA EL DATO DEL CAMPO DEL SQL CONSTRUIDO.
	MSJ_ERROR           VARCHAR2(4000);  -- VARIABLE QUE GUARDA EL MENSAJE DE ERROR A REPORTAR.
	NDIAS               NUMBER;          -- VARIABLE QUE GUARDA EL NUMERO DE DIAS PARAMETRIZADOS PARA LA CORRECCI�N.
  VPARAMET            NUMBER;          -- VARIABLE QUE GUARDA LA VALIDACI�N EXITOSA DE LA HOMOLOGACION PARAMETRICA. 1 = OK / 0 = ERR
  VOBLIGAT            NUMBER;          -- VARIABLE QUE GUARDA LA VALIDACI�N EXITOSA DE LA OBLIGATORIEDAD DEL CAMPO. 1 = OK / 0 = ERR
  VINCOSISTENCIA      NUMBER;	         -- VARIABLE QUE GUARDA EL ID DE LA INCONSISTENCIA REPORTADA.
	VTRAMITE            NUMBER;	         -- VARIABLE QUE GUARDA LA VALIDACION EXITOSA DE TRAMITES ESPECIFICOS.

  CURSOR CVALIDA(VID_REGISTRO NUMBER)
  IS
		SELECT DISTINCT DTR.ESQUEMA, DTR.ID_TIPO_REGISTRO, DTR.NOMBRE_TABLA, DCA.ID_CAMPO, DCA.NOMBRE_CAMPO, DCA.TIPO_DATO_CAMPO, DCA.APLICA_PARAMETRICA, DCA.APLICA_NEGOCIO, DCA.OBLIGATORIO
					FROM DEPURACION.DS_CAMPO_ARCHIVO DCA
		INNER JOIN DEPURACION.DS_TIPO_REGISTRO DTR
							ON DTR.ID_TIPO_REGISTRO = DCA.ID_TIPO_REGISTRO
		INNER JOIN DEPURACION.DS_VALIDACIONES_CAMPO DVC
							ON DVC.ID_CAMPO = DCA.ID_CAMPO
				WHERE DCA.ACTIVO   = 'S' AND DTR.ID_TIPO_REGISTRO = VID_REGISTRO
			UNION
		SELECT  DTR.ESQUEMA, DTR.ID_TIPO_REGISTRO, DTR.NOMBRE_TABLA, DCA.ID_CAMPO, DCA.NOMBRE_CAMPO, DCA.TIPO_DATO_CAMPO, DCA.APLICA_PARAMETRICA, DCA.APLICA_NEGOCIO, DCA.OBLIGATORIO
					FROM DS_CAMPO_ARCHIVO DCA
		INNER JOIN DS_TIPO_REGISTRO DTR
							ON DTR.ID_TIPO_REGISTRO = DCA.ID_TIPO_REGISTRO
		INNER JOIN DS_CAMPO_PARAMETRICO DCP
							ON DCP.ID_CAMPO         = DCA.ID_CAMPO
				WHERE DCA.ACTIVO = 'S' AND DTR.ID_TIPO_REGISTRO = VID_REGISTRO;
        
    VEXISTE NUMBER := 0;
    
    --TYPE CAMPOS_ARRAY IS TABLE OF NUMBER;
    VCAMPOS         DEPURACION.CAMPOS_ARRAY := DEPURACION.CAMPOS_ARRAY(1);
    POS NUMBER := 0;
    
BEGIN
      -- GUARDAR VARIABLES NO CAMBIAN DENTRO DEL PROCESO
      VNRO_RADICADO := NRORADICADO;
      SELECT VALOR INTO NDIAS FROM QUIPUX.QX_PROCESO_PARAMETRO_TRANSITO 
			 			 WHERE ID_PROCESO = 60 AND ID_PARAMETRO = 7; 
    
      FOR X IN CVALIDA(IDREGISTRO)
          LOOP
            -- INICIO DE VALIDACION DE OBLIGATORIEDAD DEL CAMPO
            SQLUPDATE := 'UPDATE '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' SET ESTADO_VALIDACION = ''VI'' WHERE NRO_IDENTIFICADOR = '||IDIDENTIFICADOR;
            IF ( X.OBLIGATORIO = 'S' ) THEN
                  -- REGISTROS VEH, PROP, TRAM
                  SQLOBLIGA := 'SELECT COUNT(1) FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE '||X.NOMBRE_CAMPO||'  IS NOT NULL AND NRO_IDENTIFICADOR = '||IDIDENTIFICADOR;
                  EXECUTE IMMEDIATE SQLOBLIGA INTO VOBLIGAT;
                  -- VALIDACION DE LA OBLIGATORIEDAD 0 ERROR 1 EXITOSA
                  IF ( VOBLIGAT = 0 ) THEN 
                      -- SE REGISTRA LA INCONSISTENCIA DE OBLIGATORIEDAD DEL CAMPO
                      EXECUTE IMMEDIATE SQLUPDATE;
                      
                      VEXISTE := 0;
                    
                      SELECT COUNT(1) 
                      INTO VEXISTE 
                      FROM DEPURACION.DS_INCONSISTENCIA
                      WHERE ID_RADICADO = VNRO_RADICADO AND
                          ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                          ID_TIPO_REGISTRO = IDREGISTRO AND
                          ID_ESTADO_EXCEPCION = 1 AND
                          IDENTIFICADOR = X.NOMBRE_CAMPO AND
                          ID_INCONSISTENCIA = 56;
                      
                      IF VEXISTE = 0 THEN
                      
                        SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
                           WHERE ID_RADICADO = VNRO_RADICADO AND
                                  ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                  ID_TIPO_REGISTRO = IDREGISTRO AND
                                  ID_ESTADO_EXCEPCION = 2 AND
                                  IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                  ID_INCONSISTENCIA = 56;
            
                        IF ( VEXISTE > 0 ) THEN
                              
                              UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 4
                                   WHERE ID_RADICADO = VNRO_RADICADO AND
                                          ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                          ID_TIPO_REGISTRO = IDREGISTRO AND
                                          ID_ESTADO_EXCEPCION = 2 AND
                                          IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                          ID_INCONSISTENCIA = 56;
                              
                        END IF;
                        INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VNRO_RADICADO, IDIDENTIFICADOR, IDREGISTRO, 1, 56, X.NOMBRE_CAMPO, SYSDATE,SYSDATE+NDIAS);								
                      END IF;
											VOBLIGAT := 1; -- SE PASA A OBLIGATORIO EXITOSO DEBIDO A QUE EL CAMPO PUEDE TENER VALIDACION DE PARAMETRICA.
                  END IF;          
            END IF;   
						IF ( VOBLIGAT > 0 ) THEN
                  -- VALIDACION DE HOMOLOGACION DE PARAMETRICAS
									IF ( X.APLICA_PARAMETRICA = 'S' ) THEN
												BEGIN
																SQLPARAME := FT_ARMADO_SQL_PARAMETRICO(X.ID_CAMPO);
																-- REGISTROS VEH, PROP, TRAM
  															SQLVALIDA := 'SELECT TRIM('|| X.NOMBRE_CAMPO ||') FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||IDIDENTIFICADOR;
																EXECUTE IMMEDIATE SQLVALIDA INTO VDATOCAMPO;
                                IF ( X.OBLIGATORIO = 'S' AND VDATOCAMPO IS NULL) THEN
                                    SELECT ID_INCOSISTENCIA INTO VINCOSISTENCIA FROM DEPURACION.DS_CAMPO_PARAMETRICO  WHERE ID_CAMPO = X.ID_CAMPO;
                                    
                                    VEXISTE := 0;
                    
                                    SELECT COUNT(1) 
                                    INTO VEXISTE 
                                    FROM DEPURACION.DS_INCONSISTENCIA
                                    WHERE ID_RADICADO = VNRO_RADICADO AND
                                        ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                        ID_TIPO_REGISTRO = IDREGISTRO AND
                                        ID_ESTADO_EXCEPCION = 1 AND
                                        IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                        ID_INCONSISTENCIA = VINCOSISTENCIA;
                                    
                                    IF VEXISTE = 0 THEN   
                                      
                                      SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
                                        WHERE ID_RADICADO = VNRO_RADICADO AND
                                              ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                              ID_TIPO_REGISTRO = IDREGISTRO AND
                                              ID_ESTADO_EXCEPCION = 2 AND
                                              IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                              ID_INCONSISTENCIA = VINCOSISTENCIA;
                          
                                      IF ( VEXISTE > 0 ) THEN
                                            
                                            UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 4
                                                 WHERE ID_RADICADO = VNRO_RADICADO AND
                                                        ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                                        ID_TIPO_REGISTRO = IDREGISTRO AND
                                                        ID_ESTADO_EXCEPCION = 2 AND
                                                        IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                                        ID_INCONSISTENCIA = VINCOSISTENCIA;
                                            
                                      END IF;
                                      
                                      INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VNRO_RADICADO, IDIDENTIFICADOR, IDREGISTRO, 1, VINCOSISTENCIA, X.NOMBRE_CAMPO, SYSDATE, SYSDATE + NDIAS);
                                    END IF;
                                    EXECUTE IMMEDIATE SQLUPDATE;
                                ELSIF ( VDATOCAMPO IS NOT NULL ) THEN
                                -- SI EL CAMPO NO VIENE NULL SE EJECUTA EL SQL PARAMETRICO DE ACUERDO AL CAMPO
                                   CASE 
                                      -- CAMPOS ID_MARCA,ID_LINEA,ID_CLASE,ID_SERVICIO,ID_COMBUSTIBLE,ID_BATERIA,ID_SECRETARIA,ID_DOCUMENTO,ID_CIUDAD,ID_PAIS,TIPO_CANCELACION
                                      WHEN X.ID_CAMPO IN (2, 4, 7, 9, 14, 16, 19, 32, 33, 42, 49, 55,77)  THEN
                                          IF ( X.ID_CAMPO IN  (55)) THEN
                                              SQLPARAME := SQLPARAME||''''||VDATOCAMPO||'''';
                                          ELSE
                                              SQLPARAME := SQLPARAME||VDATOCAMPO;
                                          END IF;
                                          VCAMPOERR := VDATOCAMPO;																	
                                          EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET ;
                                      -- CAMPOS ID_CARROCERIA
                                      WHEN X.ID_CAMPO = 11 THEN
                                        SQLPARAME := REPLACE(SQLPARAME,':VP',VDATOCAMPO);
                                        VCAMPOERR := VDATOCAMPO;--||'-'||VDATOCAMPO;
                                        SQLVALIDA := 'SELECT ID_CLASE FROM '||X.ESQUEMA||'.'||X.NOMBRE_TABLA||' WHERE NRO_IDENTIFICADOR = '||IDIDENTIFICADOR;
                                        EXECUTE IMMEDIATE SQLVALIDA INTO VDATOCAMPO;
                                        SQLPARAME := REPLACE(SQLPARAME,':VS',VDATOCAMPO);
                                        EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET  ;--,        X.ID_CLASE;
                                      -- CAMPOS ID_SECRETARIA_DESTINO, ID_SECRETARIA_ORIGEN
                                      WHEN X.ID_CAMPO IN (56, 57) THEN
                                        SQLPARAME := SQLPARAME||' '''||VDATOCAMPO||'''';
                                        SELECT COUNT(1) INTO VTRAMITE FROM DEPURACION.DS_TRAMITE WHERE ID_RADICADO = VNRO_RADICADO AND ID_TRAMITE IN (10, 15) AND NRO_IDENTIFICADOR = IDIDENTIFICADOR;
                                        IF VTRAMITE = 1 THEN
                                            VCAMPOERR := VDATOCAMPO;
                                            EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET ;
                                        ELSE
                                            VPARAMET := 1;
                                        END IF;
                                      -- CAMPOS ID_CARROCERIA_NUEVA
                                      WHEN X.ID_CAMPO = 60 THEN
                                        SQLPARAME := REPLACE(SQLPARAME,':VP',VDATOCAMPO);
                                        VCAMPOERR := VDATOCAMPO;--||'-'||VDATOCAMPO;
                                        SELECT COUNT(1) INTO VTRAMITE FROM DEPURACION.DS_TRAMITE WHERE ID_RADICADO = VNRO_RADICADO AND TO_NUMBER(ID_TRAMITE) = 2 AND NRO_IDENTIFICADOR = IDIDENTIFICADOR;
                                        IF VTRAMITE = 1 THEN --
                                            SQLVALIDA := 'SELECT ID_CLASE FROM DEPURACION.DS_VEHICULO WHERE NRO_IDENTIFICADOR = '||IDIDENTIFICADOR;
                                            EXECUTE IMMEDIATE SQLVALIDA INTO VDATOCAMPO;
                                            SQLPARAME := REPLACE(SQLPARAME,':VS',VDATOCAMPO);
                                            EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET  ;--,        X.ID_CLASE;
                                        ELSE
                                            VPARAMET := 1;
                                        END IF;
                                      -- CAMPOS ID_SERVICIO_ANTERIOR, ID_SERVICIO_NUEVO
                                      WHEN X.ID_CAMPO = 64 THEN
                                        SELECT COUNT(1) INTO VTRAMITE FROM DEPURACION.DS_TRAMITE WHERE ID_RADICADO = VNRO_RADICADO AND ID_TRAMITE = 6 AND NRO_IDENTIFICADOR = IDIDENTIFICADOR;                                      
                                        IF VTRAMITE = 1 THEN
                                            SQLPARAME := SQLPARAME||' '''||VDATOCAMPO||'''';
                                            VCAMPOERR := VDATOCAMPO;
                                            EXECUTE IMMEDIATE SQLPARAME INTO VPARAMET ;
                                        ELSE
                                            VPARAMET := 1;
                                        END IF;
                                      END CASE;
                                END IF;
													EXCEPTION
															 WHEN OTHERS THEN
                               -- INCONSISTENCIA POR FALTA DE PARAMETRIZACION O MALA PARAMETRIZACI�N EN LAS TABLAS DS_CAMPO_PARAMETRICO, DS_VALIDACION_PARAMETRICA, DS_VALIDACIONES_CAMPO
																		MSJ_ERROR := SQLERRM;
																		VPARAMET := 0;
																		INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
																				 VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_VALIDACION_PARAMETRICA',VNRO_RADICADO,IDIDENTIFICADOR,'ERROR: NO SE ENCUENTRA CONFIGURADO EL CAMPO: '||X.NOMBRE_CAMPO||' DENTRO DE LA CONFIGURACION PARAMETRICA Y ESTA MARCADO COMO CAMPO PARAMETRICO:. ', 2);
													END; 
                    -- SI LA PARAMETRIZACION NO SE ENCUENTRA HOMOLOGADA O LOS CODIGOS REGISTRADOS NO TIENE HOMOLOGACION REGISTRA INCONSISTENCIA.
										IF ( VPARAMET = 0 ) THEN
                      BEGIN
                          VPARAMET := X.ID_CAMPO;
                          EXECUTE IMMEDIATE SQLUPDATE;                      
                          SELECT ID_INCOSISTENCIA INTO VINCOSISTENCIA FROM DEPURACION.DS_CAMPO_PARAMETRICO  WHERE ID_CAMPO = X.ID_CAMPO;
                          
                          VEXISTE := 0;
                    
                          SELECT COUNT(1) 
                          INTO VEXISTE 
                          FROM DEPURACION.DS_INCONSISTENCIA
                          WHERE ID_RADICADO = VNRO_RADICADO AND
                              ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                              ID_TIPO_REGISTRO = IDREGISTRO AND
                              ID_ESTADO_EXCEPCION = 1 AND
                              IDENTIFICADOR = X.NOMBRE_CAMPO AND
                              ID_INCONSISTENCIA = VINCOSISTENCIA;
                          
                          IF VEXISTE = 0 THEN
                            
                            SELECT COUNT(1) INTO VEXISTE FROM DEPURACION.DS_INCONSISTENCIA
                              WHERE ID_RADICADO = VNRO_RADICADO AND
                                    ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                    ID_TIPO_REGISTRO = IDREGISTRO AND
                                    ID_ESTADO_EXCEPCION = 2 AND
                                    IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                    ID_INCONSISTENCIA = VINCOSISTENCIA;
                
                            IF ( VEXISTE > 0 ) THEN
                                  
                                  UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 4
                                       WHERE ID_RADICADO = VNRO_RADICADO AND
                                            ID_REGISTRO_FALLO = IDIDENTIFICADOR AND
                                            ID_TIPO_REGISTRO = IDREGISTRO AND
                                            ID_ESTADO_EXCEPCION = 2 AND
                                            IDENTIFICADOR = X.NOMBRE_CAMPO AND
                                            ID_INCONSISTENCIA = VINCOSISTENCIA;
                                  
                            END IF;
                            
                            INSERT INTO DEPURACION.DS_INCONSISTENCIA VALUES ( DEPURACION.SEQ_DS_INCONSISTENCIA.NEXTVAL, VNRO_RADICADO, IDIDENTIFICADOR, IDREGISTRO, 1, VINCOSISTENCIA, X.NOMBRE_CAMPO, SYSDATE, SYSDATE + NDIAS);
                          END IF;
                      EXCEPTION
                         WHEN OTHERS THEN
														INSERT INTO DEPURACION.DS_DETALLE_ERRORES_REGISTROS
																	 VALUES (DEPURACION.SEQ_DS_DETALLE_ERROR_REGISTRO.NEXTVAL,'DS_VALIDACION_PARAMETRICA',VNRO_RADICADO,IDIDENTIFICADOR,'ERROR: NO SE ENCUENTRA CONFIGURADO EL CAMPO: '||X.NOMBRE_CAMPO||' DENTRO DE LA CONFIGURACION PARAMETRICA Y ESTA MARCADO COMO CAMPO PARAMETRICO:. ', 2);
                      END;
                    END IF;
									END IF;                  
						END IF;
            COMMIT;
      END LOOP;
      
      -- APLICA REGLAS DE NEGOCIO PARA EL DATO EVALUADO POR REGISTRO.
      FOR CPOS IN (SELECT ID_CAMPO FROM DEPURACION.DS_CAMPO_ARCHIVO WHERE APLICA_NEGOCIO = 'S' AND ID_TIPO_REGISTRO = IDREGISTRO) LOOP
            --VCAMPOS.EXTEND(POS);
            POS := POS + 1;
            VCAMPOS(POS) := CPOS.ID_CAMPO;
            VCAMPOS.EXTEND;            
      END LOOP;
      
			IF ( IDREGISTRO = 1 ) THEN
						DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, IDIDENTIFICADOR, VCAMPOS , IDREGISTRO);
  		ELSIF ( IDREGISTRO = 2 ) THEN
						DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, IDIDENTIFICADOR, VCAMPOS, IDREGISTRO);
			ELSIF ( IDREGISTRO = 3 ) THEN
						DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, IDIDENTIFICADOR, VCAMPOS, IDREGISTRO);
			ELSIF ( IDREGISTRO = 4 ) THEN
						DEPURACION.PKG_DS_VALIDACIONES_REGISTRO.SP_PROCESAR_DATOS(VNRO_RADICADO, IDIDENTIFICADOR, VCAMPOS, IDREGISTRO);
			END IF;
      
  END SP_VALIDACION_CAMPOS;


  PROCEDURE SP_INFORME_REGISTROS(NRORADICADO NUMBER, PROCESO NUMBER) AS
  
  -- PROCESO :INDICADOR DEL CALCULO DEL INFORME PARA LOS TOTALES DEL VALIDADOR Y DE LA ACTUALIZACION
  -- 1 PARA TOTALES DEL VALIDADOR
  -- 2 PARA TOTALES DE LA ACTUALIZACI�N
  TYPE TIPO_CURSOR IS REF CURSOR;
  REGCURSOR TIPO_CURSOR;
  
  CURSOR TREGISTROS IS
      SELECT DTR.ID_TIPO_REGISTRO, DTR.ESQUEMA, DTR.NOMBRE_TABLA
          FROM DS_TIPO_REGISTRO DTR
               WHERE DTR.ACTIVO = 'S';  
         
  CURSOR ACTESTADOINCONSISTENCIAS IS
    SELECT DI.ID_EXCEPCION AS ID_EXCEPCION FROM DEPURACION.DS_INCONSISTENCIA DI
        INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
        INNER JOIN DEPURACION.DS_VEHICULO DV ON DV.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO
            WHERE DI.ID_ESTADO_EXCEPCION IN (2) --AND DV.ESTADO_VALIDACION LIKE 'VE'
              --AND DTI.TIPO_INCONSISTENCIA = 'E'
              AND DI.ID_RADICADO = NRORADICADO
    UNION ALL
      SELECT DI.ID_EXCEPCION FROM DEPURACION.DS_INCONSISTENCIA DI
          INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
          INNER JOIN DEPURACION.DS_PROPIETARIO DP ON DP.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO
            WHERE DI.ID_ESTADO_EXCEPCION IN (2) --AND DP.ESTADO_VALIDACION LIKE 'VE'
              --AND DTI.TIPO_INCONSISTENCIA = 'E'
              AND DI.ID_RADICADO = NRORADICADO
    UNION ALL
      SELECT DI.ID_EXCEPCION FROM DEPURACION.DS_INCONSISTENCIA DI
          INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
          INNER JOIN DEPURACION.DS_CONTRIBUYENTE DC ON DC.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO
            WHERE DI.ID_ESTADO_EXCEPCION IN (2) --AND DC.ESTADO_VALIDACION LIKE 'VE'
              --AND DTI.TIPO_INCONSISTENCIA = 'E'
              AND DI.ID_RADICADO = NRORADICADO
    UNION ALL
      SELECT DI.ID_EXCEPCION FROM DEPURACION.DS_INCONSISTENCIA DI
          INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DTI ON DTI.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
          INNER JOIN DEPURACION.DS_TRAMITE DT ON DT.NRO_IDENTIFICADOR = DI.ID_REGISTRO_FALLO
            WHERE DI.ID_ESTADO_EXCEPCION IN (2) --AND DT.ESTADO_VALIDACION LIKE 'VE'
              --AND DTI.TIPO_INCONSISTENCIA = 'E'
              AND DI.ID_RADICADO = NRORADICADO;
              
    CURSOR VEH IS
         SELECT NRO_PLACA, ESTADO_VALIDACION FROM DEPURACION.DS_VEHICULO WHERE ID_RADICADO = NRORADICADO;
    
    CURSOR PRO(PLACA VARCHAR2) IS
        SELECT ID_DOCUMENTO, ID_USUARIO, ESTADO_VALIDACION FROM DEPURACION.DS_PROPIETARIO 
                WHERE ID_RADICADO = NRORADICADO AND NRO_PLACA = PLACA;
        
    CURSOR CON(USUARIO VARCHAR2,DOCUMENTO NUMBER) IS
        SELECT ESTADO_VALIDACION FROM DEPURACION.DS_CONTRIBUYENTE 
                WHERE ID_RADICADO = NRORADICADO AND ID_DOCUMENTO = DOCUMENTO AND ID_USUARIO = USUARIO;
        
    CURSOR TRA(N_PLACA VARCHAR2) IS
        SELECT ESTADO_VALIDACION FROM DS_TRAMITE 
              WHERE ID_RADICADO = NRORADICADO AND NRO_PLACA = N_PLACA;

  
  SQLCOUNT    VARCHAR2(4000);
  SQLUPDATE   VARCHAR2(4000);
  VTIPO       VARCHAR2(2);
  VTOTALDIR   NUMBER := 0;
  VTOTAL      NUMBER := 0;
  REGCORRE    NUMBER := 0;    
  VERRORALER  NUMBER := 0;
  VERROREXCE  NUMBER := 0;
  VEXISTE     BOOLEAN := FALSE;
  CVEHICULO   NUMBER := 0;
  VVEHICULO   NUMBER := 0;
        
  BEGIN
      
      IF ( PROCESO = 1 ) THEN
            SELECT COUNT(1) INTO VTOTALDIR FROM DEPURACION.DS_DIRECCIONES WHERE ID_RADICADO = NRORADICADO;
            
            FOR ACT IN ACTESTADOINCONSISTENCIAS LOOP
                UPDATE DEPURACION.DS_INCONSISTENCIA SET ID_ESTADO_EXCEPCION = 3 WHERE ID_EXCEPCION = ACT.ID_EXCEPCION;
                COMMIT;
            END LOOP;
         
            FOR XR IN TREGISTROS LOOP
                    SQLUPDATE := 'SELECT DT.TIPO_INCONSISTENCIA, COUNT(DISTINCT DI.ID_REGISTRO_FALLO)
                                      FROM  DEPURACION.DS_INCONSISTENCIA DI
                                          INNER JOIN '||XR.ESQUEMA||'.'||XR.NOMBRE_TABLA||' DC ON DC.ID_RADICADO = DI.ID_RADICADO AND DI.ID_REGISTRO_FALLO = DC.NRO_IDENTIFICADOR
                                          INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DT ON DT.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
                                      WHERE DI.ID_TIPO_REGISTRO = '||XR.ID_TIPO_REGISTRO||' AND DT.TIPO_INCONSISTENCIA = ''E'' AND DI.ID_RADICADO = '||NRORADICADO||' AND DI.ID_ESTADO_EXCEPCION = 1 
                                      GROUP BY DT.TIPO_INCONSISTENCIA
                                  UNION ALL
                                  SELECT DT.TIPO_INCONSISTENCIA, COUNT(DISTINCT DI.ID_REGISTRO_FALLO)
                                      FROM DEPURACION.DS_INCONSISTENCIA DI
                                          INNER JOIN '||XR.ESQUEMA||'.'||XR.NOMBRE_TABLA||' DC ON DC.ID_RADICADO = DI.ID_RADICADO AND DI.ID_REGISTRO_FALLO = DC.NRO_IDENTIFICADOR
                                          INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DT ON DT.ID_INCONSISTENCIA = DI.ID_INCONSISTENCIA
                                      WHERE DI.ID_TIPO_REGISTRO = '||XR.ID_TIPO_REGISTRO||' AND DT.TIPO_INCONSISTENCIA = ''A'' AND DI.ID_ESTADO_EXCEPCION = 1 
                                        AND NOT EXISTS (SELECT 1 FROM DEPURACION.DS_INCONSISTENCIA DI1
                                                               INNER JOIN DEPURACION.DS_TIPO_INCONSISTENCIA DT1 ON DT1.ID_INCONSISTENCIA = DI1.ID_INCONSISTENCIA
                                                               WHERE DT1.TIPO_INCONSISTENCIA = ''E''
                                                                 AND DI1.ID_REGISTRO_FALLO = DI.ID_REGISTRO_FALLO 
                                                                 AND DI.ID_ESTADO_EXCEPCION = 1 )
                                        AND DI.ID_RADICADO = '||NRORADICADO||'
                                      GROUP BY DT.TIPO_INCONSISTENCIA';
                    OPEN REGCURSOR FOR SQLUPDATE;
                    LOOP
                        FETCH REGCURSOR INTO VTIPO, VTOTAL;
                        EXIT WHEN REGCURSOR %NOTFOUND;
                            IF (VTIPO = 'E') THEN
                                UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_EXCEPCIONES = VTOTAL WHERE ID_RADICADO = NRORADICADO AND ID_TIPO_ARCHIVO = XR.ID_TIPO_REGISTRO;
                                VERROREXCE := 1;
                            ELSE
                                UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_ALERTAS = VTOTAL WHERE ID_RADICADO = NRORADICADO AND ID_TIPO_ARCHIVO = XR.ID_TIPO_REGISTRO;
                                VERRORALER := 1;
                            END IF;
                    END LOOP;
                    CLOSE REGCURSOR;
                    IF ( VERROREXCE = 0 ) THEN
                        EXECUTE IMMEDIATE 'UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_EXCEPCIONES = 0 WHERE ID_TIPO_ARCHIVO = '||XR.ID_TIPO_REGISTRO||' AND ID_RADICADO = '||NRORADICADO;
                    END IF;
                    IF ( VERRORALER = 0 ) THEN
                        EXECUTE IMMEDIATE 'UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_ALERTAS = 0 WHERE ID_TIPO_ARCHIVO = '||XR.ID_TIPO_REGISTRO||' AND ID_RADICADO = '||NRORADICADO;
                    END IF;
            END LOOP;    
            
            COMMIT;   
            
            SQLUPDATE := NULL;
            
            FOR ACTREG IN TREGISTROS LOOP
                SQLUPDATE := 'UPDATE DEPURACION.DS_INFORME_REGISTROS DS '||CHR(13)
                          || '    SET DS.TOTAL_CORRECTAS = (SELECT  COUNT(1) - (TOTAL_ALERTAS) '||CHR(13)
                          || '                                      FROM '||ACTREG.ESQUEMA||'.'||ACTREG.NOMBRE_TABLA||' DV WHERE DV.ID_RADICADO = DS.ID_RADICADO  AND DV.ESTADO_VALIDACION IN (''VE'',''RA''))'||CHR(13)
                          || '        WHERE DS.ID_RADICADO = '||NRORADICADO||' AND DS.ID_TIPO_ARCHIVO = '||ACTREG.ID_TIPO_REGISTRO;
                EXECUTE IMMEDIATE SQLUPDATE;
                COMMIT;
                --SQLUPDATE := NULL;
                /*SQLUPDATE := 'UPDATE DEPURACION.DS_INFORME_REGISTROS DS '||CHR(13)
                          || '    SET DS.TOTAL_PENDIENTES = (SELECT  COUNT(1) - TOTAL_ALERTAS '||CHR(13)
                          || '                                      FROM '||ACTREG.ESQUEMA||'.'||ACTREG.NOMBRE_TABLA||' DV WHERE DV.ID_RADICADO = DS.ID_RADICADO  AND DV.ESTADO_VALIDACION = ''AE'')'||CHR(13)
                          || '        WHERE DS.ID_RADICADO = '||NRORADICADO||' AND DS.ID_TIPO_ARCHIVO = '||ACTREG.ID_TIPO_REGISTRO;
                EXECUTE IMMEDIATE SQLUPDATE;*/               
            END LOOP;

          --- CALCULAR EL TOTAL DE VEHICULOS CON INCONSISTENCIA EN UN LOTE
          FOR V IN VEH LOOP
                VEXISTE := FALSE;
                FOR P IN PRO(V.NRO_PLACA) LOOP
                   IF ( P.ESTADO_VALIDACION = 'VI' ) THEN
                      VEXISTE := TRUE;
                   END IF;
                   FOR C IN CON(P.ID_USUARIO,P.ID_DOCUMENTO) LOOP
                      IF ( C.ESTADO_VALIDACION = 'VI' ) THEN
                          VEXISTE := TRUE;
                      END IF;
                   END LOOP;
                END LOOP;
                FOR T IN TRA(V.NRO_PLACA) LOOP
                    IF ( T.ESTADO_VALIDACION = 'VI' ) THEN
                        VEXISTE := TRUE;
                    END IF;
                END LOOP;
                IF ( VEXISTE OR V.ESTADO_VALIDACION = 'VI' ) THEN
                    VVEHICULO := VVEHICULO + 1;
                ELSE
                    CVEHICULO := CVEHICULO + 1;
                END IF;
          END LOOP;
   
      
            UPDATE DEPURACION.DS_INFORME_LOTE SET TOTAL_ERRORES = VVEHICULO,
                                                  TOTAL_CORRECTAS = CVEHICULO,
                                                  TOTAL_PENDIENTES = (SELECT COUNT(1) FROM DEPURACION.DS_VEHICULO WHERE ESTADO_VALIDACION IN ('VP','AE') AND ID_RADICADO = NRORADICADO)
            WHERE ID_RADICADO = NRORADICADO;        
      
            
            DELETE FROM DEPURACION.DS_INFORME_INCONSISTENCIAS WHERE ID_RADICADO = NRORADICADO;
            
            INSERT INTO DEPURACION.DS_INFORME_INCONSISTENCIAS SELECT DS_INCONSISTENCIA.ID_RADICADO,
                                                                     DS_INCONSISTENCIA.ID_TIPO_REGISTRO,
                                                                     DS_INCONSISTENCIA.ID_INCONSISTENCIA,
                                                                     COUNT(DISTINCT DS_INCONSISTENCIA.ID_REGISTRO_FALLO) TOTAL
                                                                 FROM DEPURACION.DS_INCONSISTENCIA 
                                                                          WHERE ID_RADICADO = NRORADICADO
                                                                                AND ID_TIPO_REGISTRO <> 5
                                                                        GROUP BY DS_INCONSISTENCIA.ID_RADICADO,
                                                                               DS_INCONSISTENCIA.ID_TIPO_REGISTRO,
                                                                               DS_INCONSISTENCIA.ID_INCONSISTENCIA;
      
             
             UPDATE DEPURACION.DS_INFORME_REGISTROS SET TOTAL_CORRECTAS = TOTAL_CORRECTAS + VTOTALDIR
                 WHERE ID_RADICADO = NRORADICADO AND ID_TIPO_ARCHIVO = 2;
             
             COMMIT;
       ELSE
            NULL;
       END IF;
      
  END SP_INFORME_REGISTROS;

END PKG_DS_VALIDADOR;

/
--------------------------------------------------------
--  DDL for Package Body PKG_VALIDAR_DATOS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "DEPURACION"."PKG_VALIDAR_DATOS" IS

PROCEDURE SP_COMPARACION_LINEAS AS

VL_COR_MARCA_RUNT    TEMP_LINEAS_RUNT.COD_MARCA_RUNT%TYPE;
VL_COD_LINEA_RUNT    TEMP_LINEAS_RUNT.COD_LINEA_RUNT%TYPE;    
VS_NOMBRE_LINEA_RUNT TEMP_LINEAS_RUNT.NOMBRE_LINEA%TYPE;     
VS_COD_MARCA_SAP     TEMP_LINEAS_SAP.COD_MARCA%TYPE;
VS_COD_LINEA_SAP     TEMP_LINEAS_SAP.COD_LINEA%TYPE;
VS_NOMBRE_LINEA_SAP  TEMP_LINEAS_SAP.NOMBRE_LINEA%TYPE;
VS_LOG               TEMP_LOG.LOGS%TYPE; 
VL_CANTIDAD_LINEA    NUMBER;
VL_CANTIDAD_COMMIT   NUMBER;


 COD NUMBER;
 COD_LIEAN NUMBER;

CURSOR VC_LINEAS_SAP IS
      SELECT COD_MARCA,COD_LINEA,NOMBRE_LINEA
      FROM TEMP_LINEAS_SAP;

BEGIN
  VL_CANTIDAD_LINEA:=0;
  VL_CANTIDAD_COMMIT:=0;
  
  OPEN VC_LINEAS_SAP;
    LOOP
      FETCH VC_LINEAS_SAP INTO VS_COD_MARCA_SAP,VS_COD_LINEA_SAP,VS_NOMBRE_LINEA_SAP;
        EXIT WHEN VC_LINEAS_SAP%NOTFOUND;
        
        BEGIN
        SELECT COUNT(1)
        INTO VL_CANTIDAD_LINEA
        FROM TEMP_LINEAS_RUNT
        WHERE NOMBRE_LINEA =VS_NOMBRE_LINEA_SAP;
     
        EXCEPTION WHEN OTHERS THEN 
          DBMS_OUTPUT.PUT_LINE(SQLERRM);
          CONTINUE;
        END;   
          
          --SI NO ENCUENTRA VALOR INSERTA EL LOG DIRECTAMENTE
        IF VL_CANTIDAD_LINEA =0 THEN
          VS_LOG :='';
          VS_LOG :='NO SE ENCONTRO INFORMACI�N QUE COHINCIDERA CON LA LINEA '||VS_NOMBRE_LINEA_SAP || ' VERIFIQUE.';
            
          BEGIN
            INSERT INTO TEMP_LOG(COD_MARCA,COD_LINEA,NOMBRE_LINEA,LOGS)
                        VALUES(VS_COD_MARCA_SAP,VS_COD_LINEA_SAP,VS_NOMBRE_LINEA_SAP,VS_LOG);
            EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE(SQLERRM);
                ROLLBACK;
                CONTINUE;
            END;                
        ELSE
             --SI SOLO EXISTE UN REGISTRO INSERTO EN LA TABLA DE CORRECTOS
               BEGIN
                SELECT COD_MARCA_RUNT,COD_LINEA_RUNT,NOMBRE_LINEA
                INTO VL_COR_MARCA_RUNT,VL_COD_LINEA_RUNT,VS_NOMBRE_LINEA_RUNT
                FROM TEMP_LINEAS_RUNT
                WHERE NOMBRE_LINEA =VS_NOMBRE_LINEA_SAP;
                
              EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE(SQLERRM);
                ROLLBACK;
                CONTINUE;
              END;
                
              BEGIN 
                INSERT INTO TEMP_IGUALES(COD_MARCA_SAP,COD_LINEA_SAP,NOMBRE_LINEA_SAP,COD_MARCA_RUNT,COD_LINEA_RUNT,NOMBRE_LINEA)
                    VALUES(VS_COD_MARCA_SAP,
                           VS_COD_LINEA_SAP,
                           VS_NOMBRE_LINEA_SAP,
                           VL_COR_MARCA_RUNT,
                           VL_COD_LINEA_RUNT,
                           VS_NOMBRE_LINEA_RUNT);
                           
              EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE(SQLERRM);
                ROLLBACK;
                CONTINUE;
              END;
          END IF;

       --SE VALIDA PARA QUE CADA 100 REGISTROS REALICE COMMIT;
       IF VL_CANTIDAD_COMMIT =100 THEN
          VL_CANTIDAD_COMMIT :=0;
          COMMIT;
      END IF;
       

    END LOOP;
  CLOSE VC_LINEAS_SAP;
  COMMIT;


 EXCEPTION WHEN OTHERS THEN 
      DBMS_OUTPUT.PUT_LINE(SQLERRM);

END SP_COMPARACION_LINEAS;

FUNCTION F_INSERTAR_DOBLES(AVS_NOMBRE_LINEA VARCHAR2) 
            RETURN NUMBER AS
            
VL_COR_MARCA_RUNT    TEMP_LINEAS_RUNT.COD_MARCA_RUNT%TYPE;
VL_COD_LINEA_RUNT    TEMP_LINEAS_RUNT.COD_LINEA_RUNT%TYPE;    
VS_NOMBRE_LINEA_RUNT TEMP_LINEAS_RUNT.NOMBRE_LINEA%TYPE;  
VS_LOG               TEMP_LOG.LOGS%TYPE; 


CURSOR VC_REPETIDOS IS 
        SELECT COD_MARCA_RUNT,COD_LINEA_RUNT,NOMBRE_LINEA 
        FROM TEMP_LINEAS_RUNT
        WHERE NOMBRE_LINEA =AVS_NOMBRE_LINEA;

BEGIN

   OPEN VC_REPETIDOS;
    LOOP
      FETCH VC_REPETIDOS INTO VL_COR_MARCA_RUNT,VL_COD_LINEA_RUNT,VS_NOMBRE_LINEA_RUNT;
        EXIT WHEN VC_REPETIDOS%NOTFOUND;         
    
          VS_LOG :='';
          VS_LOG :='SE ENCONTRARON VARIAS LINEAS EN RUNT PARA ESTA DESCRIPCI�N SAP :'||AVS_NOMBRE_LINEA ||' DATOS DE LAS COLUMNAS TOMADOS DE LINEAS RUNT';
          BEGIN
            INSERT INTO TEMP_LOG(COD_MARCA,COD_LINEA,NOMBRE_LINEA,LOGS)
                        VALUES(TO_CHAR(VL_COR_MARCA_RUNT),
                                TO_CHAR(VL_COD_LINEA_RUNT),
                                VS_NOMBRE_LINEA_RUNT,
                                VS_LOG);

            EXCEPTION WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE(SQLERRM);
              ROLLBACK;
              CONTINUE;
          END;
    END LOOP;
  CLOSE VC_REPETIDOS;
  COMMIT;

RETURN 1 ;

END F_INSERTAR_DOBLES;


PROCEDURE QAS_CARACTERISTICAS2 AS

Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select NRO_PLACA From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

/*Delete Qas_Caracteristicas
Where Nro_placa = Ln_index.Nro_placa And RowId = Ln_Index.RowId;
        --Retorno el radicado maximo 
        Transito:=SP_ID_RADICADO_MAX(Ln_Index.Nro_Placa);*/


Insert Into correccion_datos.temp_placas_runt_sap (NRO_PLACA,	MODELO, 	ID_MARCA, 	DESCRIPCION_MARCA, 	ID_LINEA, 	DESCRIPCION_LINEA, 	ID_USO, 	
            DESCRIPCION_USO, 	ID_CLASE, 	DESCRIPCION_CLASE, 	ID_CARROCERIA, 	DESCRIPCION_CARROCERIA, 	GRUPO, 	ID_CILINDRAJE, 	
            CILINDRAJE, 	TIPO_CARGA, 	ID_CAPACIDAD, 	CAPACIDAD, 	ID_DEPARTAMENTO, 	DEPARTAMENTO, 	ID_MUNICIPIO, 	
            MUNICIPIO, 	BLINDAJE, 	CLASICO, 	NACIONAL_IMPORT, 	NOMBRE_ASEG, 	NINT_SOAT, 	FECHA_MATRICULA, 	NRO_POLIZA, 	
            FVT_SOAT, 	PORCENTAJE, 	MONEDA, 	AVALUO, 	VALOR_LIQUI, 	R_LIQUI_ACTIVA, 	TIPO_NOVEDAD,	
             VALOR_FACT, 	CREADO, 	FECHA_CREADO)	
select St.NRO_PLACA,st.MODELO, 	st.ID_MARCA, 	st.DESCRIPCION_MARCA, 	st.ID_LINEA, 	st.DESCRIPCION_LINEA, st.ID_USO, 	
            st.DESCRIPCION_USO, 	st.ID_CLASE, 	st.DESCRIPCION_CLASE, 	st.ID_CARROCERIA, st.DESCRIPCION_CARROCERIA,
            st.GRUPO, 	st.ID_CILINDRAJE,st.CILINDRAJE, 	st.TIPO_CARGA, 	st.ID_CAPACIDAD, 	st.CAPACIDAD, 	st.ID_DEPARTAMENTO,
            st.DEPARTAMENTO, 	st.ID_MUNICIPIO,st.MUNICIPIO, 	st.BLINDAJE, 	st.CLASICO, 	st.NACIONAL_IMPORT, 	st.NOMBRE_ASEG,
            st.NINT_SOAT, 	st.FECHA_MATRICULA, 	st.NRO_POLIZA,st.FVT_SOAT, 	st.PORCENTAJE, 	st.MONEDA, st.AVALUO, 	st.VALOR_LIQUI,
            st.R_LIQUI_ACTIVA, 	st.TIPO_NOVEDAD, st.VALOR_FACT, 	st.CREADO, 	st.FECHA_CREADO	
from bd_validacion_runt.vr_vehiculos_sap St
where St.NRO_PLACA =Ln_Index.Nro_Placa;

Delete From correccion_datos.temp_placas_runt_sap
Where Nro_Placa = Ln_Index.Nro_Placa And Modelo is null;


If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END QAS_CARACTERISTICAS2;
    
PROCEDURE ACTUALIZAR_CARACTERISTICAS2 AS
    
LV_LINEAR Varchar2(255) :='';
Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select NRO_PLACA From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

/*Delete Qas_Caracteristicas
Where Nro_placa = Ln_index.Nro_placa And RowId = Ln_Index.RowId;
        --Retorno el radicado maximo 
        Transito:=SP_ID_RADICADO_MAX(Ln_Index.Nro_Placa);*/
        
        SELECT VR.NOMBRE_LINEA INTO LV_LINEAR
        from BD_VALIDACION_RUNT.VR_TMP_VEHICULOS_RUNT VR
        INNER JOIN CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS ON VR.NRO_PLACA = Ln_Index.NRO_PLACA
        And Rownum = 1;

UPDATE CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS  SET VRS.LINEA_RUNT = LV_LINEAR
WHERE  VRS.NRO_PLACA = Ln_Index.NRO_PLACA;


commit;

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END ACTUALIZAR_CARACTERISTICAS2;
    
    
    PROCEDURE ACTUALIZAR_MARCA AS
    
LV_LINEAR Varchar2(255) :='';
Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select NRO_PLACA From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

/*Delete Qas_Caracteristicas
Where Nro_placa = Ln_index.Nro_placa And RowId = Ln_Index.RowId;
        --Retorno el radicado maximo 
        Transito:=SP_ID_RADICADO_MAX(Ln_Index.Nro_Placa);*/
        
        SELECT VR.NOMBRE_MARCA INTO LV_LINEAR
        from BD_VALIDACION_RUNT.VR_TMP_VEHICULOS_RUNT VR
        INNER JOIN CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS ON VR.NRO_PLACA = Ln_Index.NRO_PLACA
        And Rownum = 1;

UPDATE CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS  SET VRS.MARCA_RUNT = LV_LINEAR
WHERE  VRS.NRO_PLACA = Ln_Index.NRO_PLACA;


commit;

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END ACTUALIZAR_MARCA;
    
   PROCEDURE ACTUALIZAR_MARCA_SAP AS
    
LV_LINEAR Varchar2(255) :='';
Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select NRO_PLACA From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

/*Delete Qas_Caracteristicas
Where Nro_placa = Ln_index.Nro_placa And RowId = Ln_Index.RowId;
        --Retorno el radicado maximo 
        Transito:=SP_ID_RADICADO_MAX(Ln_Index.Nro_Placa);*/
        
        SELECT VR.NOMBRE_MARCA INTO LV_LINEAR
        from BD_VALIDACION_RUNT.VR_TMP_VEHICULOS_RUNT VR
        INNER JOIN CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS ON VR.NRO_PLACA = Ln_Index.NRO_PLACA
        And Rownum = 1;

UPDATE CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS  SET VRS.MARCA_RUNT = LV_LINEAR
WHERE  VRS.NRO_PLACA = Ln_Index.NRO_PLACA;


commit;

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END ACTUALIZAR_MARCA_SAP;
    
    
    
    PROCEDURE ACTUALIZAR_COD_MARCA_SAP AS
    
LV_LINEAR Varchar2(255) :='';
Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select MARCA_RUNT From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

     
        SELECT VR.ID_MARCA_SAP INTO LV_LINEAR
        from DEPURACION.SAP_MARCAS VR
        LEFT JOIN CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS ON VR.DESC_MARCA_SAP = Ln_Index.MARCA_RUNT
        Where  VR.DESC_MARCA_QX = Ln_Index.MARCA_RUNt And Rownum = 1;
        

UPDATE CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS  SET VRS.CODIGO_MARCA_SAP = LV_LINEAR
WHERE  VRS.MARCA_RUNT = Ln_Index.MARCA_RUNT;


commit;

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END ACTUALIZAR_COD_MARCA_SAP;
       

    PROCEDURE ACTUALIZAR_COD_LINEA_SAP AS
    
LV_LINEAR Varchar2(255) :='';
Ln_Contador Number := 0;
/*Transito Number:=0;*/

Cursor  consulta_placas Is
Select LINEA_RUNT From correccion_datos.temp_placas_runt_sap;

Begin

For Ln_Index In consulta_placas Loop

Begin

     
        SELECT VR.ID_MARCA_SAP INTO LV_LINEAR
        from DEPURACION.SAP_MARCAS VR
        LEFT JOIN CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS ON VR.DESC_MARCA_SAP = Ln_Index.LINEA_RUNT
        Where  VR.DESC_MARCA_QX = Ln_Index.LINEA_RUNT And Rownum = 1;
        

UPDATE CORRECCION_DATOS.TEMP_PLACAS_RUNT_SAP  VRS  SET VRS.CODIGO_MARCA_SAP = LV_LINEAR
WHERE  VRS.LINEA_RUNT = Ln_Index.LINEA_RUNT;


commit;

If Ln_Contador = 100 Then
  Commit;
  Ln_Contador := 0;
Else
  Ln_Contador := Ln_Contador + 1;
End If;

   
    End;
    End Loop;
    END ACTUALIZAR_COD_LINEA_SAP;
       
    
    
    

END;

/
--------------------------------------------------------
--  DDL for Function DIFFTIMES
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DEPURACION"."DIFFTIMES" (Finicial DATE , Ffinal DATE, Hinicial NUMBER, Hfinal NUMBER, Formato NUMBER ) RETURN NUMBER
IS
  Resultado NUMBER;
  MinDias   NUMBER := (Hfinal - Hinicial)*60;
  Minutos   NUMBER;
  Horas     NUMBER;
  fechadia  DATE;
  dayweek   NUMBER;
BEGIN
  
  Resultado := Ffinal - Finicial;
  
  If (Resultado = 0 ) then
      Horas := (to_number(to_char(Ffinal,'hh24')) - to_number(to_char(Finicial,'hh24')));
  else
      if (resultado = 1 ) then
           Horas := (to_number(to_char(Finicial,'hh24')) - Hinicial);
           Horas := Horas + (to_number(to_char(Ffinal,'hh24')) - Hinicial);
      else
        Horas := ( Hfinal - to_number(to_char(Finicial,'hh24')));
        For i in 1..Resultado loop
            fechadia := Finicial+i;
            If ( to_char(fechadia,'dd/mm/yyyy') = to_char(Ffinal,'dd/mm/yyyy')) then
                Horas := Horas + (to_number(to_char(Ffinal,'HH24')) - Hinicial);
            else
                select DECODE(RTRIM(LTRIM(to_char(fechadia, 'DAY', 'NLS_DATE_LANGUAGE=SPANISH'))),'LUNES', 1, 'MARTES', 2, 'MIERCOLES', 3, 'JUEVES', 4, 'VIERNES', 5, 'SABADO', 6, 7) into DAYWEEK from dual;
                if ( dayweek < 6 ) then
                  Horas := Horas + (Hfinal - Hinicial);
                end if;
            end if;
        end loop;
      end if;
  end if;
  if formato = 1 then
      RETURN Horas*3600;
  elsif formato = 2 then
      RETURN Horas*60;
  elsif formato = 3 then
      RETURN Horas;
  elsif formato = 4 then
      RETURN Horas/24;
  end if;
END DiffTimes;
 

/
--------------------------------------------------------
--  DDL for Function F_PLACA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "DEPURACION"."F_PLACA" (NRO_PLACA varchar2) return varchar2 as 

    V_PLACA VARCHAR(10);
    V_EXISTE number := 0;
    
 begin 
 
     V_PLACA := NRO_PLACA;  
     --LA PONGO EN MAYUSCULA
     V_PLACA := UPPER(V_PLACA);
     
     --REMPLAZO CARACTERES LETRAS POR "~" Y NUMEROS POR "@" PARA COMPARAR MAS FACILMENTE EL FORMATO
     V_PLACA := TRANSLATE(V_PLACA,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
     V_PLACA := TRANSLATE(V_PLACA,'0123456789','@@@@@@@@@@');
     V_PLACA := TRANSLATE(V_PLACA,'*','#');
      
     IF V_PLACA in ('~~~@@@', '#~~~@@@','~~@@@@', '#~~@@@@','~~~@@', '#~~~@@', '~~~@@~', '#~~~@@~','~~@@@', '#~~@@@') then
        return '002A';
     ELSIF V_PLACA in ('@@@@', '#@@@@') then
        return '002D';
     ELSIF V_PLACA in ('@@@~', '#@@@~', '@@@~~~', '#@@@~~~') then
        return '002N';   
     END IF;

 end;

/
