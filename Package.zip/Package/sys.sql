--------------------------------------------------------
-- Archivo creado  - mi�rcoles-enero-30-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type REPCAT$_OBJECT_NULL_VECTOR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "SYSTEM"."REPCAT$_OBJECT_NULL_VECTOR" AS OBJECT
(
  -- type owner, name, hashcode for the type represented by null_vector
  type_owner      VARCHAR2(30),
  type_name       VARCHAR2(30),
  type_hashcode   RAW(17),
  -- null_vector for a particular object instance
  -- ROBJ REVISIT: should only contain the null image, and not version#
  null_vector     RAW(2000)
)

/
--------------------------------------------------------
--  DDL for Type TP_ERROR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "SYSTEM"."TP_ERROR" is Object (
Id_Error VARCHAR2(255 BYTE), 
Nombre_Error VARCHAR2(255 BYTE), 
Constructor Function Tp_Error Return Self As Result
);
/
CREATE OR REPLACE TYPE BODY "SYSTEM"."TP_ERROR" Is 
Constructor Function Tp_Error Return Self As Result Is 
    tp_Error_1 Tp_Error := Tp_Error(null,null);
        Begin
            Self := tp_Error_1;
            Return;
            End Tp_Error;
        End;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_ERROR
--------------------------------------------------------

  CREATE OR REPLACE TYPE "SYSTEM"."TP_LISTA_ERROR" Is table of Tp_Error;

/
--------------------------------------------------------
--  DDL for Type TP_LISTA_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE TYPE "SYSTEM"."TP_LISTA_VEHICULOS" Is table of Tp_Vehiculos;

/
--------------------------------------------------------
--  DDL for Type TP_VEHICULOS
--------------------------------------------------------

  CREATE OR REPLACE TYPE "SYSTEM"."TP_VEHICULOS" AS OBJECT 
( 
NRO_PLACA VARCHAR2 (255 BYTE),
NOMBRE_MARCA VARCHAR2 (255 BYTE),
NOMBRE_LINEA VARCHAR2 (255 BYTE),
MODELO VARCHAR2 (255 BYTE),
NOMBRE_CLASE VARCHAR2 (255 BYTE),
NOMBRE_SERVICIO VARCHAR2 (255 BYTE),
NOMBRE_CARROCERIA VARCHAR2 (255 BYTE),
NRO_PUERTAS VARCHAR2 (255 BYTE),
POTENCIA VARCHAR2 (255 BYTE),
ID_SECRETARIA VARCHAR2 (255 BYTE),
NOMBRE_SECRETARIA VARCHAR2 (255 BYTE),
CILINDRAJE VARCHAR2 (255 BYTE),
CAP_PASAJEROS VARCHAR2 (255 BYTE),
CAP_TONELADAS VARCHAR2 (255 BYTE),
VALOR_FACTURA VARCHAR2 (255 BYTE),
BLINDADO VARCHAR2 (255 BYTE),
NOMBRE_ESTADO VARCHAR2 (255 BYTE),
CLASICO_ANTIGUO VARCHAR2 (255 BYTE),
FECHA_MATRICULO VARCHAR2 (255 BYTE),
CAJA VARCHAR2 (255 BYTE),
TRACCION VARCHAR2 (255 BYTE),
COMBUSTION VARCHAR2 (255 BYTE),
TRANSITO VARCHAR2 (255 BYTE),
Constructor Function TP_VEHICULOS Return Self As Result
)
/
CREATE OR REPLACE TYPE BODY "SYSTEM"."TP_VEHICULOS" Is 
Constructor Function TP_VEHICULOS Return Self As Result Is 
    TP_VEHICULOS_1 TP_VEHICULOS:=TP_VEHICULOS(null,null,null,null,null,null,null,
                                              null,null,null,null,null,null,null,null,
                                              null,null,null,null,null,null,null,null);
        Begin
            Self := TP_VEHICULOS_1;
            Return;
            End TP_VEHICULOS;
        End;

/
--------------------------------------------------------
--  DDL for Trigger DEF$_PROPAGATOR_TRIG
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "SYSTEM"."DEF$_PROPAGATOR_TRIG" 
  BEFORE INSERT ON system.def$_propagator
DECLARE
  prop_count  NUMBER;
BEGIN
  SELECT count(*) into prop_count
    FROM system.def$_propagator;

  IF (prop_count > 0) THEN
    -- Raise duplicate propagator error
    sys.dbms_sys_error.raise_system_error(-23394);
  END IF;
END;
/
ALTER TRIGGER "SYSTEM"."DEF$_PROPAGATOR_TRIG" ENABLE;
--------------------------------------------------------
--  DDL for Trigger REPCATLOGTRIG
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "SYSTEM"."REPCATLOGTRIG" 
AFTER UPDATE OR DELETE ON system.repcat$_repcatlog
BEGIN
  sys.dbms_alert.signal('repcatlog_alert', '');
END;
/
ALTER TRIGGER "SYSTEM"."REPCATLOGTRIG" ENABLE;
--------------------------------------------------------
--  DDL for Procedure EJECUTAR
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SYSTEM"."EJECUTAR" AS 

CURSOR lcur_lineas IS SELECT desc_linea FROM a_desc_carac;

lv_linea_temp VARCHAR2(255);
ln_contador NUMBER:=0;

BEGIN
    FOR ln_index IN lcur_lineas LOOP
        BEGIN
    
        lv_linea_temp:=FT_ESTANDARIZAR_LINEA(ln_index.desc_linea);
            ln_contador := ln_contador + 1;
            
            UPDATE a_desc_carac SET desc_linea_estandar = lv_linea_temp , LINEA_ESTANDAR_SIN_ESPACIOS = REPLACE(lv_linea_temp,' ','')
            WHERE desc_linea = ln_index.desc_linea;
                IF ln_contador = 500 THEN 
                    ln_contador:=0;
                    COMMIT;
                END IF;
            EXCEPTION
            WHEN OTHERS THEN 
            UPDATE a_desc_carac SET desc_linea_estandar = 'error'
            WHERE desc_linea = ln_index.desc_linea;
        END;
    END LOOP;
    
END EJECUTAR;

/
--------------------------------------------------------
--  DDL for Procedure EJEMPLO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SYSTEM"."EJEMPLO" (av_linea VARCHAR)  AS 

lv_linea_runt VARCHAR(255); 
lv_linea_temp VARCHAR(255);
lv_linea_runt_temp VARCHAR(255):='';
lv_validador_temp VARCHAR2(255);
ln_ultimo_caracter NUMBER:=0;
lv_ultimo_caracter VARCHAR2(2);

CURSOR lcur_caracteristicas IS SELECT caracteristica FROM correccion_datos.dq_caracteristicas;

Begin

    lv_linea_runt := TRANSLATE(av_linea,'-/','  '); 
    lv_linea_temp := TRANSLATE(av_linea,'-/','  '); 

    FOR ln_index IN lcur_caracteristicas LOOP
              FOR I IN 1..LENGTH(lv_linea_runt) LOOP  
                lv_validador_temp:='';
                  FOR M IN I..I+LENGTH(ln_index.caracteristica) LOOP
                     lv_validador_temp := lv_validador_temp || SUBSTR(lv_linea_runt,M,1);
                     ln_ultimo_caracter := I+LENGTH(ln_index.caracteristica)+1;
                     lv_ultimo_caracter := SUBSTR(lv_linea_runt,ln_ultimo_caracter,1);
                  END LOOP;
                   IF lv_ultimo_caracter IS NOT NULL AND lv_ultimo_caracter NOT IN ('') THEN
                        NULL;    
                   ELSIF lv_ultimo_caracter IN ('',' ') OR lv_ultimo_caracter IS NULL THEN
                        IF lv_validador_temp = ln_index.caracteristica||' ' THEN
                                 lv_linea_runt_temp:= REPLACE(lv_linea_runt,ln_index.caracteristica||' ','');
                                 lv_linea_runt := lv_linea_runt_temp;
                        ELSIF lv_validador_temp = ' '||ln_index.caracteristica THEN
                                 lv_linea_runt_temp := REPLACE(lv_linea_runt,' '||ln_index.caracteristica,'');
                                 lv_linea_runt := lv_linea_runt_temp;
                        END IF; 
                  END IF;
                END LOOP;     
     END LOOP;

DBMS_OUTPUT.put_line(Trim(lv_linea_temp));  
DBMS_OUTPUT.put_line(Trim(lv_linea_runt));


END EJEMPLO;

/
--------------------------------------------------------
--  DDL for Procedure ORA$_SYS_REP_AUTH
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SYSTEM"."ORA$_SYS_REP_AUTH" as
begin
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.repcat$_repschema TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.repcat$_repprop TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_aqcall TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_calldest TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_error TO SYS ' ||
                 'WITH GRANT OPTION';
  EXECUTE IMMEDIATE 'GRANT SELECT ON SYSTEM.def$_destination TO SYS ' ||
                 'WITH GRANT OPTION';
end;

/
--------------------------------------------------------
--  DDL for Procedure SP_EJECUTAR_VARIOS_PROCESOS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "SYSTEM"."SP_EJECUTAR_VARIOS_PROCESOS" AS 

BEGIN
    bd_validacion_runt.pkg_homologacion_oc.sp_iniciar(3);
    bd_fiscalizacion.pkg_buscar_novedad_sap_final.sp_iniciar_omisos(2018);

END SP_EJECUTAR_VARIOS_PROCESOS;

/
--------------------------------------------------------
--  DDL for Package CREAR_QX
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "SYSTEM"."CREAR_QX" AS 

PROCEDURE SP_INICIAR; 

END CREAR_QX;

/
--------------------------------------------------------
--  DDL for Package DBMS_REPCAT_AUTH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "SYSTEM"."DBMS_REPCAT_AUTH" wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
bf d6
0cfc6e4Sm6mfaMYwsbW2JygBepcwg/BKmJ4VZy/pO06UXsVUMejsissTcGWYR4qeK4TPqfDK
q7UPH+SmKP6nW9zmxMZnuK1VDzM0Iv9O4E4SvvsnHWn+EPF9hR+oBFe3fEro6RQ5R5Ejd1nr
e+fAK010dExf76gg/c6ZB3YxGPHDOqkGI4lV6HNsd57gKLwTd0bxan5UwJriIpt7Vjc=

/
--------------------------------------------------------
--  DDL for Package PKG_UTILITARIO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "SYSTEM"."PKG_UTILITARIO" AS 

/*ISVA
Nombre     :PKG_UTILITARIO
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :lv_Fecha 
Retorno    :lv_Fecha            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Encuentra la fecha maxima entre todas las fechas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

FUNCTION ft_Fecha_Maxima(av_Placa Varchar, as_Id_Tramite Number Default null) Return Varchar;
FUNCTION ft_Existe_Registro (av_Placa Varchar,as_Novedad Number Default Null)Return Boolean;
FUNCTION ft_homologar_radicado (av_placa Varchar, an_id_radicado Number) Return Number;
FUNCTION ft_Max_Rad_Vehiculos (av_placa varchar, ad_fecha Date default null) Return Number;
FUNCTION Ft_Existe_His_Traspaso (av_placa Varchar) Return Boolean;
FUNCTION Ft_Registrar_Transito(as_Id_radicado Simple_Integer) Return Varchar;
FUNCTION FT_VALIDAR_DIRECCION (av_direccion Varchar, an_codigo_runt Simple_Integer) Return Number;
FUNCTION ft_Existe_Registro_Vehiculo (av_Placa Varchar Default null, an_id_radicado Number default null)Return Boolean;
FUNCTION ft_fecha_max_tramite_runt (av_Placa VARCHAR) Return varchar;
END PKG_UTILITARIO;

/
--------------------------------------------------------
--  DDL for Package Body CREAR_QX
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "SYSTEM"."CREAR_QX" AS


FUNCTION ft_consecutivo_tabla (an_parametro NUMBER) RETURN NUMBER AS

ln_consecutivo NUMBER:=0;

BEGIN
    IF an_parametro = 1 THEN
        SELECT MAX(id_linea) INTO ln_consecutivo FROM quipux.tipo_linea;
    ELSE
        SELECT MAX(id) INTO ln_consecutivo FROM depuracion.sap_lineas;
    END IF;
    
        RETURN ln_consecutivo;
END ft_consecutivo_tabla;


PROCEDURE sp_qx_tipo_linea AS

CURSOR lcur_linea_qx IS SELECT descripcion_linea_qx, id_linea_qx FROM quipux.qx_tipo_linea;

ln_id NUMBER;

BEGIN
    FOR ln_index IN lcur_linea_qx LOOP
          ln_id :=0;
            ln_id := ft_consecutivo_tabla(1) + 1;
            INSERT INTO quipux.tipo_linea (id_linea, desc_linea, abrev_linea, min_marca, min_secuencia_linea, id_marca, id_linea_qx)
            VALUES (ln_id, ln_index.descripcion_linea_qx,'0','0',0,0,ln_index.id_linea_qx);
            
    END LOOP;
END sp_qx_tipo_linea;

PROCEDURE SP_INICIAR AS
BEGIN
    -- TAREA: Se necesita implantaci�n para PROCEDURE CREAR_QX.SP_INICIAR
    NULL;
END SP_INICIAR;

END CREAR_QX;

/
--------------------------------------------------------
--  DDL for Package Body DBMS_REPCAT_AUTH
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "SYSTEM"."DBMS_REPCAT_AUTH" wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
ba5 3a0
WEr0nOgRMSPBS3Z7Kvjx5JCUt2owg5WnTCCDfI5Av1UPOFy3ytP8lZ8t3hEfG60CTfSQMcvV
6ivyNKey557uUQmq5H5JbD4u2nCU8C8sxsa7x7zmdjj+nij7sk14NSnX4GLHDewbAlnflaQV
5Ip0a4vV4HdElsmpesU60A7ZRG8v4fOFSRFfWNoVil6uEiKYBLiqWripX8GpJaZ8UshyxIOj
3EV/homo0wcdcBB50gZ8bonh0GB5pN1QSW8ltNLN2ps5qHg4TFDnWgG7up3N8kaIB0jtO+rR
OP839Jnm3sPBXdL8EIaW3GOR7ycVj6toVCHpkKRN/WnLPYPi/XGYL71P09LHNjbMf+HU9z+W
ttKW9ohPDLdUXmufaLawN9vr5XOAgXkPX9PgtMFLHhe8jXO5u0o3rjZ87bqbdX97dwK3zxUy
OkWEQPSP30tF7ju3s8C+dWlmC1W3i3GtyWbzGK2Eurr+TuoTsQS0Dt/syQBYtpARlGmMcJ/Q
uZHG0WvcncL9qX/vNbNCWwB6eljzuQfMpuir8Y8vRTLYSlLNbup7L7i0RH8E69URqExlq/ko
CrPr/P+gWYZqqKbq0vWo8JEolfewBUbS3Tu7sQKjcYnE5Mb8PMR/fVNBoOXYkAMs3eudRCE1
YAM+sULch667d2YxFf7vvKfyn066LtD/6OlO0EWc6368k1axWwIxZjIKp8Wuno28ytJgAT8N
j5LHQVUcVKXxVfHM7P8oicVqILtVxXIrgOk8iVWdqwrPp0MDBvmkyJvfct+wRz2bw6Mum72v
bKVdOosnO6+VVrq8mcPRw1KcY0mRSRP16HIg6fdySN8Ce94HnJ2LA9Squbok3/mN0v1H0lLO
XPFJRbPFqmI2+F8/KVORKCsXMw4BHLV0Zh+Z9At//KrOmWxKssU=

/
--------------------------------------------------------
--  DDL for Package Body PKG_UTILITARIO
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "SYSTEM"."PKG_UTILITARIO" AS

FUNCTION ft_buscar_secretria (an_id_radicado Number) Return Number As

ln_id_secreatria Number:=0;

Begin
    
    Select Distinct id_secretaria Into ln_id_secreatria From bd_transitos.st_maestro
    where id_radicado = an_id_radicado;
    
    Return ln_id_secreatria;
    
End ft_buscar_secretria;

FUNCTION ft_homologar_radicado (av_placa Varchar, an_id_radicado Number) Return Number As

/*ISVA
Nombre     :ft_homologar_radicado
Autor      :Blados.Ospina
Fecha      :11/09/2018
Variables  :an_id_radicado 
Retorno    :ln_id_radicado            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Hogologa el transito
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
11/09/2018  Blados.Ospina   1.0                     */


Cursor lcur_radicados(an_id_secreataria Number) Is Select Distinct Id_radicado From bd_transitos.st_maestro 
                         Where id_secretaria = an_id_secreataria And Produccion = 'S'
                         Order by To_Number(Id_radicado) Desc;
ln_id_radicado Number:=0;
ln_exite Boolean:=False;
ln_secreataria Number:=0;

Begin
    ln_exite:=ft_Existe_Registro_Vehiculo(av_placa,an_id_radicado);
        If ln_exite = True Then
            ln_id_radicado:= an_id_radicado;
            Return ln_id_radicado;
        End If;
        ln_secreataria:=ft_buscar_secretria(an_id_radicado);
        
    For ln_index In lcur_radicados (ln_secreataria) Loop
        ln_exite:=ft_Existe_Registro_Vehiculo(av_placa,ln_index.id_radicado);
            If ln_exite = True Then
                ln_id_radicado:= ln_index.id_radicado;
                Return ln_id_radicado;
            End If;
    End Loop;
    
    Return ln_id_radicado;
            
Exception 
When Others Then 
Return ln_id_radicado;
    
End ft_homologar_radicado;

FUNCTION ft_Fecha_Maxima (av_Placa Varchar, as_Id_Tramite Number Default null) Return Varchar AS

/*ISVA
Nombre     :ft_Fecha_Maxima
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :lv_Fecha 
Retorno    :lv_Fecha            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Encuentra la fecha maxima entre todas las fechas
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

lv_Fecha Varchar(10):='';

BEGIN
          If as_Id_Tramite is not null Then
            Select 
                Max(Case Length(Fecha_tramite)
                    When 8 Then
                        To_Date(Fecha_tramite)
                    When 7 Then
                       To_Date('0'||Fecha_tramite)
                    End) Into lv_Fecha  From Bd_Transitos.St_Tramites 
                        Where Nro_Placa = av_Placa And Id_Tramite = as_Id_Tramite;
        Else    
             Select 
                 Max(Case Length(Fecha_tramite)
                    When 8 Then
                        To_Date(Fecha_tramite)
                    When 7 Then
                       To_Date('0'||Fecha_tramite)
                    End) Into lv_Fecha  From Bd_Transitos.St_Tramites 
                        Where Nro_Placa = av_Placa;
           End If;
           
       /*  If as_id_radicado is not null Then
            Select Max(Sm.Id_radicado) Into lv_Fecha  from Bd_Transitos.St_Vehiculos Sv
            Inner Join Bd_Transitos.St_Maestro Sm On Sm.Id_Radicado = Sv.Id_Radicado
            Where Sv.Nro_Placa = av_Placa;
         End If; */
            Return lv_Fecha;
Exception 
    When Others Then 
        Return '';
                
END ft_Fecha_Maxima;

FUNCTION ft_Max_Rad_Vehiculos (av_placa varchar, ad_fecha Date default null) Return Number As

/*ISVA
Nombre     :ft_Max_Rad_Vehiculos
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :ls_id_radicado 
Retorno    :ls_id_radicado            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Me devuel el radicado mayor 
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

ls_id_radicado Simple_Integer:=0;


Begin
     If ad_fecha is null Then
        Select Max(To_Number(Id_Radicado)) Into ls_id_radicado From Bd_Transitos.St_Vehiculos
            Where Nro_Placa = av_placa;
     Else
        Select Max(To_Number(Id_Radicado)) Into ls_id_radicado From Bd_Transitos.St_Tramites
            Where Nro_Placa = av_placa  And 
                To_Date(Decode(Length(Fecha_tramite),7,'0'||Fecha_tramite,Fecha_tramite)) = ad_fecha;                
    End If;
    
        Return ls_id_radicado;
/*Exception
When Others Then
    Return ls_id_radicado;*/
End ft_Max_Rad_Vehiculos;

FUNCTION ft_Existe_Registro (av_Placa Varchar,as_Novedad Number Default null)Return Boolean As

/*ISVA
Nombre     :ft_Existe_Registro
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :ls_Existe, lb_Existe
Retorno    :lb_Existe            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Verifica si existe un registro en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

ls_Existe Simple_Integer:=0;
lb_Existe boolean:=False;

Begin
    If as_Novedad is not null Then
        Select Count(1) Into ls_Existe  From Bd_Transitos.St_Tramites
            Where Nro_Placa = av_Placa And Id_Tramite = as_Novedad;
                If ls_Existe > 0 Then
                    lb_Existe:=True;
                End If;
    End If;
    
        If as_Novedad is null Then
        Select Count(1) Into ls_Existe  From Bd_Transitos.St_Tramites
            Where Nro_Placa = av_Placa;
                If ls_Existe > 0 Then
                    lb_Existe:=True;
                End If;
    End If;
    
                Return lb_Existe;
    Exception 
     When Others Then 
        Return lb_Existe;
End;

FUNCTION ft_Existe_Registro_Vehiculo (av_Placa Varchar, an_id_radicado Number Default null)Return Boolean As

/*ISVA
Nombre     :ft_Existe_Registro
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :ls_Existe, lb_Existe
Retorno    :lb_Existe            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Verifica si existe un registro en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

ls_Existe Simple_Integer:=0;
lb_Existe boolean:=False;

Begin
     If an_id_radicado is null Then
        Select Count(1) Into ls_Existe  From Bd_Transitos.St_Vehiculos
            Where Nro_Placa = av_Placa;
                If ls_Existe > 0 Then
                    lb_Existe:=True;
                End If;
     Else
        Select Count(1) Into ls_Existe  From Bd_Transitos.St_Vehiculos
            Where Nro_Placa = av_Placa And id_radicado = an_id_radicado;
                If ls_Existe > 0 Then
                    lb_Existe:=True;
                End If;
     End IF;
        Return lb_Existe;
        
    Exception 
     When Others Then 
        Return lb_Existe;
End ft_Existe_Registro_Vehiculo;

Function Ft_Existe_His_Traspaso (av_placa Varchar) Return Boolean As

/*ISVA
Nombre     :Ft_Existe_His_Traspaso
Autor      :Blados.Ospina
Fecha      :26/04/18
Variables  :ls_existe, lb_Existe
Retorno    :lb_Existe            
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Verifica si existe un registro en la base de datos
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor            Version  Modificacion   
226/04/2018  Blados.Ospina   1.0                     */

ls_existe Simple_Integer:=0;
lb_Existe Boolean:=False;

Begin
    Select Count(1) Into ls_existe From Bd_Transitos.St_Historiales_Traspaso
        Where Nro_PLaca = av_placa;
            If ls_existe > 0 Then 
                lb_Existe:=True;
            End If;
                return lb_Existe;
            Exception 
                When Others Then 
                    Return lb_Existe;
    
End Ft_Existe_His_Traspaso;

Function Ft_Registrar_Transito(as_Id_radicado Simple_Integer) Return Varchar As

/*ISVA
Nombre     :Ft_Registrar_Transito
Autor      :Blados.Ospina
Fecha      :07/05/18
Parametros :iv_Transito
Retorno    :          
Proyecto   :PKG_UTILITARIO
Versi�n    :1.0
Objetivo   :Recupera el nombre del transito
**************************************************************************
control de cambios realizados por desarrolladores
**************************************************************************
Fecha       Autor           Version  Modificacion   
07/05/2018  Blados.Ospina   1.0                     */
iv_Transito Varchar2(255 byte):='';
Begin


    Select Fm.Municipio Into iv_Transito From Bd_Transitos.St_Maestro Sm
    Inner Join Bd_Fiscalizacion.Fc_Municipio_Departamento Fm On Fm.Divipo = Sm.Id_Secretaria
    Where Id_Radicado = as_Id_radicado;
        Return iv_Transito;

Exception 
    When Others Then 
    Return '';    
    
End Ft_Registrar_Transito;

FUNCTION FT_VALIDAR_DIR(lfDireccion varchar2) return number as
lvDireccion Varchar2(100);
lvEstructuraTemp varchar2(100);
lvEstructura varchar2(100);
lvCaracter varchar2(1);
lvCaracterAnteriorAnterior varchar2(1);
lvCaracterAnterior varchar2(1) :='*';
lnLongitud Number:=0;
lnContador Number:=2;
lnCumple Number:=0;
lnBloqueNumero number := 0;
lnBloqueCaracter number := 0;

begin
 -- lvCaracterAnterior:='';
  --Remplazo Caracteres Letras Por "~" Y Numeros Por "@" Para Comparar Mas Facilmente El Formato
  lvDireccion := Trim(lfDireccion);
  lvDireccion := replace(lvDireccion,'-',' ');  
  lvDireccion := TRANSLATE(Upper(lvDireccion),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','~~~~~~~~~~~~~~~~~~~~~~~~~~');
  lvDireccion := TRANSLATE(lvDireccion,'0123456789','@@@@@@@@@@');  

lnLongitud:= length(lvDireccion);

lvEstructura := Substr(lvDireccion,1,1); -- Mapeo el primer caracter

While lnContador <= lnLongitud  
Loop
  lvCaracter := Substr(lvDireccion,lnContador,1);  
 -- lvCaracterSiguiente := Substr(lvDireccion, (lnContador - 2),1);
  
  --Permite validar las direcciones con estructura CL 10 1020 o CL 10B 1020
  If(lvEstructura In ('~ @ ','~ @ ~ ')) Then
      if(Substr(lvDireccion,lnContador,4) = '@@@@') then
        lvEstructura := lvEstructura || '@@@@';
        return 0;
      End if;  
  End If;
  
  If lvCaracter = '~' Then   
    If (lvCaracter != lvCaracterAnterior)then 
      If(lvCaracter != lvCaracterAnteriorAnterior) Then    
         lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
       End If;
    End If;
  Elsif lvCaracter = '@' Then   
    If lvCaracter != lvCaracterAnterior Then
       lvEstructura := lvEstructura || lvCaracter;
       lvCaracterAnteriorAnterior := lvCaracterAnterior;
       lvCaracterAnterior := lvCaracter;
    End If;
  Elsif lvCaracter = ' ' Then
    If lvCaracter != lvCaracterAnterior Then
        lvEstructura := lvEstructura || lvCaracter;
         lvCaracterAnteriorAnterior := lvCaracterAnterior;
         lvCaracterAnterior := lvCaracter;
    End If;
  End If; 
  
  lnContador := lnContador + 1;  
  
End Loop;  

-- Valido que la direcci�n tenga estructura v�lida
Select count(1) into lnCumple
from bd_fiscalizacion.fc_estructura_Direccion 
where lvEstructura like '%' || Estructura ||'%';

If(lnCumple > 0)then
  Return 1;
else
  Return 0;
end if;

END FT_VALIDAR_DIR;

FUNCTION FT_VALIDAR_DEPARTAMENTO (Codigo_Direccion Varchar2) return number
as
Cantidad number:=0;
begin
Select Count(1) into Cantidad From bd_fiscalizacion.Fc_Municipio_Departamento
where Divipo = Codigo_Direccion;

Return Cantidad;

Exception
When OThers Then
    Return 0;

END FT_VALIDAR_DEPARTAMENTO;

Function FT_VALIDAR_DIRECCION (av_direccion Varchar, an_codigo_runt Simple_Integer) Return Number
AS
type Array_Novedades is varray(5) of Varchar2(100 byte);
array Array_Novedades:=Array_Novedades('VRD','KM','FCA','CRG');

Validador boolean;
ln_Contador number:=0;
Posicion_Busqueda number:=0;
Validar_Transito number:=0;
Direccion_Estandarizada Varchar2(100 byte):='';
ln_existe Number:=0;


Begin
                              --Se estandariza la direccion 
Direccion_Estandarizada :=Trim(CORRECCION_DATOS.PKG_DS_ESTANDARIZA_RUNT.FT_ESTANDARIZAR_DIRECCION(av_direccion));
      Validador:=false;
       for i in 1..array.count loop
         --Varifica 
          Posicion_Busqueda := instr(Direccion_Estandarizada,array(i));
             if Posicion_Busqueda > 0 then 
               --Valido que el transito este Homologado
                Validar_Transito:= FT_VALIDAR_DEPARTAMENTO(an_codigo_runt);
                  if Validar_Transito > 0 then
                        ln_existe :=1;
                        Validador := true;
                  else 
                       ln_existe:=0;
                       Validador := true;
                  end if;
             end if;       
       end loop;
    if Validador = false then
          Posicion_Busqueda := Ft_Validar_Dir(Direccion_Estandarizada);          
          if Posicion_Busqueda > 0 then
                Validar_Transito:= FT_VALIDAR_DEPARTAMENTO(an_codigo_runt);
                if Validar_Transito > 0 then   
                    ln_existe :=1;
                else
                    ln_existe :=0;
                end if;
           else
              ln_existe :=0;         
          end if;
    end if;
    
    Return ln_existe;

END FT_VALIDAR_DIRECCION;

FUNCTION ft_fecha_max_tramite_runt (av_Placa VARCHAR) Return varchar As

ld_fecha_max varchar2(10 BYTE):='';

Begin
    SELECT MAX(DISTINCT fecha_tramite) INTO ld_fecha_max  FROM bd_transitos.arunt_tramites
    WHERE NRO_PLACA = av_Placa;
    
        RETURN ld_fecha_max;

EXCEPTION    
WHEN OTHERS THEN
    RETURN ld_fecha_max;
End ft_fecha_max_tramite_runt;

END PKG_UTILITARIO;

/
--------------------------------------------------------
--  DDL for Function FT_ESTANDARIZAR_LINEA
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "SYSTEM"."FT_ESTANDARIZAR_LINEA" (av_linea VARCHAR) RETURN VARCHAR2 AS 

lv_linea_runt VARCHAR(255); 
lv_linea_runt_temp VARCHAR(255):='';
lv_validador_temp VARCHAR2(255);
ln_ultimo_caracter NUMBER:=0;
lv_ultimo_caracter VARCHAR2(2);

CURSOR lcur_caracteristicas IS SELECT caracteristica FROM correccion_datos.dq_caracteristicas;

Begin
    lv_linea_runt := TRANSLATE(av_linea,'-/����������������������','  AEIOUAEIOUAEIOUAEIOUNN'); 

    FOR ln_index IN lcur_caracteristicas LOOP
              FOR I IN 1..LENGTH(lv_linea_runt) LOOP  
                lv_validador_temp:='';
                  FOR M IN I..I+LENGTH(ln_index.caracteristica) LOOP
                     lv_validador_temp := lv_validador_temp || SUBSTR(lv_linea_runt,M,1);
                     ln_ultimo_caracter := I+LENGTH(ln_index.caracteristica)+1;
                     lv_ultimo_caracter := SUBSTR(lv_linea_runt,ln_ultimo_caracter,1);
                  END LOOP;
                   IF lv_ultimo_caracter IS NOT NULL AND lv_ultimo_caracter NOT IN ('') THEN
                        NULL;    
                   ELSIF lv_ultimo_caracter IN ('',' ') OR lv_ultimo_caracter IS NULL THEN
                        IF lv_validador_temp = ln_index.caracteristica||' ' THEN
                                 lv_linea_runt_temp:= REPLACE(lv_linea_runt,ln_index.caracteristica||' ','');
                                 lv_linea_runt := lv_linea_runt_temp;
                        ELSIF lv_validador_temp = ' '||ln_index.caracteristica THEN
                                 lv_linea_runt_temp := REPLACE(lv_linea_runt,' '||ln_index.caracteristica,'');
                                 lv_linea_runt := lv_linea_runt_temp;
                        END IF; 
                  END IF;
                END LOOP;     
     END LOOP;

    RETURN lv_linea_runt;
    

END FT_ESTANDARIZAR_LINEA;

/
--------------------------------------------------------
--  DDL for Function WM$_CHECK_INSTALL
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "SYSTEM"."WM$_CHECK_INSTALL" return boolean is begin return false ; end;

/
